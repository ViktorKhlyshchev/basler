<?

if(!defined('loc')) if((isset($_SERVER['HTTP_HOST']) && $_SERVER['HTTP_HOST'] === 'aist.loc') || strpos($_SERVER['PHP_SELF'], 'aist.loc') !== false || file_exists(DR .'/.loc')){ define('loc', 1); } else define('loc', 0);