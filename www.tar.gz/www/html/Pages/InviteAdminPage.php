<?php

namespace Pages; # namespace Project\Aist\Admin\Page; # namespace Project\Aist\Admin\Route\Page\Invite;

use Core\Module\Url\Url;
use Routing\RouteRootRedirectAdmin;
use Admin\Layouts\RootRootDom;

class InviteAdminPage { # Project/Aist/Admin/Route/Page/Invite/RouteInviteAdminPage.php

    public static function init(){
        switch(count(Url::$list)){
            case 2:{
                switch(Url::$list[0]){
                    case 'registration_invite':{  #pred(Url::$list[1]);
                        if(empty(Url::$list[1])) return RouteRootRedirectAdmin::init(); # if empty hash
                        return RootRootDom::init();
                    }
                    default:{
                        return RouteRootRedirectAdmin::init();
                    }
                }
            }
            default: return RouteRootRedirectAdmin::init();
        }
    }
}