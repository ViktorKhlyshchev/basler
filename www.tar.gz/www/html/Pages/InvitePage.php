<?php

namespace Pages; # namespace Project\Aist\Admin\Page; # Project\Aist\Admin\Api\Route\GetRoutePageApi\Page\Invite;

use Core\Modules\User\UserLogoutAction;
use Core\Module\Error\ErrorCashContent;
use Core\Modules\Json;
use Core\Module\Response\ResponseSuccess;
use Core\Module\User\User;
use Core\Module\User\UserData;
use Core\Module\User\UserEmail;
use Core\Module\User\UserHash;
use Configs\UserHashTypeConfig;
use Core\Module\User\UserLogin;
use Routing\GetRoutePageApi;
use API\Modules\RootPageDefaultRedirectAdminRoutePageApi;
use Redirects\AuthPageRedirectAdminRoutePageApi;
use Configs\JsConfigAdmin;
use Project\Aist\Admin\Content\ContentAdmin;

class InvitePage { # Project/Aist/Admin/Api/Route/GetRoutePageApi/Page/Invite/InvitePageAdminRoutePageApi.php

    private static $user_id;
    private static $user_hash_type_id;
    private static $email;
    private static $login;
    private static $name;
    private static $surname;
    private static $hash;
    private static $face_len = 0;
    private static $face_image_indexed_len = 0;
    private static $face_list = [];
    private static $face_image_random_list = [];
    private static $city_list = [];

    private static function isset_user_hash(){
        $data = UserHash::get_user_hash_data_from_hash(self::$hash, self::$user_hash_type_id);
        if(empty($data)){
            ErrorCashContent::add_error('hash','Hash is not valid');
            return false;
        }
        self::$user_id = $data['user_id'];
        return true;
    }

    private static function set_user_hash_type_id(){
        self::$user_hash_type_id = UserHashTypeConfig::get_user_hash_type_id('registration_invite');
        if(empty(self::$user_hash_type_id)){
            ErrorCashContent::add_error('hash','Hash is not valid');
        }
    }

    private static function set_user_name(){
        $data = UserData::get_user_data(self::$user_id);
        if(empty($data)){ ErrorCashContent::add_error('user_data','User data is empty'); return false; }
        self::$name = $data['name'];
        self::$surname = $data['surname'];
    }

    private static function init_page(){
        $data = ['action' => 'invite',
            'user_id' => self::$user_id,
            'login' => self::$login,
            'email' => self::$email,
            'name' => self::$name,
            'surname' => self::$surname,
            'hash' => self::$hash,
            'data' => [
                'face_list' => self::$face_list,
                'face_image_random_list' => self::$face_image_random_list,
                'city_list' => self::$city_list,
                'face_len' => self::$face_len,
                'face_image_indexed_len' => self::$face_image_indexed_len
            ]];
        $action_data = ['title' => ContentAdmin::get_page_title('invite_page_title'),
            'script_list' => JsConfigAdmin::get_script_path('invite'),
            'init_list' => ['var data = '.Json::encode($data).'; page_object.action.invite.init(data); //trace(data); ']];
        return ResponseSuccess::init($action_data);
    }

    private static function set_hash(string $hash = null){
        if(empty($hash)) return AuthPageRedirectAdminRoutePageApi::init();
        self::$hash = $hash;
        return true;
    }

    public static function init(){
        if(User::is_login()) UserLogoutAction::init();
        self::set_hash(GetRoutePageApi::$list[1]);
        self::set_user_hash_type_id();
        if(self::isset_user_hash()){ #self::set_root_stats(); #self::set_face_image_random_list();
            self::set_user_name();
            self::$email = UserEmail::get_user_email_last(self::$user_id);
            self::$login = UserLogin::get_user_login(self::$user_id);
            return self::init_page();
        }
        return RootPageDefaultRedirectAdminRoutePageApi::init();
    }
}