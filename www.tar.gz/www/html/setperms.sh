#!/bin/bash

RD=/var/www/html

# sudo chmod -R 775 $RD
# find $RD -type d -print0 | xargs -0 chmod 775
sudo chmod 775 $RD/Xavier/restart_service.sh #sudo chmod 775 $RD/restart_service.sh
sudo chmod 775 $RD/tools/autoupdate
sudo chmod 775 $RD/tools/autoupdate/autoupdate
sudo chmod 775 $RD/tools/autoupdate/autoupdate.php
sudo chmod 775 $RD/tools/autoupdate/autoupdate_loc
sudo chmod 775 $RD/tools/misc/rmold.sh
sudo chmod 775 $RD/tools/servicesctl/service_ctl.php # sudo chmod 6775 tools/servicesctl/ssetuid sudo chmod 775 tools/servicesctl/ssetuid_loc
sudo chmod 775 $RD/tools/clear_content.sh
sudo chmod 775 $RD/tools/reboot.sh # sudo chmod 775 tools/reboot/areboot
#find /var/www/html/Temp -type d -exec chmod 755 {} \;
#find /var/www/html/Temp -type f -exec chmod 644 {} \;
#cd /var/www/html/tools/reboot && gcc areboot.c -o areboot && sudo chown root:root areboot && sudo chmod 6775 areboot && sudo chmod +s areboot
cd $RD/tools/servicesctl && sudo chown root:root ssetuid && sudo chmod 6775 ssetuid && sudo chmod +s ssetuid
cd $RD/tools/reboot && sudo chown root:root areboot && sudo chmod 6775 areboot && sudo chmod +s areboot

#cd $RD/tools/servicesctl && /usr/bin/gcc ssetuid.c -o ssetuid && sudo chown root:root ssetuid && sudo chmod 7775 ssetuid && sudo chmod +s ssetuid
cd $RD/tools/servicesctl && sudo chown root:root ssetuid && sudo chmod 7775 ssetuid
cd $RD/tools/autoupdate && sudo chown root:root autoupdate && sudo chmod 6775 autoupdate && sudo chmod +s autoupdate # 6775