<?php

$dr = $_SERVER['DOCUMENT_ROOT']; #pred($_SERVER);

include __DIR__ .'/Core/Module/Debug/debug.php';

$aistn = explode('.', $_SERVER['SERVER_ADDR']); #pred($aistn);

$f = 'aist'. $aistn[3] .'_backup_'. date('Y.m.d_H.i.s') .'.tgz';
$b = '.';
echo $dr.'<br/>';

#exec("tar -cvf $sdir/$name $root/* --exclude='$sdir/$salt' ", $out, $oky);
# aist1_backup_2021.09.15_07.25.38.tgz

$exclude = ['Resource', 'Temp', 'Core/Log/*', 'pga', $f, 'bz.php', '*.sql.gz']; #, 'Xavier'

$cond = __DIR__ .'/*.tgz';
foreach(glob($cond) as $filename){
    $filename = str_replace(__DIR__.'/', '', $filename);
    $exclude[] = $filename;
} #pred($exclude);

if(!empty($exclude)) $exclude = "--exclude='". implode("' --exclude='", $exclude) ."'";
$com = "cd '$dr' && tar $exclude -cvzf '$f' $b";
pre($com); #die;
exec($com, $out, $oky);

if($oky){
    print_r("Backup Completed!");
    pre($out);
    pre($oky);
} else {
    print_r("Backup Not Completed!");
    pre($out);
    pre($oky);
}