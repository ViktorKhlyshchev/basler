<?php

namespace Routing; # namespace Project; use Core\Module\Response\Response;

use Admin\Controllers\ConnectController;
use Admin\Controllers\TestController;
use Admin\Controllers\ToolsController;
use Admin\Controllers\TrackController;
use Admin\Controllers\DuploController;
use Admin\Controllers\MigrationController;
use Admin\Controllers\SettingsController;
use Admin\Controllers\SSettingsController;
use Admin\Controllers\DashboardController;

use Admin\Controllers\AboutController;
use Admin\Controllers\RTSController;
use Admin\Controllers\BasesController;
use Admin\Controllers\WorkModeController;
use Admin\Controllers\UsersController;
use Admin\Controllers\DebugController;
use Admin\Controllers\JournalController;
use CLI\Controllers\AistFront;
use Admin\Controllers\TCPController;
use Admin\Controllers\CalibrationController;
use Admin\Controllers\ZonesController;
use Admin\Controllers\AutoupdateController;
use Admin\Controllers\StatController;
use Admin\Controllers\ImageController; # use Core\Module\Session\Session;
use Admin\Controllers\ApikeyController;
use CLI\Controllers\BalancerThread;

class RouteAdmin {

    public static function init(){

        global $req; # pred($req);        #pred(Session::$session_id);   #pred(RP); pred(debug_backtrace());  #if($_POST) pred(ajax);  #if($_POST) pred(RP);  #if(strpos(RP, '/radmin/root/history') === 0){

        if(strpos(RP, '/admin/tcp') === 0) new TCPController(); #{ # if(preg_match('#/nominations/\d+/\d+#', RP)){ }  pred(RP);
        if(strpos(RP, '/admin/settings') === 0) new SettingsController(); #{ # if(preg_match('#/nominations/\d+/\d+#', RP)){ }  pred(RP);
        if(strpos(RP, '/admin/ssettings') === 0) new SSettingsController(); #{ # if(preg_match('#/nominations/\d+/\d+#', RP)){ }  pred(RP);
        # pred(strpos(RP, '/admin/connect') === 0 || strpos(RP, '/admin/root/connect') === 0);
        if(strpos(RP, '/admin/rtsws') === 0) new RTSController('ws'); #{ # if(preg_match('#/nominations/\d+/\d+#', RP)){ }
        if(strpos(RP, '/admin/rts') === 0) new RTSController(); #{ # if(preg_match('#/nominations/\d+/\d+#', RP)){ }
        if(strpos(RP, '/admin/journal') === 0) new JournalController(); #{ # if(preg_match('#/nominations/\d+/\d+#', RP)){ }
        if(strpos(RP, '/admin/connect') === 0 || strpos(RP, '/admin/root/connect') === 0) new ConnectController(); #{ # if(preg_match('#/nominations/\d+/\d+#', RP)){ }
        if(strpos(RP, '/admin/dashboard') === 0) new DashboardController(); #{ # if(preg_match('#/nominations/\d+/\d+#', RP)){ }
        if(strpos(RP, '/admin/root/dashboard') === 0) new DashboardController(); #{ # if(preg_match('#/nominations/\d+/\d+#', RP)){ }
        if(strpos(RP, '/admin/about') === 0) new AboutController();
        if(strpos(RP, '/admin/test') === 0 && RP === '/admin/test') new TestController();
        if(strpos(RP, '/admin/tools/backup') === 0) new ToolsController();
        if(strpos(RP, '/admin/migration') === 0) new MigrationController();
        if(strpos(RP, '/admin/track/packi') === 0) new TrackController('pack_images');
        if(strpos(RP, '/admin/track/fn') === 0) new TrackController('fnull');
        if(strpos(RP, '/admin/track/n') === 0) new TrackController('null');
        if(strpos(RP, '/admin/track/show') === 0) new TrackController('show');
        if(strpos(RP, '/admin/track/s') === 0) new TrackController('show_images');
        if(strpos(RP, '/admin/track/packt') === 0) new TrackController('pack_track');
        if(strpos(RP, '/admin/track/p') === 0) new TrackController('parse_track');
        if(strpos(RP, '/admin/track') === 0) new TrackController();
        if(strpos(RP, '/admin/debug') === 0) new DebugController();
        if(strpos(RP, '/admin/bases') === 0) new BasesController();
        if(strpos(RP, '/admin/work_mode') === 0) new WorkModeController();
        if(strpos(RP, '/admin/users') === 0) new UsersController();
        if(strpos(RP, '/admin/calibration') === 0) new CalibrationController();
        if(strpos(RP, '/admin/zones') === 0) new ZonesController();
        if(strpos(RP, '/admin/autoupdate') === 0) new AutoupdateController('page');
        if(strpos(RP, '/admin/autoupdatef') === 0) new AutoupdateController('page');
        if(strpos(RP, '/admin/cli/balancer') === 0) new BalancerThread(); # $_GET['si']
        if(strpos(RP, '/admin/image') === 0) new ImageController();
        if(strpos(RP, '/admin/stat') === 0) new StatController();
        if(strpos(RP, '/admin/apikey') === 0) new ApikeyController();
        if(strpos(RP, '/admin/tcp') === 0) new ApikeyController();

        if(strpos(RP, '/admin/cli/af') === 0) return AistFront::init();

        if(strpos(RP, '/admin/duplo/emul') === 0) new DuploController('emul');
        if(strpos(RP, '/admin/duplo') === 0) new DuploController(); #pred(strpos(RP, '/admin/fj'));
        if(strpos(RP, '/admin/fj') === 0){ require DR .'/Admin/tools/jscode_format.php'; die; }
        if(strpos(RP, '/admin/f') === 0){ require DR .'/Admin/tools/code_format.php'; die; }
        if(strpos(RP, '/admin/logout') === 0) new UsersController();
        if(strpos(RP, '/admin/sh') === 0 && ERP === 'sh'){ # /admin/sh?action=create_box_thread&thread_id=0&is_test=1&need_log=1
            $action = $_REQUEST['action']; #pred($action);   #if($action === 'create_box_thread') CreateBoxThread::init(1);
            #if($action === 'send_box_thread') SendBoxMultiThreadAction::init(0, 1, null);
        }
    }
}