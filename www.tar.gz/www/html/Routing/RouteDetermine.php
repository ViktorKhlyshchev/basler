<?php

namespace Routing; # namespace Core\Module\Route;

use Core\Module\App\App;
use Core\Module\App\AppVersion;
use Core\Modules\Bearer;
use Core\Module\Browser\Browser;
use Core\Module\Browser\BrowserDetermine;
use Core\Module\Browser\BrowserVersion;
use Core\Module\Cookie\Cookie;
use Core\Module\Device\DeviceDetermine;
use Core\Module\Device\DeviceFirm;
use Core\Module\Device\DeviceModel;
use Core\Module\Device\DeviceToken;
use Core\Module\Geo\City;
use Core\Module\Geo\Continent;
use Core\Module\Geo\Country;
use Core\Module\Geo\Geo;
use Core\Module\Geo\GeoDetermine;
use Core\Module\Geo\GeoIp;
use Core\Module\Geo\Region;
use Common\Models\History;
use Common\Modules\Ip;
use Common\Modules\IpDetermine; # use Core\Module\Ip\IpDetermine;
use Core\Module\Lang\Lang;
use Core\Module\Lang\LangDetermine;
use Core\Module\Lang\LangKeyboard;
use Core\Module\Os\Os;
use Core\Module\Os\OsDetermine;
use Core\Module\Os\OsVersion;
use Core\Module\OsServer\OsServerDetermine;
use Core\Module\Path\PathDetermine;
use Core\Module\Response\Response;
use Core\Module\Session\Session;
use Core\Module\Timezone\Timezone;
use Core\Module\Token\Token;
use Configs\TokenConfig;
use Core\Module\Url\Url;
use Core\Module\Url\UrlDetermine;
use Core\Module\User\User;
use Core\Module\User\UserAccess;
use Core\Module\User\UserDevice;
use Core\Module\Useragent\Useragent;
use Core\Module\Useragent\UseragentDetermine;
use Core\Module\Worktime\Worktime;
use Common\Modules\Lang\LangDetermineProject;

class RouteDetermine { # Core/Module/Route/RouteDetermine.php

    private static $token_id;
    public static $token_hash;
    public static $token_hash_first;
    public static $token_data;
    public static $need_determine = true;

    public static function reset_data(){
        self::$token_id = null;
        self::$token_hash = null;
        self::$token_hash_first = null;
        self::$token_data = null;
        return true;
    }

    private static function isset_token_hash_in_cookie(){
        if(Cookie::isset_token()) self::$token_hash = Cookie::get_token();
        if(isset($_POST['token'])) self::$token_hash = $_POST['token'];
        $bearer_token = Bearer::get_bearer_token(); # pred($bearer_token);
        if(!empty($bearer_token)) self::$token_hash = $bearer_token;
        if(empty(self::$token_hash)) return false;
        return true;
    }

    private static function get_determine_data(){
        $list = array('token_id' => Token::$token_id,
            'session_id' => Session::$session_id,
            'browser_id' => Browser::$browser_id,
            'browser_name' => Browser::$browser_name,
            'browser_version_id' => BrowserVersion::$browser_version_id,
            'browser_version' => BrowserVersion::$browser_version,
            'os_id' => Os::$os_id,
            'os_name' => Os::$os_name,
            'os_version_id' => OsVersion::$os_version_id,
            'os_version' => OsVersion::$os_version,
            'device_firm_id' => DeviceFirm::$device_firm_id,
            'device_firm_name' => DeviceFirm::$device_firm_name,
            'device_model_id' => DeviceModel::$device_model_id,
            'device_model_name' => DeviceModel::$device_model_name,
            'geo_id' => Geo::$geo_id,
            'country_geo_id' => Geo::$country_geo_id,
            'geo_ip_id' => GeoIp::$geo_ip_id,
            'geo_ip_network' => GeoIp::$geo_ip_network,
            'geo_postal_code' => GeoIp::$postal_code,
            'geo_ip_latitude' => GeoIp::$latitude,
            'geo_ip_longitude' => GeoIp::$longitude,
            'geo_ip_radius' => GeoIp::$radius,
            'continent_id' => Continent::$continent_id,
            'country_id' => Country::$country_id,
            'region_id' => Region::$region_id,
            'city_id' => City::$city_id
        );
        return $list;
    }

    public static function if_array_token_data(){

        $isset_user = false;
        if(!self::$need_determine){
            if(!empty(self::$token_data['user_id'])) $isset_user = true;
            if($isset_user){
                Token::set_token_id_default(self::$token_data['token_id']);
                Token::set_token_hash_default(self::$token_hash);
                TokenConfig::set_token_is_keep_default((bool)self::$token_data['is_keep']);
                User::set_user_id_default(self::$token_data['user_id']);
                UserAccess::get_user_access_list_default();
                Timezone::set_timezone_id_default(self::$token_data['timezone_id']);
                Useragent::set_useragent_id_default(self::$token_data['useragent_id']);
                Ip::set_ip_id_default(self::$token_data['ip_id']);

                Session::set_session_id_default(Session::get_session_id(User::$user_id, Token::$token_id));
                if(empty(Session::$session_id)) Session::add_session_default(); else Session::update_session_date_live_default();
                return true;
            }
        } #pred(321);
        if(!empty(self::$token_data['user_id'])) if(User::isset_user_id(self::$token_data['user_id'])) $isset_user = true;
        if($isset_user){
            $is_token_update = false;
            Token::set_token_id_default(self::$token_data['token_id']);
            Token::set_token_hash_default(self::$token_hash);
            TokenConfig::set_token_is_keep_default((bool)self::$token_data['is_keep']);
            User::set_user_id_default(self::$token_data['user_id']); # pred(self::$token_data);
            if(isset(self::$token_data['user_device_token_id'])) UserDevice::set_user_device_id_default(self::$token_data['user_device_token_id']); else UserDevice::set_user_device_id_default();
            if(!empty(User::$user_id)){
                User::update_user_date_online_default();
                UserAccess::get_user_access_list_default();
            }
            if(!empty(self::$token_data['useragent_id'])){
                $useragent = Useragent::get_useragent_from_useragent_id(self::$token_data['useragent_id']);
                $useragent_default = Useragent::get_useragent_default();
                if($useragent == $useragent_default)
                    Useragent::set_useragent_id_default(self::$token_data['useragent_id']);
                else
                    $is_token_update = true;
            } else {
                UseragentDetermine::init();
                $is_token_update = true;
            }
            if(!empty(self::$token_data['ip_id'])){
                $ip_id = self::$token_data['ip_id'];
                $ip_address = Ip::get_ip_address($ip_id);
                if($ip_address == Ip::$ip_address){
                    Ip::set_ip_id_default(self::$token_data['ip_id']);
                    if(isset(self::$token_data['continent_id'])) Continent::set_continent_id_default(self::$token_data['continent_id']); else Continent::set_continent_id_default();
                    if(isset(self::$token_data['country_id'])) Country::set_country_id_default(self::$token_data['country_id']); else Country::set_country_id_default();
                    if(isset(self::$token_data['region_id'])) Region::set_region_id_default(self::$token_data['region_id']); else Region::set_region_id_default();
                    if(isset(self::$token_data['city_id'])) City::set_city_id_default(self::$token_data['city_id']); else  City::set_city_id_default();
                    Timezone::set_timezone_id_default(self::$token_data['timezone_id']);
                } else {
                    if(\Config::$is_geo_determine) GeoDetermine::init();
                    $is_token_update = true;
                }
            } else {
                IpDetermine::init();
                if(\Config::$is_geo_determine) GeoDetermine::init();
                $is_token_update = true;
            }
            if(Lang::$lang_id!= self::$token_data['lang_id']) $is_token_update = true;
            if(LangKeyboard::$lang_keyboard_id!= self::$token_data['lang_keyboard_id']) $is_token_update = true;
            if(Browser::$browser_id!= self::$token_data['browser_id']) $is_token_update = true;
            if(isset(self::$token_data['browser_version_id'])){
                if(BrowserVersion::$browser_version_id != self::$token_data['browser_version_id']) $is_token_update = true;
            }
            if(Os::$os_id!= self::$token_data['os_id']) $is_token_update = true;
            if(OsVersion::$os_version_id!= self::$token_data['os_version_id']) $is_token_update = true;
            if(isset(self::$token_data['device_firm_id'])){
                if(DeviceFirm::$device_firm_id != self::$token_data['device_firm_id']) $is_token_update = true;
            }
            if(isset(self::$token_data['device_model_id'])){
                if(DeviceModel::$device_model_id != self::$token_data['device_model_id']) $is_token_update = true;
            }
            if(DeviceToken::$device_token_id != self::$token_data['device_token_id']) $is_token_update = true;
            if(App::$app_id != self::$token_data['app_id']) $is_token_update = true;
            if(isset(self::$token_data['app_version_id'])){
                if(AppVersion::$app_version_id != self::$token_data['app_version_id']) $is_token_update = true;
            }
            if(Lang::$lang_id != self::$token_data['lang_id']) $is_token_update = true;
            Session::set_session_id_default(Session::get_session_id(User::$user_id, Token::$token_id));
            Worktime::set_timestamp_point('Start session');
            Worktime::set_timestamp_point('Finish session');
            Worktime::set_timestamp_point('Start reset token');
            if($is_token_update){
                Token::reset_token_default();
                if(!empty(Session::$session_id)) Session::remove_session_id_default();
            } else Token::update_token_date_live_default();  #pred(Session::$session_id);
            if(empty(Session::$session_id)) Session::add_session_default(); else Session::update_session_date_live_default();
            Worktime::set_timestamp_point('Finish reset token');
            Cookie::update_token();
            Worktime::set_timestamp_point('Updated token'); # if(\Config::$is_geo_debug) print_r(self::get_determine_data());
            Worktime::set_timestamp_point('Start update token in history');
            History::update_token();
            Worktime::set_timestamp_point('Finish update token in history');
            return true;
        }
    }

    public static function init(){ # Worktime::set_timestamp_point('Token Start'); self::set(); # Worktime::set_timestamp_point('Token Finish'); # pre(Worktime::get_delta()); pred(Worktime::get_full_info());

        if(Response::$type === 'shell') return false;
        self::$token_hash_first = $_COOKIE;
        PathDetermine::init();
        History::init();
        UrlDetermine::init();
        if(count(Url::$list) > 0) if(Url::$list[0] == 'show') self::$need_determine = false; # $need_determine = false; # FOR DUPLO CHECK!! $need_determine = true; # set false FOR DUPLO CHECK!!
        #self::$need_determine = false;
        if(self::$need_determine){
            IpDetermine::init();
            UseragentDetermine::init();
            LangDetermine::init();
            BrowserDetermine::init();
            OsServerDetermine::init();
            OsDetermine::init();
            DeviceDetermine::init();
            LangDetermineProject::init(); # pred(21);
        } #pred($need_determine);
/*
        if($need_determine){ # FOR DUPLO
            IpDetermine::init();
            #UseragentDetermine::init();
            LangDetermine::init();
            #BrowserDetermine::init();
            #OsServerDetermine::init();
            #OsDetermine::init();
            #DeviceDetermine::init();
            #LangDetermineProject::init();
        }*/

        if(self::isset_token_hash_in_cookie()){
            self::$token_hash = Cookie::get_token(); #pred(self::$token_hash);
            self::$token_data = Token::get_token_data_from_hash(self::$token_hash); #pred(self::$token_data);
            if(!empty($_REQUEST['is_token_data'])){
                pre(self::$token_data);
                pre(self::$token_hash_first);
            }

            if(is_array(self::$token_data) && count(self::$token_data)) self::if_array_token_data();
        } # if(\Config::$is_geo_determine) GeoDetermine::init();

        if(empty(self::$token_hash)){
            Token::add_token_default();
        } else {
            self::$token_id = Token::get_token_id_from_token_hash(self::$token_hash);
            if(empty(self::$token_id)){
                Token::add_token_default();
            } else {
                Token::set_token_id_default(self::$token_id);
                Token::set_token_hash_default(self::$token_hash);
                Token::update_token_date_live_default();
            }
        }

        Session::add_session_default();
        Cookie::create_token(); # if(\Config::$is_geo_debug) print_r(self::get_determine_data());
        History::update_token();
        return true;
    }
}