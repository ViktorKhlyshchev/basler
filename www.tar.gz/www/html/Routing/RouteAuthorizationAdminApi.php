<?php

namespace Routing;

use Core\Module\Url\Url;
use Project\Aist\Admin\Api\Ftp\CheckFtpConnectionApi;
use Project\Aist\Admin\Api\Ftp\RemoveFtpConnectionApi;
use Project\Aist\Admin\Api\Ftp\SaveFtpConnectionApi;
use Project\Aist\Admin\Api\Key\AddKeyApi;
use Project\Aist\Admin\Api\Key\RemoveKeyApi;
use Project\Aist\Admin\Api\Key\SaveKeyApi;
use Project\Aist\Admin\Api\Apikey\AddApikeyApi;
use Project\Aist\Admin\Api\Apikey\RemoveApikeyApi;
use Project\Aist\Admin\Api\Apikey\SaveApikeyApi;
use API\Modules\UserLogoutApi; # use Project\Aist\Admin\Api\Offence\UpdateCarNumberApi; # use Project\Aist\Admin\Api\Profile\SendEmailToProfileApi;
use API\Modules\GetUpdateRadarListApi;
use Project\Aist\Admin\Api\Sms\AddSmsApi; #use Project\Aist\Admin\Api\Sms\GetSmsApi;
use Project\Aist\Admin\Api\Sms\GetSmsListApi;
use Project\Aist\Admin\Api\Sms\GetUpdateSmsListApi;
use API\Modules\TestSocketApi;
use API\Controllers\AddAdminApi; #Project\Aist\Admin\Api\User\AddAdminApi;r
use API\Controllers\LastTrack;
use Project\Aist\Admin\Api\User\Admin\BlockUserAdminApi;
use Project\Aist\Admin\Api\User\Admin\EditUserAdminApi;
use Project\Aist\Admin\Api\User\Admin\RemoveUserAdminApi;
use Project\Aist\Admin\Api\User\Admin\SaveUserAvatarApi;
use Project\Aist\Admin\Api\User\Admin\SetToAdminUserAdminApi;
use Project\Aist\Admin\Api\User\BlockAdminApi;
use Project\Aist\Admin\Api\User\Data\SaveUserEmailApi;
use Project\Aist\Admin\Api\User\Data\SaveUserLoginApi;
use Project\Aist\Admin\Api\User\Data\SaveUserNameApi;
use Project\Aist\Admin\Api\User\Data\SaveUserPasswordApi;
use Project\Aist\Admin\Api\User\Profile\GetProfileListApi;
use Project\Aist\Admin\Api\User\Profile\RemoveProfileApi;
use Project\Aist\Admin\Api\User\RemoveAdminApi;
use Project\Aist\Admin\Api\User\RemoveProfileAccountApi;
use Project\Aist\Admin\Api\User\UpdateAdminAccessApi;
use Project\Aist\Admin\Api\User\UpdateAdminApi;
use Project\Aist\Admin\Api\User\UpdateProfileApi;
use Project\Aist\Admin\Api\Video\GetVideoCacheTimestampSizeApi;
use Project\Aist\Admin\Api\Video\GetVideoFromCachetApi;
use Project\Aist\Admin\Api\Xavier\GetCalculateAngleApi;
use Project\Aist\Admin\Api\Xavier\GetCameraConfigDataApi;
use Project\Aist\Admin\Api\Xavier\GetCameraScreenLinkApi;
use Project\Aist\Admin\Api\Xavier\SaveAngleApi;
use API\Controllers\SaveTcpApi;
use Project\Aist\Admin\Api\Xavier\SetCameraConfigDataApi;
use Project\Aist\Admin\Api\Xavier\SetCameraTestConfigDataApi;
use Project\Aist\Admin\Api\Xavier\SetCameraWorkModeApi;
use API\Controllers\SaveZoneListApi;

use API\Controllers\AddProfileInviteApi; # use Project\Aist\Admin\Api\User\Profile\AddProfileInviteApi;
use API\Controllers\GetXavierDeviceInfoApi;
use API\Controllers\MonitoringController;
use API\Controllers\Monitoring\GetBoardInfoApi;
use API\Controllers\Monitoring\GetNetworkInfoApi;
use API\Controllers\GetTcpConnectStatusApi;
use API\Modules\GetInterfacesListApi;

class RouteAuthorizationAdminApi {

    public static function init(){ # pre(Url::$list[2]); pre(Url::$list);  pred($_REQUEST); #pre(getallheaders());

        if(count(Url::$list) < 3) return false;            #pred(Url::$list[2]); #get_xavier_device_info
        switch(Url::$list[2]){

            case 'monitoring': return new MonitoringController(); # /api/json/get_board_info

            case 'add_key': return AddKeyApi::init();
            case 'save_key': return SaveKeyApi::init();
            case 'remove_key': return RemoveKeyApi::init();

            case 'add_apikey': return AddApikeyApi::init();
            case 'save_apikey': return SaveApikeyApi::init();
            case 'remove_apikey': return RemoveApikeyApi::init();

            case 'remove_connect': return RemoveFtpConnectionApi::init();
            case 'check_ftp_connect': return CheckFtpConnectionApi::init();
            case 'save_ftp_connect': return SaveFtpConnectionApi::init();

            case 'save_tcp': return SaveTcpApi::init();
            case 'get_tcp_connect_status': return GetTcpConnectStatusApi::init();

            case 'save_angle': return SaveAngleApi::init();
            case 'get_calculate_angle': return GetCalculateAngleApi::init();

            case 'add_sms': return AddSmsApi::init();

            case 'get_sms_list': return GetSmsListApi::init();

            case 'get_update_sms_list': return GetUpdateSmsListApi::init();

            case 'get_update_radar_list': return GetUpdateRadarListApi::init();

            case 'save_zone_list': return SaveZoneListApi::init();

            case 'set_camera_test_config_data': return SetCameraTestConfigDataApi::init();
            case 'set_camera_config_data': return SetCameraConfigDataApi::init();
            case 'set_camera_work_mode': return SetCameraWorkModeApi::init();

            case 'get_camera_screen_link': return GetCameraScreenLinkApi::init();
            case 'get_camera_config_data': return GetCameraConfigDataApi::init();

            case 'test_socket': return TestSocketApi::init();

            case 'get_xavier_device_info': return GetXavierDeviceInfoApi::init();

            case 'get_profile_list': return GetProfileListApi::init();

            case 'add_admin': return AddAdminApi::init();
            case 'update_admin': return UpdateAdminApi::init();

            case 'update_admin_access': return UpdateAdminAccessApi::init();
            case 'block_admin': return BlockAdminApi::init();
            case 'remove_admin': return RemoveAdminApi::init();

            case 'remove_profile_account': return RemoveProfileAccountApi::init();

            case 'set_admin':
            case 'edit_admin': return EditUserAdminApi::init();

            case 'set_user_image': return SaveUserAvatarApi::init();

            case 'set_user_password': return SaveUserPasswordApi::init();

            case 'set_user_name': return SaveUserNameApi::init();

            case 'set_user_email': return SaveUserEmailApi::init();

            case 'set_user_login': return SaveUserLoginApi::init();

            case 'remove_user': return RemoveUserAdminApi::init();

            case 'block_user': return BlockUserAdminApi::init();

            case 'set_user_to_admin': return SetToAdminUserAdminApi::init();

            case 'user_logout': return UserLogoutApi::init();

            case 'get_video_from_cache': return GetVideoFromCachetApi::init();

            case 'get_video_cache_timestamp_size': return GetVideoCacheTimestampSizeApi::init();

            case 'add_profile_invite': return AddProfileInviteApi::init();
            case 'update_profile': return UpdateProfileApi::init();
            case 'remove_profile': return RemoveProfileApi::init();

            case 'last_track': return new LastTrack(); # /api/json/get_board_info получение общей статистики
            case 'get_board_info': return GetBoardInfoApi::init(); # /api/json/get_board_info получение общей статистики
            case 'get_interfaces_list': return GetInterfacesListApi::init(); # /api/json/get_interfaces_list получение статистики интерфейсов
            case 'get_network_info': return GetNetworkInfoApi::init(); # /api/json/get_network_info получение статус подключения
            # Project/Aist/Admin/Api/Monitoring/GetNetworkInfoApi.php
            # default: pred(3321);
            #default:moni
        }  #pred(321);  return false;
    }
}