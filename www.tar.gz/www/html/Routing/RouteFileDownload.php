<?php

namespace Routing; # namespace Core\Module\Route\RouteFileDownload;

use Core\Module\Response\Response;
use Core\Module\Url\Url;
use Core\Module\Worktime\Worktime; #use Project\All\Page\NotFoundPage;
use Project\Aist\Admin\Route\FileDownload\RouteAdminFileDownload;

class RouteFileDownload { # Core/Module/Route/RouteFileDownload/RouteFileDownload.php

    public static function init(){

        Response::$type = 'json';
        switch(Url::$host){
            case 'aist':
            default: return RouteAdminFileDownload::init(); #  default:{  NotFoundPage::init();  break;   }
        }
        echo '<!--'.Worktime::get_delta().'-->';
        return true;
    }
}