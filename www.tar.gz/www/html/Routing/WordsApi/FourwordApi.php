<?php

namespace Routing\WordsApi; # namespace Project\Aist\Admin\Api\Route\GetRoutePageApi\Prepare;

use Core\Module\User\User;
use Core\Module\User\UserAccess;
use Core\Module\User\UserLogin;
use API\Modules\ConnectAction;
use Routing\GetRoutePageApi;
use API\Modules\AdminLoginConfigItemPageAdminRoutePageApi; # use Project\Aist\Admin\Api\Route\GetRoutePageApi\Page\Admin\Login\Config\ConfigItem\AdminLoginConfigItemPageAdminRoutePageApi;
use API\Controllers\ZonesItemPageApi; # Project\Aist\Admin\Api\Route\GetRoutePageApi\Page\Admin\Login\Zones\ZonesItem\ZonesItemPageApi;
use API\Controllers\TcpApi; # use Project\Aist\Admin\Api\Route\GetRoutePageApi\Page\Admin\Login\Tcp\TcpItem\AdminLoginTcpItemPageAdminRoutePageApi;
use Redirects\AuthPageRedirectAdminRoutePageApi;
use API\Modules\RootPageDefaultRedirectAdminRoutePageApi;
use Common\Models\Camera;

class FourwordApi { # Project/Aist/Admin/Api/Route/GetRoutePageApi/Prepare/PrepareLinkLen4AdminRoutePageApi.php

    private static function prepare_admin_login_config(){
        if(Camera::isset_camera_id(GetRoutePageApi::$list[3])) return AdminLoginConfigItemPageAdminRoutePageApi::init(GetRoutePageApi::$list[3]);
        return RootPageDefaultRedirectAdminRoutePageApi::init();
    }

    private static function prepare_admin_login_zones(){
        if(Camera::isset_camera_id(GetRoutePageApi::$list[3])) return ZonesItemPageApi::init(GetRoutePageApi::$list[3]);
        return RootPageDefaultRedirectAdminRoutePageApi::init();
    }

    private static function prepare_admin_login_tcp(){ #pred(123);
        if(ConnectAction::isset_interface_name(GetRoutePageApi::$list[3]) || ConnectAction::isset_interface_name(GetRoutePageApi::$default_list[3])) return TcpApi::init(GetRoutePageApi::$default_list[3]);
        return RootPageDefaultRedirectAdminRoutePageApi::init();
    }

    private static function prepare_admin_login(){
        switch(GetRoutePageApi::$list[2]){
            case 'config': return self::prepare_admin_login_config();
            case 'tcp': return self::prepare_admin_login_tcp();
            case 'zones': return self::prepare_admin_login_zones();
            default: return RootPageDefaultRedirectAdminRoutePageApi::init();
        }
    }

    private static function prepare_admin(){
        if(User::is_login())
            if(UserAccess::$is_root || UserAccess::$is_admin){
                $user_login = UserLogin::get_user_login_default();
                if($user_login == GetRoutePageApi::$list[1]) return self::prepare_admin_login();
            }
        return AuthPageRedirectAdminRoutePageApi::init();
    }

    public static function init(){
        switch(GetRoutePageApi::$list[0]){
            case 'admin': return self::prepare_admin();
            default:{
                if(User::is_login()) return RootPageDefaultRedirectAdminRoutePageApi::init();
                return RootPageDefaultRedirectAdminRoutePageApi::init();
            }
        }
    }
}