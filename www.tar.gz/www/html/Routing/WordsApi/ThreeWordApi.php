<?php

namespace Routing\WordsApi; #namespace Project\Aist\Admin\Api\Route\GetRoutePageApi\Prepare;

use Core\Module\User\User;
use Core\Module\User\UserAccess;
use Core\Module\User\UserLogin;
use Routing\GetRoutePageApi;
use Admin\Init\AngleInit; # use Project\Aist\Admin\Api\Route\GetRoutePageApi\Page\Admin\Login\Angle\AdminLoginAnglePageAdminRoutePageApi;
use API\Modules\AdminLoginConfigPageAdminRoutePageApi; # use Project\Aist\Admin\Api\Route\GetRoutePageApi\Page\Admin\Login\Config\AdminLoginConfigPageAdminRoutePageApi;
use API\Controllers\AdminLoginZonesPageAdminRoutePageApi; # use Project\Aist\Admin\Api\Route\GetRoutePageApi\Page\Admin\Login\Connect\AdminLoginConnectPageAdminRoutePageApi;
use API\Modules\AdminLoginKeyPageAdminRoutePageApi; # use Project\Aist\Admin\Api\Route\GetRoutePageApi\Page\Admin\Login\Key\AdminLoginKeyPageAdminRoutePageApi;
use  API\Modules\AdminLoginApikeyPageAdminRoutePageApi; # use Project\Aist\Admin\Api\Route\GetRoutePageApi\Page\Admin\Login\Apikey\AdminLoginApikeyPageAdminRoutePageApi;
use API\Modules\AdminLoginUsersPageAdminRoutePageApi; # use Project\Aist\Admin\Api\Route\GetRoutePageApi\Page\Admin\Login\User\AdminLoginUsersPageAdminRoutePageApi;
use API\Modules\AdminLoginSettingsPageAdminRoutePageApi; # use Project\Aist\Admin\Api\Route\GetRoutePageApi\Page\Admin\Login\Settings\AdminLoginSettingsPageAdminRoutePageApi;
use Project\Aist\Admin\Api\User\AdminLogoutApi;
use Common\Modules\AdminLoginTcpPageAdminRoutePageApi;
use API\Modules\AdminLoginSmsPageAdminRoutePageApi; # use Project\Aist\Admin\Api\Route\GetRoutePageApi\Page\Admin\Login\Sms\AdminLoginSmsPageAdminRoutePageApi;
use API\Modules\AdminLoginRadarPageAdminRoutePageApi; # use Project\Aist\Admin\Api\Route\GetRoutePageApi\Page\Admin\Login\Radar\AdminLoginRadarPageAdminRoutePageApi;
use Redirects\AuthPageRedirectAdminRoutePageApi;
use API\Modules\RootPageDefaultRedirectAdminRoutePageApi;

class ThreeWordApi { # Project/Aist/Admin/Api/Route/GetRoutePageApi/Prepare/PrepareLinkLen3AdminRoutePageApi.php

    private static function prepare_admin_login(){
        switch(GetRoutePageApi::$list[2]){
            case 'angle': return AngleInit::init();
            case 'config': return AdminLoginConfigPageAdminRoutePageApi::init();
            case 'zones': return AdminLoginZonesPageAdminRoutePageApi::init();
            case 'apikey': return AdminLoginApikeyPageAdminRoutePageApi::init();
            case 'key': return AdminLoginKeyPageAdminRoutePageApi::init();
            case 'tcp': return AdminLoginTcpPageAdminRoutePageApi::init();
            case 'sms': return AdminLoginSmsPageAdminRoutePageApi::init();
            case 'users': return AdminLoginUsersPageAdminRoutePageApi::init();
            case 'settings': return AdminLoginSettingsPageAdminRoutePageApi::init();
            case 'logout': return AdminLogoutApi::init();
            default: return RootPageDefaultRedirectAdminRoutePageApi::init();
        }
    }

    private static function prepare_admin_promo(){
        switch(GetRoutePageApi::$list[2]){
            case 'settings': return AdminLoginSettingsPageAdminRoutePageApi::init();
            case 'radar': return AdminLoginRadarPageAdminRoutePageApi::init();
            case 'logout': return AdminLogoutApi::init();
            default: return RootPageDefaultRedirectAdminRoutePageApi::init();
        }
    }

    private static function prepare_admin(){
        if(User::is_login())
            if(UserAccess::$is_root || UserAccess::$is_admin){
                $user_login = UserLogin::get_user_login_default();
                #pre($user_login);                pred(GetRoutePageApi::$list[1]);
                return self::prepare_admin_login(); #  if($user_login === GetRoutePageApi::$list[1])
            } else if(UserAccess::$is_promo_radar){
                $user_login = UserLogin::get_user_login_default();
                if($user_login == GetRoutePageApi::$list[1]) return self::prepare_admin_promo();
            }
        return AuthPageRedirectAdminRoutePageApi::init();
    }

    public static function init(){
        switch(GetRoutePageApi::$list[0]){
            case 'admin': return self::prepare_admin();
            default:{
                if(User::is_login()) return RootPageDefaultRedirectAdminRoutePageApi::init();
                return RootPageDefaultRedirectAdminRoutePageApi::init();
            }
        }
    }
}