<?php

namespace Routing;

use Core\Module\Url\Url; # use Core\Module\User\User;
use API\Modules\GetJournalDataApi; # Project\Aist\Admin\Api\Journal\GetJournalDataApi; use Project\Aist\Admin\Api\Parse\ParsePrizmaApi;
use Routing\GetRoutePageApi;
use Common\Modules\GetTokenApi;
use API\Modules\IssetUserEmailApi;
use API\Modules\IssetUserLoginApi;
use Project\Aist\Admin\Api\Xavier\CreateJournalBoxForDownloadApi;
use Project\Aist\Admin\Api\Xavier\CreateJournalBoxTestApi;
use Project\Aist\Admin\Api\Xavier\SendJournalBoxTestApi;

class RouteAllAdminApi {

    public static function init(){  #pred(Url::$list);# pred(debug_backtrace());
        if(count(Url::$list) >= 3){ #pred(Url::$list[2]);
            switch(Url::$list[2]){
                case 'get_connect_info':{
                    print_r($_SERVER);
                    return true;
                }
                case 'get_journal_data': return GetJournalDataApi::init();
                case 'send_journal_box_test': return SendJournalBoxTestApi::init();
                case 'create_journal_box_test': return CreateJournalBoxTestApi::init();
                case 'create_journal_box_for_download': return CreateJournalBoxForDownloadApi::init();
                case 'get_trigger':
                case 'get_route_page': return GetRoutePageApi::init();
                case 'get_token': return GetTokenApi::init();
                case 'isset_user_login': return IssetUserLoginApi::init();
                case 'isset_user_email': return IssetUserEmailApi::init();
            }
            /*if(!empty($_POST['key_hash']))
                if($_POST['key_hash'] === 'domino777'){
                    User::$user_id=-1;
                    switch(Url::$list[2]){
                        default: return false;
                    }
                }*/
        }
        return false;
    }
}