<?php

namespace Routing; # namespace Project; use Core\Module\Response\Response;

use Front\Controllers\DuploController;
use Front\Controllers\AuthController;

class RouteFront {

    public static function init(){
        #pred(RP); pred(debug_backtrace());
        if(strpos(RP, '/duplo') === 0) new DuploController();
        if(strpos(RP, '/authn') === 0) new AuthController();
    }
}