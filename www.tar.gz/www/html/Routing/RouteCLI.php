<?php

namespace Routing; # namespace CLI\Modules;

use Common\Models\History;
use Common\Modules\IpShellDetermine; # Core\Module\Ip\IpShellDetermine;
use Core\Module\Response\Response;
use Core\Module\Url\UrlShellDetermine;

use Core\Module\Exception\ParametersException;
use Core\Module\Url\Url;
use CLI\Controllers\GetImagePathListShell; # use Project\Aist\Admin\Shell\Journal\AddJournalViolationListShell; # use Project\Aist\Admin\Shell\Journal\RemoveJournalShell; # use Project\Aist\Admin\Shell\Journal\SendBoxFtpShell;
use CLI\Controllers\GetVideoPathListShell;
use CLI\Controllers\AistUpload;
use CLI\Controllers\BalancerThread;
use CLI\Controllers\SendJournalDataForAvgSpeedShell; # use Project\Aist\Admin\Shell\Journal\SendJournalDataForAvgSpeedShell;
use CLI\Modules\Mailing\MailingShell; #use Project\Aist\Admin\Shell\Mailing\MailingShell;
use Admin\Controllers\DuploController;
use Admin\Controllers\MigrationController;
use CLI\Controllers\CafapPackMThread;
use CLI\Controllers\CafapSendMThread;
use CLI\Controllers\DuploPackMThread;
use CLI\Controllers\DuploSendMThread;
use CLI\Controllers\Testing;
use CLI\Controllers\Cleaning; # use Project\Aist\Admin\Shell\Journal\Cleaning;
use CLI\Controllers\TCleaning;
use CLI\Controllers\AistFront;
use CLI\Modules\Clean\CleanLogs;
use CLI\Modules\Deploy;
use CLI\Modules\Clean\CleanOrphanSending;
use CLI\Modules\Clean\CleanOrphanProcessing;
use CLI\Modules\Clean\CleanOrphanPacking;
use CLI\Modules\Clean\CleanTemps;
use CLI\Modules\Clean\CleanOrphanImages; # use CLI\Modules\Clean\CleanOrphanImages30;
use CLI\Modules\Clean\CleanOrphanImagesFiles;
use CLI\Modules\Clean\CleanOrphanVideos30;
use CLI\Modules\Clean\CleanOrphanJImages30;
use CLI\Modules\Clean\CleanOrphanJVideos30;
use CLI\Modules\Clean\CleanTables30;
use CLI\Modules\Clean\CleanDirs30;
use CLI\Modules\Clean\CleanResources;
use CLI\Modules\RTSWS\RTSWS;
use CLI\Controllers\AATesting;
use CLI\Controllers\AUF;
use Core\Module\Url\UrlDetermine;

class RouteCLI {

    public static function init(){

        Response::$type = 'shell'; # UrlDetermine::init();
        UrlShellDetermine::init(); #pred($_POST);
        define('RP', Url::$shell_action);
        define('ERP', array_slice(explode('/',  RP),  -2)[0]);
        IpShellDetermine::init();
        History::init();

        if(isset($_POST['page'])){
            if($_POST['page'] === 'admin/duplo') return new DuploController;#        page=admin/duplo
            if($_POST['page'] === 'admin/migration') return new MigrationController; # sudo -u www-data /usr/bin/php7.2 /var/www/html/index.php page=admin/migration action=apply
        }

        if(!isset(Url::$shell_action)) throw new ParametersException(['title ' => ParametersException::$title, 'info' => 'Shell action is not exists']); # pred(Url::$shell_action);

        switch(Url::$shell_action){
            case 'deploy': return Deploy::init();
            # sudo -u www-data /usr/bin/php7.2 $PWD/index.php action=balancer need_log=1

            # sudo -u www-data /usr/bin/php7.2 -f "$PWD/index.php" action=cafap_send_thread tid=0 need_log=1
            # sudo -u www-data /usr/bin/php7.2 -f "$PWD/index.php" action=cafap_pack_thread tid=0 need_log=1

            # sudo -u www-data /usr/bin/php7.2 -f "$PWD/index.php" action=duplo_pack_thread tid=0 need_log=1
            # sudo -u www-data /usr/bin/php7.2 -f "$PWD/index.php" action=duplo_send_thread tid=0 need_log=1

            # sudo -u www-data /usr/bin/php7.2 /var/www/html/index.php "action=send_box_thread_list" "thread_limit=2" "is_test=1" "need_log=1"
            # sudo -u www-data /usr/bin/php7.2 $PWD/index.php action=send_box_thread thread_id=0 is_test=1 need_log=1

            # sudo -u www-data /usr/bin/php7.2 $PWD/index.php action=remove_journal_list is_test=1 need_log=1
            # sudo -u www-data /usr/bin/php7.2 $PWD/index.php action=cleaning is_test=1 need_log=1

            # ExecStart=/usr/bin/php7.2 -f /var/www/html/index.php action=cleaning need_log=1 >> /dev/null 2>&1 & echo $
            # sudo -u www-data /usr/bin/php7.2 $PWD/index.php action=cleaning is_test=1 need_log=1 nl=1

            case 'cafap_pack_thread': return new CafapPackMThread();
            case 'cafap_send_thread': return new CafapSendMThread();
            case 'duplo_pack_thread': return new DuploPackMThread();
            case 'duplo_send_thread': return new DuploSendMThread();
            case 'aist_upload': return (new AistUpload());
            case 'balancer': return (new BalancerThread());
            case 'send_potok_for_avg_speed': return SendJournalDataForAvgSpeedShell::init();
            case 'mailing': return MailingShell::init();
            case 'get_image_path_list': return GetImagePathListShell::init();
            case 'get_video_path_list': return GetVideoPathListShell::init();
            case 'cleaning': return Cleaning::init(); # systemctl status aist_remove sudo -u www-data /usr/bin/php /var/www/html/index.php "action=remove_journal_list" "is_test=1" >> /dev/null 2>&1 & echo $
            case 'nclean': return Cleaning::nightclean(); # systemctl status aist_remove sudo -u www-data /usr/bin/php /var/www/html/index.php "action=remove_journal_list" "is_test=1" >> /dev/null 2>&1 & echo $
            case 'remove_journal_list': return Cleaning::init(); # systemctl status aist_remove sudo -u www-data /usr/bin/php /var/www/html/index.php "action=remove_journal_list" "is_test=1" >> /dev/null 2>&1 & echo $
            case 'ct30': return CleanTables30::init();
            case 'coi': return CleanOrphanImages::init(); # case 'coi30': return CleanOrphanImages30::init();
            case 'cov30': return CleanOrphanVideos30::init();
            case 'coji30': return CleanOrphanJImages30::init();
            case 'cojv30': return CleanOrphanJVideos30::init();
            case 'cd30': return CleanDirs30::init();
            case 'cll': return CleanLogs::init();
            case 'clt': return CleanTemps::init();
            case 'coif': return CleanOrphanImagesFiles::init();
            case 'tclean': return TCleaning::init();
            case 'aist_front': return AistFront::init();
            case 'af': return AistFront::init();
            case 'cos': return CleanOrphanSending::init();
            case 'cop': return CleanOrphanPacking::init();
            case 'copr': return CleanOrphanProcessing::init();
            case 'rtsws': return RTSWS::init(); # sudo -u www-data /usr/bin/php7.2 $PWD/index.php action=rtsws need_log=1
            case 'cra': return (new CleanResources())->all(); # sudo -u www-data /usr/bin/php7.2 $PWD/index.php action=rtsws need_log=1
            case 'priw': return new Testing(); # sudo -u www-data /usr/bin/php7.2 $PWD/index.php action=rtsws need_log=1
            case 'pgriw': return new Testing(); # sudo -u www-data /usr/bin/php7.2 $PWD/index.php action=rtsws need_log=1
            case 'aa': return new AATesting(); # sudo -u www-data /usr/bin/php7.2 $PWD/index.php action=rtsws need_log=1
            case 'auf': return new AUF(); # sudo -u www-data /usr/bin/php7.2 $PWD/index.php action=rtsws need_log=1

            default:{ throw new ParametersException([ 'title ' => ParametersException::$title, 'info' => 'Action is not valid']); }
        }
        # case 'send_boxes': return SendBoxFtpShell::init(); NOT IN WORK!
        # case 'add_journal': return AddJournalViolationListShell::init(); #return AddJournalShell::init(); #case 'add_journal_traffic_violation_list': return AddJournalViolationListShell::init();
        # case 'remove_journal': return RemoveJournalShell::init();
    }
}