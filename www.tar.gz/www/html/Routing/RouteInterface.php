<?php

namespace Routing; # namespace Project;

use Core\Module\Response\Response;
use Routing\RouteApi;
use Routing\RouteFileDownload; # Core\Module\Route\RouteFileDownload\RouteFileDownload;
use Routing\Words\RouteWords;
use Core\Module\Url\Url;

use Admin\Controllers\Journalo;

class RouteInterface { # htmls Project/Aist/Admin/Template/Dom/Admin/RootAdminDom.php Project/Aist/Admin/Template/Dom/Root/RootRootDom.php

    public static function init(){ #pred(RP); pred(debug_backtrace());

        global $req;

        if(Response::$type === 'shell') return false; #define('RP', UrlDetermine::get_request_page()); #pred($_SERVER); pred(RP);

        if(ajax && strpos(RP, '/api/json/get_trigger') === 0 && $req->post('link') === 'admin/root/history'){
            #pred($_POST);  #self::$list = Url::get_url_list($_POST['link']); #self::$default_list = Url::get_url_list($_POST['link'],false);
            return Journalo::init();# HISTORY API /admin/root/history AdminLoginHistoryPageAdminRoutePageApi
        }
        if(strpos(RP, '/admin') === 0) RouteAdmin::init();

        RouteFront::init();

        if(count(Url::$list) < 3) return RouteWords::init();
        switch(Url::$list[0]){
            case 'api': return RouteApi::init();
            case 'download':
            case 'show': return RouteFileDownload::init();
        }
        return RouteWords::init();
    }
}