<?php

namespace Routing; #namespace Project\Aist\Admin\Route\Redirect;

class RouteRootRedirectAdmin { # Project/Aist/Admin/Route/Redirect/RouteRootRedirectAdmin.php

    public static function init(){
        return RouteRootDefaultRedirectAdmin::init();
    }
}