<?php

namespace Routing;

use Core\Modules\Bearer;
use Core\Module\Exception\AccessDeniedException;
use Core\Module\Response\ResponseNotFound;
use Core\Module\Url\Url;
use Core\Module\User\User;
use Routing\RouteAuthorizationAdminApi;
use Routing\RouteGuestAdminApi;
use Routing\RouteAllAdminApi;

class RouteAdminApi {

    private static $isset_route = false;  #private static function init_route_authorization(){ return }  #private static function init_route_guest(){        return RouteGuestAdminApi::init(); } #private static function init_route_all(){ #pred(Url::$list);        return RouteAllAdminApi::init();    }

    public static function init(){ #pred(Url::$list);
        if(count(Url::$list) < 3) return ResponseNotFound::init();  #pred(User::is_login());
        #if(User::is_login()) self::$isset_route = RouteAuthorizationAdminApi::init();  #pred(self::$isset_route);
        self::$isset_route = RouteAuthorizationAdminApi::init(); pred(self::$isset_route);
        if(!self::$isset_route) self::$isset_route = RouteGuestAdminApi::init();#pred(debug_backtrace());  #pred(self::$isset_route);
        if(!self::$isset_route) self::$isset_route = RouteAllAdminApi::init(); #pred(self::$isset_route);
        if(!self::$isset_route){ $error = ['title' => AccessDeniedException::$title, 'info' => 'Access denied#24', 'data' => ['token' => Bearer::get_bearer_token()]]; throw new AccessDeniedException($error);
        } #pred(333);
        return false;
    }
}