<?php

namespace Routing;

use Core\Module\Url\Url;
use API\Controllers\UserAuthApi; # use Project\Aist\Admin\Api\Auth\UserAuth\UserAuthApi;
use API\Controllers\HashAuthApi; # use Project\Aist\Admin\Api\Auth\HashAuth\HashAuthApi;
use Routing\GetRoutePageApi; # use Project\Aist\Admin\Api\Route\GetRoutePageApi;
use Common\Modules\GetTokenApi;
use Project\Aist\Admin\Api\User\Admin\InviteRegistrationUserAdminApi;
use Project\Aist\Admin\Api\User\Admin\RecoveryPasswordUserAdminApi;
use Project\Aist\Admin\Api\User\Data\SaveUserRecoveryPasswordApi;
use API\Modules\IssetUserEmailApi;
use API\Modules\IssetUserLoginApi;
use Project\Aist\Admin\Api\User\Profile\AddProfileApi;

class RouteGuestAdminApi {

    static function init(){

        if(count(Url::$list) >= 3) #pred(Url::$list[2]);
            switch(Url::$list[2]){

                case 'save_user_settings':
                case 'create_admin_password': return InviteRegistrationUserAdminApi::init();
                case 'forgot_password': return RecoveryPasswordUserAdminApi::init();
                case 'reset_password': return SaveUserRecoveryPasswordApi::init();

                case 'get_trigger':
                case 'get_route_page': return GetRoutePageApi::init();

                case 'get_token': return GetTokenApi::init();

                case 'auth':
                case 'auth_admin':
                case 'user_auth': return UserAuthApi::init();
                case 'hash_auth': return HashAuthApi::init();

                case 'isset_user_login': return IssetUserLoginApi::init();
                case 'isset_user_email': return IssetUserEmailApi::init();

                case 'reg':
                case 'add_profile': return AddProfileApi::init();
            }

        return false;
    }
}