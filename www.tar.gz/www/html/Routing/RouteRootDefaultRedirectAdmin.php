<?php

namespace Routing; #namespace Project\Aist\Admin\Route\Redirect;

use Core\Module\User\User; # use Core\Module\Header\HeaderRedirect;
use Core\Module\User\UserLogin; # use Admin\Modules\AdminLinkDefaultAction;
use Project\Aist\Admin\Page\NotFound\NotFoundAdminPage;
use Admin\Stupids\RouteAuthRedirectAdmin;
use Admin\Controllers\ErrorPageController;

class RouteRootDefaultRedirectAdmin { # Project/Aist/Admin/Route/Redirect/RouteRootDefaultRedirectAdmin.php

    public static function init(){
        if(User::is_login()){
            $user_login = UserLogin::get_user_login_default();
            if(empty($user_login)) return RouteAuthRedirectAdmin::init(); #$link_default = AdminLinkDefaultAction::get_admin_link_default(); pred($link_default);
            #if(empty($link_default)) return NotFoundAdminPage::init();            #return NotFoundAdminPage::init();
            return new ErrorPageController(); #return HeaderRedirect::init(null, $link_default);
        }
        return RouteAuthRedirectAdmin::init();
    }
}