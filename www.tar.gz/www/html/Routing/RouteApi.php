<?php

namespace Routing;

use Core\Module\Response\Response;
use Core\Module\Response\ResponseNotFound;
use Core\Module\Url\Url;
use Core\Module\User\User;
use API\Controllers\SetXavierWorkModeApi;
use API\Controllers\CheckXavierSocketStatusApi;
use Routing\RouteAdminApi;

class RouteApi {

    public static function init(){

        Response::$type = 'json';

        if(count(Url::$list) < 3 || strtolower(Url::$list[0]) !== 'api'){
            $data = ['title' => 'Page not found', 'info' => 'Host is not exists'];
            ResponseNotFound::init($data);
            return false;
        }

        switch(Url::$list[1]){

            case 'json': {

                Response::$type = 'json';  #pred(RP);

                if(strpos(RP, '/api/json/set_xavier_work_mode') === 0){ if(!User::is_login()) return; SetXavierWorkModeApi::init(); die; } # case 'set_xavier_work_mode': return SetXavierWorkModeApi::init();
                if(strpos(RP, '/api/json/check_xavier_socket_status') === 0) return CheckXavierSocketStatusApi::init();

                switch(Url::$host){
                    case 'aist':
                    default: return RouteAdminApi::init();
                }

                ResponseNotFound::init();
                return false;
            }

            default: {
                $data = ['title' => 'Page not found', 'info' => 'Json type is not exists'];
                return ResponseNotFound::init($data);
            }
        }
    }
}