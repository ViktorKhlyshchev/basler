<?php

namespace Routing; #namespace Project\Aist\Admin\Api\Route;

use Core\Module\Response\ResponseSuccess;
use Core\Module\Response\ResponseUnprocessableEntity;
use Core\Module\Url\Url;
use Project\Aist\Admin\Api\Route\GetRoutePageApi\Prepare\PrepareLinkLen0AdminRoutePageApi;
use Project\Aist\Admin\Api\Route\GetRoutePageApi\Prepare\PrepareLinkLen1AdminRoutePageApi;
use Project\Aist\Admin\Api\Route\GetRoutePageApi\Prepare\PrepareLinkLen2AdminRoutePageApi;
use Routing\WordsApi\ThreeWordApi; # use Project\Aist\Admin\Api\Route\GetRoutePageApi\Prepare\PrepareLinkLen3AdminRoutePageApi;
use Routing\WordsApi\FourwordApi; # Project\Aist\Admin\Api\Route\GetRoutePageApi\Prepare\PrepareLinkLen4AdminRoutePageApi;
use Project\Aist\Admin\Api\Route\GetRoutePageApi\Prepare\PrepareLinkLen5AdminRoutePageApi;
use Project\Aist\Admin\Api\Route\GetRoutePageApi\Prepare\PrepareLinkLen6AdminRoutePageApi;
use Redirects\AuthPageRedirectAdminRoutePageApi;

class GetRoutePageApi {

    public static $list = [];
    public static $default_list = [];

    public static function redirect(string $title = null, string $link = null){
        $data = ['title' => $title, 'redirect' => $link];
        return ResponseSuccess::init($data);
    }

    public static function init(){ #pred(debug_backtrace());        #pred(Url::$list);
        if(!isset($_POST['link'])){
            $error = ['title' => 'Parameters problem', 'info' => 'Link is not exists'];
            ResponseUnprocessableEntity::init($error);
        }
        self::$list = Url::get_url_list($_POST['link']);
        self::$default_list = Url::get_url_list($_POST['link'], false);
        # pre(count(self::$list));        pred(self::$list);
        switch(count(self::$list)){
            case 0: return PrepareLinkLen0AdminRoutePageApi::init();
            case 1: return PrepareLinkLen1AdminRoutePageApi::init();
            case 2: return PrepareLinkLen2AdminRoutePageApi::init();
            case 3: return ThreeWordApi::init();
            case 4: return FourwordApi::init();
            case 5: return PrepareLinkLen5AdminRoutePageApi::init();
            case 6: return PrepareLinkLen6AdminRoutePageApi::init();
            default: return AuthPageRedirectAdminRoutePageApi::init();
        }
    }
}