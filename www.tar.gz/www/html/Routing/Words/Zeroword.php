<?php

namespace Routing\Words; # namespace Project\Aist\Admin\Route\Prepare;

use Core\Module\User\User;
use Core\Module\User\UserAccess;
use Admin\Stupids\RouteAdminLoginRedirectAdmin;
use Admin\Stupids\RouteAuthRedirectAdmin;

class Zeroword { # Project/Aist/Admin/Route/Prepare/RoutePrepareLinkLen0AdminPage.php

    public static function init(){ #pred(UserAccess); #pred(User::is_login());
        #$class = new \ReflectionClass('Core\Module\User\UserAccess');  $arr = $class->getStaticProperties(); pred($arr);

        if(User::is_login()){
            if(UserAccess::$is_root || UserAccess::$is_admin) return RouteAdminLoginRedirectAdmin::init();
        }
        return RouteAuthRedirectAdmin::init();
    }
}