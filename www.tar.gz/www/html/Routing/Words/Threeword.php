<?php

namespace Routing\Words; # namespace Project\Aist\Admin\Route\Prepare;

use Core\Module\Url\Url;
use Core\Module\User\User;
use Core\Module\User\UserAccess;
use Core\Module\User\UserLogin;
use API\Modules\ConnectAction;
use Project\Aist\Admin\Route\Page\Admin\Login\About\RouteAdminLoginAboutAdminPage;
use Project\Aist\Admin\Route\Page\Admin\Login\Config\RouteAdminLoginConfigAdminPage;
use Project\Aist\Admin\Route\Page\Admin\Login\Key\RouteAdminLoginKeyAdminPage;
use Project\Aist\Admin\Route\Page\Admin\Login\Radar\RouteAdminLoginRadarAdminPage; # use Project\Aist\Admin\Route\Page\Admin\Login\Sms\RouteAdminSmsConfigAdminPage; # use Project\Aist\Admin\Route\Page\Admin\Login\Tcp\RouteAdminLoginTcpAdminPage;
use Project\Aist\Admin\Route\Page\Admin\Login\Video\RouteAdminLoginVideoConfigAdminPage;
use Project\Aist\Admin\Route\Page\Admin\Login\Video\RouteAdminLoginVideoZoneAdminPage;
use Project\Aist\Admin\Route\Page\Admin\Login\Settings\RouteAdminLoginSettingsAdminPage; # use Project\Aist\Admin\Route\Page\Admin\Login\User\RouteAdminLoginUserAdminPage;
use Admin\Stupids\RouteAdminLoginTcpItemRedirectAdmin;
use Admin\Stupids\RouteAuthRedirectAdmin;
use Routing\RouteRootRedirectAdmin;
use Admin\Stupids\RouteNotFoundAdminPage;
use Admin\Layouts\RootAdminDom;

class Threeword {

    private static function prepare_admin_login_radar(){
        return RouteAdminLoginRadarAdminPage::init();
    }

    private static function prepare_admin_login(){
        return RouteAdminLoginAboutAdminPage::init();
    }

    private static function prepare_admin_config(){
        return RouteAdminLoginConfigAdminPage::init();
    }

    private static function prepare_admin_video_config(){
        return RouteAdminLoginVideoConfigAdminPage::init();
    }

    private static function prepare_admin_video_zone(){
        return RouteAdminLoginVideoZoneAdminPage::init();
    }

    private static function prepare_admin_key(){
        return RouteAdminLoginKeyAdminPage::init();
    }

    private static function prepare_admin_login_users(){
        if(UserAccess::$is_root) return RootAdminDom::init();
        return RouteRootRedirectAdmin::init();
    }

    private static function prepare_admin_login_sms(){
        if(UserAccess::$is_root) return RootAdminDom::init(); # RouteAdminSmsConfigAdminPage::init();
        return RouteRootRedirectAdmin::init();
    }

    private static function prepare_admin_login_settings(){
        return RouteAdminLoginSettingsAdminPage::init();
    }

    private static function prepare_admin(){ #pred(User::is_login()); # /api/json/get_trigger link: admin/root/dashboard
        if(!User::is_login()) return RouteAuthRedirectAdmin::init();  #pred(UserAccess::$is_root || UserAccess::$is_admin);

        if(UserAccess::$is_root || UserAccess::$is_admin){
            $user_login = UserLogin::get_user_login_default(); # pred($user_login);
            #if($user_login != Url::$list[1]) return RouteAuthRedirectAdmin::init();
            #pred(Url::$list[2]);
            switch(Url::$list[2]){
                case 'dashboard': return RootAdminDom::init();
                case 'about': return self::prepare_admin_login();
                case 'config': return self::prepare_admin_config();
                case 'video_zone': return self::prepare_admin_video_zone();
                case 'video_config': return self::prepare_admin_video_config();
                case 'zones': return RootAdminDom::init();
                case 'key': return self::prepare_admin_key();
                case 'apikey': return RootAdminDom::init();
                case 'tcp': {
                    $interfaces_name_list = ConnectAction::get_interfaces_name_list([], false, true); # pred($interfaces_name_list); #pred(empty($interfaces_name_list));
                    if(empty($interfaces_name_list)) return RootAdminDom::init();
                    return RouteAdminLoginTcpItemRedirectAdmin::init();
                }
                case 'sms': return self::prepare_admin_login_sms();
                case 'users': return self::prepare_admin_login_users();
                case 'settings': return self::prepare_admin_login_settings();
                case 'radar': return self::prepare_admin_login_radar();
                default: return RouteNotFoundAdminPage::init();
            }
        } else if(UserAccess::$is_promo_radar){
            $user_login = UserLogin::get_user_login_default();
            if($user_login !== Url::$list[1]) return RouteAuthRedirectAdmin::init();
            switch(Url::$list[2]){
                case 'video_zone': return self::prepare_admin_video_zone();
                case 'radar': return self::prepare_admin_login_radar();
                default:
                    return RouteNotFoundAdminPage::init();
            }
        }
    }

    public static function init(){
        switch(Url::$list[0]){
            case 'admin': return self::prepare_admin();
            default: return RouteNotFoundAdminPage::init();
        }
    }
}