<?php

namespace Routing\Words; # namespace Project\Aist\Admin\Route\Prepare;

use Core\Modules\User\UserLogoutAction;
use Core\Module\Url\Url;
use Core\Module\User\User;
use Core\Module\User\UserAccess;
use Core\Module\User\UserLogin;
use Admin\Stupids\LogoutUserAdminAction;
use Project\Aist\Admin\Route\Page\ConfirmEmail\RouteConfirmEmailAdminPage;
use Pages\InviteAdminPage; # Project\Aist\Admin\Route\Page\Invite\RouteInviteAdminPage; use Project\Aist\Admin\Route\Page\RecoveryPassword\RouteRecoveryPasswordAdminPage;
use Admin\Stupids\RouteNotFoundAdminPage;
use Admin\Stupids\RouteAdminLoginDashboardRedirectAdmin;
use Project\Aist\Admin\Route\Redirect\Admin\Login\Radar\RouteAdminLoginRadarRedirectAdmin;
use Routing\RouteRootRedirectAdmin;
use Admin\Layouts\RootRootDom;

class Twoword { # RoutePrepareLinkLen2AdminPage Project/Aist/Admin/Route/Prepare/RoutePrepareLinkLen2AdminPage.php

    private static function prepare_admin(){
        if(User::is_login())
            if(UserAccess::$is_root || UserAccess::$is_admin){
                $user_login = UserLogin::get_user_login_default();
                if($user_login == Url::$list[1]) return RouteAdminLoginDashboardRedirectAdmin::init();
            } else if(UserAccess::$is_promo_radar){
                $user_login = UserLogin::get_user_login_default();
                if($user_login == Url::$list[1]) return RouteAdminLoginRadarRedirectAdmin::init();
            }
        return RouteRootRedirectAdmin::init();
    }

    private static function prepare_confirm_email(){
        if(User::is_login()) LogoutUserAdminAction::init();
        return RootRootDom::init();
    }

    private static function prepare_invite(){
        if(User::is_login()) UserLogoutAction::init();
        return InviteAdminPage::init();
    }

    private static function prepare_recovery_password(){
        if(User::is_login()) UserLogoutAction::init();
        switch(count(Url::$list)){
            case 2:{
                switch(Url::$list[0]){
                    case 'recovery_password':{
                        if(empty(Url::$list[1])) return RouteRootRedirectAdmin::init();
                        return RootRootDom::init();
                    }
                    default: return RouteRootRedirectAdmin::init();
                }
            }
            default: return RouteRootRedirectAdmin::init();
        }
    }

    public static function init(){ # pred(Url::$list[0]);
        switch(Url::$list[0]){
            case 'admin': return self::prepare_admin(); # case 'profile': return self::prepare_profile();
            case 'registration_invite': return self::prepare_invite();
            case 'recovery_password': return self::prepare_recovery_password();
            case 'confirm_email': return self::prepare_confirm_email();
            default: return RouteNotFoundAdminPage::init();
        }
    }
}