<?php

namespace Routing\Words; #namespace Project\Aist\Admin\Route\Prepare;

use Core\Module\Url\Url;
use Core\Module\User\User;
use Core\Module\User\UserAccess; # use Project\Aist\Admin\Route\Page\Reg\RouteRegAdminPage;
use Admin\Stupids\RouteNotFoundAdminPage;
use Admin\Pages\PhpInfoAdminDom; # use Project\Aist\Admin\Route\Page\PhpInfo\RoutePhpInfoAdminPage;
use Admin\Stupids\RouteAdminLoginDashboardRedirectAdmin;
use Project\Aist\Admin\Route\Redirect\Admin\Login\Radar\RouteAdminLoginRadarRedirectAdmin;
use Routing\RouteRootRedirectAdmin;
use Admin\Layouts\RootRootDom;

class Oneword { # RoutePrepareLinkLen1AdminPage Project/Aist/Admin/Route/Prepare/RoutePrepareLinkLen1AdminPage.php

    private static function prepare_admin(){
        if(User::is_login()){
            if(UserAccess::$is_root || UserAccess::$is_admin) return RouteAdminLoginDashboardRedirectAdmin::init();
            else
                if(UserAccess::$is_promo_radar) return RouteAdminLoginRadarRedirectAdmin::init();
        }
        return RouteRootRedirectAdmin::init();
    }

    private static function prepare_reg(){
        if(User::is_login()){
            if(UserAccess::$is_root || UserAccess::$is_admin) return RouteAdminLoginDashboardRedirectAdmin::init();
            else if(UserAccess::$is_profile || UserAccess::$is_profile_wallet)
                return RouteProfileLoginFaceRedirectAdmin::init();
        }
        return RootRootDom::init(); # RouteRegAdminPage::init();
    }

    private static function prepare_auth(){
        if(User::is_login()) if(UserAccess::$is_root || UserAccess::$is_admin) return RouteAdminLoginDashboardRedirectAdmin::init();
        return RootRootDom::init();
    }

    public static function init(){ #pred(Url::$list[0]);
        switch(Url::$list[0]){
            case 'login':
            case 'auth': return self::prepare_auth();
            case 'reg': return self::prepare_reg();
            case 'admin': return self::prepare_admin();
            case 'phpinfo': return PhpInfoAdminDom::init();
            default: return RouteNotFoundAdminPage::init();
        }
    }
}