<?php

namespace Routing\Words; #namespace Project\Aist\Admin\Route\Prepare;

use Core\Module\Url\Url;
use Core\Module\User\User;
use Core\Module\User\UserAccess;
use Admin\Stupids\RouteNotFoundAdminPage;
use Admin\Stupids\RouteAuthRedirectAdmin;
use Routing\RouteRootDefaultRedirectAdmin;

class Fiveword { # Project/Aist/Admin/Route/Prepare/RoutePrepareLinkLen5AdminPage.php

    private static function prepare_admin(){
        if(!User::is_login()) return RouteAuthRedirectAdmin::init();
        if(UserAccess::$is_root || UserAccess::$is_admin)
            switch(Url::$list[2]){
                default:
                    return RouteNotFoundAdminPage::init();
            }
        return RouteRootDefaultRedirectAdmin::init();
    }

    public static function init(){
        switch(Url::$list[0]){
            case 'admin': return self::prepare_admin();
            default: return RouteNotFoundAdminPage::init();
        }
    }
}