<?php

namespace Routing\Words;

use Core\Module\Url\Url;
use Core\Module\User\User;
use Core\Module\User\UserAccess;
use Core\Module\User\UserLogin;
use API\Modules\ConnectAction;
use Common\Models\Camera;
use Project\Aist\Admin\Route\Page\Admin\Login\Config\ConfigItem\RouteAdminLoginConfigItemAdminPage; # use Project\Aist\Admin\Route\Page\Admin\Login\Tcp\TcpItem\RouteAdminLoginTcpItemAdminPage;
use Project\Aist\Admin\Route\Redirect\Admin\Login\Config\RouteAdminLoginConfigRedirectAdmin;
use Admin\Stupids\RouteAdminLoginRedirectAdmin;
use Admin\Stupids\RouteAdminLoginTcpRedirectAdmin;
use Admin\Stupids\RouteAuthRedirectAdmin;
use Admin\Stupids\RouteNotFoundAdminPage;
use Admin\Layouts\RootAdminDom;

class Fourword {

    private static function prepare_admin_login_config(){
        if(Camera::isset_camera_id(Url::$list[3])) return RouteAdminLoginConfigItemAdminPage::init();
        return RouteAdminLoginConfigRedirectAdmin::init();
    }

    private static function prepare_admin_login_zones(){
        if(Camera::isset_camera_id(Url::$list[3])) return RootAdminDom::init();
        return RouteAdminLoginConfigRedirectAdmin::init();
    }

    private static function prepare_admin_login_tcp(){
        if(ConnectAction::isset_interface_name(Url::$default_list[3])) return RootAdminDom::init();
        return RouteAdminLoginTcpRedirectAdmin::init();
    }

    private static function prepare_admin_login(){
        switch(Url::$list[2]){
            case 'config': return self::prepare_admin_login_config();
            case 'zones': return self::prepare_admin_login_zones();
            case 'tcp': return self::prepare_admin_login_tcp();
            default: return RouteNotFoundAdminPage::init();
        }
    }

    private static function prepare_admin(){
        if(!User::is_login()) return RouteAuthRedirectAdmin::init();
        if(UserAccess::$is_root || UserAccess::$is_admin){
            $user_login = UserLogin::get_user_login_default();
            if($user_login === Url::$list[1]) return self::prepare_admin_login();
        }
        return RouteAdminLoginRedirectAdmin::init();
    }

    public static function init(){
        switch(Url::$list[0]){
            case 'admin': return self::prepare_admin();
            default: return RouteNotFoundAdminPage::init();
        }
    }
}