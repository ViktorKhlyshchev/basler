<?php

namespace Routing\Words; #namespace Core\Module\Route\RoutePage;

use Core\Module\Response\Response;
use Core\Module\Url\Url;
use Core\Module\Worktime\Worktime;

use Admin\Controllers\ErrorPageController; # use Project\Aist\Admin\Page\NotFound\NotFoundAdminPage;

class RouteWords { # Core/Module/Route/RoutePage/RoutePage.php

    public static function init(){

        Response::$type = 'page';  #pre(Url::$host); pred(count(Url::$list));

        switch(count(Url::$list)){
            case 0: return Zeroword::init();
            case 1: return Oneword::init();
            case 2: return Twoword::init();
            case 3: return Threeword::init();
            case 4: return Fourword::init();
            case 5: return Fiveword::init();
            default: return new ErrorPageController();
        }
        if(\Config::$show_worktime){
            echo '<!--'.Worktime::get_delta().'-->';
            echo '<!--'.print_r(Worktime::$timestamp_list,true).'-->';
        }
        return true;
    }
}