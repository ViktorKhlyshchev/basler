<!DOCTYPE html>
<html>
<head>
    <link rel="apple-touch-icon" sizes="144x144" href="/Project/Aist/Admin/Template/Images/Favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/Project/Aist/Admin/Template/Images/Favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/Project/Aist/Admin/Template/Images/Favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="/Project/Aist/Admin/Template/Images/Favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/Project/Aist/Admin/Template/Images/Favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="/Project/Aist/Admin/Template/Images/Favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/Project/Aist/Admin/Template/Images/Favicon/favicon-16x16.png">
    <link rel="manifest" href="/Project/Aist/Admin/Template/Images/Favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/Project/Aist/Admin/Template/Images/Favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">

    <meta name="viewport" content="width=1480, user-scalable=yes">
    <link href='/Static/fonts/roboto.css' rel=stylesheet type='text/css' />
    <link href='/Static/fonts/roboto_condensed.css' rel=stylesheet type='text/css' />
    <link href='/Static/fonts/material_icons.css' rel=stylesheet type='text/css' />

    <link rel=stylesheet type="text/css" href="/Static/css/default.css" />

    <link rel=stylesheet href=/Static/packs/css/fa4.3.0.min.css>
    <link rel=stylesheet href="/Static/css/bootstrap.min.css" />
    <link rel=stylesheet href="/Static/css/bootstrap_notify.css" />
    <link rel=stylesheet href="/Static/css/animate.css" />
    <script>
        cl = console.log
        loc = location.host === 'aist.loc' ? true : false;
        rp = '<?= RP ?>';
        erp = '<?= ERP ?>';
        pages = {};
    </script>

    <script src="/Static/js/jquery-3.1.1.min.js"></script>
    <script src="/Static/js/jquery.extendext.min.js"></script>
    <script src="/Static/js/system/config.js"></script>

    <script src="/Static/js/bootstrap_notify.min.js"></script>
    <script src="/Static/js/lodash.min.js?>"></script>
    <script src="/Static/js/helper.js"></script>
</head>

<body>
    <div class=container>
        <? if(isset($top)) echo $top ?>
        <? if(isset($left)) echo $left ?>
        <?= $content ?>
        <? if(isset($right)) echo $right ?>
        <? if(isset($foot)) echo $foot ?>
    </div>
</body>
</html>