<?

use Project\Aist\Admin\Content\ContentAdmin;
use Admin\Controllers\MenuController;
use Project\Aist\Admin\Action\User\Data\UserPageDataAction;
use Admin\Modules\GetXavierHeaderInfoAction;
use Core\Module\User\User;
use Core\Module\User\UserAccess;

          /*  'user' => UserPageDataAction::get_data(),
            'xavier' => GetXavierHeaderInfoAction::init(),
*/
$user = UserPageDataAction::get_data(); #pred($user);
$profile_image = ($user['image_id'] === 0) ? '/Project/Aist/Admin/Template/Images/Avatar/admin_icon.png' : '/'. $user['image_dir'] .'/'. $user['image_item_id_list']['preview']['id'];

$xi = GetXavierHeaderInfoAction::init(); #pred($xi); pred(User::is_login());

if(loc) $dblink = 'http://pga/redirect.php?subject=database&server=127.0.0.1%3A5432%3Aallow&database='. \Config::$db['name']; else $dblink = site_url .'/pga/redirect.php?subject=database&server=127.0.0.1%3A5432%3Aallow&database='. \Config::$db['name'];
?>

<!DOCTYPE html>
<html lang=ru>
<head>
    <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
    <title><?= ContentAdmin::get_project_name() ?></title>
    <link rel='apple-touch-icon' sizes='57x57' href='/Project/Aist/Admin/Template/Images/Favicon/apple-icon-57x57.png'>
    <link rel='apple-touch-icon' sizes='60x60' href='/Project/Aist/Admin/Template/Images/Favicon/apple-icon-60x60.png'>
    <link rel='apple-touch-icon' sizes='72x72' href='/Project/Aist/Admin/Template/Images/Favicon/apple-icon-72x72.png'>
    <link rel='apple-touch-icon' sizes='76x76' href='/Project/Aist/Admin/Template/Images/Favicon/apple-icon-76x76.png'>
    <link rel='apple-touch-icon' sizes='114x114' href='/Project/Aist/Admin/Template/Images/Favicon/apple-icon-114x114.png'>
    <link rel='apple-touch-icon' sizes='120x120' href='/Project/Aist/Admin/Template/Images/Favicon/apple-icon-120x120.png'>
    <link rel='apple-touch-icon' sizes='144x144' href='/Project/Aist/Admin/Template/Images/Favicon/apple-icon-144x144.png'>
    <link rel='apple-touch-icon' sizes='152x152' href='/Project/Aist/Admin/Template/Images/Favicon/apple-icon-152x152.png'>
    <link rel='apple-touch-icon' sizes='180x180' href='/Project/Aist/Admin/Template/Images/Favicon/apple-icon-180x180.png'>
    <link rel='icon' type='image/png' sizes='192x192'  href='/Project/Aist/Admin/Template/Images/Favicon/android-icon-192x192.png'>
    <link rel='icon' type='image/png' sizes='32x32' href='/Project/Aist/Admin/Template/Images/Favicon/favicon-32x32.png'>
    <link rel='icon' type='image/png' sizes='96x96' href='/Project/Aist/Admin/Template/Images/Favicon/favicon-96x96.png'>
    <link rel='icon' type='image/png' sizes='16x16' href='/Project/Aist/Admin/Template/Images/Favicon/favicon-16x16.png'>
    <link rel='manifest' href='/Project/Aist/Admin/Template/Images/Favicon/manifest.json'>
    <meta name='msapplication-TileColor' content='#ffffff'>
    <meta name='msapplication-TileImage' content='/Project/Aist/Admin/Template/Images/Favicon/ms-icon-144x144.png'>
    <meta name='theme-color' content='#ffffff'>

    <meta name='viewport' content='width=1480, user-scalable=yes'>

    <link rel=stylesheet href='/Static/fonts/roboto.css'/>
    <link rel=stylesheet href='/Static/fonts/roboto_condensed.css'/>
    <link rel=stylesheet href='/Static/fonts/material_icons.css'/>

    <link rel=stylesheet href='/Static/css/default.css'/>

    <link rel=stylesheet href='/Static/packs/css/fa4.3.0.min.css'/>
    <link rel=stylesheet href='/Static/packs/css/all.min.css'/>
    <link rel=stylesheet href='/Static/css/bootstrap.min.css'/>
    <link rel=stylesheet href='/Static/css/bootstrap_notify.css'/>
    <link rel=stylesheet href='/Static/css/animate.css'/>

    <link rel=stylesheet href='/Static/css/dialog_block.css'/>
    <link rel=stylesheet href='/Static/css/style_new.css'/>
    <link rel=stylesheet href='/Static/css/style_neww.css'/>
    <link rel=stylesheet href='/Static/css/style_stand.css'/>
    <link rel=stylesheet href='/Static/packs/css/all.min.css'/>
    <link rel=stylesheet href='/Static/css/root.css'/>

    <script>
        cl = console.log
        loc = location.host === 'aist.loc' ? true : false;
        rp = '<?= RP ?>';
        erp = '<?= ERP ?>';
        pages = {};
    </script>

    <script src='/Static/js/jquery-3.1.1.min.js?'></script>
    <script src='/Static/js/jquery.extendext.min.js'></script>
    <script src='/Static/js/system/config.js'></script>

    <script src='/Static/js/bootstrap.min.js'></script>
    <script src='/Static/js/bootstrap_notify.min.js'></script>
    <script src='/Static/js/lodash.min.js?>'></script>
    <script src='/Static/js/helper.js'></script>
</head>
<? #pred(321) ?>
<body>
    <div id=all>
        <div id=header>
            <a href=/ id=logo></a>
            <div id=header_controls>
                <div id=device_number class=header_controls_item>
                    <div class=header_controls_coll style=opacity:0.7;><? if(User::is_login()): ?>Комплекс: <?= (empty($xi['name']) ? '-' : $xi['name']) ?><? endif ?></div>
                    <? if(UserAccess::$is_root): ?><div class=header_controls_coll style='opacity:.7'>DB: <a style=color:cornflowerblue href='<?= $dblink ?>'><?= \Config::$db['name'] ?></a></div><? endif ?>
                </div>
                <? # if(!data['is_promo_radar']){ ?>
                    <div id=device_address class=header_controls_item>
                        <div class=header_controls_coll style=opacity:0.7;>Адрес:</div>
                        <div class=header_controls_coll><?= $xi['address'] ?></div>
                    </div>
                <? ### if(!data['is_promo_radar']){ ?>
            </div>
            <? if(User::is_login()): ?>
                <div id=header_profile class=header_profile>
                    <div id=header_profile_image style='background:url("<?= $profile_image ?>") 50% 50% no-repeat; background-size: cover;'></div>
                    <div id=header_profile_login><?= $user['login'] ?></div>
                </div>
            <? endif ?>
        </div>
        <br/>
        <br/>
        <br/>
        <?# $lmenu ?>
        <? #(new MenuController())->showlmenu() ?>
        <? if(User::is_login()): ?><?= (new MenuController())->getlmenu() ?><? endif ?>
        <div class=container-fluid style=margin-left:45px>
            <? if(isset($top)) echo $top ?>
            <? if(isset($left)) echo $left ?>
            <?= $content ?>
            <? if(isset($right)) echo $right ?>
            <? if(isset($foot)) echo $foot ?>
        </div>
    </div>
    <div id=worktime></div>
    <!-- <div id=bg_load><div id=load_icon></div><div id=load_percent></div></div> -->
</body>
</html>