<?php

use Core\Module\User\UserAccess;

#pred($this);Board operation parameters
$res = &$this->res;
#pred($this->params);
$jsrc = substr(__DIR__, strlen(DR)) .'/'. pathinfo(__FILE__)['filename'] .'.js'; #pre($jsrc);
#pred($res['data']['log_du']);
?>
<style>
    .external {
    display: table;
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 100%;
    }
    .middle {
    display: table-cell;
    vertical-align: middle;
    }
    .internal {
    margin-left: auto;
    margin-right: auto;
    width: 100%;
    }
</style>
 <div class="external">
      <div class="middle">
        <div class="internal">
            <div class=row styler=position:relative;top:50px>
                <div class=col-xs-4></div>
                <div class='col-xs-3 center'>
                    <div class='ib center' style=position:relative;>
                        <div style='margin: 0; z-index:333' id=authn_block class=authn_block>
                            <div id="authn_title" class="block_title">Авторизация</div>
                            <div id="authn_login_block" class="authn_row" styler="margin:0;height:0;">
                                <!--<div id="authn_login_label" class="input_label">log</div>-->
                                <input placeholder=Логин title=login type="text" id="authn_login_text" name="login" class="input_text"/>
                            </div>
                            <div id="authn_password_block" class="authn_row" styler="margin: 0; height: 0;">
                                <!--<div id="authn_password_label" class="input_label">pass</div>-->
                                <input placeholder=Пароль type="password" id="authn_password_text" name="password" class="input_text" value="" />
                            </div>
                            <div id="authn_keep_block" class="authn_row" styler="margin: 0; height: 0;">
                                <div id="authn_keep_button">
                                    <div id="authn_keep" class="authn_keep_active"></div>
                                    <div id="authn_keep_label">Запомнить меня</div>
                                </div>
                                <!--<div id="authn_forgot_button">forg</div>-->
                            </div>
                            <div id="auth_submit_block" class=auth_row styler="opacity: 1; margin: 0; height: 0;">
                                <button class="btn aist_btn auth_btn" style=width:100%>Войти</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class=col-xs-4></div>
            </div>
        </div>
      </div>
    </div>
<!-- user-select: none;
<div id="authn_password_block" class="authn_row" style="margin: 0; height: 0;">
    <div id="authn_password_label" class="input_label">pass</div>
    <input type="password" id="authn_password_text" name="password" class="input_text" value="" />
</div>
<div id="authn_keep_block" class="authn_row" style="margin: 0; height: 0;">
    <div id="authn_keep_button">
        <div id="authn_keep" class="authn_keep_active"></div>
        <div id="authn_keep_label">keep</div>
    </div>
    <div id="authn_forgot_button">forg</div>
</div>
<div id="authn_submit_block" class="authn_row" style="margin: 0; height: 0;">
    <div id="authn_submit_button" class="submit_button" style="margin-bottom: 0">sav</div>
</div>
-->


<!--
<div id="authn_email_block" class="authn_row" style="margin: 0; height: 0;">
<div id="authn_email_label" class="input_label">'+stripSlashes(lang_obj['email'])+'</div>
<input type="text" id="authn_email_text" class="input_text" value="" />
</div>
<div id="authn_forgot_submit_block" class="authn_row" style="margin: 0; height: 0;">
            if(OS.isMobile){
    <div id="authn_forgot_submit_button" class="submit_button" style="">'+lang_obj['forgot']+'</div>
    <div id="authn_forgot_cancel_button" class="submit_button" style="margin-bottom: 0">'+lang_obj['cancel']+'</div>
            }
            else{
    <div id="authn_forgot_submit_button" class="submit_half_button" style="width: calc(50% - 1%); margin-right: 0;">'+lang_obj['forgot']+'</div>
    <div id="authn_forgot_cancel_button" class="submit_half_button" style="width: calc(50% - 1%); margin-left: 2%;">'+lang_obj['cancel']+'</div>
            }
</div>
<div id="authn_pas1_block" class="authn_row"+(page_object.action.authn.action.reset.is_reset?'':' style="margin: 0; height: 0;">
    <div id="authn_pas1_label" class="input_label">'+stripSlashes(lang_obj['pas1'])+'</div>
    <input type="password" id="authn_pas1_text" class="input_text" value="" />
</div>
<div id="authn_pas2_block" class="authn_row"+(page_object.action.authn.action.reset.is_reset?'':' style="margin: 0; height: 0;">
    <div id="authn_pas2_label" class="input_label">'+stripSlashes(lang_obj['pas2'])+'</div>
    <input type="password" id="authn_pas2_text" class="input_text" value="" />
</div>
<div id="authn_reset_submit_block" class="authn_row"+(page_object.action.authn.action.reset.is_reset?'':' style="margin: 0; height: 0;">
            if(OS.isMobile){
    <div id="authn_reset_submit_button" class="submit_button" style="">'+lang_obj['save']+'</div>
    <div id="authn_reset_cancel_button" class="submit_button" style="margin-bottom: 0">'+lang_obj['cancel']+'</div>-->

<!--
            <button id="authn_reset_submit_button" class="submit_half_button" style="width: calc(50% - 1%); margin-right: 0;">save</button>
            <button id="authn_reset_cancel_button" class="submit_half_button" style="width: calc(50% - 1%); margin-left: 2%;">cancel</button>>-->

<script src=<?= $jsrc ?>></script>