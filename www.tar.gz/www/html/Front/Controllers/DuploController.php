<?php

namespace Front\Controllers;

use Core\Modules\Controller\AdminController;
use Core\Modules\Dir;
use Admin\Modules\DuploFillSXML;
use Admin\Modules\DuploXMLParse;
use Front\Modules\Controller;
use Admin\Modules\Duplo;


class DuploController extends Controller { # /Admin/Controllers

    public $offence_list = [
        'none' => 'Без нарушений.',
        'with_offence' => 'С нарушением',
        'stop_line' => 'Статья 12.12. ч.2. Проезд на запрещающий сигнал светофора или на запрещающий жест регулировщика.',
        'route_vehicles' => 'Статья 12.17.ч.1.1. Движение ТС по полосе для маршрутных ТС или остановка на указанной полосе в нарушение ПДД.',
        'lane' => 'Статья 12.16.ч.1 Несоблюдение требований, предписанных дорожными знаками или разметкой проезжей части дороги.',
        'intersection_double_solid_lane' => 'Статья 12.16.ч.1 Несоблюдение требований, предписанных дорожными знаками или разметкой проезжей части дороги.',
        'speed_20' => 'Статья 12.9. ч.2 Превышение установленной скорости движения на величину более 20, но не более 40 километров в час',
        'speed_40' => 'Статья 12.9. ч.3 Превышение установленной скорости движения на величину более 40, но не более 60 километров в час',
        'speed_60' => 'Статья 12.9. ч.4 Превышение установленной скорости движения на величину более 60, но не более 80 километров в час',
        'speed_80' => 'Статья 12.9. ч.5 Превышение установленной скорости движения на величину более более 80 километров в час',
        'lane_opposite' => 'Статья 12.15 ч.4. Выезд в нарушение Правил дорожного движения на полосу, предназначенную для встречного движения, либо на трамвайные пути встречного направления.',
        'no_stop' => 'Статья 12.19. Нарушение правил остановки транспортных средств.',
        'no_parking' => 'Статья 12.19. Нарушение правил стоянки транспортных средств.',
        'reversal' => 'Статья 12.16 ч.2. Поворот налево или разворот в нарушение требований, предписанных дорожными знаками или разметкой проезжей части дороги.'
    ];

    public $duplo_data;
    public $duplo;
    public $error = [];
    public $log = [];
    public $jfs_data;
    public $last_page = false;

    public function __construct($action = null){
        parent::__construct(); #pred($_POST); pred($action);
        $jid = ERP;
        if(!$action) $this->page();
    }

    function page(){
        $post = file_get_contents('php://input'); #pre($_POST); pre($_FILES); pred($post);
        $dp = DR .'/External';
        if(!is_dir($dp)) er('DP not exist:'. $dp);
        $dp = DR .'/External/DuploXMLsTest';
        if(!is_dir($dp)){ #$perm = 0777; pre($perm);
            $r = mkdir($dp, 0775); # chmod($dp, 0775);
            if(!$r) pred('Cant create dir!__'. $dp);
        }
        $fp = DR .'/External/DuploXMLsTest/'. date('Y.m.d_H.i.s') .'.xml';
        $r = file_put_contents($fp, $post);
        if(!$r) pred('Cant put file! fp:__'. $fp);
        #chmod($fp, 0664);
        $p = new DuploXMLParse($post);
        $r = $p->check();
        if(!$r) er($r); #        pred($r);
        if(isset($r['tr_checkIn']) && isset($r['tr_checkIn']['v_time_check'])){
            $rend = $this->rend('index'); # pred($rend);
            echo $rend;
            die;
        }
        er($r);
    }

}