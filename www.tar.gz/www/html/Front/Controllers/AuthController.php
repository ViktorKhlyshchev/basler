<?php

namespace Front\Controllers;

use Front\Modules\Controller; # use Core\Modules\Controller\Controller;
use Core\Module\User\UserAccess;
use Common\Models\XavierInfo;
use Core\Module\Db\Db;
use Core\Action\User\Admin\AddAdminSystemAction;
use Core\Module\Exception\PhpException;
use Project\Aist\Admin\Action\User\Admin\UserAdminInviteRegistrationAction;
use Core\Module\User\User;
use Core\Modules\User\UserLogoutAction;
use Core\Module\Token\Token;
use Core\Module\Cookie\Cookie;
use Core\Module\User\UserLogin;
use Admin\Modules\UserAuthProjectAction;

class AuthController extends Controller {

    public function __construct($action = null){

        parent::__construct();

        if(!$action) $action = $this->action; #pred($action);

        if($action === 'refresh') $this->refresh();

        if(!$action) $this->page();

        if(ajax){
            if($action === 'login') $this->login();
        }
    }

    function get_data(){
        $res = &$this->res;
    }

    function page(){

        $res = &$this->res;
        $this->get_data();
        $rend = $this->rendl('index', 'indexf'); #ok(null, ['rend' => $rend]);
        echo $rend; die;
    }

    function login(){ # UserAuth::add_user_auth

        $data = data();# pred($data);
        $data['login'] = mb_strtolower(trim($data['login']));
        $r = UserAuthProjectAction::init($data['login'], $data['password']);
        if($r['success']) ok();
        er($r); #        pred($r);
    }

    function add_group_noajax($uid = null, $uat_id = null){
        #pre($uat_id);
        # UpdateAdminAccessApi  $user_access_ids = UserAccess::get_user_access_type_name_list($uid);
        $tn = '_user_access';
        $q = ['table' => $tn, 'select' => ['user_access_type_id'], 'where' => ['type' => 0, 'user_id' => $uid]];
        $r = Db::select($q); #pred($r);
        $uats = [];
        foreach($r as $row) $uats[] = $row['user_access_type_id']; #pred(in_array($uat_id, $uats));
        if(in_array($uat_id, $uats)) ok();
        $value_list[] = ['user_id' => $uid, 'user_access_type_id' => $uat_id, 'date_create' => 'NOW()', 'date_update' => 'NOW()', 'type' => 0];
        $q = ['table' => $tn, 'values' => $value_list];
        $r = Db::insert($q);
        return $r;
    }

    function add_group($uid = null, $uat_id = null){
        if(!$uid) $uid = (int)$this->req->post('user_id');
        if(!$uat_id) $uat_id = (int)$this->req->post('uat_id');
        #pre($uat_id);
        # UpdateAdminAccessApi  $user_access_ids = UserAccess::get_user_access_type_name_list($uid);
        $tn = '_user_access';
        $q = ['table' => $tn, 'select' => ['user_access_type_id'], 'where' => ['type' => 0, 'user_id' => $uid]];
        $r = Db::select($q); #pred($r);
        $uats = [];
        foreach($r as $row) $uats[] = $row['user_access_type_id']; #pred(in_array($uat_id, $uats));
        if(in_array($uat_id, $uats)) ok();
        $value_list[] = ['user_id' => $uid, 'user_access_type_id' => $uat_id, 'date_create' => 'NOW()', 'date_update' => 'NOW()', 'type' => 0];
        $q = ['table' => $tn, 'values' => $value_list];
        $r = Db::insert($q);

        $this->get_data();
        $rend = $this->rend('tbody', $this->res);

        if($r) ok(['rend' => $rend]);
    }

    function remove_group(){
        $uid = (int)$this->req->post('user_id');
        $uat_id = (int)$this->req->post('uat_id');
        #pre($uat_id); # UpdateAdminAccessApi  $user_access_ids = UserAccess::get_user_access_type_name_list($uid);
        $tn = '_user_access';
        $q = ['table' => $tn, 'select' => ['id', 'user_access_type_id'], 'where' => ['type' => 0, 'user_id' => $uid]];
        $r = Db::select($q); #pred($r);
        $uats = [];
        foreach($r as $row) $uats[] = $row['user_access_type_id'];
        if(!in_array($uat_id, $uats)) ok();#        pred($r);
        foreach($r as $row){
            if($row['user_access_type_id'] === $uat_id){
                Db::pseudo_delete_from_id_list([$row['id']], '_user_access', 0);
                $this->get_data();
                $rend = $this->rend('tbody', $this->res);
                ok(['rend' => $rend]);
            }
        }
    }

    function apply(){
        $data = data(); #pred($data);
        #$this->res['data'] = XavierInfo::get_all_data(); #pred($this->res['data']);
        $id = array_shift($data); #pred($data);
        unset($data['date_update']);
        #pred(123);
        $r = XavierInfo::update_bid($id, $data); #pred($this->res['data']);
        if($r) ok($r); else er($r);
    }
}