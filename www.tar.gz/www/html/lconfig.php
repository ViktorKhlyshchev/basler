<?php

$config = [
    'db' => [ #'ftype'       => 'postgresql', # full type
        'type'       => 'pgsql', # short type
        'host'       => 'localhost', # 127.0.0.1
        'port'       =>  5432,
        'name'       => 'aist',
        'login'      => 'aist',
        'password'   => 'Berlin1945',
    ],
    'servername' => 'aist1',
    'saddr' => '10.0.1.1',
   # 'cafap_remove_temp_source_dir_for_tar' => false,
    #'upload_speed_quality_min_for_offences' => 21,
    #'upload_speed_quality_min_for_non_offences' => 1,
    #'upload_forbid_not_detected_number' => true,
    #'upload_forbid_lane_opposite' => true
    #'upload_forbid_lane' => true,
    #'onethread_upload' => true
    #'remove_all' => false,
    'journal_virgin' => true,
    #'upload_duplo' => true,
    'show_all_menu' => true,
    'upload_duplo_save_resp_to_log' => true,
    'test_api_key' => 'a5ed0e6ac07c8698c3db8541cbcacb3031ea6f73'
];

foreach($config as $k => $v) if(isset(self::${$k})) self::${$k} = $v; #pred(self::$car_number_no_detect_ftp_send);

#if(\Config::$is_debug) error_reporting(E_ALL);
#if(\Config::$is_debug) error_reporting(E_ALL & ~E_WARNING);
#error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE);
error_reporting(E_ALL);