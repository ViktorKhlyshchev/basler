<?php

namespace CLI\Modules\Mailing; # namespace Project\Aist\Admin\Shell\Mailing;

use Core\Module\Email\EmailSend;
use Core\Module\Email\EmailValidation;
use Core\Module\Exception\ParametersException;
use Core\Module\Response\ResponseSuccess;
use Core\Module\User\UserEmail;
use Core\Module\User\UserLogin;
use CLI\Modules\Mailing\Mailing;
use CLI\Modules\Mailing\MailingItem;

class MailingShell { # Project/Aist/Admin/Shell/Mailing/MailingShell.php  # sudo -u www-data /usr/bin/php /var/www/public/index.php "action = mailing" "mailing_id = 1"

    private static $mailing_id;
    private static $title;
    private static $message;
    private static $start = 0;
    private static $len = 100;
    private static $timeout_count = 100;
    private static $timeout_send = 3600;

    private static function is_sent_to_user(int $user_id = null){
        if(empty($user_id)){ $error = ['title' => ParametersException::$title, 'info' => 'User ID is not exists']; throw new ParametersException($error); }
        return MailingItem::isset_user_id($user_id, self::$mailing_id);
    }

    private static function get_email_list(int $start = 0,int $len = 100){
        return UserEmail::get_user_email_list_for_mailing($start,$len);
    }

    private static function add_to_mailing_item(int $user_id = null){
        if(empty($user_id)){ $error = ['title' => ParametersException::$title, 'info' => 'User ID is not exists']; throw new ParametersException($error); }
        MailingItem::add_mailing_item($user_id, self::$mailing_id);
        return true;
    }

    private static function send(string $email = null, string $login = null){
        echo 'Email: "'.$email.'"'."\n";
        if(empty($email)) return false;
        if(empty($login)) return false;
        if(!EmailValidation::is_valid_email($email)) return false;
        $title = self::$title;
        $message = str_replace('%login%',$login, self::$message);
        $message = str_replace("\n","<br />\n",$message);
        return EmailSend::init([$email],$title,$message,\Config::$email_no_replay);
    }

    private static function prepare(){
        Mailing::update_user_all_len(self::$mailing_id);
        $n = 0;
        do {
            echo"Start from ".self::$start."\n";
            $email_list = self::get_email_list(self::$start, self::$len);
            $add_count = 0;
            if(count($email_list) === 0){
                $user_len_data = Mailing::get_user_len(self::$mailing_id);
                echo"\n";
                echo"\n";
                echo"DONE\n";
                echo"Added ".$user_len_data['user_send_len']."/".$user_len_data['user_all_len']."\n";
                return true;
            }
            foreach($email_list as $row){
                $user_id = $row['user_id']; # $user_id = 1;
                if(self::is_sent_to_user($user_id))
                    echo"Already sent to user ID: ".$user_id."\n";
                else{
                    $email = $row['email']; # $email = 'fenicks88@gmail.com';
                    $login = UserLogin::get_user_login($user_id);
                    self::send($email,$login);
                    self::add_to_mailing_item($user_id);
                    Mailing::user_send_len_plus(self::$mailing_id);
                    $user_len_data = Mailing::get_user_len(self::$mailing_id);
                    echo"Sent to user ID: ".$user_id."; ".$user_len_data['user_send_len']."/".$user_len_data['user_all_len']."\n";
                    $add_count ++;
                    $n ++;
                    if($n >= self::$timeout_count){ pre("Sleep timeout: ".self::$timeout_send);
                        $n = 0;
                        sleep(self::$timeout_send);
                    }
                }
            }
            self::$start+= self::$len;
        } while(true);
    }

    public static function init(){ #   \Config::$is_debug = true;
        if(empty($_POST['mailing_id'])){
            $error = ['title' => ParametersException::$title, 'info' => 'Mailing ID is empty'];
            throw new ParametersException($error);
        }
        self::$mailing_id = $_POST['mailing_id'];

        $r = Mailing::get_data(self::$mailing_id);
        if(empty($r)){ $error = ['title' => ParametersException::$title, 'info' => 'Mailing ID is not exists']; throw new ParametersException($error); }
        self::$title = $r['title'];
        self::$message = $r['message'];

        self::prepare();
        $data = ['success' => true];
        return ResponseSuccess::init($data);
    }
}