<?php

namespace CLI\Modules\Mailing; # namespace Project\Aist\All\Module\Mailing;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class MailingItem {

    public static $tn='mailing_item';

    public static function isset_user_id(int $user_id = null, int $mailing_id = null){
        $error_info_list = [];
        if(empty($user_id)) $error_info_list[] = 'User ID is empty';
        if(empty($mailing_id)) $error_info_list[] = 'Mailing ID is empty';
        if(count($error_info_list) > 0){
            $error = [
                'title' => ParametersException::$title,
                'info' => $error_info_list
            ];
            throw new ParametersException($error);
        }
        $where_list = [
            'user_id' => $user_id,
            'mailing_id' => $mailing_id
        ];
        return Db::isset_row(self::$tn,0,$where_list);
    }

    public static function add_mailing_item(int $user_id = null, int $mailing_id = null){
        $error_info_list = [];
        if(empty($user_id)) $error_info_list[] = 'User ID is empty';
        if(empty($mailing_id)) $error_info_list[] = 'Mailing ID is empty';
        if(count($error_info_list) > 0){
            $error = [
                'title' => ParametersException::$title,
                'info' => $error_info_list
            ];
            throw new ParametersException($error);
        }
        $q = [
            'table' => self::$tn,
            'values' => [
                'user_id' => $user_id,
                'mailing_id' => $mailing_id,
                'date_create' => 'NOW()',
                'date_update' => 'NOW()',
                'type' => 0
            ]
        ];
        $r = Db::insert($q);
        if(count($r) === 0){
            $error = [
                'title' => DbQueryException::$title,
                'info' => 'Mailing item was not add'
            ];
            throw new DbQueryException($error);
        }
        return $r[0]['id'];
    }
}