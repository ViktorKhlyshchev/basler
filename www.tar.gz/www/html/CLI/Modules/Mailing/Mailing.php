<?php

namespace CLI\Modules\Mailing; # namespace Project\Aist\All\Module\Mailing;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;
use Core\Module\User\UserEmail;

class Mailing {

    public static $tn = 'mailing';

    public static function get_data(int $mailing_id = null){

        if(empty($mailing_id)){ $error = ['title' => ParametersException::$title, 'info' => 'Mailing ID is empty']; throw new ParametersException($error); }
        $q = [
            'table' => self::$tn,
            'select' => ['id', 'title', 'message', 'user_send_len', 'user_all_len'],
            'where' => ['id' => $mailing_id, 'type' => 0], 'limit' => 1
        ];
        $r = Db::select($q);
        if(count($r)) return [
            'id' => $mailing_id,
            'title' => $r[0]['title'],
            'message' => $r[0]['message'],
            'user_send_len' => $r[0]['user_send_len'],
            'user_all_len' => $r[0]['user_all_len'],
        ];
    }

    public static function get_user_len(int $mailing_id = null){
        if(empty($mailing_id)){ $error = ['title' => ParametersException::$title, 'info' => 'Mailing ID is empty']; throw new ParametersException($error); }
        $q = ['table' => self::$tn, 'select' => ['user_send_len', 'user_all_len'], 'where' => ['id' => $mailing_id, 'type' => 0], 'limit' => 1];
        $r = Db::select($q);
        if(count($r) === 0) return null;
        return [
            'user_send_len' => $r[0]['user_send_len'],
            'user_all_len' => $r[0]['user_all_len'],
        ];
    }

    public static function user_send_len_plus(int $mailing_id = null){
        if(empty($mailing_id)){
            $error = [
                'title' => ParametersException::$title,
                'info' => 'Mailing ID is empty'
            ];
            throw new ParametersException($error);
        }
        $q = [
            'table' => self::$tn,
            'set' => [
                'user_send_len' => [
                    'function' => 'user_send_len + 1'
                ],
                'date_update' => 'NOW()'
            ],
            'where' => [
                'id' => $mailing_id,
                'type' => 0
            ]
        ];
        if(!Db::update($q)){
            $error = [
                'title' => DbQueryException::$title,
                'info' => 'Mailing was not update'
            ];
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function update_user_all_len(int $mailing_id = null){
        if(empty($mailing_id)){
            $error = [
                'title' => ParametersException::$title,
                'info' => 'Mailing ID is empty'
            ];
            throw new ParametersException($error);
        }
        $user_all_len=UserEmail::get_user_len();
        $q = [
            'table' => self::$tn,
            'set' => [
                'user_all_len' => $user_all_len,
                'date_update' => 'NOW()'
            ],
            'where' => [
                'id' => $mailing_id,
                'type' => 0
            ]
        ];
        if(!Db::update($q)){
            $error = [
                'title' => DbQueryException::$title,
                'info' => 'Mailing was not update'
            ];
            throw new DbQueryException($error);
        }
        return true;
    }
}