<?php

namespace CLI\Modules\Cafap;

use Core\Modules\Dir; # use Common\Modules\Date;
use Configs\DirConfig;
use Core\Module\Encrypt\Hash;
use Core\Module\File\File;
use Core\Modules\Json;
use Common\Modules\ImagePathListAction;
use Project\Aist\Admin\Action\Video\VideoPathListAction;
use Common\Models\UploadServer;
use Common\Models\Journal;
use Common\Models\JournalImage;
use Common\Models\JournalVideo;
use Common\Models\XavierInfo; # use CLI\Modules\PreparingImages\PrepareImages;
use CLI\Modules\PreparingImages\PrepareImagesAction;
use Common\Models\Zone;
use Common\Models\Packing;
use Common\Models\PackingQ;
use Common\Models\Processing;
use Core\Module\Geo\Country;
use Common\Modules\Date;

class CafapCreatepackage {

    public $error = false;
    public $jid;
    public $journal_hash;
    public $old_journal_hash;
    public $camera_id;
    public $country_code;
    public $name;
    public $address;
    public $serial_number;
    public $certificate_number_c; # FOR XML
    public $certificate_number_c_date; # FOR XML
    public $certificate_number;
    public $certificate_date;
    public $timezone;
    public $car_number;
    public $traffic_violation;
    public $timestamp;
    public $speed;
    public $speed_xml;
    public $speed_quality;
    public $join_count;
    public $point_recognized_count;
    public $speed_max;
    public $coords;
    public $cafap_ids = [];

    public $video_list = [];

    public $image_list = [];

    public $image_width;
    public $image_height;
    public $dir_package;
    public $dir_package_source;
    public $dir_package_keys;
    public $dir_package_tar;
    public $dir_gpackage;
    public $date_create;
    public $tar_fp;
    public $direction;
    public $lane;
    public $is_plate_invert;
    public $files_paths = [];

    public $dir_global_keys;
    public $private_key_path;
    public $public_key_path;
    public $track_number_list = [];

    public $image_prepared_combo_size;
    public $direction_up;
    public $direction_down;
    public $combo_car_number_coords = [];

    public $customer_config = [];

    public $is_for_download;
    public $recognize_type;
    public $car_type;
    public $errors = [];
    public $aerrors = [];
    public $log = [];
    public $flog = [];
    public $keys_created = [];
    public $keys_sort = [];
    public $sets;

    function set_error($error = null){ $this->aerrors[] = $error; pre($error);
        if(!$error) $errors[] = $error; pred($error);  #if(loc)pred($this->errors); else pre($this->errors);
        Journal::update_error($this->jid, implode('|', $this->errors));
        Packing::update_error($this->id, implode('|', $this->errors));
        Processing::update_error($this->jid, implode('|', $this->errors));
        $this->errors = [];
    }

    function set_cerror($error = null){ $this->aerrors[] = $error; pre('JID:'. $this->jid); pre($error);
        #unset($this->track_number_list); unset($this->image_list); unset($this->car_number_coords); unset($this->files_paths); unset($this->video_list); unset($this->log); unset($this->combo_car_number_coords);
        #pred(debug_backtrace());pred($this->errors);
        if($error) $this->errors[] = $error; #pred($this->errors);
        #if(loc)pred(debug_backtrace());
        if(loc) pre($this->errors); else pre($this->errors);
        Journal::update_error($this->jid, implode("\n", $this->errors));
        PackingQ::update_error($this->id, implode("\n", $this->errors));
        # Processing::update_cerror($this->jid, implode("\n", $this->errors));
        $this->errors = [];
    }

    function __construct(array $data = [], array $serv = [], &$cpmt){ #pred($data);

        $this->id = $data['id'];
        $this->jid = $data['jid'];
        $this->log[] = 'CafapCreatepackage INIT start procID:'. $cpmt->proc_id;
        Packing::update_log($this->id, implode("|\n", $this->log));
        $this->serv = $serv;
        $this->sets = $cpmt->sets;
    }

    function create(){

        if(!$this->set_xavier_info()) return;
        if(!$this->check_source_image_files()){ $this->set_cerror('!check_source_image_files() Journal have image problem with image list '. __FUNCTION__); return; }
        if(!$this->set_journal_data()) return;

        $this->log[] = 'b Zone::get_zone_speed_max';
        $this->speed_max = Zone::get_zone_speed_max($this->camera_id); # was set_zone_data(){
        $this->set_hash();
        $this->set_customer_config();
        if(!$this->set_cafap_ids()){ pre('Fail $this->set_cafap_ids()'); return; }
        if(!$this->prepare_dir()){ $this->set_cerror('!prepare_dir()'); return;} #$this->log[] = 'b create_image_overlay()'; # new CafapImageOverlay($this); # creates prepared_* images in journal_image
        $this->log[] = 'b foreach($this->cafap_ids'; #pred($this->cafap_ids); #Packing::update_log($this->id, implode("|\n", $this->log));
        if(!$this->set_image_list()){ $this->set_cerror(__CLASS__ .'::'. __FUNCTION__. ': Cant set_image_list() #138'); return; }
        if(!$this->set_video_list()){ $this->set_cerror('Cant set_video_list() '. __FUNCTION__); return; } # http://192.168.2.73/api/json/create_journal_box_test?journal_id = 10127&is_test =
        $this->road_lane_number = JournalImage::get_road_lane_number($this->jid); #pred($this->sets['cafap_pack']);

        if($this->speed > $this->sets['common_pack']['max_speed_for_speed_na'] || $this->speed < 0){
            $this->speed_xml = 'n/a';
        } else {
            if($this->speed_quality < $this->sets['common_pack']['min_speed_quality_for_speed_na']){
                if($this->speed > $this->sets['zone']['speed_permissible']) $this->speed_xml = 'n/a';
            }
        }

        if($this->speed_xml !== 'n/a') $this->speed_xml = $this->speed; #if($this->speed_xml === 'n/a') $this->speed_xml = 0; else $this->speed_xml = $this->speed;

        if(loc){
            if($this->sets['cafap_pack']['need_xml']){
                $cxml = new CafapXML($this); #pred($cxml); #$this->xml =  $this->set_xml_test();            #pred($this->file_list);
                if(!$cxml->xml){ $this->set_cerror('Cant new CafapXML() '. __FUNCTION__); return; }
            }
            if($this->sets['cafap_pack']['need_json']){ if(!$this->set_json()){ $this->set_cerror('Cant set_json() '. __FUNCTION__); return; } }
        } else {
            if($this->sets['cafap_pack']['need_xml']){
                $cxml = new CafapXML($this);
                if(!$cxml->xml){ $this->set_cerror('Cant new CafapXML() '. __FUNCTION__); return; }
            }
            if($this->sets['cafap_pack']['need_json']){
                if(!$this->set_json()){ $this->set_cerror( 'Cant set_json() '. __FUNCTION__); return; }
            }
        }
        if(!$this->set_keys()){ $this->set_cerror('!set_keys()'); return; }
        if(!$this->create_tar()){ $this->set_cerror('!create_tar()'); return; } # copy($this->tar_fp, DR .'/1111111111.tar'); #echo 'copeid';  #pred($data); # /mnt/data/0git/aist.loc/Resource/Box/21/1/tar/ace331456fbfcb5a78d67d3b99ba5496124cbcd3.tar $this->log[] = 'b Packing::update_log'; #Packing::update_log($this->id, implode("|\n", $this->log));
        $this->log[] = 'CafapCreatepackage ended';
        Packing::update_log($this->id, implode("|\n", $this->log));
        return $this->tar_fp;
    }

    function prepare_dir(){

        $key_id = $this->serv['key_id'];
        if(empty($key_id)){ $this->set_cerror('empty($key_id)'); return; }

        if(!Dir::create_dirn(DirConfig::$dir_cafap_package_tar)) er('cant create dir '. __FUNCTION__ .'#1 dir:__'. DirConfig::$dir_cafap_package_tar);

        $this->log[] = 'prepare_dir()';  #$this->dir_package = Date::get_date_paths($this->date_create, DirConfig::$dir_cafap_package);
        $this->dir_gpackage = DR .'/'. DirConfig::$dir_cafap_package_temp .'/'. $this->jid;
        $this->dir_package = DR .'/'. DirConfig::$dir_cafap_package_temp .'/'. $this->jid .'/'. $key_id; #pre($this->dir_package);

        #if(\Config::$dir_package_logging){ Dir::create_dir(DirConfig::$dir_log .'/cba/'); $lp = Dir::get_global_dir(DirConfig::$dir_log .'/cba/'. $this->jid .'.log'); file_put_contents($lp, $this->dir_package . $this->journal_hash."\n", FILE_APPEND); }
        if(is_dir($this->dir_package)) Dir::remove_dirn($this->dir_package);
        $r = Dir::create_dirn($this->dir_package);
        if(!$r){ $error = error_get_last(); $error['message'].= '|cant create dir '. __FUNCTION__ .'#2!! dir:__'. $this->dir_package; $this->set_cerror(implode('|', $error)); return; }

        $this->dir_package_source = $this->dir_package .'/source';
        $r = Dir::create_dirn($this->dir_package_source);
        if(!$r){ $error = error_get_last(); $error['message'].= '|cant create dir '. __FUNCTION__ .'#2!! dir:__'. $this->dir_package_source; $this->set_cerror(implode('|', $error)); return; }

        $this->dir_package_keys = $this->dir_package .'/keys';
        $r = Dir::create_dirn($this->dir_package_keys);
        if(!$r){ $error = error_get_last(); $error['message'].= '|cant create dir '. __FUNCTION__ .'#2!! dir:__'. $this->dir_package_keys; $this->set_cerror(implode('|', $error)); return; }

        $this->dir_global_keys = DirConfig::$dir_key;
        $r = Dir::create_dirn($this->dir_global_keys);
        if(!$r){ $error = error_get_last(); $error['message'].= '|cant create dir '. __FUNCTION__ .'#2!! dir:__'. $this->dir_global_keys; $this->set_cerror(implode('|', $error)); return; }

        $dir_key = Dir::get_global_dirn(DirConfig::$dir_key .'/'. $key_id);
        $this->private_key_path = $dir_key .'/private.pem'; #die;
        $this->public_key_path = $dir_key .'/public.pem'; # if(nl){ echo 'private key path: '. $this->private_key_path."\n";  echo 'public key path: '. $this->public_key_path."\n\n"; }
        return true;
    }

    function set_journal_data(){ #pred($this->check_source_image_files());

        $this->log[] = 'set_journal_data()';
        $r = Journal::get_one_for_cafap($this->jid); #pred($r);
        if(empty($r)){ $this->set_cerror('Journal data is empty '. __FUNCTION__); return;}
        #$this->old_journal_hash = $r['hash'];
        $this->camera_id = $r['camera_id'];
        $this->country_code = empty($r['country_id']) ? null : Country::get_country_code_from_country_id($r['country_id']);
        $this->car_number = $r['car_number'];
        $this->car_type = $r['car_type'];
        $this->traffic_violation = $r['traffic_violation'];
        #$this->date_traffic_violation_raw = $r['date_traffic_violation'];
        #pre($r['date_traffic_violation']); $this->date_traffic_violation = Date::get_ms_from_date_time_ms($r['date_traffic_violation']);
        #$this->traffic_violation_ts = Date::get_ms_from_date_time_ms($r['date_traffic_violation']);
        $this->date_traffic_violation = $r['date_traffic_violation'];
        $this->traffic_violation_ts = Date::get_ts_from_date_time_ms($r['date_traffic_violation']);        #pre($this->traffic_violation_ts);        pred((int)$this->traffic_violation_ts);
        #pred((int)$this->timezone);        pre($this->timezone);
        #$interval = new \DateInterval("PT20M"); # P1Y pre($interval);$interval = new DateInterval("PT20M"); # P1Y  pred($interval);
        if(strpos($this->timezone, ':') !== false){
            $date1 = \DateTime::createFromFormat('H:i', $this->timezone); #$date2 = \DateTime::createFromFormat('H:i', '00:00'); #           pre($date1);            pre($date2);
            $interval = $date1->diff(\DateTime::createFromFormat('H:i', '00:00')); #pred($interval);
            $this->timestamp = (int)$this->traffic_violation_ts + $interval->h * 3600 + $interval->i * 60; #pred($this->timestamp);
        } else {
            $this->timestamp = (int)$this->traffic_violation_ts + (int)$this->timezone * 3600; #pred($this->timestamp);
        } #$this->xmltimestamp = (int)$this->traffic_violation_ts;

        $this->traffic_violation_date = \DateTime::createFromFormat('U', $this->timestamp); #pred($this->traffic_violation_date);
        $this->speed = (int)$r['speed'];
        $this->speed_quality = (int)$r['speed_quality'];
        $this->join_count = (int)$r['join_count'];
        $this->point_count = (int)$r['point_count'];
        $this->point_recognized_count = (int)$r['point_recognized_count'];
        $this->date_create = $r['date_create'];
        $this->recognize_type = $r['recognize_type'];
        $this->lane = $r['lane'];
        $this->is_plate_invert = $r['is_plate_invert']; # pre($this->jid);pred($r);
        if($this->traffic_violation == 'no_stop' || $this->traffic_violation == 'no_parking') $this->speed = 0;
        return true;
    }

    function set_hash(){

        $this->log[] = 'set_hash()';

        $hash_list = [
            $this->serial_number,
            $this->certificate_number,
            $this->jid,
            $this->date_create,
            $this->timestamp, # this is why always diff
            time(), # this is why always diff mt_rand(0, time()) # this is why always diff
        ];
        $this->journal_hash = Hash::get_sha1_encode(implode(':', $hash_list)); #Journal::update_journal_hash($this->jid, $this->journal_hash);
        Packing::set_hash($this->id, $this->journal_hash);
        return true;
    }

    function set_customer_config(){

        $this->log[] = 'set_customer_config()';

        $r = XavierInfo::get_list_from_group('customer');
        if(empty($r)){ $this->set_cerror('!get_list_from_group(customer)'); return; }
        foreach($r['customer'] as $key => $value){
            if(mb_substr($key, 0, 3) == 'is_' || mb_substr($key, 0, 5) == 'need_')
                $this->customer_config[$key] = (bool)$value;
            else
                $this->customer_config[$key] = $value;
        } #pred($this->customer_config);
        return true;
    }

    function set_cafap_ids(){ #pred(self::$is_for_download);

        $this->log[] = 'set_cafap_ids()';
        $r = UploadServer::get_cafap(['need_send' => 1, ['union' => 'or', 'column' => 'need_send', 'value' => 2]]);
        if(empty($r)) return;
        foreach($r as $row) if(!empty($row['key_id'])) $this->cafap_ids[] = ['id' => $row['id'], 'key_id' => $row['key_id']]; #  #pred(self::$ftp_id_list);
        if(empty($this->cafap_ids)) return;
        return true;
    }

    function set_keys(){  #if(!loc){

        $q_list = [];
        if(!file_exists($this->private_key_path)) $q_list[] = 'openssl genrsa -out '. $this->private_key_path .' 1024';
        if(!file_exists($this->public_key_path)) $q_list[] = 'openssl rsa -in '. $this->private_key_path .' -pubout > '. $this->public_key_path;
        if(!file_exists($this->private_key_path)){ $er = 'Private key path is empty '. $this->private_key_path .'|'. __FUNCTION__; $this->set_cerror($er); return; }
        if(!file_exists($this->public_key_path)){ $er = 'Public key path is empty '. $this->private_key_path .'|'. __FUNCTION__; $this->set_cerror($er); return; }
        if(count($q_list) > 0) foreach($q_list as $q) exec($q); #if(nl){ echo $this->private_key_path."\n"; echo $this->public_key_path."\n\n";}

        $sign_fp = $this->dir_package_source .'/'. $this->journal_hash .'.sign'; #pred($sign_fp);
        $q_list = [];
        $q_list[] = 'cat '.implode(' ', $this->files_paths) .' > '. $this->dir_package_keys .'/'. $this->journal_hash .'.bin';
        $q_list[] = 'openssl dgst -sha1 -sign '. $this->private_key_path .' -out '. $sign_fp .' '. $this->dir_package_keys .'/'. $this->journal_hash .'.bin'; #exec($q_list[0]);pred($q_list);
        foreach($q_list as $q) @exec($q);/*
        foreach($q_list as $q) @exec($q, $o, $rc);
        foreach($q_list as $q){
            $r = @exec($q, $o, $rc);
            pre('==============44441');
            pre($r);
            pre('==============44442');
            pre($o);
            pre('==============44443');
            pre($rc);
            pre('==============44444');
        }
        #pred(4344);*/#pred($q_list);
        #pred(filesize($sign_fp));
        if(!filesize($sign_fp)){ $er = 'Private or public key cantbe read! prk:_'. $this->private_key_path .'|puk:_'. $this->public_key_path .'|'. __FUNCTION__; $this->errors[] = $er; return; }
        $this->files_paths[] = $sign_fp;
        #$this->files_paths[] = $this->journal_hash .'.sign';
        #foreach($this->files_paths as $index => $file_path) $this->files_paths[$index] = Dir::get_global_dirn($file_path); # if(nl){ pre($this->jid); pre($this->traffic_violation); }
        #if(nl) pre($this->files_paths);
        return true;
    }

    function create_tar(){  #$this->tar_fp = $this->dir_package_tar .'/'. $this->journal_hash .'.tar';

        $ymdp = Date::get_ymd_path($this->traffic_violation_date); #pred($this->files_paths);
        $this->tar_dp = DR .'/'. DirConfig::$dir_cafap_package_tar .'/'. $ymdp;

        if(!Dir::create_dirn($this->tar_dp)) er('cant create dir for tar '. __FUNCTION__ .'#111 dir:__'. $this->tar_dp);

        $this->tar_fp = $this->tar_dp .'/'. $this->journal_hash .'.tar';
        #$this->tar_fp = $this->tar_dp .'/'. $this->journal_hash .'.phar';
        #$files_basenames = [];        foreach($this->files_paths as $fp) $files_basenames[] = pathinfo($fp, PATHINFO_BASENAME); #$pd = new \Phar($this->tar_fp);

        $pd = new \PharData($this->tar_fp);
        $r = $pd->buildFromDirectory($this->dir_package_source); #$pd->compress(\Phar::TAR);

        #pred($this->files_paths);
        #$cmd = 'tar -cvf '. $this->tar_fp .' -C '. $this->dir_package_source .' '. implode(' ', $files_basenames); #pred($cmd); # creating tar
        #$r = shell_exec($cmd); #pred($r);  $this->log[] = $r; #pred( $this->log);
        #$r = Packing::update_log($this->id, implode("|\n", $this->log)); #pred($r); #'b Packing::update_log';
        #if(nl) pre("\nFile list:\n", $this->files_paths);
        #if(nl) pre('tar path: '. $this->tar_fp."\n"); #pre(this->tar_fp);        #pred(file_exists($this->tar_fp));pred($this->files_paths);

        $file_exists = file_exists($this->tar_fp);
        if($file_exists) $fs = (int)filesize($this->tar_fp); else $fs = -1;
        $this->log[] = __CLASS__ .'->'.  __FUNCTION__  .': tarsize:'. $fs .'| tarfp:__'. $this->tar_fp;
        Packing::update_log($this->id, implode("|\n", $this->log)); $this->log = [];

        if(!$file_exists){ $this->set_cerror(__CLASS__ .'->'.  __FUNCTION__  .': JID: '.  $this->jid .' | tar file not exist! '. $this->tar_fp); return; } # '. $this->journal_hash .' | '.
        if($fs < 10){ $this->set_cerror(__CLASS__ .'->'.  __FUNCTION__  .': JID: '.  $this->jid .' | tar have not valid file size: '. $fs .' path: '. $this->tar_fp); $this->tar_fp = null; return; } # Dir::remove_dirn($this->dir_gpackage);# pre($r); pre($this->dir_package); pre($this->dir_gpackage);pred($r);

        XavierInfo::increment_value('create_stat', 'cafap_alltime_created_qty');
        XavierInfo::increment_value('create_stat', 'cafap_created_qty');
        return true;
    }

    function update_state(){ # Journal::update_journal_to_box_create($this->jid));
        #$r = Processing::add_for_balancer(['jd' => $jd, 'tid' => 0]); pre($r);
        #$r = Processing::add_for_balancer(['jd' => $jd, 'tid' => 0]); pre($r);
        #if(!Journal::update_journal_to_box_create($this->jid)){ $this->set_cerror('Problem with update journal to create '. __FUNCTION__);  return; }
        return true;
    }

    function set_xavier_info(){ # FOR HASH AND XML

        $this->log[] = 'set_xavier_info()';
        $r = XavierInfo::get_list_from_group('about');
        if(empty($r)){ Journal::update_journal_to_error($this->jid, 'Xavier info is empty', 0); return; }
        $this->name = $r['about']['name'];
        $this->serial_number = $r['about']['serial_number'];
        $this->certificate_number = $r['about']['sertificate_number'];
        $this->license_number = $r['about']['license_number'];
        $this->timezone = $r['about']['timezone'];
        $this->coords = $r['about']['coords'];
        $this->address = $r['about']['address'];
        $r = XavierInfo::get_list_from_group('direction');
        if(empty($r)){ Journal::update_journal_to_error($this->jid, 'Xavier info "direction" is empty', 0); return;}
        $this->direction_up = $r['direction']['up'];
        $this->direction_down = $r['direction']['down'];
        return true;
    }

    function check_source_image_files($jid = null){

        if($jid) $this->jid = $jid;
        $source_image_list = JournalImage::get_image_list_from_keys($this->jid); #pred($source_image_list);
        if(empty($source_image_list)){ $this->set_cerror('Journal image list is empty #396 '. __FUNCTION__); return; }
        $image_id_list = [];
        foreach($source_image_list as $image_row) if(!empty($image_row['image_id'])) $image_id_list[] = $image_row['image_id'];# else pre($image_row);
        if(empty($image_id_list)){ $this->set_cerror('Journal image ID list is empty '. __FUNCTION__); return; }
        $image_path_list = ImagePathListAction::get_image_path_list($image_id_list, true, true, true);  #pred($image_path_list);
        foreach($image_path_list as $image_row){
            $file_path = Dir::get_global_dir($image_row['image_dir']) .'/'. $image_row['image_item_id_list']['source']['id'];
            if(!file_exists($file_path)){ $this->set_cerror('Image is not exists#333: '. $file_path .' | '. __FUNCTION__); return; } #if(nl) pre($file_path."\n");#, filesize($file_path)."\n\n");
            $file_size = filesize($file_path);
            if($file_size < 100){ $this->set_cerror('Image have not valid file size: '. $file_size .' path: '. $file_path .' | '. __FUNCTION__); return; }
        } #pred($image_path_list);
        return true;
    }

    function set_image_list(){
        /*$key_list = [ # 'prepared_middle_number', 'prepared_after_number', 'prepared_before_number',
        # 'prepared_middle_zoom', 'prepared_after_zoom', 'prepared_before_zoom',
        # 'prepared_after', 'prepared_middle', 'prepared_before',
        # 'prepared_combo', 'number_coords_collage' ]; */
        $image_keys_for_cafap = \Config::$image_keys_for_cafap; #pre($image_keys_for_cafap);
        #if(\Config::$cafap_exclude_debug_collage) $image_keys_for_cafap = array_filter($image_keys_for_cafap, function($e){ return ($e !== 'number_coords_collage'); });

        if($this->sets['cafap_pack']['exclude_debug_collage']) $image_keys_for_cafap = array_filter($image_keys_for_cafap, function($e){ return ($e !== 'number_coords_collage'); });
        #pred($image_keys_for_cafap);
        if($this->traffic_violation === 'none'){
            $index = array_search('prepared_middle', $image_keys_for_cafap);
            if($index !== false) array_splice($image_keys_for_cafap, $index, 1);
        }  #if(loc) #pred($image_keys_for_cafap);

        $r = JournalImage::get_journal_image_data_list_from_journal_id($this->jid, $image_keys_for_cafap, true); # pred($r);
        if(empty($r)){ $this->set_cerror(__CLASS__ .'::'.  __FUNCTION__ .': Image list is empty#433 ' . json_encode($image_keys_for_cafap)); return; }
        $image_id_list = array_keys($r); #if(nl) pre("Journal_Image:\n", $r); #if(nl) pre('before base image path action:__', $image_id_list, "\n");
        $this->image_list = ImagePathListAction::get_image_path_list($image_id_list, true, true, true);
        #if(nl) pre('after base image path action: ', $this->image_list, "\n");
        if(!count($this->image_list)){ $this->set_cerror('Image list path is empty '. __FUNCTION__); return; }
        $this->image_width = PrepareImagesAction::$image_sizes_list['source']['width'];
        $this->image_height = PrepareImagesAction::$image_sizes_list['source']['height'];

        foreach($r as $image_id => $row){
            if($row['key'] === 'number_coords_collage'){
                $image_data = $this->image_list[$image_id];
                $this->image_list[$image_id]['key'] = $row['key'];
                $image_path = $image_data['image_dir'] .'/'. $image_data['image_item_id_list']['source']['id'];
                $this->image_width = $image_data['image_item_id_list']['source']['width'];
                $this->image_height = $image_data['image_item_id_list']['source']['height'];
                if(file_exists($image_path)) $this->image_size = filesize($image_path);
                if(count($row['track_coords'])) $this->track_number_list = $row['track_coords'];
                continue;
            }
            $this->image_list[$image_id]['key'] = $row['key'];
        }

        $index = 0;  #if(nl) pre($this->image_list);
        $temp = $this->image_list;
        $this->image_list = [];
        foreach($image_keys_for_cafap as $v){
            foreach($temp as $k => $vv){
                if($vv['key'] === $v) $this->image_list[$k] = $vv;
            }
        } #pred($this->image_list);

        foreach($this->image_list as $row){ #pred($row);
            $source_image_path = $row['image_dir'] .'/'. $row['image_item_id_list']['source']['id'];
            $image_extension = File::get_file_extension_from_file_path($source_image_path);

            if($row['key'] === 'number_coords_collage'){
                $result_image_path = $this->dir_package_source .'/'. $this->journal_hash . '_'. $index .'_dev.'. $image_extension;
            } elseif($row['key'] === 'prepared_combo'){
                $result_image_path = $this->dir_package_source .'/'. $this->journal_hash . '.'. $image_extension;
            } else {
                #if(!$index) #$result_image_path = $this->dir_package_source .'/'. $this->journal_hash . '.'. $image_extension;
                    #$result_image_path = $this->dir_package_source .'/'. $this->journal_hash . $row['key'] .'.'. $image_extension;
                #else
                $result_image_path = $this->dir_package_source .'/'. $this->journal_hash .'_'. $index .'.'. $image_extension; #$result_image_path = $this->dir_package_source .'/'. $this->journal_hash . $row['key'] .'_'. $index .'.'. $image_extension;
            } #pre($result_image_path);

            if(!file_exists($source_image_path)){ $this->set_cerror('Image is not exist, fp_'. $source_image_path .' '. __FUNCTION__); return; }
            $image_file_size = filesize($source_image_path); #pre($source_image_path); #pred($image_file_size);
            if(!$image_file_size){ $this->set_cerror('File '. $source_image_path .' have empty size '. __FUNCTION__); return; } #pre($source_image_path);
            if(!copy($source_image_path, $result_image_path)){ $er = 'File '. $source_image_path .' not copied to '. $result_image_path .' '. __FUNCTION__; pre($er); $this->set_cerror($er); return; }
            $this->files_paths[] = $result_image_path; #pred($this->files_paths);
            $index++;
        } #pred($this->files_paths);
        return true;
    }

    function set_video_list(){
        switch($this->traffic_violation){
            case 'none':
            case 'speed_20':
            case 'speed_40':
            case 'speed_60':
            case 'speed_80':
            return true;
        }
        $video_id_list = JournalVideo::get_videos_ids($this->jid, 1);
        if(empty($video_id_list)) return true;
        $this->video_list = VideoPathListAction::get_video_path_list($video_id_list, true, true, true); #pred($this->video_list);
        $index = 0;
        foreach($this->video_list as $row){
            $source_video_path = $row['video_dir'] .'/'. $row['video_item_id_list']['source']['id'];
            if(!file_exists($source_video_path)){ $this->set_cerror('Video file is empty#1 '. $source_video_path .' | '. __FUNCTION__); return; }  #pred($source_video_path);
            $video_extension = File::get_file_extension_from_file_path($source_video_path);
            $result_video_path = $this->dir_package_source .'/'. $this->journal_hash .'_'. $index .'.'. $video_extension;

            if(!copy($source_video_path, $result_video_path)){ $this->set_cerror('Video copy failed from '. $source_video_path .' to '. $result_video_path, 0); return; }
            $this->files_paths[] = $result_video_path;
            $index++;
        }
        return true;
    }

    function set_json(){
        #$this->traffic_violation = 'none';
        if($this->sets['cafap_pack']['json_only_for_offences'] && $this->traffic_violation === 'none') return true; #if($this->combo_car_number_coords)

        /*$car_number_coords = [
            'x' => (int)($this->combo_car_number_coords[0]['x']),
            'y' => (int)($this->combo_car_number_coords[0]['y']),
            'w' => (int)(($this->combo_car_number_coords[3]['x'] - $this->combo_car_number_coords[0]['x'])),
            'h' => (int)(($this->combo_car_number_coords[3]['y'] - $this->combo_car_number_coords[0]['y'])),
        ];*/
        $list = [
            'datetime' => $this->timestamp,
            'direction' => $this->direction == 'up' ? 2 : 1,
            'lane' => 1,
            'deviceSerial' => $this->serial_number,
            'license' => $this->certificate_number#, 'position' => $car_number_coords
        ];  #if($this->combo_car_number_coords) $list['position'] = $car_number_coords;

        $file_name = $this->journal_hash .'.json';
        $file_json_path = Dir::get_global_dir($this->dir_package_source .'/'. $file_name);
        $this->files_paths[] = $file_json_path; #            $this->files_paths[] = $file_name;
        if(!file_put_contents($file_json_path, Json::encode($list))){ $this->set_cerror('JSON file was not create'); return; }

        return true;
    }
}