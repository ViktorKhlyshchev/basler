<?php

namespace CLI\Modules\Cafap;

use Common\Modules\Date;
use Core\Modules\Dir;
use Common\Models\Image\Image;
use Core\Module\Video\Video;
use Common\Modules\ImagePathAction;
use Project\Aist\Admin\Action\Video\VideoPathListAction;
use Common\Models\Journal;
use Common\Models\JournalImage;
use Common\Models\JournalVideo;
use Common\Models\XavierInfo;
use Admin\Modules\Ftp;
use Common\Models\Sending;
use Common\Models\SendingQ;
use Configs\DirConfig;

class CafapSendpackage {

    public $error;
    public $cercode; # CRITICAL ERROR CODE
    public $cer;
    public $cerror;
    public $aerrors = []; # allerrors
    public $errors = [];
    public $object_name;
    public $jid;
    public $journal_hash;
    public $dir_box;
    public $dir_box_source;
    public $dir_box_keys;
    public $dir_box_tar;
    public $tar_file_path;
    public $file_size;
    public $date_create;
    public $timestamp;
    public $is_all_ftp_send;
    public $strys;
    public $log = [];
    public $duplo_data = false;

    public $offence_path = [
        'none' => 'potok',
        'stop_line' => 'stop_line',
        'no_stop' => 'no_stop',
        'no_parking' => 'no_parking',
        'route_vehicles' => 'route_vehicles',
        'lane' => 'lane',
        'intersection_double_solid_lane' => 'intersection_double_solid_lane',
        'speed_20' => 'speed_20',
        'speed_40' => 'speed_40',
        'speed_60' => 'speed_60',
        'speed_80' => 'speed_80',
        'lane_opposite' => 'lane_opposite',
        'reversal' => 'reversal',
    ];

    public $ftp_list = [];
    public $timezone;

    function set_error($error){
        $this->errors = $error;
        Journal::update_journal_to_error($this->jid, $this->errors, 0);
    }

    function set_cerrorR($error){ # set_crucial_error
        $this->errors = $error;
        Journal::update_journal_to_error($this->jid, $this->errors, 1);
    }

    function set_cerror($error = null){
        $this->cerror = true;
        $this->aerrors[] = $error;
        if($error) $this->errors[] = $error; #pred($this->errors);
        if(loc) pre($this->errors); else pre($this->errors);
        Journal::update_error($this->jid, implode("\n", $this->errors));
        SendingQ::update_error($this->id, implode("\n", $this->errors));
        $this->errors = [];
    }

    function __construct(array $data = [], array $serv = []){ #pred($serv); #pred($data);

        $this->log[] = 'CafapSendpackage INIT start';

        $this->id = $data['id'];
        $this->jid = $data['jid'];
        $this->data = $data;
        $this->serv = $serv;
    }

    function send(){        #pred($this->serv);        #pred($this);

        $r = XavierInfo::get_list_from_group('about');
        $this->device_name = &$r['about']['name'];

        $this->timezone = XavierInfo::get_timezone();

        $offence_date = Journal::get_offence_date($this->jid); #pre($offence_date);
        $temp = stristr($offence_date, '.', true);
        if(!$temp) $temp = @$offence_date;
        $offence_timestamp = strtotime($temp) + (int)$this->timezone * 3600;#pred($offence_timestamp);
        $year = Date::get_year_full($offence_timestamp);
        $month = Date::get_month($offence_timestamp);
        $day = Date::get_day($offence_timestamp);

        if($this->data['offence']){
            $key = isset($this->offence_path[$this->data['offence']]) ? $this->offence_path[$this->data['offence']] : 'other';
        } else $key = $this->offence_path['none'];

        $this->serv['ftp_dp'] = str_replace(
            ['%device_name%', '%year%', '%month%', '%day%', '%traffic_violation%'],
            [$this->device_name, $year, $month, $day, $key],
            $this->serv['path']
        );
        if(substr($this->serv['ftp_dp'], 0, 1) === '/') $this->serv['ftp_dp'] = substr($this->serv['ftp_dp'], 1); # remove suffix slash
        if(substr($this->serv['ftp_dp'], -1) === '/') $this->serv['ftp_dp'] = substr($this->serv['ftp_dp'], 0, -1); # remove prefix slash
        $this->serv['ftp_fn'] = $this->data['hash'] .'.tar';
        $this->serv['ftp_fp'] = $this->serv['ftp_dp'] .'/'. $this->serv['ftp_fn']; #$remove_all = true; if(isset(\Config::$remove_all)) $remove_all = \Config::$remove_all; # pre(\Config::$upload_duplo);        pred($this->duplo);

        $this->log[] = 'b send_package_list()'; # XavierInfo::increment_trysend(); #if(0){ #if(!empty($_REQUEST['need_log'])) pre("Sent to FTP \n"); #$is_send = true;

        if(!file_exists($this->data['file_path'])){ $this->set_cerror('file not exists!'. $this->data['file_path']); return; }
        $fs = filesize($this->data['file_path']);
        Sending::update_size($this->id, $fs);
        if($fs < 10){ $this->cer = 'tar have not valid file size: '. $fs .' path: '. $this->tar_fp .' | '. __FUNCTION__; $this->set_cerror($this->cer); $this->cercode = 11; return; }

        $this->serv['local_fp'] = $this->data['file_path'];
        $this->serv['address'] = $this->serv['ip_address'];
        $this->serv['port'] = $this->serv['ip_port']; # pred($this->serv);

        if(isset($this->serv['testfn'])){ # sudo -u www-data /usr/bin/php7.2 -f "$PWD/index.php" action=cafap_send_thread tid=0 need_log=1 testfn=1.file
            $fp = DR .'/'. DirConfig::$dir_temp . '/'. $this->serv['testfn'];
            $this->serv['local_fp'] = $fp;
            $this->serv['ftp_fn'] = $this->serv['testfn'];
            $this->serv['ftp_fp'] = $this->serv['ftp_dp'] .'/'. $this->serv['testfn'];
        }

        $ftp = new Ftp($this->serv); #pred($ftp);
        pre('SENDING!');
        $r = $ftp->send(); #pred($r);
        $this->log = array_merge($this->log, $ftp->log);
        Sending::update_log($this->id, implode("|\n", $this->log));
        if($r) return true;
        foreach($ftp->errors as $v){ $this->set_cerror($v); $this->set_cerror('!send_tar()'); }
    }

    function remove_journal_resources(){
        $image_id_list = JournalImage::get_images_ids($this->jid);
        if(count($image_id_list) > 0){
            foreach($image_id_list as $image_id){
                $image_data = ImagePathAction::get_image_path_data($image_id, true, true, true);
                if(!empty($image_data))
                    if(!empty($image_data['image_dir']))
                        if(file_exists($image_data['image_dir'])){
                            Dir::remove_dir($image_data['image_dir']); # if(!empty($_POST['is_test']))  echo "->> remove image_dir: ".$image_data['image_dir']."\n";
                        }
            }
            Image::delete_image_id_list($image_id_list);
        }
        $video_id_list = JournalVideo::get_videos_ids($this->jid);
        if(count($video_id_list)){
            $video_list = VideoPathListAction::get_video_path_list($video_id_list, true, true, true);
            foreach($video_list as $video_row)
                if(!empty($video_row['video_dir']) && file_exists($video_row['video_dir'])) Dir::remove_dir($video_row['video_dir']); #if(!empty($_POST['is_test'])) pre("->> remove video_dir: ".$video_row['video_dir']."\n");
            Video::delete_video_id_list($video_id_list);
        }
        return true;
    }
}