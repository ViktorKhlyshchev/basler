<?php

namespace CLI\Modules\Cafap;

use Core\Modules\Dir; #use Common\Modules\Date; use Configs\DirConfig;
use Common\Models\Journal;

class CafapXML {

    public $error;
    public $xml;

    function set_error($error){
        $this->error = $error;
        Journal::update_journal_to_error($this->jid, $this->error, 0);
    }

    function set_cerror($error){
        $this->error = $error;
        Journal::update_journal_to_error($this->jid, $this->error, 1);
    }

    function __construct(&$ccp = null){ # CafapCreatePackage

        # uses is_plate_invert, country_code

        if($ccp === null) return;

        #$timestamp = $ccp->traffic_violation_ts; #$timestamp = $ccp->timestamp - $ccp->timezone * 3600;
        $timestamp = $ccp->timestamp;
        $list[] = '<?xml version = "1.0" encoding = "utf-8"?>';
        $list[] = '<report>';
        $list[] = '<targetinfo>';
        $list[] = '<nDatetime>'. $timestamp .'</nDatetime>';
        $list[] = '<nDirection>'. ($ccp->direction == 'up' ? 2 : 1) .'</nDirection>';
        $list[] = '<tDirectionName>'. ($ccp->direction === 'up' ? $ccp->direction_up : $ccp->direction_down) .'</tDirectionName>';
        $list[] = '<nDisplaySpeed>'. $ccp->speed_xml .'</nDisplaySpeed>';
        $list[] = '<nSpeedThreshold>'. $ccp->speed_max .'</nSpeedThreshold>';
        $list[] = '<nDisplaySpeedQuality>'. $ccp->speed_quality .'</nDisplaySpeedQuality>';
        $list[] = '<nDisplayJoinCount>'. $ccp->join_count .'</nDisplayJoinCount>';
        $list[] = '<nLane>'. $ccp->lane .'</nLane>';
        $list[] = '<nImagePresent>1</nImagePresent>';
        $list[] = '<nImageWidth>'. $ccp->image_width .'</nImageWidth>';
        $list[] = '<nImageHeight>'. $ccp->image_height .'</nImageHeight>';
        if(array_search('need_xml_recognize_quality', $ccp->customer_config) !== false) $list[] = '<nRecognizeQuality>'. $ccp->speed_quality .'</nRecognizeQuality>';
        if(array_search('need_xml_avg_recognize_quality', $ccp->customer_config) !== false) $list[] = '<nAvgRecognizeQuality>'.Journal::get_avg_speed_quality_for_last_N_rows($ccp->customer_config['xml_avg_recognize_quality_rows_count']) .'</nAvgRecognizeQuality>';
        if(array_search('need_xml_recognize_type', $ccp->customer_config) !== false) $list[] = '<nRecognizeType>'. $ccp->recognize_type .'</nRecognizeType>';
        if(!empty($ccp->combo_car_number_coords))
            if(count($ccp->combo_car_number_coords) === 4){
                $list[] = '<nRectNumX1>'. (int)$ccp->combo_car_number_coords[0]['x'] .'</nRectNumX1>';
                $list[] = '<nRectNumY1>'. (int)$ccp->combo_car_number_coords[0]['y'] .'</nRectNumY1>';
                $list[] = '<nRectNumX2>'. (int)$ccp->combo_car_number_coords[3]['x'] .'</nRectNumX2>';
                $list[] = '<nRectNumY2>'. (int)$ccp->combo_car_number_coords[3]['y'] .'</nRectNumY2>';
                $list[] = '<nRectNumX3>'. (int)$ccp->combo_car_number_coords[1]['x'] .'</nRectNumX3>';
                $list[] = '<nRectNumY3>'. (int)$ccp->combo_car_number_coords[1]['y'] .'</nRectNumY3>';
            }
        $list[] = '<nSize>'. $ccp->image_prepared_combo_size .'</nSize>';
        $list[] = '<nTZOffset>'. $ccp->timezone .'</nTZOffset>';
        $list[] = '<tApprovalCertificateExpDate>'. $ccp->certificate_number_c_date .'</tApprovalCertificateExpDate>';
        $list[] = '<tApprovalCertificateNumber>'. $ccp->certificate_number_c .'</tApprovalCertificateNumber>';
        $list[] = '<tCarType>'. $ccp->car_type .'</tCarType>';
        $list[] = '<tCertificateExpDate>'. $ccp->certificate_date .'</tCertificateExpDate>';
        $list[] = '<tCertificateNumber>'. $ccp->certificate_number .'</tCertificateNumber>';
        $list[] = '<tDeviceSerial>'. $ccp->serial_number .'</tDeviceSerial>';
        $list[] = '<tGpsPos>('. $ccp->coords .')</tGpsPos>';
        $list[] = '<tLicenseNumber>'. $ccp->car_number .'</tLicenseNumber>';
        $list[] = '<tCountryCode>'. $ccp->country_code .'</tCountryCode>';
        $list[] = '<nPlateInvert>'. (int)$ccp->is_plate_invert .'</nPlateInvert>';
        $list[] = '<tRadarName>'. $ccp->name .'</tRadarName>';
        $list[] = '<tSensorName>'. $ccp->address .'</tSensorName>';
        $list[] = '<tTargetGlobalUID>'. $ccp->journal_hash .'</tTargetGlobalUID>';
        $list[] = '<tTargetID>'. $ccp->jid .'</tTargetID>';
        $list[] = '<nSpeedMeasuringError>1</nSpeedMeasuringError>';
        if(\Config::$is_need_track_list_in_xml)
            if(count($ccp->track_number_list) > 0){
                $list[] = '<trackCarNumber>';
                for($i = 1;$i < count($ccp->track_number_list); $i++)
                    if(isset($ccp->track_number_list[$i])){
                        $list[] = '<trackCarNumberItem>';
                            $list[] = '<number>'. mb_strtolower($ccp->track_number_list[$i]['number'], "utf-8") .'</number>';
                            $list[] = '<speed>'. (int)$ccp->track_number_list[$i]['speed'] .'</speed>';
        //                    $list[] = '<quality>'.round($ccp->track_number_list[$i]['speed_quality']) .'</quality>';
                            $list[] = '<x>'. round($ccp->track_number_list[$i]['x']) .'</x>';
                            $list[] = '<y>'. round($ccp->track_number_list[$i]['y']) .'</y>';
                        $list[] = '</trackCarNumberItem>';
                    }
                $list[] = '</trackCarNumber>';
            }
//        'none',
//        'lane_opposite', // done
//        'speed_20', // done
//        'speed_40', // done
//        'speed_60', // done
//        'speed_80', // done
//        'no_parking',
//        'no_stop',
//        'reversal', // done
//        'route_vehicles', // done
        switch($ccp->traffic_violation){
            case 'speed_20':
            case 'speed_40':
            case 'speed_60':
            case 'speed_80':{
                $list[] = '<nOverSpeed>1</nOverSpeed>';
                break;
            }
            case 'route_vehicles':{
                $list[] = '<nWrongLine>1</nWrongLine>';
                break;
            }
            case 'lane_opposite':{
                $list[] = '<nWrongDirection>1</nWrongDirection>';
                break;
            }
            case 'reversal':{
                $list[] = '<nNoUTurnOnlyForward>1</nNoUTurnOnlyForward>';
                break;
            }
            case 'no_stop':{
                $list[] = '<noStop>1</noStop>';
                break;
            }
            case 'no_parking':{
                $list[] = '<noParking>1</noParking>';
                break;
            }
        }
        $list[] = '<trackCarNumberLen>'. count($ccp->track_number_list) .'</trackCarNumberLen>';
        $list[] = '<nDisplayPointRecognizedCount>'. $ccp->point_recognized_count .'</nDisplayPointRecognizedCount>';
        $list[] = '</targetinfo>';
        $list[] = '</report>';
        $this->xml = implode("\n", $list);

       # pred($ccp->journal_hash);
        $file_name = $ccp->journal_hash .'.xml';
        $file_xml_path = Dir::get_global_dirn($ccp->dir_package_source .'/'. $file_name);

        #pre('\Config::$is_need_save_xml_in_resources');        pre(\Config::$is_need_save_xml_in_resources);
        /*if(\Config::$is_need_save_xml_in_resources){
            $dir_package_xml = Dir::get_global_dir(DirConfig::$dir_cafap_xml);
            Dir::create_dir($dir_package_xml);
            $dc = Date::get_date(strtotime($ccp->date_create), 'Y.m.d'); #$dir_package_xml .= '/'. Date::get_date();
            $dir_package_xml .= '/'. $dc;
            Dir::create_dir($dir_package_xml);
            $box_mxl_path = $dir_package_xml .'/'. $ccp->journal_id .'.xml'; #pred($box_mxl_path); #if(file_exists($box_mxl_path)) unlink($box_mxl_path);
            $r = file_put_contents($box_mxl_path, implode("\n", $list)); #pre($r); pre($box_mxl_path);
        }*/

        if(!file_put_contents($file_xml_path, $this->xml)){ $this->xml = null; $ccp->set_cerror('XML file was not create'. __FUNCTION__); return false; }

        $ccp->files_paths[] = $file_xml_path;

        if(!empty($_REQUEST['show_xml'])) pre($list);

        return $this->xml;/*

        $file_name = $ccp->journal_hash .'.xml';
        $file_xml_path = Dir::get_global_dir($ccp->dir_package_source .'/'. $file_name);

        $ccp->file_list[] = $file_xml_path;
        $ccp->file_name_list[] = $file_name;
        #pre('\Config::$is_need_save_xml_in_resources');        pre(\Config::$is_need_save_xml_in_resources);
        if(\Config::$is_need_save_xml_in_resources){
            $dir_package_xml = Dir::get_global_dir(DirConfig::$dir_package_xml);
            Dir::create_dir($dir_package_xml);
            $dc = Date::get_date(strtotime($ccp->date_create), 'Y.m.d'); #$dir_package_xml .= '/'. Date::get_date();
            $dir_package_xml .= '/'. $dc;
            Dir::create_dir($dir_package_xml);
            $box_mxl_path = $dir_package_xml .'/'. $ccp->jid .'.xml'; #pred($box_mxl_path); #if(file_exists($box_mxl_path)) unlink($box_mxl_path);
            $r = file_put_contents($box_mxl_path, implode("\n", $list)); #pre($r); pre($box_mxl_path);
        }

        if(file_put_contents($file_xml_path, implode("\n", $list)) === false){ $ccp->set_error('XML file was not create'. __FUNCTION__); return false; }
        if(!empty($_REQUEST['show_xml'])) pre($list);*/

        return true;
    }
}