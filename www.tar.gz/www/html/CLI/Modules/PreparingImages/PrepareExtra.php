<?php

namespace CLI\Modules\PreparingImages;

use Common\Models\Zone;
use Common\Models\XavierInfo;
use Common\Models\Journal;
use Common\Models\JournalImage;
use Core\Modules\Json;
use Common\Modules\Date;
use Common\Modules\ImagePathListAction;
use Common\Models\Image\Image;
use Core\Modules\Dir;

trait PrepareExtra {

    public static $image_sizes_list = [

        'number_coords_collage' => [
            'width' => 900,
            'height' => 600,
            'quality' => 80
        ],
        'source' => [
            'width' => 900,
            'height' => 600,
            'quality' => 80
        ],
        'before' => [
            'width' => 900,
            'height' => 600,
            'quality' => 80
        ],
        'middle' => [
            'width' => 1600,
            'height' => 1338,
            'quality' => 80
        ],
        'after' => [
            'width' => 900,
            'height' => 600,
            'quality' => 80
        ],
        'zoom' => [
            'width' => 900,
            'height' => 600,
            'quality' => 80
        ],
        'none' => [
            'width' => 900,
            'height' => 600,
            'quality' => 80
        ],
        'number' => [
            'width' => 300,
            'height' => 100,
            'quality' => 80
        ]
    ];

    public static $image_sizes_list_off = [
        'crosswalk' => [
            'before' => [
                'width' => 1600,
                'height' => 1338,
                'quality' => 80
            ],
            'middle' => [
                'width' => 1600,
                'height' => 1338,
                'quality' => 80
            ],
            'after' => [
                'width' => 1600,
                'height' => 1338,
                'quality' => 80
            ]
        ]
    ];

    private static $image_resolution_list = [

        'stop_line' => [
            'width' => 900,
            'height' => 600,
            'quality' => 80
        ],
        'route_vehicles' => [
            'width' => 980,
            'height' => 540,
            'quality' => 80
        ],
        'no_stop' => [
            'width' => 1200,
            'height' => 540,
            'quality' => 80
        ],
        'no_parking' => [
            'width' => 1200,
            'height' => 540,
            'quality' => 80
        ],
        'oncoming_lane' => [
            'width' => 980,
            'height' => 540,
            'quality' => 80
        ],
        'reversal' => [
            'width' => 980,
            'height' => 540,
            'quality' => 80
        ],
        'lane' => [
            'width' => 980,
            'height' => 540,
            'quality' => 80
        ],
        'lane_opposite' => [
            'width' => 980,
            'height' => 540,
            'quality' => 80
        ],
        'intersection_double_solid_lane' => [
            'width' => 900,
            'height' => 600,
            'quality' => 80
        ],
        'speed_20' => [
            'width' => 500,
            'height' => 526,
            'quality' => 80 # 'width' => 900, 'height' => 600, 'quality' => 80
        ],
        'speed_40' => [# 'width' => 900, 'height' => 600, 'quality' => 80
            'width' => 500,
            'height' => 526,
            'quality' => 80
        ],
        'speed_60' => [
            'width' => 500,
            'height' => 526,
            'quality' => 80 # 'width' => 900, 'height' => 600, 'quality' => 80
        ],
        'speed_80' => [
            'width' => 900,
            'height' => 600,
            'quality' => 80
        ],
        'none' => [
            'width' => 500,
            'height' => 526,
            'quality' => 80 # 'width' => 900, 'height' => 600, 'quality' => 80
        ],
        'number_coords_collage' => [
            'width' => 900,
            'height' => 600,
            'quality' => 80
        ],
        'roadside' => [
            'width' => 900,
            'height' => 600,
            'quality' => 80
        ],
        'crosswalk' => [
            'width' => 900,
            'height' => 600,
            'quality' => 80
        ]
    ];

    private static function set_error($error){
        self::$error = $error;
        Journal::update_journal_to_error(self::$journal_id, self::$error, 0);
    }

    private static function set_cerror($error){ # set_crucial_error # TODO ADD GLOBAL BALANCER ERR0RR!!
        self::$error = $error;
        self::$errors[] = $error;
        Journal::update_journal_to_error(self::$journal_id, self::$error, 1);
    }

    private static function set_timezone(){
        self::$timezone = XavierInfo::get_timezone();
        return true;
    }

    private static function reset_data(){
        self::$journal_id = null;
        self::$object_id = null;
        self::$object_address = null;
        self::$object_gps = null;
        self::$timestamp = null;
        self::$timezone = null;
        self::$speed = null;
        self::$floor_speed = null;
        self::$certificate_number = null;
        self::$serial_number = null;
        self::$traffic_violation = null;
        self::$traffic_violation_type = null;
        self::$direction_list = [];
        self::$camera_direction_list = [];
        self::$image_list = [];
        self::$image_zoom_list = [];
        self::$image_before = null;
        self::$image_middle = null;
        self::$image_after = null;
        self::$image_combo_result = null;
        self::$image_car_number_list = [];
        self::$direction_list = [];
        self::$combo_car_number_coords = [];
        self::$error = false;
        self::$errors = [];
        return true;
    }

    private static function set_xavier_data(){
        $r = XavierInfo::get_list_from_group('about');
        if(empty($r)){ self::$error = 'Xavier data is empty'; Journal::update_journal_to_error(self::$journal_id, self::$error, 0); return false; }
        self::$object_id = $r['about']['name'];
        self::$object_address = $r['about']['address'];
        self::$object_gps = $r['about']['coords'];
        self::$serial_number = $r['about']['serial_number'];
        self::$certificate_number = $r['about']['sertificate_number'];
        return true;
    }

    private static function set_zone_data(){
        if(!count(self::$image_list)){ self::set_cerror('Image list is empty #3 ' . __FUNCTION__); return false; }
        foreach(self::$image_list as $index => $row) self::$image_list[$index]['speed_max'] = Zone::get_zone_speed_max($row['camera_id']);
        return true;
    }

    private static function set_direction_list(){
        $r = XavierInfo::get_list_from_group('direction');
        if(empty($r)){ self::$error = 'Direction is empty'; Journal::update_journal_to_error(self::$journal_id, self::$error, 0); return false; }
        foreach($r['direction'] as $key => $row) self::$direction_list[$key] = $row;
        return true;
    }

    private static function set_journal_image_data(){
        $r = JournalImage::get_journal_image_data_list_from_journal_id(self::$journal_id, ['source', 'before', 'after', 'middle', 'lane_opposite']);
        #$r = JournalImage::get_journal_image_data_list_from_journal_id(self::$journal_id, ['source']); #pred($r); #foreach($r as $row){ unset($row['track_coords']); unset($row['car_number_coords']); pre($row); } #pred(123);
        if(!count($r)){ self::set_cerror('Image list is empty #2 ' . __FUNCTION__); return false; }

        $isset_track_coords = false;
        foreach($r as $row){
            if(empty($row['car_number_coords'])){ self::set_cerror('Journal ID: '. self::$journal_id. ' have image without car_number_coords' . __FUNCTION__); return false; }
            if(empty($row['timestamp'])){ self::set_cerror('Journal ID: '. self::$journal_id. ' have image without timestamp' . __FUNCTION__); return false; }
            if($row['direction'] == 'undef'){ self::set_cerror('Journal ID: '. self::$journal_id. ' have image without direction ' . __FUNCTION__); return false; }

            self::$image_list[] = [
                'journal_image_id' => $row['journal_image_id'],
                'camera_id' => $row['camera_id'],
                'source_image_id' => $row['image_id'],
                'car_number_coords' => empty($row['car_number_coords']) ? null : Json::decode($row['car_number_coords']),
                'direction' => empty($row['direction']) ? null : $row['direction'],
                'key' => empty($row['key']) ? null : $row['key'],
                'lane' => empty($row['lane']) ? 1 : $row['lane'],
                'timestamp' => empty($row['timestamp']) ? null : $row['timestamp'],
                'track_coords' => empty($row['track_coords']) ? null : $row['track_coords'],
            ];
            if(!empty($row['track_coords'])) $isset_track_coords = true;
        }  #pred($r);  #pred(self::$traffic_violation);
        switch(self::$traffic_violation){
            case 'lane':
            case 'lane_opposite':
            case 'route_vehicles': {
                if(!$isset_track_coords){ self::set_cerror('Journal ID: '. self::$journal_id .' have not track coords in image list ' . __FUNCTION__); return false; }
                break;
            }
        }
        return true;
    }

    private static function remove_journal_image(){
        $key_list = ['prepared_after', 'prepared_before', 'prepared_middle', 'prepared_combo'];
        return JournalImage::delete_journal_image_bkeys(self::$journal_id, $key_list);
    }

    private static function set_result_image_id(){

        if(!isset(self::$image_resolution_list[self::$traffic_violation])){ self::set_cerror('Traffic violation is not exists '. __FUNCTION__); return false; }
        if(!count(self::$image_list)){ self::set_cerror('Image list is empty #5 '. __FUNCTION__); return false; }
        switch(self::$traffic_violation){
            case 'lane':
            case 'lane_opposite':
            case 'reversal':
            case 'route_vehicles':
            case 'roadside':
            case 'crosswalk': {
                self::$image_before = self::get_image_db_data('before'); #if(!self::$image_before){ self::set_cerror(__CLASS__ .'::'.__FUNCTION__ .' self::$image_before fail! #392');return; }
                self::$image_after = self::get_image_db_data('after');
                self::$image_middle = self::get_image_db_data('middle');
                self::$image_zoom_list = []; #self::$image_zoom_list['before'] = self::get_image_db_data('zoom'); self::$image_zoom_list['after'] = self::get_image_db_data('zoom'); self::$image_zoom_list['middle'] = self::get_image_db_data('zoom');
                self::$image_car_number_list = []; #self::$image_car_number_list['before'] = self::get_image_db_data('number'); self::$image_car_number_list['after'] = self::get_image_db_data('number'); self::$image_car_number_list['middle'] = self::get_image_db_data('number');
                self::$image_combo_result = self::get_image_db_data();
                break;
            }
            case 'speed_20':
            case 'speed_40':
            case 'speed_60':
            case 'speed_80': { #self::$image_before = self::get_image_db_data('before'); self::$image_after = self::get_image_db_data('after');
                self::$image_middle = self::get_image_db_data('middle');
                self::$image_zoom_list = []; # self::$image_zoom_list['before'] = self::get_image_db_data('zoom'); self::$image_zoom_list['after'] = self::get_image_db_data('zoom'); self::$image_zoom_list['middle'] = self::get_image_db_data('zoom');
                self::$image_car_number_list = []; # self::$image_car_number_list['before'] = self::get_image_db_data('number');  self::$image_car_number_list['after'] = self::get_image_db_data('number'); self::$image_car_number_list['middle'] = self::get_image_db_data('number');
                self::$image_combo_result = self::get_image_db_data(); #pred(self::$image_combo_result);
                break;
            }
            case 'no_stop':
            case 'no_parking': {
                if(!isset(self::$image_sizes_list['before']) || !isset(self::$image_sizes_list['after'])){
                    self::$image_middle = self::get_image_db_data('middle');
                    self::$image_zoom_list = [];
                    self::$image_car_number_list = [];
                    self::$image_combo_result = self::get_image_db_data();
                } else {
                    self::$image_before = self::get_image_db_data('before');
                    self::$image_after = self::get_image_db_data('after'); # self::$image_middle = self::get_image_db_data('middle');
                    self::$image_zoom_list = [];
                    self::$image_car_number_list = [];
                    self::$image_combo_result = self::get_image_db_data();
                }
                break;
            }
            case 'oncoming_lane':
            case 'none': { # self::$image_middle = self::get_image_db_data('source');
                self::$image_middle = self::get_image_db_data('middle');
                #self::$image_zoom_list = []; # self::$image_zoom_list['middle'] = self::get_image_db_data('zoom');
                #self::$image_zoom_list['middle'] = self::get_image_db_data('zoom'); #pred(self::$image_zoom_list);
                self::$image_car_number_list = []; #self::$image_car_number_list['middle'] = self::get_image_db_data('number');
                self::$image_combo_result = self::get_image_db_data(); #pred(self::$image_combo_result);
                break;
            }
            default: {
                self::set_cerror('Traffic_violation not defined! self::$traffic_violation:__'. self::$traffic_violation .' | '. __FUNCTION__);
                return false;
            }
        }
        if(self::$is_track_glued){
            $r = JournalImage::get_journal_image_data_list_from_journal_id(self::$journal_id, ['number_coords_collage']);
            if(!empty($r))
                foreach($r as $row){
                    $image_list = ImagePathListAction::get_image_path_list([$row['image_id']], true, true, true);
                    foreach($image_list as $image_data){
                        $source_path = Dir::get_global_dir($image_data['image_dir']).'/'.$image_data['image_item_id_list']['source']['id'];
                        if(file_exists($source_path)){
                            if(!empty($_REQUEST['need_log'])) pre('source_image_path 1:__'. $source_path ."\n");
                            $image_object = Image::get_image_object_from_file_path($source_path);
                            $image_object = self::get_car_track_line($image_object, $row);
                            imagejpeg($image_object, $source_path, self::$image_resolution_list['number_coords_collage']['quality']);
                        }
                        break;
                    }
                    break;
                } # self::$number_coords_collage = Image::get_image_object_from_file_path($image_data['source_image_path']);
        }
        return true;
    }

    private static function get_image_with_bottom_label($image_object = null, array $label_list = [], int $text_y = 0, int $text_x = 0){
        if(empty($image_object)) return null;
        $image_padding_row = self::$image_padding_row;
        $font_size = self::$font_size;
        $font_file = self::$font_file;
        $font_color = imagecolorallocate($image_object, 255, 255, 255);
        foreach($label_list as $text){
            imagettftext($image_object, $font_size, 0, $text_x, $text_y, $font_color, $font_file, $text);
            $text_y+= $image_padding_row+$font_size;
        }
        return $image_object;
    }

    private static function get_image_data_timestamp(array $image_data = []){
        return Date::get_date_time_ms_full_from_ms(Date::get_ms_from_date_time_ms($image_data['timestamp']) + self::$timezone * 3600000);
    }

    private static function get_direction_label(array $image_data = null){
        if(empty($image_data)) return null; # $camera_id = $image_data['camera_id'];
        $direction = $image_data['direction'];
        #$camera_direction = self::$camera_direction_list[$camera_id]; #$r = XavierInfo::get_list_from_group('direction');
        #if($_REQUEST['is_test'])pred($direction); #if($_REQUEST['is_test'])pred(self::$direction_list);
        #$camera_direction = $r['camera_direction']; # pre($direction);        pre(self::$direction_list);
        $direction_content = @self::$direction_list[$direction]; # pre($direction_content);
        #$direction_content = null;
        /*switch($camera_direction){
            case 'up': {
                $direction_content = empty($direction) ? null : self::$direction_list[$direction];
                break;
            }
            case 'down': {
                switch($direction){
                    case 'up': {
                        $direction_content = self::$direction_list['down'];
                        break;
                    }
                    case 'down': {
                        $direction_content = self::$direction_list['up'];
                        break;
                    }
                    default: {
                        $direction_content = null;
                        break;
                    }
                    break;
                }
                break;
            }
        }*/ #if($_REQUEST['is_test'])pred($direction_content);
        if(!$direction_content) $direction_content = 'not defined';
        return $direction_content;
    }

    private static function get_car_track_line($image_object = null, array $image_data = null){
        if(empty($image_object)) return null;
        if(count($image_data['track_coords']) < 2) return $image_object;
        $border_width = self::$border_width;
        $before_green = imagecolorallocate($image_object, 4, 239, 48);
        imagesetthickness($image_object, $border_width);
        for($i = 1;$i < count($image_data['track_coords']);$i++){
            $x1 = (int)$image_data['track_coords'][$i-1]['x'];
            $y1 = (int)$image_data['track_coords'][$i-1]['y'];
            $x2 = (int)$image_data['track_coords'][$i]['x'];
            $y2 = (int)$image_data['track_coords'][$i]['y'];
            imageline(
                $image_object,
                $x1,
                $y1,
                $x2,
                $y2,
                $before_green
            );
            if($i == 1) imagefilledellipse($image_object, $x1, $y1, 10, 10, $before_green);
            imagefilledellipse($image_object, $x2, $y2, 10, 10, $before_green);
        }
        return $image_object;
    }

    static function get_car_body_border($image_object = null, array $image_data = null){
        if(empty($image_object)) return null;
        $border_width = self::$border_width;
        $border_w_percent = self::$car_border_w_percent;
        $border_h_percent = self::$car_border_h_percent;
        $before_red = imagecolorallocate($image_object, 255, 0, 0);
        $before_white = imagecolorallocate($image_object, 255, 255, 255);
        imagesetthickness($image_object, $border_width);
        $w_before = $image_data['car_number_coords'][3]['x']-$image_data['car_number_coords'][0]['x'];
        $h_before = $image_data['car_number_coords'][3]['y']-$image_data['car_number_coords'][0]['y'];
        $w_after = $w_before*$border_w_percent;
        $h_after = $h_before*$border_h_percent;
        $w_delta = $w_after-$w_before;
        $h_delta = $h_after-$h_before;
        $x_1 = $image_data['car_number_coords'][0]['x']-($w_delta/2);
        $y_1 = $image_data['car_number_coords'][0]['y']-($h_delta/2);
        $x_2 = $x_1+$w_after;
        $y_2 = $y_1+$h_after;
        imagerectangle(
            $image_object,
            $x_1,
            $y_1,
            $x_2,
            $y_2,
            $before_red
        );
        imagesetthickness($image_object, $border_width);
        imagerectangle(
            $image_object,
            $x_1+$border_width,
            $y_1+$border_width,
            $x_2-$border_width,
            $y_2-$border_width,
            $before_white
        );
        return $image_object;
    }

    static function get_label_height(int $label_len = 5){
        if(empty($label_len)) return 0; # $image_padding_row = self::$image_padding_row; $font_size = self::$font_size;  $font_line = 1*$image_padding_row+$font_size;  return $label_len*($font_line)+$image_padding_row;
        return $label_len*(self::$image_padding_row+self::$font_size)+self::$image_padding_row+14;
    }

    private static function set_return(){ #if(!empty($_REQUSET['need_log']) && self::$error) pre(self::$error);
        if(self::$errors) pre(self::$errors); #  pred(debug_backtrace()); #pred(self::$image_zoom_list); #pred(self::$image_combo_result);
        return [
            'error' => self::$error,
            'errors' => self::$errors,
            'image_list' => self::$image_list,
            'combo_car_number_coords' => self::$combo_car_number_coords,
            'result' => [
                'combo_image' => self::$image_combo_result,
                'zoom_image_list' => self::$image_zoom_list,
                'car_number_list' => self::$image_car_number_list,
                'before' => self::$image_before,
                'after' => self::$image_after,
                'middle' => self::$image_middle,
            ]
        ];
    }
}