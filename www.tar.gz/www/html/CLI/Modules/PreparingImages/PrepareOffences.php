<?php

namespace CLI\Modules\PreparingImages;

use Core\Modules\Dir;
use Common\Modules\Date;

trait PrepareOffences {

    private static function prepare_image_no_stop_with_2_images(){
        if(!count(self::$image_list)){ self::set_cerror('Image list is empty #1437 '. __FUNCTION__); return false; }
        $image_list = [];
        $camera_list = [];
        foreach(self::$image_list as $index => $row)
            switch($row['key']){
                case 'before':
                case 'middle':
                case 'source':
                case 'after': {
                    $image_list[$row['key']] = $row;
                    $image_list[$row['key']]['index'] = $index;
                    if(!isset($camera_list[$row['camera_id']]))
                        $camera_list[$row['camera_id']] = [];
                    $camera_list[$row['camera_id']][$row['key']] = $row;
                    break;
                }
            }
        if(count($image_list) < 1){ self::set_cerror('Image list < 1 '. __FUNCTION__); return false; }
        switch(count($camera_list)){
            case 1: {
                foreach($camera_list as $camera_id => $image_list) break;
                $image_quality_data = self::$image_resolution_list[self::$traffic_violation];
                $image_result_width = $image_quality_data['width'];
                $image_result_height = $image_quality_data['height'];
                $image_result_quality = $image_quality_data['quality'];
                $image_result = imagecreatetruecolor($image_result_width, $image_result_height);
                $label_list = [];
                $image_data = $image_list['before'];
                $direction_label = self::get_direction_label($image_data);

                $label_list[] = 'ID КОМПЛЕКСА: '. self::$object_id .'    ВРЕМЯ ФИКСАЦИИ: '. self::$timestamp .'    ТИП НАРУШЕНИЯ: С7';
                $label_list[] = 'АДРЕС: '.mb_strtoupper(self::$object_address, 'utf-8') . (empty($direction_label)?'':('    НАПРАВЛЕНИЕ: '.mb_strtoupper($direction_label, 'utf-8')));
                $label_list[] = 'КООРДИНАТЫ: '.mb_strtoupper(self::$object_gps, 'utf-8');

                $image_before_data = self::get_combo_image_with_car_number_object($image_list['before'], count($label_list), $image_result_width/2, $image_result_height-4*self::$image_padding_row, false, true, 1);
                $image_before_object = $image_before_data['image_object'];
                $image_before_width = $image_before_data['width'];
                $image_before_height = $image_before_data['height'];
                self::$image_combo_result['cropped'] = $image_before_data['cropped'];
                $image_after_data = self::get_combo_image_with_car_number_object($image_list['after'], count($label_list), $image_result_width/2, $image_result_height-4*self::$image_padding_row, false, true, 1);
                $image_after_object = $image_after_data['image_object'];
                $image_after_width = $image_after_data['width'];
                $image_after_height = $image_after_data['height'];
                self::$image_combo_result['cropped'] = $image_after_data['cropped'];
                $font_y = $image_result_height-self::get_label_height(1)-self::$image_padding_row;
                imagecopy($image_result, $image_before_object, 0, 0, 0, 0, $image_before_width, $image_before_height);
                imagecopy($image_result, $image_after_object, $image_before_width, 0, 0, 0, $image_after_width, $image_after_height);
                $image_result = self::get_image_with_bottom_label($image_result, $label_list, $font_y, self::$font_x);
                if(!empty($_GET['show_image'])){ header('Content-Type: image/jpeg'); imagejpeg($image_result); die; }
                Dir::create_dir(self::$image_combo_result['dir']);
                return imagejpeg($image_result, self::$image_combo_result['path'], self::$image_combo_result['quality']);
            }
            default: {
                self::set_cerror('Camera list is not correct '. __FUNCTION__);
                return false;
            }
        }
    }

    private static function prepare_image_reversal_new(){
        if(!count(self::$image_list)){ self::set_cerror('Image list is empty #1510 '. __FUNCTION__); return false; }
        $image_list = [];
        foreach(self::$image_list as $index => $row)
            switch($row['key']){
                case 'before':
                case 'middle':
                case 'after': {
                    $image_list[$row['key']] = $row;
                    $image_list[$row['key']]['index'] = $index;
                    break;
                }
            }
        if(count($image_list) != 2 && count($image_list) != 3){ self::set_cerror('Image list != 2 and != 3 prepare_image_reversal_new#1'); return false; }
        # $font_x = 7; $font_h = $font_x * 2;
        switch(count($image_list)){
            case 3: {
                $image_quality_data = self::$image_resolution_list[self::$traffic_violation];
                $image_result_width = $image_quality_data['width'];
                $image_result_height = $image_quality_data['height'];
                $image_result_quality = $image_quality_data['quality'];
                $image_result = imagecreatetruecolor($image_result_width, $image_result_height);
                $label_list = [];
                $image_data = $image_list['before'];
                $direction_label = self::get_direction_label($image_data);

                $timestamp = self::get_image_data_timestamp($image_list['middle']);
                $label_list[] = 'ID КОМПЛЕКСА: '. self::$object_id .'    ВРЕМЯ ФИКСАЦИИ: '.$timestamp .'    ТИП НАРУШЕНИЯ: С10';
                $label_list[] = 'АДРЕС: '. mb_strtoupper(self::$object_address, 'utf-8') . (empty($direction_label)?'':('    НАПРАВЛЕНИЕ: '. mb_strtoupper($direction_label, 'utf-8')));
                $label_list[] = 'КООРДИНАТЫ: '. mb_strtoupper(self::$object_gps, 'utf-8');

                $label_h = self::get_label_height(count($label_list));
                $left_column_w = (int)($image_result_width *.35);
                $left_column_h = (int)($image_result_height);
                $left_cell_h = (int)(($left_column_h / 2));
                $right_column_w = $image_result_width-$left_column_w;
                $right_column_h = (int)($image_result_height-$label_h);
                $image_before_object = self::get_combo_image_with_car_number_object($image_list['before'], 1, $left_column_w, $left_cell_h, false, true, 3, false, false, 'before');
                $image_after_object = self::get_combo_image_with_car_number_object($image_list['after'], 1, $left_column_w, $left_cell_h, false, true, 3, false, false, 'after');
                # $image_middle_object = self::get_combo_image_with_car_number_object($image_list['middle'], 0, $right_column_w, $right_column_h, false, false, 1);
                $image_middle_object = self::get_combo_image_with_car_number_object($image_list['middle'], 0, $right_column_w, $right_column_h, false, false, 1, false, false, null, 0.15, -0.15);
                # if(!empty($_GET['is_test_image'])){ header('Content-Type: image/jpeg'); imagejpeg($image_middle_object['image_object']); die; }
                # if(!empty($_GET['show_image'])){ header('Content-Type: image/jpeg'); imagejpeg($image_middle_object['image_object']); die; }
                imagecopy($image_result, $image_before_object['image_object'], 0, 0, 0, 0, $image_before_object['width'], $image_before_object['height']);
                imagecopy($image_result, $image_after_object['image_object'], 0, $image_before_object['height'], 0, 0, $image_after_object['width'], $image_after_object['height']);
                imagecopy($image_result, $image_middle_object['image_object'], $image_before_object['width'], 0, 0, 0, $image_middle_object['width'], $image_middle_object['height']);
                foreach($image_middle_object['cropped']['car_number_coords'] as $index => $car_number_coords_item) $image_middle_object['cropped']['car_number_coords'][$index]['x']+= $image_before_object['width'];
                self::$combo_car_number_coords = $image_middle_object['cropped']['car_number_coords'];
                $font_y = $image_middle_object['height']+4*self::$image_padding_row;
                $image_result = self::get_image_with_bottom_label($image_result, $label_list, $font_y, $left_column_w + self::$font_x);
                #if(!empty($_GET['show_image'])){ header('Content-Type: image/jpeg'); imagejpeg($image_result); die; }
                Dir::create_dir(self::$image_combo_result['dir']);
                if(!imagejpeg($image_result, self::$image_combo_result['path'], self::$image_combo_result['quality'])){ self::set_cerror('Image combo was not save '. __FUNCTION__ .', fp__'. self::$image_combo_result['path']); return false; }
                return true;
            }
            default: {
                self::set_cerror('Image list count is not correct '. __FUNCTION__);
                return false;
            }
        }
    }

    private static function prepare_image_oncoming_lane(){ # need add convert car number coords...and need test
        if(!count(self::$image_list)){ self::set_cerror('Image list is empty #1598'. __FUNCTION__); return false; }
        $image_list = [];
        $camera_list = [];
        foreach(self::$image_list as $index => $row)
            switch($row['key']){
                case 'before':
                case 'middle':
                case 'source':
                case 'after': {
                    $image_list[$row['key']] = $row;
                    $image_list[$row['key']]['index'] = $index;
                    if(!isset($camera_list[$row['camera_id']]))
                        $camera_list[$row['camera_id']] = [];
                    $camera_list[$row['camera_id']][$row['key']] = $row;
                    break;
                }
            }
        if(!count($image_list)){ self::set_cerror('Image list < 1 '. __FUNCTION__); return false; }
        switch(count($camera_list)){
            case 1: {
                foreach($camera_list as $camera_id => $image_list)
                    break;
                $label_list = [];
                $image_data = $image_list['middle'];
                $direction_label = self::get_direction_label($image_data);
                $image_quality_data = self::$image_resolution_list[self::$traffic_violation];
                $image_result_width = $image_quality_data['width'];
                $image_result_height = $image_quality_data['height'];
                $image_result_quality = $image_quality_data['quality'];
                $image_result = imagecreatetruecolor($image_result_width, $image_result_height);

                $label_list[] = 'ID КОМПЛЕКСА: '. self::$object_id .'    ВРЕМЯ ФИКСАЦИИ: '. self::$timestamp .'    ТИП НАРУШЕНИЯ: С7';
                $label_list[] = 'АДРЕС: '.mb_strtoupper(self::$object_address, 'utf-8'). (empty($direction_label)?'':('    НАПРАВЛЕНИЕ: '.mb_strtoupper($direction_label, 'utf-8').'    ')) .'    КООРДИНАТЫ: '.mb_strtoupper(self::$object_gps, 'utf-8');

                $label_len = count($label_list);
                $label_h = self::get_label_height($label_len);
                $image_before_data = self::get_combo_image_with_car_number_object($image_data, 0, $image_result_width, $image_result_height-$label_h, false, false, 1);
                $image_before_object = $image_before_data['image_object'];
                $image_before_width = $image_before_data['width'];
                $image_before_height = $image_before_data['height'];
                self::$image_combo_result['cropped'] = $image_before_data['cropped'];
                if(!imagecopy($image_result, $image_before_object, 0, 0, 0, 0, $image_before_width, $image_before_height)){ self::set_cerror('Image was not copy resize '. __FUNCTION__); return false; }
                self::$combo_car_number_coords = $image_before_data['cropped']['car_number_coords'];
                # foreach($image_middle_object['cropped']['car_number_coords'] as $index => $car_number_coords_item) $image_middle_object['cropped']['car_number_coords'][$index]['x']+= $image_before_object['width'];//
                # self::$combo_car_number_coords = $image_middle_object['cropped']['car_number_coords'];
                $image_result = self::get_image_with_bottom_label($image_result, $label_list, $image_before_height+self::$image_padding_row+self::$font_size, self::$font_x);
                if(!empty($_GET['show_image'])){ header('Content-Type: image/jpeg'); imagejpeg($image_result); die; }
                Dir::create_dir(self::$image_combo_result['dir']);
                if(!imagejpeg($image_result, self::$image_combo_result['path'], self::$image_combo_result['quality'])){
                    self::set_cerror('Image combo was not save '. __FUNCTION__ .', fp__'. self::$image_combo_result['path']);
                    return false;
                }
                return true;
            }
            default: {
                self::set_cerror('Camera list is not correct '. __FUNCTION__);
                return false;
            }
        }
    }

    private static function prepare_image_no_parking_with_2_images(){
        if(!count(self::$image_list)){ self::set_cerror('Image list is empty #1756 '. __FUNCTION__); return false; }
        $image_list = [];
        $camera_list = [];
        foreach(self::$image_list as $index => $row)
            switch($row['key']){
                case 'before':
                case 'middle':
                case 'source':
                case 'after': {
                    $image_list[$row['key']] = $row;
                    $image_list[$row['key']]['index'] = $index;
                    if(!isset($camera_list[$row['camera_id']]))
                        $camera_list[$row['camera_id']] = [];
                    $camera_list[$row['camera_id']][$row['key']] = $row;
                    break;
                }
            }
        if(count($image_list) < 1){ self::set_cerror('Image list < 1 '. __FUNCTION__); return false; }
        switch(count($camera_list)){
            case 1: {
                foreach($camera_list as $camera_id => $image_list) break;
                $image_quality_data = self::$image_resolution_list[self::$traffic_violation];
                $image_result_width = $image_quality_data['width'];
                $image_result_height = $image_quality_data['height'];
                $image_result_quality = $image_quality_data['quality'];
                $image_result = imagecreatetruecolor($image_result_width, $image_result_height);
                $label_list = [];
                $image_data = $image_list['before'];
                $direction_label = self::get_direction_label($image_data);

                $label_list[] = 'ID КОМПЛЕКСА: '. self::$object_id .'    ВРЕМЯ ФИКСАЦИИ: '. self::$timestamp .'    ТИП НАРУШЕНИЯ: С2';
                $label_list[] = 'АДРЕС: '.mb_strtoupper(self::$object_address, 'utf-8') . (empty($direction_label)?'':('    НАПРАВЛЕНИЕ: '.mb_strtoupper($direction_label, 'utf-8')));
                $label_list[] = 'КООРДИНАТЫ: '.mb_strtoupper(self::$object_gps, 'utf-8');

                $image_before_data = self::get_combo_image_with_car_number_object($image_list['before'], count($label_list), $image_result_width/2, $image_result_height-4*self::$image_padding_row, false, true, 1);
                $image_before_object = $image_before_data['image_object'];
                $image_before_width = $image_before_data['width'];
                $image_before_height = $image_before_data['height'];
                self::$image_combo_result['cropped'] = $image_before_data['cropped'];
                $image_after_data = self::get_combo_image_with_car_number_object($image_list['after'], count($label_list), $image_result_width/2, $image_result_height-4*self::$image_padding_row, false, true, 1);
                $image_after_object = $image_after_data['image_object'];
                $image_after_width = $image_after_data['width'];
                $image_after_height = $image_after_data['height'];
                self::$image_combo_result['cropped'] = $image_after_data['cropped'];
                $font_y = $image_result_height-self::get_label_height(1)-self::$image_padding_row;
                imagecopy($image_result, $image_before_object, 0, 0, 0, 0, $image_before_width, $image_before_height);
                imagecopy($image_result, $image_after_object, $image_before_width, 0, 0, 0, $image_after_width, $image_after_height);
                $image_result = self::get_image_with_bottom_label($image_result, $label_list, $font_y, self::$font_x);
                if(!empty($_GET['show_image'])){ header('Content-Type: image/jpeg'); imagejpeg($image_result); die; }
                Dir::create_dir(self::$image_combo_result['dir']);
                return imagejpeg($image_result, self::$image_combo_result['path'], self::$image_combo_result['quality']);
            }
            default: {
                self::set_cerror('Camera list is not correct '. __FUNCTION__);
                return false;
            }
        }
    }

    private static function prepare_image_lane(){ # set_source_image_path
        if(!count(self::$image_list)){ self::set_cerror(__FUNCTION__ .':'. __LINE__ .' | Image list is empty #256'); return false; }
        $image_list = [];
        foreach(self::$image_list as $index => $row)
            switch($row['key']){
                case 'before':
                case 'middle':
                case 'after': {
                    $image_list[$row['key']] = $row;
                    $image_list[$row['key']]['index'] = $index;
                    break;
                }
            }
        if(count($image_list) != 2 && count($image_list) != 3){ self::set_cerror(__FUNCTION__ .':'. __LINE__ .' | Image list != 2 and != 3'); return false; } # pred($image_list);
        # $font_x = 7; $font_h = $font_x * 2; #pre(array_keys($image_list)); #pred($image_list); pred(count($image_list));
        switch(count($image_list)){
            case 3: {
                $image_quality_data = self::$image_resolution_list[self::$traffic_violation];
                $image_result_width = $image_quality_data['width'];
                $image_result_height = $image_quality_data['height']; # $image_result_quality = $image_quality_data['quality'];
                $image_result = imagecreatetruecolor($image_result_width, $image_result_height);
                $label_list = [];
                $image_data = $image_list['before'];
                $direction_label = self::get_direction_label($image_data);

                $timestamp = self::get_image_data_timestamp($image_list['middle']);
                $label_list[] = 'ID КОМПЛЕКСА: '. self::$object_id .'    ВРЕМЯ ФИКСАЦИИ: '.$timestamp;

                if(self::$floor_speed === 'n/a') $speed = 'СКОРОСТЬ ТС: '. self::$floor_speed; else $speed = 'СКОРОСТЬ ТС,  КМ/Ч: '. self::$floor_speed;
                $label_list[] = $speed .' (ОГРАНИЧЕНИЕ '.$image_data['speed_max'].'/'.$image_data['speed_max'].')';
                if(!empty($direction_label)) $label_list[] = 'НАПРАВЛЕНИЕ: '.mb_strtoupper($direction_label, 'utf-8');
                $label_list[] = 'АДРЕС: '. mb_strtoupper(self::$object_address, 'utf-8') .'    GPS: '. mb_strtoupper(self::$object_gps, 'utf-8') .'    C7';

                $label_h = self::get_label_height(count($label_list));
                $left_column_w = (int)($image_result_width*.35);
                $left_column_h = (int)($image_result_height);
                $left_cell_h = (int)(($left_column_h / 2));
                $right_column_w = $image_result_width-$left_column_w;
                $right_column_h = (int)($image_result_height-$label_h);
                $image_before_object = self::get_combo_image_with_car_number_object($image_list['before'], 1, $left_column_w, $left_cell_h, false, true, 3, false, false, 'before');
                $image_after_object = self::get_combo_image_with_car_number_object($image_list['after'], 1, $left_column_w, $left_cell_h, false, true, 3, false, false, 'after');
                # $image_middle_object = self::get_combo_image_with_car_number_object($image_list['middle'], 0, $right_column_w, $right_column_h, false, false, 1);
                # $right_column_w = 500; #$right_column_h = 400; #pre($right_column_w);pred($right_column_h);
                # $image_middle_object = self::get_combo_image_with_car_number_object($image_list['middle'], 0, $right_column_w, $right_column_h, false, false, 1, false, false, null, 0.15, -0.15);
                $image_middle_object = self::get_combo_image_with_car_number_object($image_list['middle'], 0, $right_column_w, $right_column_h, false, false, 1, false, false, null); # ID 31624 fix Collages wrong crop
                # if(!empty($_GET['is_test_image'])){ header('Content-Type: image/jpeg');  imagejpeg($image_middle_object['image_object']); die; }
                #if(!empty($_GET['show_image'])){ header('Content-Type: image/jpeg'); imagejpeg($image_middle_object['image_object']); die; } # MIDe
                imagecopy($image_result, $image_before_object['image_object'], 0, 0, 0, 0, $image_before_object['width'], $image_before_object['height']);
                imagecopy($image_result, $image_after_object['image_object'], 0, $image_before_object['height'], 0, 0, $image_after_object['width'], $image_after_object['height']);
                imagecopy($image_result, $image_middle_object['image_object'], $image_before_object['width'], 0, 0, 0, $image_middle_object['width'], $image_middle_object['height']);
                foreach($image_middle_object['cropped']['car_number_coords'] as $index => $car_number_coords_item) $image_middle_object['cropped']['car_number_coords'][$index]['x']+= $image_before_object['width'];
                self::$combo_car_number_coords = $image_middle_object['cropped']['car_number_coords'];
                $font_y = $image_middle_object['height'] + 4 * self::$image_padding_row;
                $image_result = self::get_image_with_bottom_label($image_result, $label_list, $font_y, $left_column_w+self::$font_x);
                # if(!empty($_GET['show_image'])){header('Content-Type: image/jpeg'); imagejpeg($image_result); die; }
                Dir::create_dir(self::$image_combo_result['dir']);
                if(!imagejpeg($image_result, self::$image_combo_result['path'], self::$image_combo_result['quality'])){ self::set_cerror('Image combo was not save '. __FUNCTION__ .', fp__'. self::$image_combo_result['path']); return false; }
                return true;
            }
            default: {
                self::set_cerror('Image list count is not correct '. __FUNCTION__);
                return false;
            }
        }
    }

    private static function prepare_image_route_vehicles(){
        if(!count(self::$image_list)){ self::set_cerror(__FUNCTION__ .':'. __LINE__ .' | Image list is empty #325'); return false; }
        $image_list = [];
        foreach(self::$image_list as $index => $row)
            switch($row['key']){
                case 'before':
                case 'middle':
                case 'after': {
                    $image_list[$row['key']] = $row;
                    $image_list[$row['key']]['index'] = $index;
                    break;
                }
            }
        if(count($image_list) != 2 && count($image_list) != 3){ self::set_cerror(__FUNCTION__ .':'. __LINE__ .' | Image list != 2 and != 3'); return false; } # pred($image_list);
        # $font_x = 7; $font_h = $font_x * 2; #pre(array_keys($image_list)); #pred($image_list); pred(count($image_list));
        switch(count($image_list)){
            case 3: {
                $image_quality_data = self::$image_resolution_list[self::$traffic_violation];
                $image_result_width = $image_quality_data['width'];
                $image_result_height = $image_quality_data['height']; # $image_result_quality = $image_quality_data['quality'];
                $image_result = imagecreatetruecolor($image_result_width, $image_result_height);
                $label_list = [];
                $image_data = $image_list['before'];
                $direction_label = self::get_direction_label($image_data);

                $timestamp = self::get_image_data_timestamp($image_list['middle']);
                $label_list[] = 'ID КОМПЛЕКСА: '. self::$object_id .'    ВРЕМЯ ФИКСАЦИИ: '.$timestamp;

                if(self::$floor_speed === 'n/a') $speed = 'СКОРОСТЬ ТС: '. self::$floor_speed; else $speed = 'СКОРОСТЬ ТС,  КМ/Ч: '. self::$floor_speed;
                $label_list[] = $speed .' (ОГРАНИЧЕНИЕ '. $image_data['speed_max'] .'/'. $image_data['speed_max'].')';
                if(!empty($direction_label)) $label_list[] = 'НАПРАВЛЕНИЕ: '.mb_strtoupper($direction_label, 'utf-8');
                $label_list[] = 'АДРЕС: '.mb_strtoupper(self::$object_address, 'utf-8') .'    GPS: '.mb_strtoupper(self::$object_gps, 'utf-8') .'    C6';

                $label_h = self::get_label_height(count($label_list));
                $left_column_w = (int)($image_result_width*.35);
                $left_column_h = (int)($image_result_height);
                $left_cell_h = (int)(($left_column_h/2));
                $right_column_w = $image_result_width-$left_column_w;
                $right_column_h = (int)($image_result_height-$label_h);
                $image_before_object = self::get_combo_image_with_car_number_object($image_list['before'], 1, $left_column_w, $left_cell_h, false, true, 2, false, false, 'before', 0, -0.2);
                $image_after_object = self::get_combo_image_with_car_number_object($image_list['after'], 1, $left_column_w, $left_cell_h, false, true, 3, false, false, 'after', 0, -0.2);
                #$image_middle_object = self::get_combo_image_with_car_number_object($image_list['middle'], 0, $right_column_w, $right_column_h, false, false, 1);
                $image_middle_object = self::get_combo_image_with_car_number_object($image_list['middle'], 0, $right_column_w, $right_column_h, false, false, 1, false, false, null, 0, -0.15);
                #pred($image_middle_object);
                # if(!empty($_GET['show_image'])){ header('Content-Type: image/jpeg'); imagejpeg($image_before_object['image_object']); die;}
                # if(!empty($_GET['show_image'])){ header('Content-Type: image/jpeg'); imagejpeg($image_middle_object['image_object']); die; }
                imagecopy($image_result, $image_before_object['image_object'], 0, 0, 0, 0, $image_before_object['width'], $image_before_object['height']);
                imagecopy($image_result, $image_after_object['image_object'], 0, $image_before_object['height'], 0, 0, $image_after_object['width'], $image_after_object['height']);
                imagecopy($image_result, $image_middle_object['image_object'], $image_before_object['width'], 0, 0, 0, $image_middle_object['width'], $image_middle_object['height']);
                foreach($image_middle_object['cropped']['car_number_coords'] as $index => $car_number_coords_item) $image_middle_object['cropped']['car_number_coords'][$index]['x']+= $image_before_object['width'];
                self::$combo_car_number_coords = $image_middle_object['cropped']['car_number_coords'];
                $font_y = $image_middle_object['height']+4*self::$image_padding_row;
                $image_result = self::get_image_with_bottom_label($image_result, $label_list, $font_y, $left_column_w+self::$font_x);
                if(!empty($_GET['show_image'])){ header('Content-Type: image/jpeg'); imagejpeg($image_result); die; }
                Dir::create_dir(self::$image_combo_result['dir']);
                if(!imagejpeg($image_result, self::$image_combo_result['path'], self::$image_combo_result['quality'])){ self::set_cerror('Image combo was not save '. __FUNCTION__ .', fp__'. self::$image_combo_result['path']); return false; }
                return true;
            }
            default: {
                self::set_cerror('Image list count is not correct '. __FUNCTION__);
                return false;
            }
        }
    }
}