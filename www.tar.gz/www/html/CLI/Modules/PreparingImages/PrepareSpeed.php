<?php

namespace CLI\Modules\PreparingImages;

use Core\Modules\Dir;

trait PrepareSpeed {

    static function prepare_image_speed(){ #pred(self::$image_combo_result);
        if(!count(self::$image_list)){ self::set_cerror('Image list < 1 prepare_image_speed#1'); return false; }
        $image_list = [];
        $camera_list = [];
        foreach(self::$image_list as $index => $row)
            switch($row['key']){
                case 'before':
                case 'middle':
                case 'source':
                case 'after': {
                    $image_list[$row['key']] = $row;
                    $image_list[$row['key']]['index'] = $index;
                    if(!isset($camera_list[$row['camera_id']])) $camera_list[$row['camera_id']] = [];
                    $camera_list[$row['camera_id']][$row['key']] = $row;
                    break;
                }
            }
        if(!count($image_list)){ self::set_cerror('Image list < 1 prepare_image_speed#2'); return false; }

        switch(count($camera_list)){  # http://88.201.178.22:2050/api/json/crreate_image_test?journal_id = 16951&show_image = 1
            case 1: {
                foreach($camera_list as $camera_id => $image_list) break;
                $image_result_data = self::get_image_speed_object($image_list['middle'], 3, false); #pred($image_result_data);
                #$image_before_object_resized = ImageConvert::resize_image_from_image_object($image_before_object_cropped, $image_result_width, $image_result_height, $image_type, self::$traffic_violation_type);
                self::$combo_car_number_coords = $image_result_data['cropped']['car_number_coords']; # if(!empty($_GET['show_image'])){ header('Content-Type: image/jpeg'); imagejpeg($image_result); die; }
                Dir::create_dir(self::$image_combo_result['dir']); #pre(self::$image_combo_result);
                # self::$image_combo_result['cropped']['car_number_coords'] = self::$combo_car_number_coords; # ADDED LPN COORDS FOR OFFENCES BY ALENEVI #pred(self::$image_combo_result); #pred(self::$combo_car_number_coords); #self::$image_combo_result
                if(0 && !cli && !empty($_GET['si'])){ header('Content-Type: image/jpeg'); imagejpeg($image_result_data['image_object']); die; }

                return imagejpeg($image_result_data['image_object'], self::$image_combo_result['path'], self::$image_combo_result['quality']);
            }
            // на случай если ВДРУГ понадобится калаж с двух камер http://88.201.178.22:2050/api/json/crreate_image_test?journal_id = 16943&show_image = 1
//            case 2: {
//                $image_col_list = [];
//                foreach($camera_list as $camera_id => $image_list){
//                    $image_result_data = self::get_image_speed_object($image_list['middle'], count($image_col_list));
//                    $image_col_list[] = $image_result_data;
//                    if(count($image_col_list) == 2)
//                        break;
//                }
//                $image_quality_data = self::$image_resolution_list[self::$traffic_violation];
//                $image_result_width = $image_quality_data['width']*2;
//                $image_result_height = $image_quality_data['height'];
//                $image_result_quality = $image_quality_data['quality'];
//
//                $image_result = imagecreatetruecolor($image_result_width, $image_result_height);
//                $image_x = 0;
//                foreach($image_col_list as $image_row){
//                    imagecopy($image_result, $image_row['image_object'], $image_x, 0, 0, 0, $image_row['width'], $image_row['height']);
//                    $image_x+= $image_row['width'];
//                }
//                if(!empty($_GET['show_image'])){ header('Content-Type: image/jpeg'); imagejpeg($image_result); die; }//
//                Dir::create_dir(self::$image_combo_result['dir']);//
//                return imagejpeg($image_result, self::$image_combo_result['path'], self::$image_combo_result['quality']);            }
            default: {
                self::set_cerror('A lot of images count');
                return false;
            }
        }
    }



    static function get_image_speed_object(array $image_data = null, int $index = null, bool $need_car_number = true){ #pre($need_car_number); pred(func_get_args());
        if(empty($image_data)) return null;
        $label_list = [];
        $direction_label = self::get_direction_label($image_data);
        $image_quality_data = self::$image_resolution_list[self::$traffic_violation];
        $image_result_width = $image_quality_data['width'];
        $image_result_height = $image_quality_data['height'];
        $image_result_quality = $image_quality_data['quality'];
        $image_result = imagecreatetruecolor($image_result_width, $image_result_height);
        if(is_null($index)) $label_list[] = 'ДАТА/ВРЕМЯ ФИКСАЦИИ: '. self::$timestamp;
        else {
            switch($index){
                case 0: { $label_list[] = 'ПЕРВАЯ ФИКСАЦИЯ: '. self::$timestamp; break; }
                case 1: { $label_list[] = 'ВТОРАЯ ФИКСАЦИЯ: '. self::$timestamp; break; }
            }
        }

        $label_list[] = 'ID КОМПЛЕКСА: '. self::$object_id .'    ВРЕМЯ ФИКСАЦИИ: '. self::$timestamp;
        if(self::$floor_speed === 'n/a') $speed = 'СКОРОСТЬ ТС: '. self::$floor_speed; else $speed = 'СКОРОСТЬ ТС,  КМ/Ч: '. self::$floor_speed;
        $label_list[] = $speed .' (ОГРАНИЧЕНИЕ '. $image_data['speed_max'] .'/'. $image_data['speed_max'] .')';
        $label_list[] = (empty($direction_label)?'':('НАПРАВЛЕНИЕ: '. mb_strtoupper($direction_label, 'utf-8')));
        $label_list[] = 'АДРЕС: '. mb_strtoupper(self::$object_address, 'utf-8');
        $label_list[] = 'GPS: '. mb_strtoupper(self::$object_gps, 'utf-8') .'    С1.1';

        $label_len = count($label_list);
        $car_number_x = 0; $car_number_y = 0;
        $car_number_w = 0; $car_number_h = 0;
        $image_car_number_before_object = null;
        if($need_car_number){
            $image_car_number_before_data = self::get_car_number_image_object($image_data);
            $image_car_number_before_object = $image_car_number_before_data['image_object'];
            $car_number_w = $image_car_number_before_data['width'];
            $car_number_h = $image_car_number_before_data['height'];
            $car_number_x = (int)($image_result_width / 2 - $car_number_w / 2);
            $image_cropped_h = $image_result_height-$car_number_h - 3 * self::$image_padding_row;
            $image_before_data = self::get_combo_image_with_car_number_object($image_data, $label_len, $image_result_width, $image_cropped_h, false, false, 1);
            #get_combo_image_with_car_number_object($image_data, 0, $image_result_width, $image_result_height, false, false, 3, false, false, 'middle');
        } else {
            $image_cropped_h = $image_result_height-self::get_label_height($label_len);
            $image_before_data = self::get_combo_image_with_car_number_object($image_data, 0, $image_result_width, $image_cropped_h, false, false, self::$balancer->sets['imaging']['crop_zoom'], false, false, 'speed_crop', 0, 0);
        }
        $image_before_object = $image_before_data['image_object'];
        $image_before_w = $image_before_data['width'];
        $image_before_h = $image_before_data['height'];
        # if(!empty($_GET['show_image'])){  header('Content-Type: image/jpeg'); imagejpeg($image_before_object); die; }
        // final image
        # imagecopyresized($image_result, $image_before_object, 0, 0, 0, 0, $image_result_width, $image_result_height, $image_before_data['cropped']['width'], $image_before_data['cropped']['height']);
        imagecopy($image_result, $image_before_object, 0, 0, 0, 0, $image_before_w, $image_before_h);
        # if(!empty($_GET['show_image'])){ header('Content-Type: image/jpeg'); imagejpeg($image_result); die; }
        if($need_car_number) imagecopy($image_result, $image_car_number_before_object, $car_number_x, $image_before_h+self::$image_padding_row, 0, 0, $car_number_w, $car_number_h);
        # $font_y = $image_before_h+$car_number_h+self::$image_padding_row+self::$font_size;
        $font_y = $image_before_h + self::$font_size + 12;
        $image_result = self::get_image_with_bottom_label($image_result, $label_list, $font_y, self::$font_x);
        if(0 && !cli && !empty($_GET['show_image'])){ header('Content-Type: image/jpeg'); imagejpeg($image_result); die; }
        /* $image_result_temp = imagecreatetruecolor($image_result_width, $image_result_height); echo $image_result_width.'x'.$image_result_height;die;
        imagecopyresized($image_result_temp, $image_result, 0, 0, 0, 0, $image_result_width, $image_result_height, $image_before_data['cropped']['width'], $image_before_data['cropped']['height']);
        if(!empty($_GET['show_image'])){ header('Content-Type: image/jpeg'); imagejpeg($image_result_temp); die; } */
        return [
            'image_object' => $image_result,
            'width' => $image_result_width,
            'height' => $image_result_height,
            'cropped' => $image_before_data['cropped']
        ];
    }
}