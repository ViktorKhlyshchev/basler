<?php

namespace CLI\Modules\PreparingImages;

use Common\Modules\Date;
use Core\Modules\Dir;
use Common\Models\Image\Image; # use Common\Modules\ImageConvert;
use Common\Models\Image\ImageItem;
use Core\Modules\Json;
use Common\Modules\ImagePathAction; # use Common\Modules\ImagePathListAction;
use Common\Models\Journal;
use Common\Models\JournalImage;
use Common\Models\XavierInfo;
use Common\Models\Zone;

class PrepareImagesAction { # was GetPreparedJournalImageListAction VIP lines 886 1040 1052 http://aist.loc/admin/cli/balancer?si=1

    use PrepareCombo;
    use PrepareNone;
    use PrepareExtra; # prepare_image_none
    use PrepareBMA;
    use PrepareOffences;
    use PrepareSpeed;
    use PrepareTest;

    static $error;
    static $errors = [];
    static $balancer;
    static $journal_id;
    static $object_id;
    static $object_address;
    static $serial_number;
    static $certificate_number;
    static $object_gps;
    static $timestamp;
    static $speed; # static $speed_max;
    static $floor_speed;
    static $speed_quality;
    static $traffic_violation;
    static $traffic_violation_type;
    static $is_track_glued;
    static $image_before;
    static $image_middle;
    static $image_after;
    static $image_combo_result; # static $number_coords_collage;
    static $image_zoom_list = [];
    static $image_car_number_list = []; # static $camera_direction_list = [];
    static $direction_list = [];
    static $image_list = []; # static $image_key_list = [];

    static $image_padding_row = 5;
    static $car_number_percent = 3;
    static $font_file = DR .'/Static/fonts/RobotoTTF/Roboto-Regular.ttf';
    static $font_size = 8;
    static $font_x = 7;
    static $font_h = 9;
    static $border_width = 2;
    static $car_border_w_percent = 4;
    static $car_border_h_percent = 9; # static $car_number_border_padding_x = 15; static $car_number_border_padding_y = 50;
    static $timezone;
    static $combo_car_number_coords = [];
    static $camera_direction_list = [];
    static $sets;

    static function init(int $journal_id = null, $balancer = null){
        if(empty($journal_id)) return null;
        self::$balancer = $balancer;
        self::$sets = &$balancer->sets; #pred(self::$sets);
        self::$border_width = self::$sets['imaging']['border_width'];
        self::reset_data();
        self::$journal_id = $journal_id;
        self::set_timezone();
        self::remove_journal_image();
        if(!self::set_journal_data()) return self::set_return(); #pred(123);
        if(!self::set_journal_image_data()) return self::set_return(); #pred(self::$image_list); #pred(321);
        if(!self::set_zone_data()) return self::set_return();
        if(!self::set_xavier_data()) return self::set_return();
        self::$camera_direction_list = Zone::get_camera_direction_list();
        if(!self::set_direction_list()) return self::set_return();
        if(!self::set_source_image_path()) return self::set_return();
        if(!self::set_result_image_id()) return self::set_return();
        if(!self::prepare_image()) return self::set_return(); #if(isset($_GET['showpaths']))pred('PATHS#1');
        return self::set_return();
    }

    static function prepare_image(){ #pred(self::$traffic_violation);
        switch(self::$traffic_violation){ // калаж для двух разных камер с ОДНОГО КОМПЛЕКСА before,  after & middle(обязательно) // http://88.201.178.22:2050/api/json/crreate_image_test?journal_id = 16943&show_image = 1 // journal_id: 16951 // только одно изображение before,  after & middle(обязательно) // http://88.201.178.22:2050/api/json/crreate_image_test?journal_id = 16951&show_image = 1
            case 'speed_20':
            case 'speed_40':
            case 'speed_60':
            case 'speed_80': { # before - первая фиксация after - последняя фикцсация middle - для коллажа # self::prepare_image_before();
                self::$traffic_violation_type = 'speed';
                if(!self::prepare_image_middle()) return false; # COMBO!! #pred(self::$image_combo_result); # self::prepare_image_after()
                return self::prepare_image_speed(); # get_image_speed_object -> get_combo_image_with_car_number_object
            } # journal_id: 16945 http://88.201.178.22:2050/api/json/crreate_image_test?journal_id = 16945&show_image = 1
            case 'lane': # journal_id: 16923 3 картинки в каллаже before,  after & middle # http://88.201.178.22:2050/api/json/crreate_image_test?journal_id = 16923&show_image = 1
            case 'lane_opposite':
            case 'crosswalk':
            case 'roadside': {
                if(!self::prepare_image_before(true, true, true)) return false;
                if(!self::prepare_image_middle(false)) return false;
                if(!self::prepare_image_after(true, true, false)) return false; #if(isset($_GET['showpaths']))pred('PATHS#1');
                return self::prepare_image_lane();
            }
            case 'route_vehicles': {
                if(!self::prepare_image_before(true, true, false)) return false;
                if(!self::prepare_image_middle(false, true)) return false;
                if(!self::prepare_image_after(true, true, false)) return false;
                return self::prepare_image_route_vehicles();
            } # journal_id: 17104  одно изображение http://88.201.178.22:2050/api/json/crreate_image_test?journal_id = 17104&show_image = 1
            case 'reversal': {
                if(!self::prepare_image_before(true, true, true)) return false;
                if(!self::prepare_image_middle(false)) return false;
                if(!self::prepare_image_after(true, true, false)) return false;
                return self::prepare_image_reversal_new();
            } # journal_id: 17104 # одно изображение http://88.201.178.22:2050/api/json/crreate_image_test?journal_id = 17104&show_image = 1
            case 'oncoming_lane': {
                if(!self::prepare_image_middle()) return false;
                return self::prepare_image_oncoming_lane();
            } #case 'no_stop': { if(!self::prepare_image_middle()) return false; return self::prepare_image_no_stop();    } case 'no_parking': { if(!self::prepare_image_middle())   return false; return self::prepare_image_no_parking(); }
            case 'no_stop': {
                if(!self::prepare_image_before(true, true, true)) return false;
                if(!self::prepare_image_after(true, true, false)) return false;
                return self::prepare_image_no_stop_with_2_images();
            }
            case 'no_parking': {
                if(!self::prepare_image_before(true, true, true)) return false;
                if(!self::prepare_image_after(true, true, false)) return false;
                return self::prepare_image_no_parking_with_2_images();
            }
            case 'none': {
                self::$traffic_violation_type = 'none';
                if(!self::prepare_image_middle()) return; #pred(self::$image_combo_result); pred(321); #pred(self::$image_combo_result);
                return self::prepare_image_none(); #pred(self::$image_combo_result);
            }
            default: {
                self::set_cerror(__FUNCTION__ .':'. __LINE__ .' | Traffic violation is not correct:'. self::$traffic_violation);
                return false;
            }
        }
    }

    static function set_journal_data(){ # pred(self::$sets['zone']['speed_permissible']);
        $r = Journal::get_journal_data_for_overlay_image(self::$journal_id); #pred($r);
        if(empty($r)){ self::set_cerror(__FUNCTION__ .':'. __LINE__ .' | Image collage was not created #3 '); return false; }
        self::$timestamp = empty($r['date_start_track']) ? null : Date::get_ms_from_date_time_ms($r['date_start_track']);
        self::$timestamp += self::$timezone * 3600 * 1000;
        self::$timestamp = Date::get_date_time_ms_full_from_ms(self::$timestamp);

        self::$speed_quality = $r['speed_quality'];
        self::$speed = $r['speed'];
        if(self::$speed > self::$sets['common_pack']['max_speed_for_speed_na'] || self::$speed < 0){
            self::$speed = 'n/a';
            self::$floor_speed = 'n/a';
        }
        if(self::$speed_quality < self::$sets['common_pack']['min_speed_quality_for_speed_na']){
            if(self::$speed > self::$sets['zone']['speed_permissible']){
                self::$speed = 'n/a';
                self::$floor_speed = 'n/a';
            }
        }
        if(self::$speed !== 'n/a') self::$floor_speed = floor(self::$speed);
        self::$traffic_violation = $r['traffic_violation'];
        self::$is_track_glued = $r['is_track_glued'];
        return true;
    }

    static function set_source_image_path(){
        if(!count(self::$image_list)){ self::set_cerror('Image list is empty #4' . __FUNCTION__); return false; }
        foreach(self::$image_list as $index => $row){
            if(!empty($_REQUEST['need_dlog'])) pre('before image path action:__'. $row['source_image_id'] ."\n"); #pred(debug_backtrace());
            if(0){
                unset($row['track_coords']);
                unset($row['car_number_coords']);
            } #pred(self::$image_list); #pred($row); #pre($row['source_image_id']);
            if(loc) $crucial = true; else $crucial = false;
            $r = ImagePathAction::get_image_path_data($row['source_image_id'], true, true, true, $crucial);
            if(!empty($_REQUEST['need_dlog'])) pre('after image path action: '.$row['source_image_id']."\n\n");
            if(!count($r)){
                self::set_cerror('Image list is empty #4'. __FUNCTION__);
                if(loc){
                    unset($row['car_number_coords']);
                    unset($row['track_coords']);
                    #pred(self::$journal_id, self::$error .':__', $row);
                }
                return false;
            }
            self::$image_list[$index]['source_image_path'] = Dir::get_global_dir($r['image_dir']) .'/'. $r['image_item_id_list']['source']['id'];
            self::$image_list[$index]['source_image_width'] = $r['image_item_id_list']['source']['width'];
            self::$image_list[$index]['source_image_height'] = $r['image_item_id_list']['source']['height'];
            $file_path = Dir::get_global_dir($r['image_dir']) .'/'. $r['image_item_id_list']['source']['id']; #if(nl) pre("SOURCE IMAGE PATH__", $file_path."\n");
            if(!file_exists($file_path)){ #pred(debug_backtrace());
                if(loc) return true; # LOC DEBUG #2
                self::set_cerror('Source image path is empty, fp__'. $file_path .' | '. __FUNCTION__);
                return false;
            }
            $file_size = filesize($file_path);
            if($file_size < 100){ self::set_cerror(__CLASS__ .'::'. __FUNCTION__ .': Source image file size is empty #196, fs__'. $file_size .' fp__'. $file_path); return false; }
        }
        return true;
    }

    static function get_image_db_data(string $image_type = null){ #if(empty($image_type)) pred(debug_backtrace());# pree(func_get_args());
        if(empty($image_type)) $image_resolution = self::$image_resolution_list[self::$traffic_violation]; else $image_resolution = self::$image_sizes_list[$image_type];
        $image_id = Image::add_image_full(null, null, null, $image_resolution['width'], $image_resolution['height'], 'image/jpeg', null, 'image/jpeg', 'jpg'); # Hash::get_random_hash(), pre($image_id);
        if(empty($image_id)) return null;
        $image_item_id = ImageItem::add_image_item(null, $image_id, $image_resolution['width'], $image_resolution['height'], 'source', 'image/jpeg', null, 'image/jpeg', 'jpg');
        if(!empty($_REQUEST['need_dlog'])) pre('before image path action 2: '.$image_id."\n");
        $r = ImagePathAction::get_image_path_data($image_id, true, true, true);
        if(!empty($_REQUEST['need_dlog'])) pre('after image path action 2: '.$image_id."\n");
        if(empty($r)) return;
        $imgp = $r['image_dir'] .'/'. $r['image_item_id_list']['source']['id']; #pre($imgp); #if(!file_exists($imgp)){ pre($r); self::set_cerror( __CLASS__ .'::'. __FUNCTION__ .' image file not exist! #375 | fp:__'. $imgp); return; }
        return [
            'image_id' => $image_id,
            'image_item_id' => $image_item_id,
            'width' => $image_resolution['width'],
            'height' => $image_resolution['height'],
            'quality' => $image_resolution['quality'],
            'dir' => $r['image_dir'],
            'path' => $imgp,
            'data' => []
        ];
    }

    static function get_car_number_border($image_object = null, array $image_data = null){
        if(empty($image_object)) return null; #pred($image_object);
        $border_width = self::$border_width; #pred($border_width);
        #if(!$border_width) return $image_object;
        $car_number_width = $image_data['car_number_coords'][3]['x']-$image_data['car_number_coords'][0]['x'];
        $car_number_height = $image_data['car_number_coords'][3]['y']-$image_data['car_number_coords'][0]['y']; #pre($car_number_width);
        # pre($car_number_width); pre(self::$sets['imaging']['car_number_border_padding_x']); pre($car_number_width * self::$sets['imaging']['car_number_border_padding_x']); pre(($car_number_width * self::$sets['imaging']['car_number_border_padding_x'] / 100)); pred((int)($car_number_width * self::$sets['imaging']['car_number_border_padding_x'] / 100));
        #$car_number_border_padding_x = (int)($car_number_width * self::$sets['imaging']['car_number_border_padding_x'] / 100);# pre($car_number_border_padding_x);
        #$car_number_border_padding_y = (int)($car_number_height * self::$sets['imaging']['car_number_border_padding_y'] / 100); #pred($car_number_border_padding_y);
        $car_number_border_padding_x = self::$sets['imaging']['car_number_border_padding_x'];
        $car_number_border_padding_y = self::$sets['imaging']['car_number_border_padding_y'];
        #if(gettype($image_object) !== 'resource')  #if(loc) pred(debug_backtrace());
        $before_red = @imagecolorallocate($image_object, 0, 255, 0); # pred(debug_backtrace()); #pred($before_red);        pred(error_get_last());        pred(debug_backtrace());
        if(!$before_red){ self::$error = error_get_last(); self::$errors[] = self::$error; return; }
        #$before_white = imagecolorallocate($image_object, 255, 255, 255);
        if(self::$sets['imaging']['show_inner_border']) $before_white = imagecolorallocate($image_object, 255, 255, 255);
        #if($border_width){
            $x1 = $image_data['car_number_coords'][0]['x'] - $car_number_border_padding_x;
            $x2 = $image_data['car_number_coords'][3]['x'] + $car_number_border_padding_x;
            $y1 = $image_data['car_number_coords'][0]['y'] - $car_number_border_padding_y;
            $y2 = $image_data['car_number_coords'][3]['y'] + $car_number_border_padding_y;  #pre($x1); pre($x2); pre($y1); pre($y2);
            imagesetthickness($image_object, $border_width);
            imagerectangle($image_object, $x1, $y1, $x2, $y2, $before_red);
        #}
        #pre($image_data['car_number_coords'][0]['x']); pre($x1); pre($image_data['car_number_coords'][3]['x']); pre($x2); pred($image_data);
        #if($x1 > $image_data['car_number_coords'][0]['x']) $x1 = $image_data['car_number_coords'][0]['x'];
        #if($x2 > $image_data['car_number_coords'][3]['x']) $x2 = $image_data['car_number_coords'][3]['x'];  #pre($image_data['car_number_coords'][0]['x']);    #if($x1 > )      # pred($image_data);
        # imageantialias($image_object, false);
        if(self::$sets['imaging']['show_inner_border']){
            $x1 = $image_data['car_number_coords'][0]['x'] - $car_number_border_padding_x + $border_width;
            $x2 = $image_data['car_number_coords'][3]['x'] + $car_number_border_padding_x - $border_width;
            $y1 =  $image_data['car_number_coords'][0]['y'] - $car_number_border_padding_y + $border_width;
            $y2 =  $image_data['car_number_coords'][3]['y'] + $car_number_border_padding_y - $border_width;  #pre($x1); pre($x2); pre($y1); pred($y2); # pred($border_width);
            imagesetthickness($image_object, $border_width);
            imagerectangle($image_object, $x1, $y1, $x2, $y2, $before_white);
        }
        return $image_object;
    }

    static function get_car_number_image_object(array $image_data = null){
        if(empty($image_data)) return null;
        $image_quality_data = self::get_image_db_data(); # $image_result_width = $image_quality_data['width'];
        $image_result_height = $image_quality_data['height'];
        $car_before_number_x1 = $image_data['car_number_coords'][0]['x'];
        $car_before_number_y1 = $image_data['car_number_coords'][0]['y'];
        $car_before_number_w = $image_data['car_number_coords'][3]['x']-$image_data['car_number_coords'][0]['x'];
        $car_before_number_h = $image_data['car_number_coords'][3]['y']-$image_data['car_number_coords'][0]['y']; # $car_before_number_percent = self::$car_number_percent;
        $car_number_percent = 8;
        $car_number_proportion = $car_before_number_w/$car_before_number_h;
        $car_before_number_result_h = (int)($image_result_height/$car_number_percent);
        $car_before_number_result_w = (int)($car_before_number_result_h*$car_number_proportion);
        if(!empty($_REQUEST['need_log'])) pre('source_image_pat 2h: '.$image_data['source_image_path']."\n");
        $image_before_object = Image::get_image_object_from_file_path($image_data['source_image_path']); # $image_before_source_width = $image_data['source_image_width']; $image_before_source_height = $image_data['source_image_height'];
        $image_car_number_before_result = imagecreatetruecolor($car_before_number_result_w, $car_before_number_result_h);
        imagecopyresized(
            $image_car_number_before_result,
            $image_before_object,
            0, 0,
            $car_before_number_x1, $car_before_number_y1,
            $car_before_number_result_w, $car_before_number_result_h,
            $car_before_number_w, $car_before_number_h
        );
        return ['image_object' => $image_car_number_before_result, 'width' => imagesx($image_car_number_before_result), 'height' => imagesy($image_car_number_before_result)];
    }

    static function get_image_sizes_with_car_number_in_center(array $image_data = null, int $image_width = null, int $image_height = null, float $zoom = 1){ #pred(debug_backtrace()); # if($zoom !== 1.0)
        if(empty($image_data)) return null; #$func_get_args = func_get_args(); array_shift($func_get_args); pre($func_get_args); #pre($image_data);
        #pre(self::$traffic_violation);        pre(self::$traffic_violation_type);
        #if(self::$traffic_violation_type === 'speed')
        $result_image_sizes = self::get_image_db_data($image_data['key']);
        $image_result_width = $result_image_sizes['width'];
        $image_result_height = $result_image_sizes['height'];
        $image_width_temp = $result_image_sizes['width'];
        $image_height_temp = $result_image_sizes['height'];
        if(!is_null($image_width)) $image_width_temp = $image_width;
        if(!is_null($image_height)) $image_height_temp = $image_height;
        $image_width_temp *= $zoom;
        $image_height_temp *= $zoom;
        $x_n_1 = $image_data['car_number_coords'][0]['x'];
        $y_n_1 = $image_data['car_number_coords'][0]['y'];
        $x_n_2 = $image_data['car_number_coords'][3]['x'];
        $y_n_2 = $image_data['car_number_coords'][3]['y'];
        $w_before = $x_n_2-$x_n_1;
        $h_before = $y_n_2-$y_n_1;
        $w_delta = (int)($image_width_temp - $w_before);
        $h_delta = (int)($image_height_temp - $h_before);
        $x_1 = $x_n_1 - ($w_delta / 2);
        $y_1 = $y_n_1 - ($h_delta / 2);  #pre($zoom); pre(self::$traffic_violation_type);
        #if(self::$traffic_violation_type === 'speed' && $zoom === 3.0){ pre($y_1); $y_1 -= 300; pred($y_1); }
        #if(self::$traffic_violation_type === 'speed' && $zoom === 3.0) $x_1 -= 100;
        $x_2 = $x_1 + $image_width_temp;
        $y_2 = $y_1 + $image_height_temp; #if(self::$traffic_violation_type === 'speed' && $zoom) $y_2 - 300;  #if($zoom){ pre($y_1); pre($y_2); }
        if($x_1 < 0){
            $x_1 = 0;
            $x_2 = $image_width_temp;
        }
        if($y_1 < 0){
            $y_1 = 0;
            $y_2 = $image_height_temp;
        }
        if($x_2 > $image_data['source_image_width']){
            $x_2 = $image_data['source_image_width'];
            $x_1 = $x_2 - $image_width_temp;
            if($x_1 < 0){
                $x_1 = 0;
                $image_width = $x_2;
            }
        }
        if($y_2 > $image_data['source_image_height']){
            $y_2 = $image_data['source_image_height'];
            $y_1 = $y_2 - $image_height_temp;
            if($y_1 < 0){
                $y_1 = 0;
                $image_height = $y_2;
            }
        }
        $x_1 = (int)$x_1;
        $y_1 = (int)$y_1;
        $image_width = (int)($x_2 - $x_1);
        $image_height = (int)($y_2 - $y_1);
        return [
            'x' => $x_1,
            'y' => $y_1,
            'width' => $image_width,
            'height' => $image_height
        ];
    }
}