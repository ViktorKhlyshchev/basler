<?php

namespace CLI\Modules\PreparingImages;

use Common\Models\Image\Image;
use Common\Modules\ImageConvert;

trait PrepareCombo { # was GetPreparedJournalImageListAction VIP lines 886 1040 1052 http://aist.loc/admin/cli/balancer?si=1

    private static function get_combo_image_with_car_number_object(
        array $image_data = null, #0
        int $label_line_len = 5, #1
        int $need_width = null, #2
        int $need_height = null, #3
        bool $need_car_number = true, #4
        bool $need_timestamp = true, #5
        float $zoom = 1, #6
        bool $need_car_body_border = false, #7
        bool $need_track_line = false, #8
        string $image_type = null, #9
        float $move_x_percent = 0, #10
        float $move_y_percent = 0 #11
    ){ #pred(321); #pre(debug_backtrace()); pre(444);  #if($zoom != 1) pred(debug_backtrace());# pred(func_get_args()); # L674 prepare_image_speed # L606 prepare_image_middle 637 ($image_data, 0, $image_result_width, $image_result_height, false, false, 3, false, false, 'middle');
        /*[1] => 0
        [2] => 1600
        [3] => 1338
        [4] =>
        [5] =>
        [6] => 3
        [7] =>
        [8] =>
        [9] => middle*/
        # L1234 prepare_image_speed  1109 get_image_speed_object 1162 ($image_data, $label_len, $image_result_width, $image_cropped_h, false, false, 1);
        /*[1] => 0
        [2] => 500
        [3] => 442
        [4] =>
        [5] =>
        [6] => 1
        [7] =>
        [8] =>
        [9] =>
        [10] => 0
        [11] => 0*/
        #if(func_get_args()[9] === 'middle')   #pred(func_get_args()[9]);  pre(func_get_args());# pred(debug_backtrace()); #pred($image_data);
        #if(func_get_args()[9] !== 'middle')  pred(debug_backtrace()); #pred(func_get_args()[9]);  pre(func_get_args());# pred(debug_backtrace()); #pred($image_data);
        if(empty($image_data)) return null; #pred(debug_backtrace()); $car_number_percent = 8; $font_h = self::$font_h; $font_size = self::$font_size; #if($image_type === 'none_crop') pre($need_width);
        $image_quality_data = self::get_image_db_data(); #if($image_type === 'none_crop') pred($image_quality_data);
        $image_result_width = $image_quality_data['width'];
        $image_result_height = $image_quality_data['height']; # $image_result_quality = $image_quality_data['quality'];
        if(!is_null($need_width)) $image_result_width = $need_width;
        if(!is_null($need_height)) $image_result_height = $need_height;
        #if(nl) pre('source_image_path: '. $image_data['source_image_path'] ."\n"); #pre($image_data['source_image_path']);   #pred(debug_backtrace());
        #pre($image_data['source_image_path']);  #pred($image_data);

        $image_before_object = Image::get_image_object_from_file_path($image_data['source_image_path'], $image_data);
        if(gettype($image_before_object) !== 'resource') if(loc){ # pre($image_data['source_image_path']);
            if(!file_exists($image_data['source_image_path'])) pre('File not exist! fp:__'. $image_data['source_image_path']); # pred(file_exists($image_data['source_image_path']));
            pre(debug_backtrace()); pred('File not exist! fp:__'. $image_data['source_image_path']); # set_source_image_path
        }  #if(isset($_GET['showpaths'])) pre($image_data['source_image_path']); #pred($image_before_object);

        if($need_car_body_border) $image_before_object = self::get_car_body_border($image_before_object, $image_data);
        if($need_car_number){
            $image_car_number_before_data = self::get_car_number_image_object($image_data);
            $image_car_number_before_result = $image_car_number_before_data['image_object'];
        }
        if($need_track_line){
            $image_before_object = self::get_car_track_line($image_before_object, $image_data);
            $image_before_object = self::get_car_number_border($image_before_object, $image_data);
        }
        $image_before_object = self::get_car_number_border($image_before_object, $image_data);
        $result_image_sizes = self::get_image_db_data($image_data['key']);
        $result_before_proportion = $result_image_sizes['width'] / $result_image_sizes['height'];
        if(is_null($need_width)) $need_width = $result_image_sizes['width'];
        if(is_null($need_height)) $need_height = $result_image_sizes['height'];
        $result_before_width = $need_width * $zoom;
        $result_before_height = (int)($result_before_width / $result_before_proportion);
        $image_text_area_h = self::get_label_height($label_line_len);
        $label_height = $image_text_area_h - 2 * self::$image_padding_row;
        if(is_null($need_width)) $image_before_cropped_w = $result_before_width; else $image_before_cropped_w = $need_width;

        if(is_null($need_height))
            $image_before_cropped_h = $result_before_height-$image_text_area_h - 2 * self::$image_padding_row;
        else
            $image_before_cropped_h = $need_height-$label_height;

        if($need_timestamp) $image_before_cropped_h = $image_before_cropped_h - self::$font_size; /* echo 'zoom: '.$zoom."\n"; echo '$need_width: '.$need_width."\n"; echo '$need_height: '.$need_height."\n"; echo '$result_before_width: '.$result_before_width."\n"; echo '$result_before_height: '.$result_before_height."\n"; echo '$image_before_cropped_w: '.$image_before_cropped_w."\n"; echo '$image_before_cropped_h: '.$image_before_cropped_h."\n\n";*/

        if($zoom === 1) $zoom = 2; #pred($zoom);
        $image_cropped_sizes = self::get_image_sizes_with_car_number_in_center($image_data, $image_before_cropped_w, $image_before_cropped_h, $zoom);
        if(1) if($image_type === 'none_crop' || $image_type === 'speed_crop'){ # func_get_args()[9] !== 'middle'
           # pre(debug_backtrace());
            if(self::$traffic_violation === 'none' || self::$traffic_violation_type === 'speed') $zoom = 1; #  pre($zoom);            pred($image_cropped_sizes);
        }
/*      if(self::$traffic_violation === 'none' && $zoom !== 1.0){
            $image_cropped_sizes = self::get_image_sizes_with_car_number_in_center($image_data, $image_before_cropped_w, $image_before_cropped_h, $zoom);
        } else $image_cropped_sizes = self::get_image_sizes_with_car_number_in_center($image_data, $image_before_cropped_w, $image_before_cropped_h, $zoom);*/

        $crop_x = $image_cropped_sizes['x'] + $image_cropped_sizes['width'] * $move_x_percent; // image move left
        $crop_y = $image_cropped_sizes['y'] + $image_cropped_sizes['height'] * $move_y_percent; #  $crop_x = $image_cropped_sizes['x']; $crop_y = $image_cropped_sizes['y'];
        # if($crop_x>$image_data['car_number_coords'][0]['x']) $crop_x = $image_data['car_number_coords'][0]['x']-50; car_item_controls_

        #if(self::$traffic_violation_type === 'speed' && $zoom === 3.0){ pre($crop_x); pred($crop_y); } #if(self::$traffic_violation_type === 'speed' && $zoom === 3.0) $crop_y -= 100;

        if($crop_x < 0) $crop_x = 0;
        if($crop_y < 0) $crop_y = 0;
        $image_size_list = [
            'x' => $crop_x,
            'y' => $crop_y,
            'width' => $image_cropped_sizes['width'],
            'height' => $image_cropped_sizes['height'],
            'source_w' => $image_data['source_image_width'],
            'source_h' => $image_data['source_image_height'],
            'car_number_coords' => $image_data['car_number_coords'],
        ];
        #if(0 && $image_type === 'none_crop'){ # func_get_args()[9] !== 'middle' pre(debug_backtrace());  pre($zoom);  pred($image_size_list); }
        if($crop_x != 0) foreach($image_data['car_number_coords'] as $index => $car_number_coords_item) $image_size_list['car_number_coords'][$index]['x']-= $crop_x;
        if($crop_y != 0) foreach($image_data['car_number_coords'] as $index => $car_number_coords_item) $image_size_list['car_number_coords'][$index]['y']-= $crop_y; #if($zoom != 1) pred(debug_backtrace());
        if($zoom != 1)
            foreach($image_data['car_number_coords'] as $index => $car_number_coords_item){
                $image_size_list['car_number_coords'][$index]['x'] /= $zoom;
                $image_size_list['car_number_coords'][$index]['y'] /= $zoom;
                $image_size_list['car_number_coords'][$index]['x'] = (int)$image_size_list['car_number_coords'][$index]['x'];
                $image_size_list['car_number_coords'][$index]['y'] = (int)$image_size_list['car_number_coords'][$index]['y'];
            }  #pre($image_size_list);

        #if(0 && $image_type === 'none_crop'){            pre(debug_backtrace());            pre($zoom);            pred($image_size_list);        }

        /*$move_x_percent = 2;
        if(1 && func_get_args()[9] !== 'middle'){
            pre($move_x_percent);
            pred($move_y_percent);
        }*/
        #if(1 && func_get_args()[9] !== 'middle') $zoom = 2;# pred($zoom); pred(self::$traffic_violation);
        #if($zoom === 1.0) pred($image_size_list);
        #if($zoom !== 1.0){ pre($zoom); pre(self::$traffic_violation); pred($image_size_list); }
        #if(self::$traffic_violation_type === 'speed' && $zoom === 1.0) $image_size_list['y']-=150; # pred(self::$balancer->sets);
        if($image_type === 'none_crop' || $image_type === 'speed_crop'){
            if(self::$traffic_violation === 'none' || self::$traffic_violation_type === 'speed'){
                $image_size_list['y']-= self::$balancer->sets['imaging']['crop_height'];
                $image_size_list['x']-= self::$balancer->sets['imaging']['crop_x'];
            }  #if(self::$traffic_violation === 'none' && $image_type === 'none_crop'){  }
        }
        #if(self::$traffic_violation === 'none' && $zoom === 1.0) $image_size_list['y']-= self::$balancer->sets['imaging']['crop_height'];
        #if(self::$traffic_violation === 'none' && $zoom !== 1.0){ $image_size_list['x']+= self::$balancer->sets['imaging']['crop_x']; } # pre($image_size_list['x']);  pred($image_size_list['x']);# pre($image_size_list['x']);  pred($image_size_list['x']);
        #if(self::$traffic_violation === 'none' && $zoom === 1.0) pred(self::$traffic_violation === 'none' && $zoom === 1.0); #pre(self::$traffic_violation === 'none' && $zoom === 1.0); #pre($image_size_list);
        $image_before_object_cropped = imagecrop($image_before_object, $image_size_list);
        #if(!empty($_GET['show_image'])){ header('Content-Type: image/jpeg'); imagejpeg($image_before_object_cropped); die; }
        #if(!cli){ pred(321); }
        #if(!cli){ #pred($image_before_object_cropped); }
        #if($zoom) pred(debug_backtrace());
        #if(func_get_args()[9] !== 'middle') pred(debug_backtrace());
        # 1 middle self::prepare_image_middle(true, true)
        # 2 crop self::prepare_image_none()
        #pre(func_get_args()[9]);
        #if(1 && func_get_args()[9] !== 'middle') pred($zoom);

        if(0 && !cli && $image_type === 'none_crop') if(!empty($_GET['si'])){  header('Content-Type: image/jpeg'); imagejpeg($image_before_object_cropped); die; } #if(!cli){ header('Content-Type: image/jpeg'); imagejpeg($image_before_object_cropped); die; }
        if(0 && !cli && $image_type === 'middle') if(!empty($_GET['si'])){  header('Content-Type: image/jpeg'); imagejpeg($image_before_object_cropped); die; } #if(!cli){ header('Content-Type: image/jpeg'); imagejpeg($image_before_object_cropped); die; }
        if(0 && !cli && $zoom != 1) if(!empty($_GET['si'])){ header('Content-Type: image/jpeg'); imagejpeg($image_before_object_cropped); die; } #if(!cli){ header('Content-Type: image/jpeg'); imagejpeg($image_before_object_cropped); die; }
        #pred($_GET['si']); #pred(321);
        if(0 && !cli && !empty($_GET['si'])){ header('Content-Type: image/jpeg'); imagejpeg($image_before_object);
            #imagejpeg($image_before_object_cropped); pred(func_get_args()[9]);
        die; } #pred(self::$traffic_violation_type);
        $image_before_object_resized = ImageConvert::resize_image_from_image_object($image_before_object_cropped, $image_result_width, $image_result_height, $image_type, self::$traffic_violation_type);
        #if($image_type === 'none_crop') pred($image_before_object_resized);
        if(0 && !cli && !empty($_GET['si'])){ if($image_type === 'none_crop' || $image_type === 'speed_crop'){ header('Content-Type: image/jpeg'); imagejpeg($image_before_object_resized); die; } }
        #pred($image_before_object_resized);
        #$image_before_object_resized_w = imagesx($image_before_object_resized); # $image_before_object_resized_h = imagesy($image_before_object_resized); $coords_percent = $image_before_object_resized_w/$image_before_cropped_w;
        $image_before_object_resized_delta_x = 0; # $image_before_object_resized_delta_y = $y_1*$coords_percent;
        $image_before_object_resized_delta_y = 0; // debug
        $cropar = ['x' => $image_before_object_resized_delta_x, 'y' => $image_before_object_resized_delta_y, 'width' => $image_before_cropped_w,  'height' => $image_before_cropped_h]; #pred($cropar);
        $image_before_object_cropped = imagecrop($image_before_object_resized, $cropar);
        # if(!empty($_GET['show_image'])){ header('Content-Type: image/jpeg'); imagejpeg($image_before_object_cropped); die; }
        #if($need_car_number) imagecopy($image_before_object_cropped, $image_car_number_before_result, 0, $image_before_cropped_h-$car_before_number_result_h, 0, 0, $car_before_number_result_w, $car_before_number_result_h);
        $image_before_result = imagecreatetruecolor($image_before_cropped_w, $image_result_height); # echo $image_before_cropped_w."\n"; echo $image_before_cropped_h."\n"; print_r($image_size_list);die;
        #if(!empty($_GET['si'])){ header('Content-Type: image/jpeg'); imagejpeg($image_before_object_cropped); die; }
        #if(!empty($_GET['si'])){ header('Content-Type: image/jpeg'); imagejpeg($image_before_result); die; }

        if(is_null($image_type)) imagecopyresized($image_before_result, $image_before_object_cropped, 0, 0, 0, 0, $image_before_cropped_w, $image_before_cropped_h, $image_size_list['width'], $image_size_list['height']);
        # if(!empty($_GET['si'])){ header('Content-Type: image/jpeg'); imagejpeg($image_before_result); die; }
        if(!is_null($image_type)) imagecopy($image_before_result, $image_before_object_cropped, 0, 0, 0, 0, $image_before_cropped_w, $image_before_cropped_h);
        # if(!empty($_GET['si'])){ header('Content-Type: image/jpeg'); imagejpeg($image_before_result); die; }
        if($need_timestamp){
            $timestamp = self::get_image_data_timestamp($image_data);
            $label_list = ['ДАТА/ВРЕМЯ: '. mb_strtoupper($timestamp, 'utf-8')];
            $image_before_result = self::get_image_with_bottom_label($image_before_result, $label_list, $image_before_cropped_h + 2 * self::$image_padding_row+self::$font_size, self::$font_x);
        }
        $retar = ['image_object' => $image_before_result, 'width' => $image_before_cropped_w, 'height' => $image_result_height, 'cropped' => $image_size_list]; #red($ret);
        return $retar;
    }
}