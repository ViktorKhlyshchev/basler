<?php

namespace CLI\Modules\PreparingImages;

use CLI\Modules\PreparingImages\PrepCombo;
use Core\Modules\Dir;

trait PrepareBMA { # before middle after

    private static function prepare_image_before(bool $need_car_number = true, bool $need_car_body_zoom = true, bool $need_track_line = false){ #pred(debug_backtrace());
        if(!count(self::$image_list)){ self::set_cerror('Image list is empty #111 '. __FUNCTION__); return false; }
        $image_list = [];
        $camera_list = [];
        foreach(self::$image_list as $index => $row)
            switch($row['key']){
                case 'before':
                case 'middle':
                case 'after': {
                    $image_list[$row['key']] = $row;
                    $image_list[$row['key']]['index'] = $index;
                    if(!isset($camera_list[$row['camera_id']])) $camera_list[$row['camera_id']] = [];
                    $camera_list[$row['camera_id']][$row['key']] = $row;
                    break;
                }
            }
        if(!count($image_list)){ self::set_cerror(__FUNCTION__ .': Image list < 1 '); return false; }

        if(empty($image_list['before'])){
            if(loc) pred($image_list['before']);
            self::set_cerror('empty($image_list[before]) '. __FUNCTION__);
            return false;
        } #pred(count($image_list));pred($cdr, self::$image_before['dir']);
        # pred(self::$image_sizes_list);
        #pred(self::$image_sizes_list);
        $image_data = $image_list['before'];
        #pred(self::$image_list);
        #pred($image_list);

        #$image_data = $image_list['middle']; #pred($image_data);
        $image_index = $image_data['index'];
        #$image_index = $image_list['middle']['index'];
        $image_source_data = self::$image_list[$image_index];
        #$image_quality_data = self::$image_sizes_list['before'];
        if(self::$traffic_violation === 'crosswalk') $image_quality_data = self::$image_sizes_list_off[self::$traffic_violation]['before']; else $image_quality_data = self::$image_sizes_list['before'];

        #pred(debug_backtrace()); #       $image_sizes_list_off  $image_quality_data = self::$image_sizes_list['before'];
        #pred(self::$traffic_violation); #       $image_sizes_list_off  $image_quality_data = self::$image_sizes_list['before'];
        $image_result_width = $image_quality_data['width']; #pred($image_result_width);
        $image_result_height = $image_quality_data['height']; #        $image_result_quality = $image_quality_data['quality'];
        $image_source_width = $image_source_data['source_image_width']; #        $image_source_height = $image_source_data['source_image_height'];
        $image_source_data['proportions'] = $image_result_width / $image_source_width;
        if(empty(self::$image_before)){ self::set_cerror( __FUNCTION__ .': Image before is empty #52'); return; }
        self::$image_before['data'] = $image_source_data;
        $label_list = [];
        $label_list[] = 'ВРЕМЯ ФИКСАЦИИ: '. self::$timestamp .'    S/N '.mb_strtoupper(self::$serial_number, 'utf-8') .'    '. mb_strtoupper(self::$object_address, 'utf-8') .'    ('. mb_strtoupper(self::$object_gps, 'utf-8') .')';
        $label_h = self::get_label_height(count($label_list));
        $image_temp_h = $image_result_height - $label_h;
        #$image_result_data = self::get_combo_image_with_car_number_object($image_data, 0, $image_result_width, $image_temp_h, false, false, 2, false, $need_track_line, 'before'); if(!empty($_GET['sb'])){ header('Content-Type: image/jpeg'); imagejpeg($image_result_data['image_object']); die; } #pred($image_result_data);
        $image_result_data = self::get_combo_image_with_car_number_object($image_data, 0, $image_result_width, $image_temp_h, false, false, 2, false, $need_track_line, 'before'); #if(!empty($_GET['sb'])){ header('Content-Type: image/jpeg'); imagejpeg($image_result_data['image_object']); die; } #pred($image_result_data);
        $image_temp = $image_result_data['image_object']; #pre($image_result_height); pred($image_temp_h);
        $image_result = imagecreatetruecolor($image_result_width, $image_result_height);
        imagecopy($image_result, $image_temp, 0, 0, 0, 0, $image_result_width, $image_temp_h);
        #imagecopy($image_result, $image_temp, 0, 0, 0, 0, $image_result_width, $image_result_height);
        if(1 && !empty($_GET['sb'])){ header('Content-Type: image/jpeg');  imagejpeg($image_result); die; } #imagejpeg($image_before_object);die; }  #pred(count(self::$image_list));
        $image_result = self::get_image_with_bottom_label($image_result, $label_list, $image_result_data['height'] + self::$image_padding_row + self::$font_size, self::$font_x);
        $cdr = Dir::create_dir(self::$image_before['dir']);
        if(!$cdr){
            if(loc) pred("cant create dir #2!!". self::$image_before['dir']); else pre("cant create dir #2!!". self::$image_before['dir']); #pred($r);  #pred($cdr, self::$image_before['dir']);
        }
        #if(1 && !empty($_GET['sb'])){ header('Content-Type: image/jpeg');  imagejpeg($image_result); die; } #imagejpeg($image_before_object);die; }  #pred(count(self::$image_list));
        if(!imagejpeg($image_result, self::$image_before['path'], self::$image_before['quality'])){ self::set_cerror('Image was not save '. __FUNCTION__ .', path:__'. self::$image_before['path']); return false; }
        if($need_car_number && isset(self::$image_car_number_list['before'])){
            $image_car_number_data = self::get_car_number_image_object($image_data);
            $image_car_number_object = $image_car_number_data['image_object'];
            self::$image_car_number_list['before']['data'] = $image_source_data;
            Dir::create_dir(self::$image_car_number_list['before']['dir']);
            if(!imagejpeg($image_car_number_object, self::$image_car_number_list['before']['path'], self::$image_car_number_list['before']['quality'])){ self::set_cerror('Image was not save #2 '. __FUNCTION__ .', path:__'. self::$image_car_number_list['before']['path']); return false; }
        }
        if($need_car_body_zoom && isset(self::$image_zoom_list['before'])){
            $image_car_body_data = self::get_combo_image_with_car_number_object($image_data, 0, $image_result_width, $image_result_height, false, false, 1, true);
            $image_car_body_object = $image_car_body_data['image_object'];
            self::$image_zoom_list['before']['data'] = $image_source_data;
            $dcr = Dir::create_dir(self::$image_zoom_list['before']['dir']); #pred($dcr);
            if(!imagejpeg($image_car_body_object, self::$image_zoom_list['before']['path'], self::$image_zoom_list['before']['quality'])){ self::set_cerror('Image was not save #3 '. __FUNCTION__ .', path:__'. self::$image_zoom_list['before']['path']); return false; }
        }
        return true;
    }

    private static function prepare_image_after(bool $need_car_number = true, bool $need_car_body_zoom = true, bool $need_track_line = false){
        if(!count(self::$image_list)){ self::set_cerror('Image list is empty #222 '. __FUNCTION__); return false; }
        $image_list = [];
        $camera_list = [];
        foreach(self::$image_list as $index => $row)
            switch($row['key']){
                case 'before':
                case 'middle':
                case 'after': {
                    $image_list[$row['key']] = $row;
                    $image_list[$row['key']]['index'] = $index;
                    if(!isset($camera_list[$row['camera_id']]))
                        $camera_list[$row['camera_id']] = [];
                    $camera_list[$row['camera_id']][$row['key']] = $row;
                    break;
                }
            }
        if(!count($image_list)){ self::set_cerror('Image list < 1 '. __FUNCTION__); return false; }
        if(empty($image_list['after'])){ self::set_cerror('empty($image_list[after]) prepare_image_after#1'); return false; }
        $image_data = $image_list['after']; #pred($image_data);
        $image_index = $image_data['index'];
        $image_source_data = self::$image_list[$image_index];
        #$image_quality_data = self::$image_sizes_list['after'];
        if(self::$traffic_violation === 'crosswalk') $image_quality_data = self::$image_sizes_list_off[self::$traffic_violation]['after']; else $image_quality_data = self::$image_sizes_list['after']; # $image_quality_data = self::$image_sizes_list['after'];
        $image_result_width = $image_quality_data['width'];
        $image_result_height = $image_quality_data['height']; # $image_result_quality = $image_quality_data['quality'];
        $image_source_width = $image_source_data['source_image_width']; # $image_source_height = $image_source_data['source_image_height'];
        $image_source_data['proportions'] = $image_result_width/$image_source_width;
        if(empty(self::$image_after)){ self::set_cerror('Image after is empty '. __FUNCTION__); return false; }
        self::$image_after['data'] = $image_source_data;
        $label_list = [];
        $label_list[] = 'ВРЕМЯ ФИКСАЦИИ: '. self::$timestamp .'    S/N '. mb_strtoupper(self::$serial_number, 'utf-8') .'    '. mb_strtoupper(self::$object_address, 'utf-8') .'    ('. mb_strtoupper(self::$object_gps, 'utf-8') .')';
        $label_h = self::get_label_height(count($label_list));
        $image_temp_h = $image_result_height-$label_h;
        $image_result_data = self::get_combo_image_with_car_number_object($image_data, 0, $image_result_width, $image_temp_h, false, false, 2, false, $need_track_line, 'after');
        $image_temp = $image_result_data['image_object'];
        $image_result = imagecreatetruecolor($image_result_width, $image_result_height);
        imagecopy($image_result, $image_temp, 0, 0, 0, 0, $image_result_width, $image_temp_h);
        #if(1 && !empty($_GET['sa'])){ header('Content-Type: image/jpeg');  imagejpeg($image_result); die; } #imagejpeg($image_before_object);die; }  #pred(count(self::$image_list));
        $image_result = self::get_image_with_bottom_label($image_result, $label_list, $image_result_data['height']+self::$image_padding_row+self::$font_size, self::$font_x);
        $cdr = Dir::create_dir(self::$image_after['dir']); #if(!empty($_GET['show_after'])){ header('Content-Type: image/jpeg');# imagejpeg($image_before_object);  imagejpeg($image_result); die; }

        if(!imagejpeg($image_result, self::$image_after['path'], self::$image_after['quality'])){ pre(333321); self::set_cerror('Image after was not save #1 '. __FUNCTION__ .', imfp:__'. self::$image_after['path']); return false; }
        if($need_car_number && isset(self::$image_car_number_list['after'])){
            $image_car_number_data = self::get_car_number_image_object($image_data);
            $image_car_number_object = $image_car_number_data['image_object'];
            self::$image_car_number_list['after']['data'] = $image_source_data;
            Dir::create_dir(self::$image_car_number_list['after']['dir']);
            if(!imagejpeg($image_car_number_object, self::$image_car_number_list['after']['path'], self::$image_car_number_list['after']['quality'])){ pre(333321); self::set_cerror('Image after was not save #2 '. __FUNCTION__ .', imfp:__'. self::$image_car_number_list['after']['path']); return false; }
        }

        if($need_car_body_zoom && isset(self::$image_zoom_list['after'])){
            $image_car_body_data = self::get_combo_image_with_car_number_object($image_data, 0, $image_result_width, $image_result_height, false, false, 1, true);
            $image_car_body_object = $image_car_body_data['image_object'];
            self::$image_zoom_list['after']['data'] = $image_source_data;
            Dir::create_dir(self::$image_zoom_list['after']['dir']);
            if(!imagejpeg($image_car_body_object, self::$image_zoom_list['after']['path'], self::$image_zoom_list['after']['quality'])){ pre(333321); self::set_cerror('Image after was not save #3 '. __FUNCTION__ .', imfp:__'. self::$image_zoom_list['after']['path']); return false; }
        }
        return true;
    }

    private static function prepare_image_middle(bool $need_car_number = true, bool $need_car_body_zoom = true){ #pre(debug_backtrace()); pre(333);
        if(!count(self::$image_list)){ self::set_cerror('Image list is empty #333 '. __FUNCTION__); return false; }
        $image_list = [];
        $camera_list = [];
        foreach(self::$image_list as $index => $row)
            switch($row['key']){
                case 'before':
                case 'middle':
                case 'after': {
                    $image_list[$row['key']] = $row;
                    $image_list[$row['key']]['index'] = $index;
                    if(!isset($camera_list[$row['camera_id']])) $camera_list[$row['camera_id']] = [];
                    $camera_list[$row['camera_id']][$row['key']] = $row;
                    break;
                }
            } #pred(count($image_list));
        if(!count($image_list)){ self::set_cerror('Image list qty < 1'); return false; }
        $image_data = $image_list['middle'];
        $image_index = $image_data['index'];
        $image_source_data = self::$image_list[$image_index]; #
        $image_quality_data = self::$image_sizes_list['middle'];
        #if(self::$traffic_violation === 'crosswalk') $image_quality_data = self::$image_sizes_list_off[self::$traffic_violation]['middle']; else $image_quality_data = self::$image_sizes_list['middle'];
        $image_result_width = $image_quality_data['width'];
        $image_result_height = $image_quality_data['height'];  # $image_result_quality = $image_quality_data['quality'];
        $image_source_width = $image_source_data['source_image_width']; # $image_source_height = $image_source_data['source_image_height'];
        $image_source_data['proportions'] = $image_result_width / $image_source_width;
        if(empty(self::$image_middle)){ self::set_cerror('Image middle is empty'); return false; } #pred($image_data);
        self::$image_middle['data'] = $image_source_data; #pred(self::$image_middle); #pred(self::$balancer->sets['imaging']['crop_zoom']);
        if(self::$traffic_violation === 'none' || self::$traffic_violation_type === 'speed') $zoom = self::$balancer->sets['imaging']['crop_zoom']; else $zoom = 3;# pred($zoom);
        $pc = new PrepCombo($image_data, 0, $image_result_width, $image_result_height, $zoom, false, 'middle'); #pred($image_result_data);
        if($pc->error){ self::$error = $pc->error; self::$errors[] = array_merge(self::$error, $pc->error); return; }
        $image_result_data = $pc->retar; #pred($image_result_data);
        #if(!empty($_GET['sm'])){ header('Content-Type: image/jpeg'); imagejpeg($image_result_data['image_object']); die; } # imagejpeg($image_before_object);
        Dir::create_dir(self::$image_middle['dir']);
        $r = imagejpeg($image_result_data['image_object'], self::$image_middle['path'], self::$image_middle['quality']); # pred($r);
        #if(1 && !empty($_GET['sm'])){ header('Content-Type: image/jpeg');  echo imagejpeg($image_result_data['image_object']); die; } #imagejpeg($image_before_object);die; }  #pred(count(self::$image_list));
        if(!$r){ self::set_cerror('Image middle was not save #1, fp:__'. self::$image_middle['path']); return false; }

        if($need_car_number && isset(self::$image_car_number_list['middle'])){ #pred(self::$image_car_number_list);
            $image_car_number_data = self::get_car_number_image_object($image_data);
            $image_car_number_object = $image_car_number_data['image_object'];
            self::$image_car_number_list['middle']['data'] = $image_source_data;
            Dir::create_dir(self::$image_car_number_list['middle']['dir']);
            #if(1 && !empty($_GET['sm'])){ header('Content-Type: image/jpeg'); imagejpeg($image_car_body_data['image_object']); die; }
            $r = imagejpeg($image_car_number_object, self::$image_car_number_list['middle']['path'], self::$image_car_number_list['middle']['quality']); #  pred($r);
            if(!$r){ self::set_cerror('Image middle was not save #2, fp:__'. self::$image_car_number_list['middle']['path']); return false; }
        } # pred(self::$image_zoom_list);
        #pre($need_car_body_zoom);
        if($need_car_body_zoom && isset(self::$image_zoom_list['middle'])){ #pred(self::$image_car_number_list);
            $pc = new PrepCombo($image_data, 0, $image_result_width, $image_result_height, 1, true, 'middle'); #pred($image_car_body_data['image_object']);
            $image_car_body_data = $pc->retar;
            if(1 && !empty($_GET['sm'])){ header('Content-Type: image/jpeg'); imagejpeg($image_car_body_data['image_object']); die; } # imagejpeg($image_before_object);
            self::$image_zoom_list['middle']['data'] = $image_source_data;
            Dir::create_dir(self::$image_zoom_list['middle']['dir']);
            if(!imagejpeg($image_car_body_data['image_object'], self::$image_zoom_list['middle']['path'], self::$image_zoom_list['middle']['quality'])){ self::set_cerror('Image middle was not save #692, fp:__'. self::$image_zoom_list['middle']['path']); return false; }
        }
        return true;
    }
}