<?php

namespace CLI\Modules\PreparingImages;

use Core\Modules\Dir;
use Common\Models\Journal; #use CLI\Modules\PrepareImages;
use Common\Models\JournalImage;
use Common\Modules\Date;

class PrepareImages { # CafapImageOverlay

    public $error;
    public $errors = [];

    function set_error($error){
        $this->error = $error;
        Journal::update_journal_to_error($this->jid, $this->error, 0);
    }

    function set_cerror($error){
        $this->error = $error;
        Journal::update_journal_to_error($this->jid, $this->error, 1);
    }

    function __construct($jid = null, $balancer = null){ # was CafapImageOverlay uses is_plate_invert, country_code

        if($jid === null) return; # pred($balancer);

        $image_index = 0;
        $r = PrepareImagesAction::init($jid, $balancer); # pred(array_keys($r)); #pred($r); #pred($r['result']);
        if($r['error']){ pre($r['error']); $this->error = $r['error']; $this->errors = array_merge($this->errors, PrepareImagesAction::$errors); return false; }

        $this->combo_car_number_coords = $r['combo_car_number_coords'];
        $data = $r['result']; #pred($data);
        #pred(array_keys($data)); #pred($data['zoom_image_list']); # pred($data['combo_image']);
        $ret = []; #pred($data['combo_image']);
        if(!empty($data['combo_image'])){ # $im = file_get_contents($data['combo_image']['path']); pred($im);
            #if(0 && loc && !cli && !empty($_GET['si'])){ $im = imagecreatefromjpeg($data['combo_image']['path']); header('Content-Type: image/jpeg'); imagejpeg($im); die; }
            #if(1 && loc && !cli && !empty($_GET['si'])){ $im = imagecreatefromjpeg($data['combo_image']['path']); header('Content-Type: image/jpeg'); imagejpeg($im); die; }
            $image_index++;
            $file_path = Dir::get_global_dir($data['combo_image']['path']); # if(file_exists($file_path)) $image_prepared_combo_size = filesize($file_path);
            $r = JournalImage::add_journal_image(
                # todo need invset why http://10.0.1.8/admin/root/history 146684 <b>Notice</b>:  Undefined index: cropped in <b>/var/www/html/Project/Aist/Admin/Action/Xavier/CreateBoxAction.php</b> on line <b>323
                # temp solution add @ -  @JournalImage::add_journal_image
                null,
                $jid,
                $data['combo_image']['image_id'],
                'front',
                $image_index,
                null, #$data['combo_image']['cropped']['car_number_coords'],
                'prepared_combo'
            );
            $ret[] = $r;
        }
        #pred($data['before']);
        if(!empty($data['before'])){
            #if(0 && loc && !cli && !empty($_GET['si'])){ $im = imagecreatefromjpeg($data['before']['path']); header('Content-Type: image/jpeg'); imagejpeg($im); die; }
            $image_index++; # if(empty($direction) && empty($lane)){ $direction = $data['before']['data']['direction']; } # $lane = $data['before']['data']['lane']; $car_number_coords = $data['before']['data']['car_number_coords']; $proportions = $data['before']['data']['proportions'];

            $r = JournalImage::add_journal_image(
                $data['before']['data']['camera_id'],
                $jid,
                $data['before']['image_id'],
               'front',
                $image_index,
                empty($data['before']['data']['car_number_coords']) ? null : $data['before']['data']['car_number_coords'],
                'prepared_before',
                $data['before']['data']['direction'],
                Date::get_ms_from_date_time_ms($data['before']['data']['timestamp'])
            );
            $ret[] = $r;
        }

        if(!empty($data['middle'])){
            $image_index++;
            #$direction = $data['middle']['data']['direction']; # $lane = $data['middle']['data']['lane']; $car_number_coords = $data['middle']['data']['car_number_coords']; $proportions = $data['middle']['data']['proportions'];
            $r = JournalImage::add_journal_image(
                $data['middle']['data']['camera_id'],
                $jid,
                $data['middle']['image_id'],
                'front',
                $image_index,
                empty($data['middle']['data']['car_number_coords']) ? null : $data['middle']['data']['car_number_coords'],
                'prepared_middle',
                $data['middle']['data']['direction'],
                Date::get_ms_from_date_time_ms($data['middle']['data']['timestamp'])
            );
            $ret[] = $r;
        }

        if(!empty($data['after'])){
            $image_index++;
            # if(empty($direction) && empty($lane)) $direction = $data['after']['data']['direction']; #$lane = $data['after']['data']['lane']; $car_number_coords = $data['after']['data']['car_number_coords']; $proportions = $data['after']['data']['proportions'];

            $r = JournalImage::add_journal_image(
                $data['after']['data']['camera_id'],
                $jid,
                $data['after']['image_id'],
                'front',
                $image_index,
                empty($data['after']['data']['car_number_coords']) ? null : $data['after']['data']['car_number_coords'],
                'prepared_after',
                $data['after']['data']['direction'],
                Date::get_ms_from_date_time_ms($data['after']['data']['timestamp'])
            );
            $ret[] = $r;
        }

        if(!empty($data['zoom_image_list'])){
            foreach($data['zoom_image_list'] as $row){
                $image_index++;
                $r = JournalImage::add_journal_image(
                    $row['data']['camera_id'],
                    $jid,
                    $row['image_id'],
                   'front',
                    $image_index,
                    empty($row['data']['car_number_coords']) ? null : $row['data']['car_number_coords'],
                    'prepared_'. $row['data']['key'] .'_zoom',
                    $row['data']['direction'],
                    Date::get_ms_from_date_time_ms($row['data']['timestamp'])
                );
                $ret[] = $r;
            }
        }

        if(!empty($data['car_number_list'])){
            foreach($data['car_number_list'] as $row){
                $image_index++;
                $r = JournalImage::add_journal_image(
                    $row['data']['camera_id'],
                    $jid,
                    $row['image_id'],
                    'front',
                    $image_index,
                    empty($row['data']['car_number_coords']) ? null : $row['data']['car_number_coords'],
                    'prepared_'. $row['data']['key'] .'_number',
                    $row['data']['direction'],
                    Date::get_ms_from_date_time_ms($row['data']['timestamp'])
                );
                $ret[] = $r;
            }
        }

        return $r;
    }
}