<?php

namespace CLI\Modules\PreparingImages;

use Core\Modules\Dir;

trait PrepareNone {

    private static function prepare_image_none(){ #pred(333);

        if(!count(self::$image_list)){ self::set_cerror('Image list is empty #444 '. __FUNCTION__); return false; }

        $image_list = [];
        $camera_list = [];
        foreach(self::$image_list as $index => $row)
            switch($row['key']){
                case 'before':
                case 'middle':
                case 'source':
                case 'after': {
                    $image_list[$row['key']] = $row;
                    $image_list[$row['key']]['index'] = $index;
                    if(!isset($camera_list[$row['camera_id']])) $camera_list[$row['camera_id']] = [];
                    $camera_list[$row['camera_id']][$row['key']] = $row;
                    break;
                }
            }
        if(!count($image_list)){ self::set_cerror('Image list < 1 '. __FUNCTION__); return false; }
        switch(count($camera_list)){
            case 1: {
                foreach($camera_list as $camera_id => $image_list) break;

                # FOR CAR NUMBER CUT FOR DUPLO
                #$image_result_data = self::get_image_speed_object($image_list['middle'], 3, false, self::$is_old_label_type);
                #self::$combo_car_number_coords = $image_result_data['cropped'];
                # FOR CAR NUMBER CUT FOR DUPLO

                $label_list = [];
                $image_data = $image_list['middle'];
                $direction_label = self::get_direction_label($image_data);
                $image_quality_data = self::$image_resolution_list[self::$traffic_violation];
                $image_result_width = $image_quality_data['width'];
                $image_result_height = $image_quality_data['height'];
                $image_result_quality = $image_quality_data['quality'];
                $image_result = imagecreatetruecolor($image_result_width, $image_result_height);

                if(self::$floor_speed === 'n/a') $speed = self::$floor_speed; else $speed = self::$floor_speed .' КМ/Ч';
                $label_list[] = 'ID КОМПЛЕКСА: '. self::$object_id .'    СКОРОСТЬ ТС: '.  $speed;
                $label_list[] = 'ВРЕМЯ ФИКСАЦИИ: '. self::$timestamp .'    ТИП НАРУШЕНИЯ: С0';
                $label_list[] = 'АДРЕС: '.mb_strtoupper(self::$object_address, 'utf-8');
                $label_list[] = (empty($direction_label) ? '' : ('НАПРАВЛЕНИЕ: '.mb_strtoupper($direction_label, 'utf-8').'    ')) .'КООРДИНАТЫ: '. mb_strtoupper(self::$object_gps, 'utf-8');

                $label_len = count($label_list);
                $label_h = self::get_label_height($label_len); #pred($image_data);

                if(1 && loc && !cli && !empty($_GET['si'])){
                    $image_before_data = self::get_test($image_data, 0, $image_result_width, $image_result_height - $label_h, false, false, self::$balancer->sets['imaging']['crop_zoom'], false, false, 'none_crop', 0, 0);
                    header('Content-Type: image/jpeg'); imagejpeg($image_before_data['image_object']); die;
                }

                $image_before_data = self::get_combo_image_with_car_number_object($image_data, 0, $image_result_width, $image_result_height - $label_h, false, false, self::$balancer->sets['imaging']['crop_zoom'], false, false, 'none_crop', 0, 0);
                $image_before_object = $image_before_data['image_object'];
                $image_before_width = $image_before_data['width'];
                $image_before_height = $image_before_data['height']; #pred($image_before_data['image_object']);
                if(1 && loc && !cli && !empty($_GET['si'])){ header('Content-Type: image/jpeg'); imagejpeg($image_before_data['image_object']); die; } # /admin/cli/balancer?si=1
                self::$image_combo_result['cropped'] = $image_before_data['cropped'];#pred(self::$image_combo_result);
                if(!imagecopy($image_result, $image_before_object, 0, 0, 0, 0, $image_before_width, $image_before_height)){ self::set_cerror('Image was not copy resize '. __FUNCTION__); return false; }
                $image_result = self::get_image_with_bottom_label($image_result, $label_list, $image_before_height+self::$image_padding_row + self::$font_size + 6, self::$font_x);

                if(1 && loc && !cli && !empty($_GET['si'])){ header('Content-Type: image/jpeg'); imagejpeg($image_result); die; }
                self::$combo_car_number_coords = $image_before_data['cropped']['car_number_coords'];
                Dir::create_dir(self::$image_combo_result['dir']); #self::$image_combo_result['cropped']['car_number_coords'] = self::$combo_car_number_coords;  # ADDED LPN COORDS FOR OFFENCES BY ALENEVI
                if(!imagejpeg($image_result, self::$image_combo_result['path'], self::$image_combo_result['quality'])){ self::set_cerror('Image combo was not save '. __FUNCTION__ .', fp__'. self::$image_combo_result['path'] .' | '. __FUNCTION__); return false; } #pred(self::$image_combo_result);
                return true;
            }
            default: {
                self::set_cerror('Camera list is not correct '. __FUNCTION__);
                return false;
            }
        }
    }
}