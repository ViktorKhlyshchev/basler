<?

define('DR', __DIR__); #$_SERVER['DOCUMENT_ROOT']
if(php_sapi_name() === 'cli') define('cli', true); else define('cli', false);

require __DIR__ .'/Core/Module/Debug/debug.php';

$gdp = '/var/www/html/Resource/Image/2021/09/07';
pre($gdp);echo '_______';print_r($gdp);echo '_______';
$cmd = 'stat \''. $gdp .'\''; pre(exec($cmd, $o, $r));
pre($o); pre($r); pre(is_dir($gdp)); pre(file_exists($gdp)); pre(file_exists($gdp));
$files = scandir($gdp); pre($files); pre(count($files) < 3);