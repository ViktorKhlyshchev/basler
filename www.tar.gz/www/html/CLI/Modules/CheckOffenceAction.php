<?php

namespace CLI\Modules; #namespace Project\Aist\Admin\Action\Xavier;

use Common\Modules\Date;
use Core\Modules\Dir;
use Configs\DirConfig;
use Common\Models\Image\Image;
use Core\Module\Video\Video;
use CLI\Modules\CloneImageAction;
use Common\Modules\ImagePathAction;
use Project\Aist\Admin\Action\Video\GetVideoCacheTimestampSizeAction;
use Project\Aist\Admin\Action\Video\GetVideoPartFromCacheAction;
use Project\Aist\Admin\Action\Video\VideoPathListAction;
use CLI\Modules\CheckOffence\CheckCarDirectionAction;
use CLI\Modules\CheckOffence\CheckCrossingLanesLineAction;
use CLI\Modules\CheckOffence\CheckMoveOutFromControlZoneAction;
use CLI\Modules\CheckOffence\CheckNoParkingAction;
use CLI\Modules\CheckOffence\CheckNoStopAction;
use CLI\Modules\CheckOffence\CheckOncomingLaneAction;
use CLI\Modules\CheckOffence\GetLaneNumberAction;
use Admin\Modules\GetZoneAction; # use Project\Aist\Admin\Action\Zone\GetZoneAction;
use Common\Models\Journal;
use Common\Models\JournalImage;
use Common\Models\JournalVideo; # use Project\Aist\Admin\Shell\Journal\SendBoxFtpShell; use CLI\Modules\SendBoxMultiThreadAction;

class CheckOffenceAction {

    private static $camera_id = 1;
    private static $journal_id_list = [];
    private static $journal_list = [];
    private static $zone_no_stop_name_list = ['no_stop'];
    private static $zone_no_parking_name_list = ['no_parking'];
    private static $zone_control_name_list = ['control_zone'];
    private static $zone_lane_name_list = ['lane'];
    private static $zone_no_stop_list = [];
    private static $zone_no_parking_list = [];
    private static $zone_control_list = [];
    private static $zone_control_buffer_list = [];
    private static $zone_lane_list = [];
    private static $timestamp_step; //    private static $timestamp_step_const = 8;
    private static $timestamp_between_tracks = 24;
    private static $timestamp_reversal = 10; // time for reverse make
    private static $image_key_for_track_list = ['number_coords_collage'];
    private static $zone_control_buffer_percent_y = 0.04;
    private static $zone_control_buffer_percent_x = 0.015;
    private static $zone_control_buffer_width = 40;
    private static $zone_control_buffer_height = 40;
    private static $loop_count_max = 10;
    private static $timestamp_last;
    private static $correct_bug_ms = 1;
    private static $video_timestamp_delta = 3000;
    private static $video_time_delta_min = 2000;
    public static $direction_point_len_min = 3;
    public static $error;
    public static $errors;

    public static function init(array $journal_id_list = null){ # pred(debug_backtrace());

        self::$journal_id_list = [];
        self::$journal_list = [];
        self::$zone_no_stop_list = [];
        self::$zone_no_parking_list = [];
        self::$zone_control_list = [];
        self::$zone_control_buffer_list = [];
        self::$zone_lane_list = [];
        self::$timestamp_step = \Config::$check_work_timeout;
        self::$timestamp_last = null;
        self::$error = null;
        self::$errors = [];

        self::$journal_id_list = $journal_id_list;
        // развороты, склееные на комплексе self::$journal_id_list = [151426];  [150193];  [150202]; 150217]; 150230];
        // lane - пересечение полосы  lane_opposite - встречная полоса no_parking - парковка запрещена no_stop - остановка запрещена reversal - разворот 150180 150181 150193 150195 150202 150203 lane opposite 150217 150230 - S
        # need test with traffic violation 150157 150158 150159
        self::$timestamp_last = time(); # self::$timestamp_last = 1608678611;  self::$timestamp_last = 1608816700;
        self::$zone_no_stop_list = self::get_zone_list(self::$zone_no_stop_name_list, true); // zones stop violation
        self::$zone_no_parking_list = self::get_zone_list(self::$zone_no_parking_name_list, true); // zones parking violation
        self::$zone_lane_list = self::get_zone_list(self::$zone_lane_name_list, true); // zones lanes
        self::$zone_control_list = self::get_zone_list(self::$zone_control_name_list, true); // control zone
        self::set_control_zone_to_buffer_zones();
        self::set_lane_rule_lines(); #pred(debug_backtrace()); #pred(self::$journal_id_list); #echo"\n\nSTART LOOP\n\n";
        self::$journal_list = Journal::get_car_number_data_list_with_timestamp(self::$journal_id_list); #pred(self::$journal_list);
        foreach(self::$journal_list as $index => $row){
            self::$journal_list[$index]['is_parent_journal'] = Journal::is_parent_journal($row['id']); #pred($row);
            self::$journal_list[$index] = self::prepare_journal_item(self::$journal_list[$index]);
            if(!self::$journal_list[$index]['is_parent_journal']){
                $r = self::prepare_car_row(self::$journal_list[$index]);
                if(!$r) return;
                self::$journal_list[$index] = $r;#pred(debug_backtrace());
            }
        } #pred(debug_backtrace()); #pre(self::$journal_list); №pre(unset(self::$journal_list)); efault_double_track_list
        self::set_journal_id_list();

        foreach(self::$journal_list as $index => $row){ #pred(self::$journal_list[$row]['track_list']);
            unset(self::$journal_list[$index]['track_list']);
            unset(self::$journal_list[$index]['work_time_ms_list']); #unset(self::$journal_list[$index]['no_stop_data']);
        } #pred(self::$journal_list); #$data = ['journal_list' => self::$journal_list]; #pre(Dir::get_global_dir(DirConfig::$dir_log.'/glue_log.txt'));
        #file_put_contents(Dir::get_global_dir(DirConfig::$dir_log.'/glue_log.txt'), print_r($data, true));
        return self::$journal_id_list;
    }

    private static function get_zone_list(array $zone_name_list = [], bool $need_only_first = false){
        $r = GetZoneAction::init(self::$camera_id, $zone_name_list);
        if(empty($r)) return [];
        $zone_list = [];
        foreach($zone_name_list as $zone_name){
            if(empty($r[$zone_name]['layer_list'])) continue;
            foreach($r[$zone_name]['layer_list'] as $layer_row){
                if(empty($layer_row['point_list'])) continue;
                $temp_list = [];
                foreach($layer_row['point_list'] as $point_row) $temp_list[] = ['x' => $point_row['x'], 'y' => $point_row['y']];
                if(empty($temp_list)) continue;
                if(empty($zone_list[$zone_name])) $zone_list[$zone_name] = [];
                $temp = ['list' => $temp_list];
                if(isset($layer_row['time'])) $temp['timestamp'] = $layer_row['time'];
                if(isset($layer_row['direction'])) $temp['direction'] = $layer_row['direction'];
                if(isset($layer_row['lane'])) $temp['lane'] = $layer_row['lane'];
                if(isset($layer_row['rules'])) $temp['rules'] = $layer_row['rules'];
                $zone_list[$zone_name][] = $temp;
            }
        }
        if($need_only_first) return array_shift($zone_list);
        return $zone_list;
    }

    private static function set_lane_rule_lines(){
        if(empty(self::$zone_lane_list)) return;
        for($zone_index = 0;$zone_index < count(self::$zone_lane_list); $zone_index++){
            if(count(self::$zone_lane_list[$zone_index]['list']) < 4) continue;
            array_shift(self::$zone_lane_list[$zone_index]['list']);
            $temp_list = self::$zone_lane_list[$zone_index]['list'];
            usort(self::$zone_lane_list[$zone_index]['list'], function($a, $b){ return $a['y'] > $b['y']; });
            $line_up = [
                self::$zone_lane_list[$zone_index]['list'][0],
                self::$zone_lane_list[$zone_index]['list'][1],
            ];
            $line_down = [
                self::$zone_lane_list[$zone_index]['list'][2],
                self::$zone_lane_list[$zone_index]['list'][3],
            ];
            usort(self::$zone_lane_list[$zone_index]['list'], function($a, $b){ return $a['x'] > $b['x']; });
            $line_left = [
                self::$zone_lane_list[$zone_index]['list'][0],
                self::$zone_lane_list[$zone_index]['list'][1],
            ];
            $line_right = [
                self::$zone_lane_list[$zone_index]['list'][2],
                self::$zone_lane_list[$zone_index]['list'][3],
            ];
            self::$zone_lane_list[$zone_index]['line_list'] = [];
            switch(self::$zone_lane_list[$zone_index]['direction']){
                case 'up': {
                    self::$zone_lane_list[$zone_index]['line_list'] = [
                        'up' => $line_up,
                        'down' => $line_down,
                        'left' => $line_left,
                        'right' => $line_right,
                    ];
                    break;
                }
                case 'down': {
                    self::$zone_lane_list[$zone_index]['line_list'] = [
                        'up' => $line_down,
                        'down' => $line_up,
                        'left' => $line_right,
                        'right' => $line_left,
                    ];
                    break;
                }
            }
            self::$zone_lane_list[$zone_index]['denied_line_list'] = self::$zone_lane_list[$zone_index]['line_list'];
            for($rule_index = 0; $rule_index < count(self::$zone_lane_list[$zone_index]['rules']['allowed_list']); $rule_index++)
                if(self::$zone_lane_list[$zone_index]['rules']['allowed_list'][$rule_index]['is_always'])
                    switch(self::$zone_lane_list[$zone_index]['rules']['allowed_list'][$rule_index]['rule']){
                        case 'arrow_forward': {
                            unset(self::$zone_lane_list[$zone_index]['denied_line_list']['up']); break;
                        }
                        case 'arrow_back': {
                            unset(self::$zone_lane_list[$zone_index]['denied_line_list']['down']); break;
                        }
                        case 'arrow_right': {
                            unset(self::$zone_lane_list[$zone_index]['denied_line_list']['right']); break;
                        }
                        case 'arrow_left': {
                            unset(self::$zone_lane_list[$zone_index]['denied_line_list']['left']); break;
                        }
                    }
            self::$zone_lane_list[$zone_index]['list'] = $temp_list;
        }
    }

    private static function set_control_zone_to_buffer_zones(){
        if(empty(self::$zone_control_list)) return false;
        for($zone_index = 0;$zone_index<count(self::$zone_control_list);$zone_index++)
            if(count(self::$zone_control_list[$zone_index]['list'])  >= 4){
                if(count(self::$zone_control_list[$zone_index]['list']) > 4)
                    array_shift(self::$zone_control_list[$zone_index]['list']);
                usort(self::$zone_control_list[$zone_index]['list'], function($a, $b){
                    return $a['y'] > $b['y'];
                });
                $zone_up = [
                    self::$zone_control_list[$zone_index]['list'][0],
                    self::$zone_control_list[$zone_index]['list'][1],
                ];
                usort($zone_up, function($a, $b){ return $a['x'] > $b['x']; });
                $zone_down = [
                    self::$zone_control_list[$zone_index]['list'][2],
                    self::$zone_control_list[$zone_index]['list'][3],
                ];
                usort($zone_down, function($a, $b){ return $a['x'] > $b['x']; });
                $cube_width_left_percent = abs($zone_up[1]['x']-$zone_up[0]['x'])*self::$zone_control_buffer_percent_x;
                $cube_width_right_percent = abs($zone_down[1]['x']-$zone_down[0]['x'])*self::$zone_control_buffer_percent_x;
                $cube_height_left_percent = abs($zone_down[0]['y']-$zone_up[0]['y'])*self::$zone_control_buffer_percent_y;
                $cube_height_right_percent = abs($zone_down[1]['y']-$zone_up[1]['y'])*self::$zone_control_buffer_percent_y;
                if($cube_width_left_percent<self::$zone_control_buffer_width/2 || $cube_width_right_percent<self::$zone_control_buffer_width/2 || $cube_width_left_percent > self::$zone_control_buffer_width || $cube_width_right_percent > self::$zone_control_buffer_width
                ){
                    $cube_width_left_percent = self::$zone_control_buffer_width;
                    $cube_width_right_percent = self::$zone_control_buffer_width;
                }
                if($cube_height_left_percent<self::$zone_control_buffer_height/2 || $cube_height_right_percent<self::$zone_control_buffer_height/2 || $cube_height_left_percent > self::$zone_control_buffer_height || $cube_height_right_percent > self::$zone_control_buffer_height
                ){
                    $cube_height_left_percent = self::$zone_control_buffer_height;
                    $cube_height_right_percent = self::$zone_control_buffer_height;
                } # echo"height left: ".$cube_height_left_percent."\n"; echo"height right: ".$cube_height_right_percent."\n"; echo"width left: ".$cube_width_left_percent."\n"; echo"width right: ".$cube_width_right_percent."\n";
                $zone_up[] = [
                    'x' => $zone_up[1]['x'],
                    'y' => $zone_up[1]['y']+$cube_height_right_percent,
                ];
                $zone_up[] = [
                    'x' => $zone_up[0]['x'],
                    'y' => $zone_up[0]['y']+$cube_height_left_percent,
                ];
                $zone_down[] = [
                    'x' => $zone_down[1]['x'],
                    'y' => $zone_down[1]['y']-$cube_height_right_percent,
                ];
                $zone_down[] = [
                    'x' => $zone_down[0]['x'],
                    'y' => $zone_down[0]['y']-$cube_height_left_percent,
                ];
                $zone_left = [$zone_up[0], $zone_down[0]];
                usort($zone_left, function($a, $b){ return $a['x'] > $b['x']; });
                $zone_left[] = ['x' => $zone_left[1]['x'] + $cube_width_left_percent, 'y' => $zone_left[1]['y']];
                $zone_left[] = ['x' => $zone_left[0]['x']+$cube_width_left_percent, 'y' => $zone_left[0]['y']];
                $zone_right = [$zone_up[1], $zone_down[1]];
                usort($zone_right, function($a, $b){ return $a['x'] > $b['x']; });
                $zone_right[] = ['x' => $zone_right[1]['x'] - $cube_width_right_percent, 'y' => $zone_right[1]['y']];
                $zone_right[] = ['x' => $zone_right[0]['x'] - $cube_width_right_percent, 'y' => $zone_right[0]['y']];
                self::$zone_control_list[$zone_index]['buffer_zones']['up'] = $zone_up;
                self::$zone_control_list[$zone_index]['buffer_zones']['down'] = $zone_down;
                self::$zone_control_list[$zone_index]['buffer_zones']['left'] = $zone_left;
                self::$zone_control_list[$zone_index]['buffer_zones']['right'] = $zone_right;
            }
        return true;
    }

    private static function get_track_list(array &$journal_data = null){
        if(empty($journal_data)) return null;
        $r = JournalImage::get_track_list([$journal_data['id']], [], self::$image_key_for_track_list, true, $journal_data['camera_id']);
        if(empty($r)) return null;
        $journal_data['track_list'] = [];
        foreach($r as $key => $row) $journal_data['track_list'][$key] = isset($row[self::$image_key_for_track_list[0]]) ? $row[self::$image_key_for_track_list[0]] : null;
        $journal_data = self::add_work_time_ms($journal_data, 'got_track_list');
        return $journal_data;
    }

    private static function prepare_car_direction(array $journal_data = []){
        if(empty($journal_data)) return $journal_data;
        $r = CheckCarDirectionAction::init($journal_data['track_list']);
        $car_direction = $r['car_direction'];
        if($car_direction != $journal_data['direction']){
            $journal_data['need_update'] = true;
            $journal_data['is_update_direction'] = true;
            $journal_data['direction_old'] = $journal_data['direction'];
            $journal_data['direction'] = $car_direction;
        }
        $journal_data['direction_list'] = $r['direction_list'];
        $journal_data['direction_history_list'] = $r['direction_history_list'];
        $journal_data = self::add_work_time_ms($journal_data, 'prepared_car_direction');
        return $journal_data;
    }

    private static function prepare_no_stop_zone(array $journal_data = [], bool $is_glued_track_list = false){
        if(empty($journal_data)) return $journal_data;
        if(empty(self::$zone_no_stop_list)) return $journal_data;
        $track_key = 'track_list';
        if($is_glued_track_list) $track_key = 'glued_track_list';
        $r = CheckNoStopAction::init($journal_data[$track_key], self::$zone_no_stop_list);
        if(empty($r)) return $journal_data;
        $journal_data['no_stop_data'] = $r;
        if($r['is_inside_zone']){
            $journal_data['need_update'] = $journal_data['traffic_violation'] != $r['traffic_violation_zone'];
            $journal_data['is_no_stop'] = true;
            $journal_data['update_traffic_violation_list'][] = $r['traffic_violation_zone'];
            $journal_data['traffic_violation_data_list'][] = [
                'journal_id' => $journal_data['id'],
                'traffic_violation' => $r['traffic_violation_zone'],
            ];
        }
        $journal_data = self::add_work_time_ms($journal_data, 'prepared_no_stop_zone');
        return $journal_data;
    }

    private static function prepare_move_out_from_zone(array $journal_data = []){
        if(empty($journal_data)) return $journal_data;
        if(empty(self::$zone_control_list)) return $journal_data;
        $r = CheckMoveOutFromControlZoneAction::init($journal_data['track_list'], self::$zone_control_list, $journal_data['direction']);
        if(empty($r)) return $journal_data;
        if($r['is_move_out_from_zone']){
            $journal_data['is_move_out_from_zone'] = true;
            $journal_data['is_need_find_next_track'] = false;
        }
        $journal_data = self::add_work_time_ms($journal_data, 'prepared_move_out_from_zone');
        return $journal_data;
    }

    private static function prepare_crossing_lanes_lines(array $journal_data = []){
        if(empty($journal_data)) return $journal_data;
        if(empty(self::$zone_lane_list)) return $journal_data;
        $r = CheckCrossingLanesLineAction::init($journal_data['track_list']['converted_track_list'], self::$zone_lane_list);
        if(empty($r)) return $journal_data;
        if($r['is_crossing_lanes_lines']){
            $journal_data['need_update'] = $journal_data['traffic_violation'] != $r['traffic_violation_zone'];
            $journal_data['is_crossing_lanes_lines'] = true;
            $journal_data['crossing_lanes_lines_data'] = ['video_timestamp_from' => $r['timestamp'], 'video_timestamp_to' => $r['timestamp']];
            $journal_data['update_traffic_violation_list'][] = $r['traffic_violation_zone'];
            $journal_data['traffic_violation_data_list'][] = [
                'journal_id' => $journal_data['id'],
                'traffic_violation' => $r['traffic_violation_zone'],
                'video_timestamp_from' => $r['timestamp'],
                'video_timestamp_to' => $r['timestamp'],
            ];
        }
        $journal_data = self::add_work_time_ms($journal_data, 'prepared_crossing_lanes_line');
        return $journal_data;
    }

    private static function prepare_lane_number(array $journal_data = []){
        if(empty($journal_data)) return $journal_data;
        if(empty(self::$zone_lane_list)) return $journal_data;
        if(nl)
            echo"Journal ID: ".$journal_data['id']."\n";
        $r = GetLaneNumberAction::init($journal_data['track_list'], self::$zone_lane_list);
        if(empty($r)) return $journal_data;
        $journal_data['lane'] = $r['lane'];
        Journal::update_journal_lane_number($journal_data['id'], $journal_data['lane']);
        JournalImage::update_journal_lane_number($journal_data['id'], $journal_data['lane']);
        $journal_data = self::add_work_time_ms($journal_data, 'prepare_lane_number');
        return $journal_data;
    }

    private static function create_video(array &$journal_data = []){
        $temp = []; # pre($journal_data['video']); # [timestamp_from] => 1634777374199 [timestamp_to] => 1634777374199
        if(empty($journal_data['video'])){
            $journal_data['need_update'] = true;
            $journal_data['traffic_violation'] = 'none';
            return $journal_data;
        }
        $journal_data['video']['timestamp_from'] -= self::$video_timestamp_delta;
        $journal_data['video']['timestamp_to'] += self::$video_timestamp_delta;
        $temp[] = $journal_data['video'];
        Journal::update_journal_description($journal_data['id'], $temp);
        $r = GetVideoCacheTimestampSizeAction::init(self::$camera_id);
        $temp[] = $r;
        Journal::update_journal_description($journal_data['id'], $temp);
        if(!empty($r['error_list'])){
            $journal_data['need_update'] = true;
            $journal_data['traffic_violation'] = 'none';
            return $journal_data;
        }
        $timestamp_min = $r['timestamp']['start'];
        $timestamp_max = $r['timestamp']['finish'];
        if($journal_data['video']['timestamp_from'] < $timestamp_min){
            $journal_data['video']['timestamp_from'] = $timestamp_min;
            $journal_data['video']['timestamp_to'] += 1000;
        }
        if($journal_data['video']['timestamp_to'] > $timestamp_max) $journal_data['video']['timestamp_to'] = $timestamp_max;
        Journal::update_journal_description($journal_data['id'], $temp);
        $temp[] = $journal_data['video'];
        $temp[] = [
            'delta' => $journal_data['video']['timestamp_to'] - $journal_data['video']['timestamp_from'],
            'delta_min' => self::$video_time_delta_min,
        ];
        Journal::update_journal_description($journal_data['id'], $temp);
        if($journal_data['video']['timestamp_to']-$journal_data['video']['timestamp_from']<self::$video_time_delta_min){
            $journal_data['need_update'] = true;
            $journal_data['traffic_violation'] = 'none';
            return $journal_data;
        }
        $r = GetVideoPartFromCacheAction::init(self::$camera_id, $journal_data['video']['timestamp_from'], $journal_data['video']['timestamp_to'], !empty($_POST['is_debug_video']));
        $temp[] = $r;
        Journal::update_journal_description($journal_data['id'], $temp);
        if(!empty($r['error_list'])){
            $journal_data['need_update'] = true;
            $journal_data['traffic_violation'] = 'none';
            return $journal_data;
        }
        $track_list = $journal_data['track_list']['default_track_list'];
        if(!empty($journal_data['update_track_list']['default_track_list'])) $track_list = $journal_data['update_track_list']['default_track_list'];
        JournalVideo::add_journal_video(self::$camera_id, $journal_data['id'], $r['video']['id'], null, 0, null, $track_list, $journal_data['direction'], $journal_data['timestamp']);
        return $journal_data;
    }

    private static function prepare_no_parking_zone(array $journal_data = [], bool $is_glued_track_list = false){
        if(empty($journal_data)) return $journal_data;
        if(empty(self::$zone_no_parking_list)) return $journal_data;
        $track_key = 'track_list';
        if($is_glued_track_list)
            $track_key = 'glued_track_list';
        $r = CheckNoParkingAction::init($journal_data[$track_key], self::$zone_no_parking_list);
        if(empty($r)) return $journal_data;
        $journal_data['no_parking_data'] = $r;
        if($r['is_inside_zone']){
            $journal_data['need_update'] = $journal_data['traffic_violation'] != $r['traffic_violation_zone'];
            $journal_data['is_no_parking'] = true;
            $journal_data['update_traffic_violation_list'][] = $r['traffic_violation_zone'];
            $journal_data['traffic_violation_data_list'][] = [
                'journal_id' => $journal_data['id'],
                'traffic_violation' => $r['traffic_violation_zone'],
            ];
        }
        $journal_data = self::add_work_time_ms($journal_data, 'prepared_no_parking_zone');
        return $journal_data;
    }

    private static function prepare_oncoming_lane(array $journal_data = []){
        if(empty($journal_data)) return $journal_data;
        if(empty(self::$zone_lane_list)) return $journal_data;
        $r = CheckOncomingLaneAction::init($journal_data, self::$zone_lane_list);
        if(empty($r)) return $journal_data;
        if($r['is_oncoming_lane']){
            $journal_data['need_update'] = true;
            $journal_data['is_oncoming_lane'] = true;
            $journal_data['oncoming_lane_history'] = $r['history_list'];
            $journal_data['oncoming_lane_data'] = [
                'video_timestamp_from' => $r['timestamp_from'],
                'video_timestamp_to' => $r['timestamp_to'],
            ];
            $journal_data['update_traffic_violation_list'][] = $r['traffic_violation_zone'];
            $journal_data['traffic_violation_data_list'][] = [
                'journal_id' => $journal_data['id'],
                'traffic_violation' => $r['traffic_violation_zone'],
                'video_timestamp_from' => $r['timestamp_from'],
                'video_timestamp_to' => $r['timestamp_to'],
            ];
        }
        $journal_data = self::add_work_time_ms($journal_data, 'prepare_oncoming_lane');
        return $journal_data;
    }

    private static function prepare_crossing_lines_with_merge_with_last_track(array $journal_data = [], array $last_track_list = [], array $current_track_list = []){
        if(empty($journal_data) || empty($last_track_list) || empty($current_track_list)) return $journal_data;
        if(empty(self::$zone_lane_list)) return $journal_data;
        $last_track_point = end($last_track_list['converted_track_list']);
        $current_track_point = $current_track_list['converted_track_list'][0];
        $track_list = [
            $last_track_point,
            $current_track_point,
        ];
        $r = CheckCrossingLanesLineAction::init($track_list, self::$zone_lane_list);
        if(empty($r)) return $journal_data;
        if($r['is_crossing_lanes_lines']){
            $timestamp_delta = ($current_track_point['timestamp']-$last_track_point['timestamp'])/1000;
            if($timestamp_delta <= self::$timestamp_between_tracks){
                $journal_data['need_update'] = true;
                $journal_data['is_crossing_lanes_lines'] = true;
                $journal_data['crossing_lanes_lines_data'] = [
                    'video_timestamp_from' => $last_track_point['timestamp'],
                    'video_timestamp_to' => $current_track_point['timestamp'],
                ];
                $journal_data['update_traffic_violation_list'][] = $r['traffic_violation_zone'];
                $journal_data['traffic_violation_data_list'][] = [
                    'journal_id' => $journal_data['id'],
                    'timestamp_delta' => $timestamp_delta,
                    'traffic_violation' => $r['traffic_violation_zone'],
                    'video_timestamp_from' => $last_track_point['timestamp'],
                    'video_timestamp_to' => $current_track_point['timestamp'],
                ];
            }
        }
        $journal_data = self::add_work_time_ms($journal_data, 'prepared_crossing_lanes_line_in_glued_track');
        return $journal_data;
    }

    private static function get_timestamp_from_track_list(string $key = null, array $track_list = [], int $timestamp = null){
        if(!isset($track_list[$key])) return null;
        if(count($track_list[$key])<3) return null;
        $start_point_data = array_shift($track_list[$key]);
        $finish_point_data = end($track_list[$key]);
        if(!isset($start_point_data['timestamp']) || !isset($finish_point_data['timestamp'])) return null;
        return [
            'start' => $timestamp,
            'finish' => $timestamp+abs($finish_point_data['timestamp']-$start_point_data['timestamp'])/self::$correct_bug_ms,
        ];
    }

    private static function add_work_time_ms(array &$journal_data = null, string $name = null){
        $journal_data['work_time_ms_list'][] = ['name' => $name, 'timestamp' => microtime(true)];
        return $journal_data;
    }

    private static function update_work_time(array $journal_data = []){
        if(count($journal_data['work_time_ms_list']) < 2) $journal_data['work_time_ms_list'][] = ['name' => 'finish', 'timestamp' => microtime(true)];
        $journal_data['work_time'] = $journal_data['work_time_ms_list'][count($journal_data['work_time_ms_list'])-1]['timestamp']-$journal_data['work_time_ms_list'][0]['timestamp'];
        for($index = 1;$index<count($journal_data['work_time_ms_list']);$index++)
            $journal_data['work_time_list'][$journal_data['work_time_ms_list'][$index]['name']] = round(($journal_data['work_time_ms_list'][$index]['timestamp'] - $journal_data['work_time_ms_list'][$index-1]['timestamp']) * 1000, 2);
        return $journal_data;
    }

    private static function prepare_traffic_violation(array $journal_data = []){ # pre($journal_data);

        if(empty($journal_data)) return $journal_data; #pred($journal_data['glued_track_count']);

        if(!$journal_data['glued_track_count']){ #pred($journal_data['direction_list']);
            if($journal_data['is_crossing_lanes_lines'] && $journal_data['is_oncoming_lane']){
                if(isset($journal_data['direction_list']) && $journal_data['direction_list']['up'] > self::$direction_point_len_min && $journal_data['direction_list']['down'] > self::$direction_point_len_min){
                    $traffic_violation = 'reversal';
                    $journal_data['is_reversal'] = true;
                    $journal_data['reversal_data'] = [
                        'video_timestamp_from' => $journal_data['direction_history_list'][0]['timestamp_from'],
                        'video_timestamp_to' => $journal_data['direction_history_list'][count($journal_data['direction_history_list'])-1]['timestamp_to'],
                    ];
                    $journal_data['video'] = [
                        'timestamp_from' => $journal_data['reversal_data']['video_timestamp_from'],
                        'timestamp_to' => $journal_data['reversal_data']['video_timestamp_to'],
                    ];
                } else {
                    $traffic_violation = 'lane_opposite';
                    $journal_data['is_oncoming_lane'] = true;

                    if(isset($journal_data['direction_history_list']))
                        $journal_data['oncoming_lane_data'] = [
                            'video_timestamp_from' => $journal_data['direction_history_list'][0]['timestamp_from'],
                            'video_timestamp_to' => $journal_data['direction_history_list'][count($journal_data['direction_history_list'])-1]['timestamp_to'],
                        ]; #pred($journal_data['oncoming_lane_data']);
                    $journal_data['video'] = [
                        'timestamp_from' => $journal_data['oncoming_lane_data']['video_timestamp_from'],
                        'timestamp_to' => $journal_data['oncoming_lane_data']['video_timestamp_to'],
                    ]; #pred($journal_data['video']);
                }
                $journal_data['need_update'] = true;
                $journal_data['update_traffic_violation_list'][] = $traffic_violation;
                $journal_data['traffic_violation_data_list'][] = ['journal_id' => $journal_data['id'], 'traffic_violation' => $traffic_violation];
            }
        }

        if($journal_data['is_reversal']){
            $traffic_violation = 'reversal';
            $journal_data['video'] = ['timestamp_from' => $journal_data['reversal_data']['video_timestamp_from'], 'timestamp_to' => $journal_data['reversal_data']['video_timestamp_to']];
        } else if($journal_data['is_oncoming_lane']){
            $traffic_violation = 'lane_opposite';
            $journal_data['video'] = [
                'timestamp_from' => $journal_data['oncoming_lane_data']['video_timestamp_from'],
                'timestamp_to' => $journal_data['oncoming_lane_data']['video_timestamp_to'],
            ];
        } else if($journal_data['is_crossing_lanes_lines']){
            $traffic_violation = 'lane';
            $journal_data['video'] = [
                'timestamp_from' => $journal_data['crossing_lanes_lines_data']['video_timestamp_from'],
                'timestamp_to' => $journal_data['crossing_lanes_lines_data']['video_timestamp_to'],
            ];
        } else if($journal_data['is_no_stop']){
            if(floor($journal_data['speed']) === 0){
                $journal_data['is_no_stop'] = false;
                $traffic_violation = 'none';
            } else $traffic_violation = 'no_stop';
        } else if($journal_data['is_no_parking']){
            if(floor($journal_data['speed']) === 0){
                $journal_data['is_no_parking'] = false;
                $traffic_violation = 'none';
            } else $traffic_violation = 'no_parking';
        } else $traffic_violation = 'none';

        $journal_data['update_traffic_violation'] = $traffic_violation;
        if(!empty($journal_data['video']) && \Config::$is_need_traffic_violation_video)
            switch($journal_data['update_traffic_violation']){
                case 'reversal':
                case 'lane_opposite':
                case 'lane': {
                    if($journal_data['update_traffic_violation'] !== $journal_data['traffic_violation']){
                        pre('$journal_data[update_traffic_violation] !== $journal_data[traffic_violation]');
                        JournalVideo::pseudo_remove_journal_id_list([$journal_data['id']]);
                        $journal_data = self::create_video($journal_data);
                    } else if(!JournalVideo::isset_video($journal_data['id'])){
                        pre('$journal_data[update_traffic_violation] === $journal_data[traffic_violation]');
                        pre('!JournalVideo::isset_video($journal_data[ID])');
                        $journal_data = self::create_video($journal_data);
                    }
                    break;
                }
            }
        return $journal_data;
    }

    private static function prepare_find_next_tracks(array $journal_data = []){

        if(empty($journal_data)) return $journal_data;
        if(!$journal_data['is_need_find_next_track']) return $journal_data;
        $loop_index = 0;
        $journal_id = $journal_data['id'];
        $timestamp_start = $journal_data['timestamp'];
        $timestamp_finish = $journal_data['timestamp']+self::$timestamp_step*1000;
        $last_direction = $journal_data['direction'];
        $last_track_list = $journal_data['track_list'];
        $last_track_timestamp = count($last_track_list['default_track_list']) > 0 ? $last_track_list['default_track_list'][count($last_track_list['default_track_list'])-1]['timestamp'] : null;
        $t_list = [$timestamp_start];
        do {
            $loop_index++;
            if($loop_index > self::$loop_count_max) break; # echo"\n\nFINISH WITH EXIT FROM LOOP\n"; echo"car_number: ".$journal_data['car_number']."\n";

            $journal_step_list = Journal::get_journal_list_with_step($journal_data['car_number'], $timestamp_start, $timestamp_finish, $journal_id);
            if(empty($journal_step_list)){
                $journal_data['is_need_find_next_track'] = false;
                return $journal_data;
            }

            for($journal_step_index = 0;$journal_step_index<count($journal_step_list);$journal_step_index++){
                $journal_id = $journal_step_list[$journal_step_index]['id'];
                $timestamp_start = $journal_step_list[$journal_step_index]['timestamp'];
                $timestamp_finish = $journal_step_list[$journal_step_index]['timestamp']+self::$timestamp_step*1000;
                $journal_data['is_skip'] = ($journal_step_list[$journal_step_index]['timestamp'] + self::$timestamp_step*1000) > self::$timestamp_last*1000;
                if($journal_data['is_skip']) return $journal_data;
                $t_list[] = $timestamp_start;
                $journal_step_list[$journal_step_index]['work_time'] = 0;
                $journal_step_list[$journal_step_index]['work_time_ms_list'] = [];
                $journal_step_list[$journal_step_index]['work_time_list'] = [];
                $journal_step_list[$journal_step_index]['update_traffic_violation_list'] = [];
                $journal_step_list[$journal_step_index]['is_need_find_next_track'] = true;
                $journal_step_list[$journal_step_index]['is_done'] = false;
                $journal_step_list[$journal_step_index]['is_skip'] = false;
                $journal_step_list[$journal_step_index]['is_move_out_from_zone'] = false;
                $journal_step_list[$journal_step_index]['is_crossing_lanes_lines'] = false;
                $journal_step_list[$journal_step_index]['is_no_stop'] = false;
                $journal_step_list[$journal_step_index]['is_no_parking'] = false;
                $journal_step_list[$journal_step_index]['is_oncoming_lane'] = false;
                $journal_step_list[$journal_step_index]['is_reversal'] = false;
                $journal_step_list[$journal_step_index] = self::get_track_list($journal_step_list[$journal_step_index]);
                if(!empty($journal_step_list[$journal_step_index])){ #$journal_step_list[$journal_step_index] = self::prepare_car_direction($journal_step_list[$journal_step_index]);

                    if(!empty($journal_step_list[$journal_step_index]['direction'])&&!empty(self::$zone_no_stop_list)){
                        $journal_step_list[$journal_step_index] = self::prepare_no_stop_zone($journal_step_list[$journal_step_index]);
                        $journal_step_list[$journal_step_index] = self::prepare_no_parking_zone($journal_step_list[$journal_step_index]);
                        $journal_step_list[$journal_step_index] = self::prepare_move_out_from_zone($journal_step_list[$journal_step_index]);
                        $journal_step_list[$journal_step_index] = self::prepare_crossing_lanes_lines($journal_step_list[$journal_step_index]);
                        $journal_step_list[$journal_step_index] = self::prepare_oncoming_lane($journal_step_list[$journal_step_index]);
                        $journal_step_list[$journal_step_index] = self::prepare_crossing_lines_with_merge_with_last_track($journal_step_list[$journal_step_index], $last_track_list, $journal_step_list[$journal_step_index]['track_list']);
                    }

                    if(empty($journal_data['update_track_list'])) $journal_data['update_track_list'] = $journal_data['track_list'];
                    $journal_data['glued_journal_id_list'][] = $journal_step_list[$journal_step_index]['id'];
                    foreach($journal_step_list[$journal_step_index]['track_list'] as $track_key => $track_list){
                        if(!isset($journal_data['update_track_list'][$track_key])) $journal_data['update_track_list'][$track_key] = [];
                        if(!isset($journal_data['glued_track_list'][$track_key])) $journal_data['glued_track_list'][$track_key] = [];
                        if(!isset($journal_data['update_track_list'][$track_key])) $journal_data['update_track_list'][$track_key] = [];
                        $journal_data['glued_track_list'][$track_key] = array_merge($journal_data['glued_track_list'][$track_key], $journal_step_list[$journal_step_index]['track_list'][$track_key]);
                        $journal_data['update_track_list'][$track_key] = array_merge($journal_data['update_track_list'][$track_key], $journal_step_list[$journal_step_index]['track_list'][$track_key]);
                    }
                    $journal_data['glued_track_count']++;
                    if($journal_step_list[$journal_step_index]['is_crossing_lanes_lines']){
                        $traffic_violation = 'lane';
                        $journal_data['need_update'] = true;
                        $journal_data['lane'] = true;
                        $journal_data['crossing_lanes_lines_data'] = [
                            'video_timestamp_from' => $journal_step_list[$journal_step_index]['crossing_lanes_lines_data']['video_timestamp_from'],
                            'video_timestamp_to' => $journal_step_list[$journal_step_index]['crossing_lanes_lines_data']['video_timestamp_to'],
                        ];
                        $journal_data['update_traffic_violation_list'][] = $traffic_violation;
                        $journal_data['traffic_violation_data_list'][] = [
                            'journal_id' => $journal_step_list[$journal_step_index]['id'],
                            'traffic_violation' => $traffic_violation,
                            'video_timestamp_from' => $journal_step_list[$journal_step_index]['crossing_lanes_lines_data']['video_timestamp_from'],
                            'video_timestamp_to' => $journal_step_list[$journal_step_index]['crossing_lanes_lines_data']['video_timestamp_to'],
                        ];
                    }
                    if(!empty($journal_step_list[$journal_step_index]['direction'])
                        &&!empty($last_direction)
                        &&$journal_step_list[$journal_step_index]['direction'] != $last_direction
                    ){
                        $traffic_violation = 'reversal';
                        $journal_data['need_update'] = true;
                        $journal_data['is_reversal'] = true;
                        $journal_data['reversal_data'] = [
                            'video_timestamp_from' => $last_track_timestamp,
                            'video_timestamp_to' => $journal_step_list[$journal_step_index]['track_list']['default_track_list'][0]['timestamp'],
                        ];
                        $journal_data['update_traffic_violation_list'][] = $traffic_violation;
                        $journal_data['traffic_violation_data_list'][] = [
                            'journal_id' => $journal_step_list[$journal_step_index]['id'],
                            'traffic_violation' => $traffic_violation,
                            'video_timestamp_from' => $last_track_timestamp,
                            'video_timestamp_to' => $journal_step_list[$journal_step_index]['track_list']['default_track_list'][0]['timestamp'],
                        ];
                        $journal_step_list[$journal_step_index]['is_need_find_next_track'] = false;
                    }
                    if(!$journal_step_list[$journal_step_index]['is_need_find_next_track']){
                        $journal_data['is_need_find_next_track'] = false;
                        $journal_data['glued_track_count'] ++;
                        return $journal_data;
                    }
                    if(!is_null($journal_step_list[$journal_step_index]['direction']))
                        $last_direction = $journal_step_list[$journal_step_index]['direction'];
                    if(!empty($journal_step_list[$journal_step_index]['track_list']))
                        $last_track_list = $journal_step_list[$journal_step_index]['track_list'];
                }
            }
        } while($journal_data['is_need_find_next_track']);
        return $journal_data;
    }

    static function prepare_journal_item(array $journal_data = []){
        $journal_data['work_time'] = 0;
        $journal_data['work_time_ms_list'] = [];
        $journal_data['work_time_list'] = [];
        $journal_data['update_traffic_violation_list'] = [];
        $journal_data['part_list'] = [];
        $journal_data['track_list'] = [];
        $journal_data['update_track_list'] = [];
        $journal_data['glued_track_list'] = [];
        $journal_data['glued_track_count'] = 0;
        $journal_data['video_timestamp_from'] = 0;
        $journal_data['video_timestamp_to'] = 0;
        $journal_data['need_update'] = false;
        $journal_data['is_need_find_next_track'] = true;
        $journal_data['is_done'] = false;
        $journal_data['is_skip'] = false;
        $journal_data['is_move_out_from_zone'] = false;
        $journal_data['is_crossing_lanes_lines'] = false;
        $journal_data['is_no_stop'] = false;
        $journal_data['is_no_parking'] = false;
        $journal_data['is_oncoming_lane'] = false;
        $journal_data['is_reversal'] = false;
        $journal_data = self::add_work_time_ms($journal_data, 'start');
        $journal_data = self::get_track_list($journal_data);
        if(empty($journal_data)) return $journal_data; # $journal_data = self::prepare_car_direction($journal_data); $journal_data = self::prepare_lane_number($journal_data);
        #if(empty($journal_data)) return $journal_data; if(!empty($_REQUEST['need_log'])){ print_r($journal_data);die;}
        if($journal_data['is_parent_journal']) return $journal_data;
        if(!$journal_data['is_no_detect']){ # $journal_data = self::get_track_list($journal_data); if(empty($journal_data)) return $journal_data;
            if(!empty($journal_data['direction'])){
                $journal_data = self::prepare_no_stop_zone($journal_data);
                $journal_data = self::prepare_no_parking_zone($journal_data);
                $journal_data = self::prepare_move_out_from_zone($journal_data);
                $journal_data = self::prepare_crossing_lanes_lines($journal_data);
                $journal_data = self::prepare_oncoming_lane($journal_data); # $journal_data = self::prepare_lane_number($journal_data);
            }
            $journal_data = self::prepare_find_next_tracks($journal_data);
            if($journal_data['glued_track_count'] > 0 && !empty(self::$zone_no_stop_list)){
                $journal_data = self::prepare_no_stop_zone($journal_data, true);
                $journal_data = self::prepare_no_parking_zone($journal_data, true);
                $journal_data['track_list'] = $journal_data['glued_track_list']; # $journal_data = self::prepare_car_direction($journal_data);
            }
            $journal_data = self::prepare_traffic_violation($journal_data);
        }
        $journal_data = self::update_work_time($journal_data);
        return $journal_data;
    }

    static function prepare_car_row(array $journal_data = null){ #pred($journal_data); # pred($journal_data['glued_journal_id_list']); pred($journal_data);
        #unset($journal_data['track_list']); unset($journal_data['glued_track_list']); unset($journal_data['update_track_list']);  print_r($journal_data); die;
        if(empty($journal_data)) return $journal_data;
        if($journal_data['is_skip']) return $journal_data; #pred($journal_data['update_traffic_violation']);
        if(isset($journal_data['update_traffic_violation']))
            switch($journal_data['update_traffic_violation']){
                case 'lane':
                case 'lane_opposite':
                case 'route_vehicles':
                case 'reversal': { #pred($journal_data['glued_track_count']);
                    $source_image_list = JournalImage::get_image_list_from_keys($journal_data['id']); #$source_image_list = JournalImage::get_image_list_from_keys_src($journal_data['id']);  #pred($source_image_list[0]['image_id']);
                    #pre($middle_image_id);
                    $middle_image_id = CloneImageAction::init($source_image_list[0]['image_id']);

                    if(!$middle_image_id){ self::$error = 'CANT CloneImageAction::init!'; self::$errors[] = self::$error; self::$errors[] = CloneImageAction::$errors; if(hand) pred(self::$errors); return; }  #if(!$middle_image_id) pred('Cant find middle image!'); #pred($source_image_list[0]['image_id']);

                    if($journal_data['glued_track_count']){
                        $end_journal_id = end($journal_data['glued_journal_id_list']);
                        $glued_image_list = JournalImage::get_image_list_from_keys($end_journal_id); #$glued_image_list = JournalImage::get_image_list_from_keys_src($end_journal_id);
                        $after_image_id = CloneImageAction::init($glued_image_list[0]['image_id']);
                    } else {
                        $after_image_id = CloneImageAction::init($source_image_list[0]['image_id']);
                    } #$imagesa = JournalImage::get_all_images_bjid($journal_data['id']); #pred($imagesa); #if(!$after_image_id) pred('Cant find after image!'); #pre(count($source_image_list)); pre($source_image_list);
                    #pre($middle_image_id); pred($after_image_id); #pre($source_image_list[0]['image_id']); pre($source_image_list[0]);
                    JournalImage::update_journal_image_key($source_image_list[0]['id'], 'before'); # IMAGES DOUBLING!!!
                    $r = JournalImage::add_journal_image(
                        self::$camera_id,
                        $journal_data['id'],
                        $middle_image_id,
                        'front',
                        1,
                        $source_image_list[0]['car_number_coords'],
                        'middle',
                        $source_image_list[0]['direction'],
                        $source_image_list[0]['timestamp'],
                        $source_image_list[0]['lane'],
                        $source_image_list[0]['track_coords']
                    ); if(hand){ pre(self::$journal_id_list); pre($r); } #pred($r);
                    if($journal_data['glued_track_count'] > 0)
                        $r = JournalImage::add_journal_image(
                            self::$camera_id,
                            $journal_data['id'],
                            $after_image_id,
                            'front',
                            2,
                            $glued_image_list[0]['car_number_coords'],
                            'after',
                            $glued_image_list[0]['direction'],
                            $glued_image_list[0]['timestamp'],
                            $glued_image_list[0]['lane'],
                            $glued_image_list[0]['track_coords']
                        );
                    else
                        $r = JournalImage::add_journal_image(
                            self::$camera_id,
                            $journal_data['id'],
                            $after_image_id,
                            'front',
                            2,
                            $source_image_list[0]['car_number_coords'],
                            'after',
                            $source_image_list[0]['direction'],
                            $source_image_list[0]['timestamp'],
                            $source_image_list[0]['lane'],
                            $source_image_list[0]['track_coords']
                        );
                    break;
                }
            }
        if($journal_data['need_update']){ if(!ajax && hand) pre('$journal_data[need_update]!!!'); # add switch for clone journal row
            Journal::update_journal_traffic_violation($journal_data['id'], $journal_data['update_traffic_violation'], $journal_data['direction']);
            # echo"traffic violation was update from: '".$journal_data['traffic_violation']."' to '".$journal_data['update_traffic_violation']."'\n";
        }

        if(empty($journal_data['glued_track_count'])) return $journal_data;
        JournalImage::update_track_list($journal_data['id'], $journal_data['update_track_list']['default_track_list'], $journal_data['direction']);
        Journal::update_journal_to_glued($journal_data['id'], count($journal_data['glued_journal_id_list']));
        $remove_journal_id_list = [];
        foreach($journal_data['glued_journal_id_list'] as $glued_journal_id){
            $remove_journal_id_list[] = $glued_journal_id;
            Journal::update_journal_to_child_glued($glued_journal_id, $journal_data['id']);
        }
        if(!empty($remove_journal_id_list)) self::remove_journal_id_list($remove_journal_id_list);
        return $journal_data;
    }

    private static function set_journal_id_list(){
        self::$journal_id_list = []; #pred(self::$journal_list);
        foreach(self::$journal_list as $car_row) if(!$car_row['is_skip']) self::$journal_id_list[] = $car_row['id']; #if(nl && self::$journal_list) pre(self::$journal_id_list[0]);
        return true;
    }

    private static function remove_journal_id_list(array $journal_id_list = []){
        foreach($journal_id_list as $index => $journal_id){
            $journal_data = Journal::get_journal_data($journal_id); #if(!empty($_POST['is_test'])) echo"starting remove journal_id: ".$journal_id."\n";
            if(!empty($journal_data)){
                $date_create = $journal_data['date_create'];
                if(!empty($date_create)){
                    $dir_box = Date::get_date_path($date_create, DirConfig::$dir_cafap_package);
                    $dir_box .= '/'.$journal_id;
                    $dir_box = Dir::get_global_dir($dir_box);
                    if(file_exists($dir_box)) Dir::remove_dir($dir_box); # if(!empty($_POST['is_test']))  echo"- > > remove dir box: ".$dir_box."\n";
                }
            }

            $images_ids = JournalImage::get_images_ids($journal_id);

            if(count($images_ids)){
                foreach($images_ids as $image_id){
                    $image_data = ImagePathAction::get_image_path_data($image_id, true, true, true, false); #pred($image_data);
                    if(empty($image_data) || empty($image_data['image_dir'])) continue;
                    $imgdp = Dir::get_global_dirn($image_data['image_dir']); #pred($imgd);
                    if(is_dir($imgdp)){
                        if(nl) pre("->> remove image_dir: ". $imgdp ."\n");
                        $r = Dir::remove_dirn($imgdp); pre($r);
                        if(!$r) pred('Cant remove dir!');
                    }
                }
                Image::pseudo_remove_image_id_list($images_ids); // update to type = 1 Image::delete_image_id_list($images_ids); // delete
            }

            $video_id_list = JournalVideo::get_videos_ids($journal_id);
            if(count($video_id_list)){
                $video_list = VideoPathListAction::get_video_path_list($video_id_list, true, true, true);
                foreach($video_list as $video_row){
                    if(empty($video_row['video_dir'])) continue;
                    $viddp = $video_row['video_dir'];
                    if(!is_dir($viddp)) continue;
                    $r = Dir::remove_dirn($viddp); pre($r);
                    if(nl) pre("->> remove video_dir: ". $viddp ."\n");
                }
                Video::delete_video_id_list($video_id_list);
            }
            Journal::pseudo_remove_journal_id_list([$journal_id]); #Journal::delete_journal_id_list([$journal_id]);
        }
    }
}