<?php

namespace CLI\Modules;

class CLIController {

    public $req;
    public $res;
    public $action;

    public function __construct($c = null){

        global $req;   # $req::init(); #pred($_POST); pred($req->post('action'));
        $this->action = $req->post('action');

        #if(!$this->beforeAction()) die;
        #$cr = new \ReflectionClass('Core\Module\Controller\Controller');
        $cr = new \ReflectionClass(get_called_class());
        #pred($cr);
        $this->views_dir = str_replace('Controller', '', basename($cr->getFileName(), '.php'));
        $this->view_dir = DR .'/Admin/Views/'. $this->views_dir; #        pred($this->view_dir);
        $this->req = $req; #pred($this->req);

    }
}