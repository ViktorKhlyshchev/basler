<?php

namespace CLI\Modules\RTSWS;

use Core\Module\Token\Token;
use Core\Module\User\UserAccess;
use Admin\Controllers\RTSController;

function handshake($connect){

    $info = array();

    $line = fgets($connect);
    $header = explode(' ', $line);
    $info['method'] = $header[0];
    $info['uri'] = $header[1];

    //считываем заголовки из соединения
    while($line = rtrim(fgets($connect))){
        if(preg_match('/\A(\S+): (.*)\z/', $line, $matches)){
            $info[$matches[1]] = $matches[2];
        } else break;
    }

    $address = explode(':', stream_socket_get_name($connect, true)); //получаем адрес клиента
    $info['ip'] = $address[0];
    $info['port'] = $address[1];

    if(empty($info['Sec-WebSocket-Key'])){
        return false;
    }

    $SecWebSocketAccept = base64_encode(pack('H*', sha1($info['Sec-WebSocket-Key'] . '258EAFA5-E914-47DA-95CA-C5AB0DC85B11'))); //отправляем заголовок согласно протоколу вебсокета
    $upgrade = "HTTP/1.1 101 Web Socket Protocol Handshake\r\n" .
        "Upgrade: websocket\r\n" .
        "Connection: Upgrade\r\n" .
        "Sec-WebSocket-Accept:".$SecWebSocketAccept."\r\n\r\n";
    fwrite($connect, $upgrade);

    return $info;
}

function decode($data){

    $unmaskedPayload = '';
    $decodedData = [];

    $firstByteBinary = sprintf('%08b', ord($data[0])); // estimate frame type:
    $secondByteBinary = sprintf('%08b', ord($data[1]));
    $opcode = bindec(substr($firstByteBinary, 4, 4));
    $isMasked = ($secondByteBinary[0] == '1') ? true : false;
    $payloadLength = ord($data[1]) & 127;

    if(!$isMasked){ // unmasked frame is received:
        return array('type' => '', 'payload' => '', 'error' => 'protocol error (1002)');
    }

    switch ($opcode){ // text frame:
        case 1:
            $decodedData['type'] = 'text';
            break;

        case 2:
            $decodedData['type'] = 'binary';
            break;

        // connection close frame:
        case 8:
            $decodedData['type'] = 'close';
            break;

        // ping frame:
        case 9:
            $decodedData['type'] = 'ping';
            break;

        // pong frame:
        case 10:
            $decodedData['type'] = 'pong';
            break;

        default:
            return array('type' => '', 'payload' => '', 'error' => 'unknown opcode (1003)');
    }

    if($payloadLength === 126){
        $mask = substr($data, 4, 4);
        $payloadOffset = 8;
        $dataLength = bindec(sprintf('%08b', ord($data[2])) . sprintf('%08b', ord($data[3]))) + $payloadOffset;
    } elseif($payloadLength === 127){
        $mask = substr($data, 10, 4);
        $payloadOffset = 14;
        $tmp = '';
        for($i = 0; $i < 8; $i++){
            $tmp .= sprintf('%08b', ord($data[$i + 2]));
        }
        $dataLength = bindec($tmp) + $payloadOffset;
        unset($tmp);
    } else {
        $mask = substr($data, 2, 4);
        $payloadOffset = 6;
        $dataLength = $payloadLength + $payloadOffset;
    }

    /**
     * We have to check for large frames here. socket_recv cuts at 1024 bytes
     * so if websocket-frame is > 1024 bytes we have to wait until whole
     * data is transferd.
     */
    if(strlen($data) < $dataLength){
        return false;
    }

    if($isMasked){
        for ($i = $payloadOffset; $i < $dataLength; $i++){
            $j = $i - $payloadOffset;
            if(isset($data[$i])){
                $unmaskedPayload .= $data[$i] ^ $mask[$j % 4];
            }
        }
        $decodedData['payload'] = $unmaskedPayload;
    } else {
        $payloadOffset = $payloadOffset - 4;
        $decodedData['payload'] = substr($data, $payloadOffset);
    }

    #return json_encode($decodedData, 1);
    return json_decode($decodedData['payload'], 1);
}

//пользовательские сценарии:

function onClose($connect){
    consolemsg("close OK");
}

function consolestart(){
	consolemsg("console - start");
}

function consolemsg($msg){
    echo $msg."\r\n";
    return;
	$file = null;
	if(!file_exists($GLOBALS['file'])){
	    $file = fopen($GLOBALS['file'],"w");
		fputs($file, "<!DOCTYPE html>\r\n<html>\r\n<head>\r\n<title>GC - console log</title>\r\n\r\n<meta charset=\"UTF-8\" />\r\n</head>\r\n<body>\r\n"); //Сохраняем значение счётчика
	} else
	    $file = fopen($GLOBALS['file'],"a");

	echo $msg."\r\n";
    return;
	fputs($file, "[<b>".date("Y.m.d-H:i:s")."</b>]". $msg ."<br />\r\n");
	fclose($file);
}

function consoleend(){
	consolemsg("console - end");
}

function isDaemonActive($pidfile){
  if(is_file($pidfile)){
        $pid = file_get_contents($pidfile); //проверяем на наличие процесса, функция posix_kill может быть устаревшей возможно потребуется замена при переходе на PHP 5.3+
        if(posix_kill($pid, 0)){ //демон уже запущен
            return true;
        } else { //pid-файл есть, но процесса нет
            consolemsg("there is no process with PID = ".$pid.", last termination was abnormal...");
            consolemsg("try to unlink PID file...");
            if(!@unlink($pidfile)){
                consolemsg("ERROR не могу уничтожить pid-файл. ошибка"); //не могу уничтожить pid-файл. ошибка
                exit(-1);
            }
        }
  }
  return false;
}

#function encode(string $payload = '', $type = 'text', $masked = false){ pre(func_get_args());
function encode($payload = null, $type = 'text', $masked = false){ #pre(func_get_args());

    $frameHead = array();
    $payloadLength = strlen($payload);

    switch($type){
        case 'text':
            // first byte indicates FIN, Text-Frame (10000001):
            $frameHead[0] = 129;
            break;

        case 'close':
            // first byte indicates FIN, Close Frame(10001000):
            $frameHead[0] = 136;
            break;

        case 'ping':
            // first byte indicates FIN, Ping frame (10001001):
            $frameHead[0] = 137;
            break;

        case 'pong':
            // first byte indicates FIN, Pong frame (10001010):
            $frameHead[0] = 138;
            break;
    }

    // set mask and payload length (using 1, 3 or 9 bytes)
    if($payloadLength > 65535){
        $payloadLengthBin = str_split(sprintf('%064b', $payloadLength), 8);
        $frameHead[1] = ($masked === true) ? 255 : 127;
        for ($i = 0; $i < 8; $i++){
            $frameHead[$i + 2] = bindec($payloadLengthBin[$i]);
        }
        // most significant bit MUST be 0
        if($frameHead[2] > 127){
            return array('type' => '', 'payload' => '', 'error' => 'frame too large (1004)');
        }
    } elseif($payloadLength > 125){
        $payloadLengthBin = str_split(sprintf('%016b', $payloadLength), 8);
        $frameHead[1] = ($masked === true) ? 254 : 126;
        $frameHead[2] = bindec($payloadLengthBin[0]);
        $frameHead[3] = bindec($payloadLengthBin[1]);
    } else {
        $frameHead[1] = ($masked === true) ? $payloadLength + 128 : $payloadLength;
    }

    // convert frame-head to string:
    foreach(array_keys($frameHead) as $i){
        $frameHead[$i] = chr($frameHead[$i]);
    }
    if($masked === true){ # generate a random mask:
        $mask = array();
        for ($i = 0; $i < 4; $i++) $mask[$i] = chr(rand(0, 255));
        $frameHead = array_merge($frameHead, $mask);
    }
    $frame = implode('', $frameHead);

    // append payload to frame:
    for($i = 0; $i < $payloadLength; $i++){
        $frame .= ($masked === true) ? $payload[$i] ^ $mask[$i % 4] : $payload[$i];
    }
    return $frame;
}

class RTSWS {

    public static $connects = [];
    public static $approved_connects = [];
    public static $token_id = [];
    public static $token_data;
    public static $timeout = 2;

    public static function check_user($token_hash = null){
        #self::$token_id = Token::get_token_id_from_token_hash($token_hash); #        pred(self::$token_id);
        self::$token_data = Token::get_token_data_from_hash($token_hash);
       # pred(self::$token_id);
        pred(self::$token_data );
        # User::set_user_id_default(self::$token_data['user_id']);
        # Session::set_session_id_default(Session::get_session_id(User::$user_id, Token::$token_id));
    }

    public static function get_cookies($headerCookies){
        $headerCookies = explode('; ', $headerCookies['Cookie']);

        $cookies = array();

        foreach($headerCookies as $itm) {
            list($key, $val) = explode('=', $itm, 2);
            $cookies[$key] = $val;
        } # pred($cookies); // assoc array of all cookies
        return $cookies; // assoc array of all cookies
    }

    public static function approve_connect($connect, $info){ #pre($info);

        $token_hash = self::get_cookies($info); #pred($info);
        $token_hash = $token_hash['token'];  # pred($token_hash); # self::$token_id = Token::get_token_id_from_token_hash($token_hash); pred(self::$token_id);
        self::$token_data = Token::get_token_data_from_hash($token_hash);
        $user_access_type_name_list = UserAccess::get_user_access_type_name_list(self::$token_data['user_id']);
        if(in_array('root', $user_access_type_name_list)){
            self::$approved_connects[] = $connect; #        pred($user_access_type_name_list);
            return true;
        }
        # pred(self::$token_id); pred(self::$token_data );
        # User::set_user_id_default(self::$token_data['user_id']);
        # Session::set_session_id_default(Session::get_session_id(User::$user_id, Token::$token_id));
    }

    public static function on_message($connect, $data){

        $mes = decode($data); #pred($mes);
        if(!in_array($connect, self::$connects)) return; # approved_
        consolemsg("Message:". $mes['token']);
        if(isset($mes['ref_time'])){
            $mes['ref_time'] = (int)$mes['ref_time'];
            if($mes['ref_time'] < 0) $mes['ref_time'] = 2;
            if($mes['ref_time'] > 60) $mes['ref_time'] = 2;
            self::$timeout = $mes['ref_time'];
        }
        # $data = json_encode(['rend' => '']); # $mes['token']
        # fwrite($connect, encode($data));// echo функция ответа
    }

    public static function sendd(){

        $rtsc = new RTSController();
        $rend = $rtsc->wsref(); #pred($rend);
        #$rend = rawUrlEncode($rend);
        #$rend = rtrim(strtr(base64_encode($rend), '+/', '-_'), '=');
        #$rend = base64_encode($rend);
        $data = json_encode(['rend' => $rend]);      #  $data = $rend;
        #$data =  base64_encode($rend);

        #$data = rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
        #pred($data);
        $data = encode($data); #pred( encode($data));
        foreach(self::$connects as $connect) fwrite($connect, $data);
    }

    public static function init(array $data = []){ #pred($data);    #public function __construct(array $data = []){ #pred($data);

        #pre($_SERVER);        pred(ajax);
        #pred(\Config::$saddr);
        //system config
        error_reporting(E_ALL); //Выводим все ошибки и предупреждения
        set_time_limit(0);		//Время выполнения скрипта безгранично
        ob_implicit_flush();	//Включаем вывод без буферизации
        ignore_user_abort(true);//Выключаем зависимость от пользователя
        //system config
        UserAccess::$is_root = true;
        $baseDir = dirname(__FILE__);
        $pidfile = $baseDir .'/pid_file.pid';

        //srdin/stdout
        /*ini_set('error_log', $baseDir.'/echowserrors.txt');
        fclose(STDIN);
        fclose(STDOUT);
        fclose(STDERR);
        $STDIN = fopen('/dev/null', 'r');
        $STDOUT = fopen($baseDir.'/echowsconsolelog.txt', 'ab');
        $STDERR = fopen($baseDir.'/echowsconsoleerr.txt', 'ab');
        //srdin/stdout //log-file
        $GLOBALS = $baseDir.'/echowslog.html';*/
        consolestart();
        consolemsg("echows - try to start...");
        //log-file

        //pid-file
        //Если в PID файле хранится PID процесса и он активен, то не запускаем копию
        if(isDaemonActive($pidfile)){
            consolemsg("CANCEL echows - already active");
            consoleend();
            exit();
        }
        $r = @file_put_contents($pidfile, getmypid());//СОХРАНЯЕМ PID в файле
        @chmod($pidfile, 0664);
        if(!$r) pred('Cant write pid file!');
        consolemsg("OK getmypid = ".getmypid());
        //pid-file

        $timelimit = 0; // если 0, то тогда безлимитно, только на сообщение, иначе кол-во секунд
        $starttime = round(microtime(true), 2);

        consolemsg("socket - try to start...");
        $saddr = "tcp://". \Config::$saddr .":8888"; pre($saddr);
        $socket = stream_socket_server($saddr, $errno, $errstr);

        if(!$socket){
            consolemsg("ERROR socket unavailable " .$errstr. "(" .$errno. ")");
            @unlink($pidfile);
            consolemsg("pidfile ".$pidfile." ulinked");
            consoleend();
            die($errstr. "(" .$errno. ")\n");
        }

        self::$connects = [];
        self::$approved_connects = [];

        $c = 0;

        while(true){

            $c++; echo $c ."\n"; # pre($c ."\n");
            consolemsg("socket - main while...");  //формируем массив прослушиваемых сокетов:
            $read = self::$connects;
            $read[] = $socket; #pre($read);
            $write = $except = null;

            #$st = microtime(1);
            if(!stream_select($read, $write, $except, self::$timeout)){ // ожидаем сокеты доступные для чтения (без таймаута)
                consolemsg("socket - main while1...");
               # break; # pre("444444444444\n");
            }
            #$et = microtime(1);  # pre($st);  pre($et);        #pre($dbr);

            self::sendd(); #self::$times[] = date("H:i:s", $et - $st); #pre(date("H:i:s", $et - $st));
            consolemsg("socket - main while555...");
            if(in_array($socket, $read)){ //есть новое соединение то обязательно делаем handshake //принимаем новое соединение и производим рукопожатие:
                consolemsg("socket - main while11...");
                if(($connect = stream_socket_accept($socket, -1)) && $info = handshake($connect)){
                    consolemsg("new connection... connect=".$connect.", info=". json_encode($info) ." OK");                    //var_dump($info);

                    $r = self::approve_connect($connect, $info);
                    if(!$r){                 #onClose($connect);
                        consolemsg("connection closed...");
                        fclose($connect);
                        unset(self::$connects[array_search($connect, self::$connects)]);
                        return;
                    }
                    self::$connects[] = $connect;//добавляем его в список необходимых для обработки
                    pre(self::$connects);
                    # onOpen($connect, $info);// onOpen($connect, $info){	consolemsg("open OK");  //fwrite($connect, encode('Привет, мы соеденены')); }
                }
                unset($read[array_search($socket, $read)]);
            }
            consolemsg("socket - main while2...");

            foreach($read as $connect){ pre($c ."\n"); //обрабатываем все соединения

                $data = fread($connect, 100000);

                if(!$data){ //соединение было закрыто
                    consolemsg("connection closed...");
                    fclose($connect);
                    unset(self::$connects[array_search($connect, self::$connects)]);
                    onClose($connect);//вызываем пользовательский сценарий
                    consolemsg("OK");
                    continue;
                }

                self::on_message($connect, $data);//вызываем пользовательский сценарий
/*
                $f = decode($data);
                if($f['payload']=="OFF"){ //shutdown by command
                    consolemsg("OFF command receive");
                    consolemsg("time = ".(round(microtime(true),2) - $starttime));
                    fclose($socket);
                    consolemsg("socket - closed");
                    unlink($pidfile);
                    consolemsg("pidfile ".$pidfile." ulinked");
                    consoleend();
                    exit();
                }*/
                consolemsg("socket - main while3...");
            } # pre($timelimit);
            consolemsg("socket - main while4...");
            /*if($timelimit !== 0 && (round(microtime(true), 2) - $starttime) > $timelimit){ //Если за пределами timelimit - вырубаем процесс
                consolemsg("time limit is over");
                consolemsg("time = ".(round(microtime(true),2) - $starttime));
                fclose($socket);
                consolemsg("socket - closed#1");
                unlink($pidfile);
                consolemsg("pidfile ".$pidfile." ulinked");
                consoleend();
                exit();
            }*/
        }

        //unreachble code
        fclose($socket);
        consolemsg("socket - closed#2");
        unlink($pidfile);
        consolemsg("pidfile ".$pidfile." ulinked");
        consoleend();
    }
}