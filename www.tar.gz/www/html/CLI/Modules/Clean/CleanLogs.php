<?php

namespace CLI\Modules\Clean;

use Configs\DirConfig;
use Core\Modules\Log;
use Common\Modules\Dir;
use Common\Models\XavierInfo;

class CleanLogs {  # sudo -u www-data /usr/bin/php7.2 /var/www/html/index.php action=cll is_test=1 need_log=1
    # sudo -u www-data /usr/bin/php7.2 $PWD/index.php action=cll need_log=1 hand=1

    static $inwork = false;

    public static function init(){ # statistics и setting_debug?

        self::$inwork = true;

        Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #16');
        $dp = DR .'/'. DirConfig::$dir_log; #self::clean_days('aupc', 5); # pre($r); #$r = self::clean_months('au', 2);
        $log_dirs = glob($dp .'/*', GLOB_ONLYDIR); $dir_logsbns = []; #pred(glob($dp .'/*', GLOB_ONLYDIR));

       $def_log_conf = XavierInfo::get_groupa('log'); #pred($def_log_conf);
       $def_log_conf['max_days'] = (int)$def_log_conf['max_days'];
       $def_log_conf['max_mbytes'] = (int)$def_log_conf['max_mbytes'];
       $logs_confs = XavierInfo::get_groupa('logs');

        foreach($log_dirs as $v){ #pred($v);
            $bn = basename($v);
            $objs = scandir($v);
            unset($objs[0]); unset($objs[1]);
            if(isset($logs_confs[$bn])){
                $log_conf = json_decode($logs_confs[$bn], 1);
                $log_conf['max_days'] = (int)$log_conf['max_days'];
                $log_conf['max_mbytes'] = (int)$log_conf['max_mbytes'];
            } else  $log_conf = $def_log_conf; #            pre($log_conf);
            foreach($objs as $objn){
                if(is_dir($v .'/'. $objn)) $r = Dir::remove_dirn($v .'/'. $objn);
            }
            $r = self::max_files($v, $log_conf['max_days']);
            $r = self::max_weight($v, $log_conf['max_mbytes'].'mb');
        } #$dir_lgsbnos[] = basename($dp);

        #$r = self::max_files(DR .'/'. DirConfig::$dir_log_php, 7);        $r = self::max_weight(DR .'/'. DirConfig::$dir_log_php, '1gb');        $r = self::max_files(DR .'/'. DirConfig::$dir_log_er, 7);        $r = self::max_weight(DR .'/'. DirConfig::$dir_log_er, '1gb');
        self::$inwork = false;
    }

    public static function clean_days($sdir, $max_days){ # subdir  #$dp = DR .'/'. DirConfig::$dir_log .'/'. $sdir;
        $dp = DR .'/Temp/Log/'. $sdir;
        foreach(glob($dp .'/*.log') as $filename){
            pred($filename);
        }   #pred(321);
    }

    public static function clean_months($sdir, $max_months){ #pred(func_get_args()); # subdir

        $dp = DR .'/'. DirConfig::$dir_log .'/'. $sdir;
        if(!is_dir($dp)) return;
        $objs = scandir($dp); #pre(count($objs));
        $extra_dirs_qty = count($objs) - ($max_months + 2);
        if(!$extra_dirs_qty) return; #pred($extra_dirs_qty); #if(count($objs) < $max_months + 2) return; #pre($objs);
        $c = 0;
        foreach($objs as $objn){
            if($objn === '.' || $objn === '..') continue;
            $c++;
            if($c > $extra_dirs_qty) return; #pre($dp .'/'. $objn);
            $r = Dir::remove_dirn($dp .'/'. $objn);
            if(!$r) pred($r);
        } #$dp # subdir path  #foreach(glob($dp .'/*') as $sdp){ # subdir path   #pre($sdp);    #}
    }

    public static function max_files($dp, $max_days){ #pre(func_get_args());
        $objs = scandir($dp); #pre(count($objs));
        $tsborder = time() - 3600 * 24 * $max_days;
        foreach($objs as $objn){
            if($objn === '.' || $objn === '..') continue;#pred($objn);
            $date = str_replace('.log', '', $objn);
            $dt = \DateTime::createFromFormat('Y.m.d', $date);
            if(!$dt) continue;
            $dts = $dt->getTimestamp(); #pred($dp .'/'. $objn);
            if($dts < $tsborder) $r = unlink($dp .'/'. $objn);
        }
    }

    public static function max_weight($dp, $max_weight){ # pre($max_weight); # pre($dp);

        $parsed = false;
        if(strpos($max_weight, 'gb') !== false){
            $parsed = true;
            $max_weight = (int)str_replace('gb', '', $max_weight);
            $max_weight = 1024 * 1024 * 1024 * $max_weight;
        }

        if(strpos($max_weight, 'mb') !== false){
            $parsed = true;
            $max_weight = (int)str_replace('mb', '', $max_weight);
            $max_weight = 1024 * 1024 * $max_weight;
        }
        if(!$parsed){
            $max_weight = (int)str_replace('mb', '', $max_weight);
            $max_weight = 1024 * 1024 * $max_weight;
        }
        #pred($max_weight);
        set_time_limit(600);
        ini_set('max_execution_time', '600');

        $du = Dir::du($dp); # pred($du);  #if($du < $max_weight) return;
        $c = 0;
        while($du >= $max_weight){ # while(1){ pre($max_weight); pre($du); pred($dp);
            $c++; if($c > 1000000) return; # $c++; if($c > 10) return;
            $objs = scandir($dp); #pred($objs);
            if(count($objs) === 3) return; #pre($objs);
            $objn = array_pop($objs);
            $r = unlink($dp .'/'. $objn); # pre($dp .'/'. $objn);
            $du = Dir::du($dp); #pred($du);
        }
    }
}