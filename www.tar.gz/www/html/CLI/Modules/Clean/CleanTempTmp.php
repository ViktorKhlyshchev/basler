<?php

namespace CLI\Modules\Clean;

use Configs\DirConfig;
use Core\Modules\Log;
use Core\Modules\Dir;

class CleanTempTmp {

    static $inwork = false;

    public static function init(){
        self::$inwork = true;
        Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #1515');
        $r = self::clean_temps();
        self::$inwork = false;
    }

    public static function clean_temps(){

        $cts = time() + \Config::$timezones; #pred(date('d.m.Y_H:i:s', $cts));
        $dp = DirConfig::$tmp_dir;
        $objs = scandir($dp); #pre(count($objs));
        if(count($objs) === 2) return;

        foreach($objs as $objn){
            if($objn === '.' || $objn === '..') continue;
            $ts = explode('_', $objn); #pred($dp .'/'. $objn);
            $ts = (int)array_pop($ts);
            if($cts > $ts) Dir::remove_dirn($dp .'/'. $objn); #pred($ts);
        } #pred($dirs);
    }
}