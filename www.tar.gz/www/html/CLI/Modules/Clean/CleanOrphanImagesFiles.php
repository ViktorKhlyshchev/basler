<?php

namespace CLI\Modules\Clean;

use Core\Module\Db\Db;
use Common\Modules\Date;
use Common\Models\Journal;
use Common\Models\Processing;
use Core\Modules\Dir;
use Core\Modules\Log;
use Configs\DirConfig;

class CleanOrphanImagesFiles { # private static $timezones = 0;

    static $times = [];

    public static function remove_imagefile($image){

        $dp = Date::get_date_pathwoc($image['date_create'], DirConfig::$dir_image) .'/'. $image['iid'];        #pre($dp);
        $imgdp = Dir::get_global_dirn($dp); #pre($imgdp);
        pre('REMOVING: ' . $imgdp); # pre(rmdir($imgdp));
        $rr = Dir::remove_dirn($imgdp); #pred($rr);
        if(!$rr){ Log::erlog(__CLASS__ .'::'. __FUNCTION__ .' cant removedir! #25 dp:__'. $imgdp); pre(__CLASS__ .'::'. __FUNCTION__ .' cant removedir! #25 dp:__'. $imgdp); if(hand) pred('critERRR!'); }
        return $rr;
    }

    public static function clean_by_iid($iid = null){ # $timezones #self::$timezones = $timezones;
        $removed = false;
        if(!$iid){ if(hand) pred('iid cantbe null!!'); return; }

        $tn = '_image as i';
        $sel = ['i.id as iid', 'i.date_create', 'ii.id as iiid', 'ii.file_extension', 'ji.id as jiid', 'j.id as jid']; #'ii.id',
        $where = ['1=1', 'i.id='. $iid]; # SELECT i.id, i.date_create, ii.file_extension, ji.id FROM _image as i LEFT JOIN journal_image as ji ON  ii.image_id = ji.image_id  WHERE 1=1 AND date_create<'2021-11-10 08:49:43'  ORDER BY i.id ASC LIMIT 10
        $join = ' LEFT JOIN _image_item as ii ON  ii.image_id = i.id ';
        $join .= ' LEFT JOIN journal_image as ji ON ji.image_id = i.id ';
        $join .= ' LEFT JOIN journal as j ON  j.id = ji.journal_id ';
        $where = ' WHERE '. implode(' AND ', $where). ' ';
        $order = ' ORDER BY i.id ASC'; #$order = ' ORDER BY i.id DESC'; #$limit = ' LIMIT '. $limitn .' '; #pred($limit);
        $limit = ''; #pred($limit);
        $q = 'SELECT '. implode(', ', $sel). ' FROM '. $tn . $join . $where . $order . $limit; #pre($q); #$dbr = Db::get_results($q);
        $dbr = Db::res($q); #pred($dbr); $tc = $dbr->rowCount(); if(hand){ pre('$tc rowCount:'. $tc); sleep(2); } #count($dbr); #pre($dbr[0]); pre($dbr[$c-1]); pred($с);
        if(hand) pre($q);
        while($irow = Db::fetch($dbr)){
            if(hand) pre($irow);
            $row = $irow;
            $r = self::remove_imagefile($irow); #pred($r);
            if($r) $removed = true;
            $txt = __CLASS__ .':'. __FUNCTION__ . ': #49 removing JID:'. $irow['jid'] .' created_at: '. $irow['date_create'];
            Log::clean_log($txt);
            if(hand) pre($txt); # $this->deleted_jids = [];
            $r = Journal::set_clean($irow['jid']);
            $r = Processing::set_clean($irow['jid']);
        } #pred($irow);
        #if(hand){ if($r) pre('REMOVED! JID: '. $row['jid']); }
        $row['removed'] = $removed;
        return $row;
    }

    public static function init(){ # $timezones #self::$timezones = $timezones;

        if(count(self::$times) > 10) self::$times = [];
        Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #62');
        pre(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #63');
        self::$times = [];
        $st = microtime(1); #self::boundries(); DIFF:5.660.381 00:24:31

        if(1){ #$dp = DR .'/'. DirConfig::$dir_image .'/'. $y .'/'. $m; #pred($dp);
            $idp = DR .'/'. DirConfig::$dir_image;
            foreach(glob($idp .'/*', GLOB_ONLYDIR) as $ydp){ #pred(scandir($ydp)); # year delete dir path # pred($ydp);
                foreach(glob($ydp .'/*', GLOB_ONLYDIR) as $mdp){ #pred(scandir($mdp)); # month delete dir path #$days = glob($mdp .'/*', GLOB_ONLYDIR); pred($days); #foreach(glob($mdp .'/*', GLOB_ONLYDIR) as $ddp){ #pred(scandir($ddp)); # day delete dir path pred($ddp);
                    foreach(glob($mdp .'/*', GLOB_ONLYDIR) as $ddp){ #pred(scandir($ddp)); # day delete dir path pred($ddp);
                        $explode = explode('/', $ddp); #pred($explode);
                        $dd = ($explode[count($explode) - 3]) .'.'. ($explode[count($explode) - 2]) .'.'. ($explode[count($explode) - 1]);
                        $dts = \DateTime::createFromFormat('Y.m.d', $dd);                        #pred($dts);
                        if(!$dts) continue;
                        foreach(glob($ddp .'/*', GLOB_ONLYDIR) as $idp){
                            $explode = explode('/', $idp);
                            $iid = $explode[count($explode) - 1];
                            $r = self::clean_by_iid((int)$iid);
                            if(hand) pre('$iid: '. $iid .' | imdp:__'. $idp); #  pre($r);
                            if(!$r['removed']){
                                $rr = Dir::remove_dirn($idp); #pred($rr);
                                if($rr){
                                    $txt = __CLASS__ .':'. __FUNCTION__ . ' launch #84 image_dir deleted:__'. $idp; Log::clean_log($txt);
                                    if(hand) pre($txt);
                                } else {
                                    $txt = __CLASS__ .'::'. __FUNCTION__ .' cant removedir! #87 dp:__'. $idp;
                                    Log::erlog($txt);
                                    pre($txt);
                                    if(hand) pred('critERRR!');
                                }
                            }
                        }
                        if(count(scandir($ddp)) === 2){ $r = rmdir($ddp); if(!$r){ $txt = __CLASS__ .'::'. __FUNCTION__ .' cant removedir! #92 dp:__'. $ddp; Log::erlog($txt); pre($txt); if(hand) pred('critERRR!'); } }
                    } # pred(scandir($ddp));
                    if(count(scandir($mdp)) === 2){ $r = rmdir($mdp); if(!$r){ $txt = __CLASS__ .'::'. __FUNCTION__ .' cant removedir! #92 dp:__'. $mdp; Log::erlog($txt); pre($txt); if(hand) pred('critERRR!'); } }
                }
                if(count(scandir($ydp)) === 2){ $r = rmdir($ydp); if(!$r){ $txt = __CLASS__ .'::'. __FUNCTION__ .' cant removedir! #92 dp:__'. $ydp; Log::erlog($txt); pre($txt); if(hand) pred('critERRR!'); } }
            }
        }

        $et = microtime(1); # pre($dbr); # pre($st);  pre($et);
        self::$times[] = date("H:i:s", $et - $st);
    }
}