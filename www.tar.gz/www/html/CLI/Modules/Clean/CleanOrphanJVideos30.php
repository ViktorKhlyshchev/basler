<?php

namespace CLI\Modules\Clean;

use Core\Module\Db\Db;
use Common\Modules\Date;
use Common\Models\JournalVideo;
use Core\Module\Video\Video;
use Core\Module\Video\VideoItem;
use Core\Modules\Dir; #use Configs\DirConfig;
use Core\Modules\Log;
use Configs\DirConfig;

class CleanOrphanJVideos30 { # private static $timezones = 0;

    static $day_dps = [];
    static $times = [];

    public static function remove_videofile($video){
        #$video_data = VideoPathAction::get_video_path_data($video_id, true, true, true, false); pred($video_data);
        #if(empty($video_data) || empty($video_data['video_dir'])) return;

        $dp = Date::get_date_pathwoc($video['idate'], DirConfig::$dir_video) .'/'. $video['vid'];        #pre($dp);
        $imgdp = Dir::get_global_dirn($dp); pre($imgdp);

        $gdp = dirname($imgdp); #pre($gdp);
        if(!in_array($gdp, self::$day_dps)){
            $rr = Dir::remove_dirn($gdp); pre($rr);
            if(!$rr){ $files = scandir($gdp); pre($files); }
            self::$day_dps[] = $gdp; #pre(self::$day_dps);            pred($rr);
            return $rr;
        } else return true;

        if(is_dir($imgdp)){
            if(nl) pre("->> remove video_dir: ". $imgdp ."\n");
            $r = Dir::remove_dirn($imgdp); pre($r);
            if(!$r) pred('Cant remove dir!'. $imgdp);
        }
        #$gdp = '/var/www/html/Resource/Video/2021/09/07';pre('is_dir($gdp)'. (int)is_dir($gdp));

        #if($gdp === '/var/www/html/Resource/Video/2021/09/07') return true;
        $is_dir_gdp = is_dir($gdp);
        pre('is_dir($gdp)'. (int)$is_dir_gdp);
        # $gdpr = '/var/www/html/Resource/Video/2021/09/07'; pre($gdp);echo '_______';print_r($gdp);echo '_______';  pre($gdp);  pre($gdp === $gdpr); $cmd = 'stat \''. $gdp .'\''; pre(exec($cmd, $o, $r)); pre($o); pre($r); pre(is_dir($gdp));  pre(file_exists($gdp));  pre(file_exists($gdp));
        if($is_dir_gdp){
            $files = scandir($gdp); #pre($files); pre(count($files) < 3);
            if(count($files) < 3){ $rr = Dir::remove_dirn($gdp); pre($rr); return $rr; }
        }
        return $r;
    }

    public static function init(){ # $timezones #self::$timezones = $timezones;

        Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #54');
        pre(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #55');
        $st = microtime(1); # pred(self::boundries());

        $days = 30; #$fd = Date::get_date_time_full(time() - 3600*24*$days); #pred($fd);
        $fd = Date::get_date(time() - 3600*24*$days, 'Y-m-d');

        $limitn = 500000;
        #$limitn = 10;
        $tn = 'journal_video as jv';
        $sel = ['jv.id as jvid', 'j.id as jid', 'jv.date_create as jvdate', 'v.id as vid', 'v.date_create idate', 'vi.id as viid', 'vi.file_extension']; #'vi.id',
        $where = ['1=1', 'jv.date_create<\''. $fd .'\'' #'vi.id='. $virow['id'], 'jv.id IS NULL',
        ];
        # SELECT v.id, v.date_create, vi.file_extension, jv.id FROM _video as i LEFT JOIN journal_video as jv ON  vi.video_id = jv.video_id  WHERE 1=1 AND date_create<'2021-11-10 08:49:43'  ORDER BY v.id ASC LIMIT 10
        $join = ' LEFT JOIN _video as v ON  v.id = jv.video_id ';
        $join .= ' LEFT JOIN _video_item as vi ON  vi.video_id = v.id ';
        $join .= ' LEFT JOIN journal as j ON  j.id = jv.journal_id ';
        $where = ' WHERE '. implode(' AND ', $where). ' ';
        $order = ' ORDER BY jv.id ASC';
        $limit = ' LIMIT '. $limitn .' '; #pred($limit);
        $q = 'SELECT '. implode(', ', $sel). ' FROM '. $tn . $join . $where . $order . $limit; pre($q);
        $dbr = Db::get_results($q);
        $et = microtime(1);
        self::$times[] = date("H:i:s", $et - $st);
        $c = count($dbr); #pre($c); pre($dbr);
        pre(date("H:i:s", $et - $st));
        $vis_ids = []; $jvis_ids = []; $vs_ids = [];

        $cc = 0;
        $step = 5000;
        $st = microtime(1);
        foreach($dbr as $k => $row){ #pre($row);
            $cc++;#            pre($k .'/'. $c);
           # pre('$jvid:'. $row['jvid']); # if($row['jvid']) pred('END!!!'); #continue;
            if($row['jid'] && $row['jvid']) pred('END!!!'); #continue; #continue;

            if($row['vid']) $r = self::remove_videofile($row); #pred($r);
            if($row['jvid']) $jvis_ids[] = $row['jvid'];
            if($row['vid']) $vs_ids[] = $row['vid'];
            if($row['viid']) $vis_ids[] = $row['viid'];

            if($cc === $step){
                pre($row);
                pre($k .'/'. $c);  #pre($step .' REMOVES'); # pre($jids);
                pre('$jvis_ids:'. count($jvis_ids)); pre('$vs_ids:'. count($vs_ids)); pre('$vis_ids:'. count($vis_ids));
                VideoItem::delete_bids($vis_ids);
                JournalVideo::delete_bids($jvis_ids);
                Video::delete_bids($vs_ids);
                $vis_ids = []; $jvis_ids = []; $vs_ids = [];
                $cc = 0;
            } #pred('sleep(2)');            sleep(2);
        }

        pre('$jvis_ids:'. count($jvis_ids)); pre('$vs_ids:'. count($vs_ids)); pre('$vis_ids:'. count($vis_ids));
        VideoItem::delete_bids($vis_ids);
        JournalVideo::delete_bids($jvis_ids);
        Video::delete_bids($vs_ids);

        $et = microtime(1); #pre(date("H:i:s", $et - $st));
        self::$times[] = date("H:i:s", $et - $st);
        if($dbr){ pre($c); pre($dbr[0]); pre($dbr[$c-1]); }
        pre(self::$times);
        pre('END!' . __FILE__);
    }
}