<?php

namespace CLI\Modules\Clean;

use Core\Module\Db\Db;
use Common\Modules\Date;
use Core\Modules\Dir;
use Core\Modules\Log;
use Configs\DirConfig;
use Common\Models\Journal;
use Common\Models\Processing;

class CleanResources {

    public $jid;
    public $day_dpsi = []; # day deleted paths for images
    public $day_dpsv = []; # day deleted paths for videos
    public $day_dpsp = []; # day deleted paths for packets
    public $cleaned_days = [];
    public $times = [];
    public $secs_inday = 3600*24;
    public $days = 30;
    public $single;

    public function remove_imagefile($row){
        $dp = Date::get_date_pathwoc($row['idate'], DirConfig::$dir_image) .'/'. $row['iid'];        #pre($dp);
        $imgdp = Dir::get_global_dirn($dp); #pred($imgdp);
        $r = Dir::remove_dirn($imgdp);
        if($r){ $txt = __CLASS__ .'::'. __FUNCTION__ .' | Dir removed:__'. $imgdp; Log::clean_log($txt); if(hand){ pre($txt); } }
        else
            { $db = debug_backtrace(); $er = __CLASS__ .'::'. __FUNCTION__ .' cant removedir! #29 dp:__'. $imgdp .' | db:'. json_encode($db); Log::erlog($er); if(hand){ pre($er); pre($db); pred('critERRR!'); } } # if($r){            if(hand)  $imgdp        }
        return $r;
    }

    public function remove_videofile($row){
        $dp = Date::get_date_pathwoc($row['vdate'], DirConfig::$dir_video) .'/'. $row['vid'];        #pre($dp);
        $viddp = Dir::get_global_dirn($dp);# pred($viddp);
        $r = Dir::remove_dirn($viddp);
        if($r){ if(hand){ pre('Dir removed:__'. $viddp); } } else { $txt = __CLASS__ .'::'. __FUNCTION__ .' cant removedir! #37 dp:__'. $viddp; Log::erlog($txt); if(hand){ pre($txt); pred('critERRR!'); }}
        return $r;
    }

    public function __construct($jid = null){
        $jid = (int)$jid;
        if(!$jid) return;
        $this->single = true;
        $this->clean($jid);
    }

    public function all(){

        $txt = __CLASS__ .'::'. __FUNCTION__ .' laucnhed for allcreate=1 #50'; Log::clean_log($txt); if(hand) pre($txt);
        $tn = '__processing';

        $select = ['id'];
        $where = ['1=1', 'allcreate=1', 'clean IS NULL'];
        $where_query = ' WHERE '. implode(' AND ', $where). ' ';
        $order = ' ORDER BY id ASC '; #$limit = ' LIMIT 10';
        $limit = '';

        if(hand){
            $q = 'SELECT count(id) FROM '. $tn . $where_query; #pre($q);
            $r = Db::get_result($q); #pred($r);
            $tc = $r['count'];
            pre('NEED REMOVE '. $tc .' RECORDS!!');
            if(loc){ echo 'sleep(2)'; sleep(2); };
        }

        $q = 'SELECT '. implode(', ', $select). ' FROM '. $tn . $where_query . $order . $limit; #pre($q);
        $res = Db::res($q); #pred($res); #pre(count($res)); #pred($res); pre($res); pred('NEED CLEAN '. count($res) .' RECORDS!!');        if(loc){ echo 'sleep(5)'; sleep(5); }
        $c = 0;
        #while($r = Db::fetch($res)){ pred($r); }        pred($r);
        while($r = Db::fetch($res)){ $c++; if(hand) pre('COUNT: '. $c .'/'. $tc .' REMOVED!'); $this->clean($r['id']); } # pred($r);
        $txt = __CLASS__ .'::'. __FUNCTION__ .' for allcreate=1 ended | DELETED '. $c .' RECORDS!! #72'; Log::clean_log($txt); if(hand) pre($txt);
        if(loc){ echo 'sleep(2)'; sleep(2); };
        $txt = __CLASS__ .'::'. __FUNCTION__ .' laucnhed for nocreate=1 #50'; Log::clean_log($txt); if(hand){ pre($txt); sleep(2); }

        $where = ['1=1', 'nocreate=1', 'clean IS NULL'];
        $where_query = ' WHERE '. implode(' AND ', $where). ' ';

        if(hand){
            $q = 'SELECT count(id) FROM '. $tn . $where_query; #pre($q);
            $r = Db::get_result($q); #pred($r);
            $tc = $r['count'];
            pre('NEED REMOVE '. $tc .' RECORDS!!');
            if(loc){ echo 'sleep(2)'; sleep(2); };
        }

        $q = 'SELECT '. implode(', ', $select). ' FROM '. $tn . $where_query . $order . $limit; #pre($q);
        $res = Db::res($q); #pred($res); #pre(count($res));
        $c = 0;
        while($r = Db::fetch($res)){ $c++; $this->clean($r['id']); if(hand) pre('COUNT: '. $c .'/'. $tc .' REMOVED!'); }
        $txt = __CLASS__ .'::'. __FUNCTION__ .' for nocreate=1 ended | DELETED '. $c .' RECORDS!! #72'; Log::clean_log($txt); if(hand){ pre($txt); sleep(2); }
        if(loc){ echo 'sleep(2)'; sleep(2); };
    }

    public function clean($jid = null){ # $timezones #$this->timezones = $timezones;

        if(!$jid) return;
        $this->times[] = [];

        $single = '';
        if($this->single) $single = ' for single';

        $st = microtime(1);  #$limitn = 500000;  #$limitn = 10;
        $tn = 'journal as j';
        $sel = ['j.id as jid', 'j.date_create as jdate', 'ji.id as jiid', 'i.id as iid', 'i.date_create as idate', 'ii.id as iiid', 'ii.file_extension',
            'jv.id as jvid', 'v.id as vid', 'v.date_create as vdate', 'vii.id as viid']; #'ii.id',
        $where = ['1=1', 'j.id=\''. $jid .'\'']; #'ii.id='. $iirow['id'], 'ji.id IS NULL', # SELECT i.id, i.date_create, ii.file_extension, ji.id FROM _image as i LEFT JOIN journal_image as ji ON  ii.image_id = ji.image_id  WHERE 1=1 AND date_create<'2021-11-10 08:49:43'  ORDER BY i.id ASC LIMIT 10
        $join = ' LEFT JOIN journal_image as ji ON  j.id = ji.journal_id ';
        $join .= ' LEFT JOIN _image as i ON  ji.image_id = i.id ';
        $join .= ' LEFT JOIN _image_item as ii ON  ii.image_id = i.id ';
        $join .= ' LEFT JOIN journal_video as jv ON jv.journal_id = j.id ';
        $join .= ' LEFT JOIN _video as v ON v.id = jv.video_id ';
        $join .= ' LEFT JOIN _video_item as vii ON vii.video_id = v.id ';
        $where = ' WHERE '. implode(' AND ', $where). ' ';
        $order = ' ORDER BY j.id ASC'; #$limit = ' LIMIT '. $limitn .' '; #pred($limit);
        $q = 'SELECT '. implode(', ', $sel). ' FROM '. $tn . $join . $where . $order; #pre($q); #  . $limit
        $dbr = Db::get_results($q);  #pre(count($dbr));
        if(!$dbr){ pre('ZERO RESULTS!'); return; }
        $c = count($dbr); #pre($c); pre($dbr[0]); pre($dbr[$c-1]); #if(loc){ echo 'sleep(1)'; sleep(1); }
        $et = microtime(1);  # pre($st);  pre($et);        #pre($dbr);
        $this->times[] = date("H:i:s", $et - $st); #00:15:42
        $st = microtime(1); #  pred($dbr);
        $txt = __CLASS__ .':'. __FUNCTION__ . $single . ' launch #123 JID:'. $jid .' created_at: '. $dbr[0]['jdate']; Log::clean_log($txt); if(hand) pre($txt); # $this->deleted_jids = [];

        $cc = 0; #pred($dbr);

        foreach($dbr as $row){ #pred($row);
            $cc++; #pre('REMOVING JID:'. $jid .' | counter:'. $cc);
            if($row['idate']) $this->remove_imagefile($row);
            if($row['vdate']) $this->remove_videofile($row);
        }

        $r = Journal::set_clean($jid);
        $r = Processing::set_clean($jid);

        /*$et = microtime(1); #pre(date("H:i:s", $et - $st));
        pre($c); pre($dbr[0]); pre($dbr[$c-1]);
        $this->times[] = date("H:i:s", $et - $st);
        pre($this->times);
        pre('END!' . __FILE__);*/

        #if(loc){ echo 'sleep(1)'; sleep(1); }
    }
}