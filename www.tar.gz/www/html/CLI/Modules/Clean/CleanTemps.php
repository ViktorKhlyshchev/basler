<?php

namespace CLI\Modules\Clean;

use Configs\DirConfig;
use Core\Modules\Log;
use Core\Modules\Dir;

class CleanTemps { // sudo -u www-data /usr/bin/php /var/www/html/index.php "action=remove_journal_list" "is_test=1" >> /dev/null 2>&1 & echo $

    static $inwork = false;
    static $inwork_check = 0;

    public static function init(){ # statistics и setting_debug?

        /*if(self::$inwork){
            self::$inwork_check++;
            if(self::$inwork_check > 10){
                self::$inwork_check = 0;
                self::$inwork = false;
            }
            return;
        }*/
        self::$inwork = true;
        Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #15');
        $r = self::clean_temps();
        self::$inwork = false;
    }

    public static function clean_temps(){

        $dp = DR .'/'. DirConfig::$dir_cafap_package_temp; # $dirs = array_filter(glob($dp .'/*'), 'is_dir');
        foreach(glob($dp .'/*', GLOB_ONLYDIR) as $dirp){ # foreach(glob($dp .'/*.log', GLOB_ONLYDIR)
            $fct = filectime($dirp); #1640032130-1640031977
            $t = time();
            $diff = $t - $fct; #pre($diff);
            if($diff > 300) Dir::remove_dirn($dirp); # pred($fct);
        } #pred($dirs);
    }
}