<?php

namespace CLI\Modules\Clean;

use Core\Module\Db\Db;
use Common\Modules\Date;
use Common\Models\JournalImage;
use Common\Models\Image\Image;
use Common\Models\Image\ImageItem;
use Core\Modules\Dir;
use Core\Modules\Log;
use Configs\DirConfig;

class CleanOrphanImages { # private static $timezones = 0;

    static $times = [];

    public static function remove_imagefile($image){

        $dp = Date::get_date_pathwoc($image['date_create'], DirConfig::$dir_image) .'/'. $image['iid'];        #pre($dp);
        $imgdp = Dir::get_global_dirn($dp); #pre($imgdp);
        pre('REMOVING:' . $imgdp); # pre(rmdir($imgdp));
        $rr = Dir::remove_dirn($imgdp); #pred($rr);
        if(!$rr){ Log::erlog(__CLASS__ .'::'. __FUNCTION__ .' cant removedir! #25 dp:__'. $imgdp); pre(__CLASS__ .'::'. __FUNCTION__ .' cant removedir! #25 dp:__'. $imgdp); if(hand) pred('critERRR!'); }
        return $rr;
    }

    public static function init(){ # $timezones #self::$timezones = $timezones;

        if(count(self::$times) > 10) self::$times = [];
        Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #87');
        pre(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #88');
        $st = microtime(1); #self::boundries(); DIFF:5.660.381 00:24:31
        $et = microtime(1); # pre($dbr); # pre($st);  pre($et);
        self::$times[] = date("H:i:s", $et - $st); # 1 00:15:42

        $limitn = 100000;
        $st = microtime(1); # pred(self::boundries());  #$limitn = 500000; #$limitn = 100000; #$limitn = 1005; #$limitn = 15;
        $tn = '_image as i';
        $sel = ['i.id as iid', 'i.date_create', 'ii.id as iiid', 'ii.file_extension', 'ji.id as jiid', 'j.id as jid']; #'ii.id',
        $where = ['1=1'];
        # SELECT i.id, i.date_create, ii.file_extension, ji.id FROM _image as i LEFT JOIN journal_image as ji ON  ii.image_id = ji.image_id  WHERE 1=1 AND date_create<'2021-11-10 08:49:43'  ORDER BY i.id ASC LIMIT 10
        $join = ' LEFT JOIN _image_item as ii ON  ii.image_id = i.id ';
        $join .= ' LEFT JOIN journal_image as ji ON ji.image_id = i.id ';
        $join .= ' LEFT JOIN journal as j ON  j.id = ji.journal_id ';
        $where = ' WHERE '. implode(' AND ', $where). ' ';
        $order = ' ORDER BY i.id ASC'; #$order = ' ORDER BY i.id DESC';
        $limit = ' LIMIT '. $limitn .' '; #pred($limit); $limit = ''; #pred($limit);
        $q = 'SELECT '. implode(', ', $sel). ' FROM '. $tn . $join . $where . $order . $limit;
        if(hand) pre($q);
        #$dbr = Db::get_results($q);
        $dbr = Db::res($q); #pred($dbr->rowCount());

        /*$res = Db::res($q); #pred($res); #pre(count($res));
        $c = 0;
        while($r = Db::fetch($res)){ $c++; if(hand) pre('COUNT: '. $c .'/'. $tc .' REMOVED!'); $this->clean($r['id']); }*/

        $tc = $dbr->rowCount(); #if(!$tc) self::$repeat = false;
        if(hand){ pre('$tc rowCount:'. $tc); sleep(2); } #count($dbr); #pre($dbr[0]); pre($dbr[$c-1]); pred($с);
        $et = microtime(1); # pre($dbr); # pre($st);  pre($et);
        self::$times[] = date("H:i:s", $et - $st);

        $st = microtime(1);
        $iis_ids = []; $jiis_ids = []; $is_ids = [];
        $cc = 0;
        $k = 0;
        $rc = 0;
        $step = 10000;  #foreach($dbr as $k => $irow){ #pred($irow);
        while($irow = Db::fetch($dbr)){ #pred($irow);
            $cc++; $k++; #pre($k .'/'. $c); # $iid = $irow['iid']; #pre($jid);$jvideos_ids = JournalVideo::get_all_videos_ids($jid); pred($jvideos_ids); #pre('$iid:'. $iid); # if($irow['jiid']) pred('END!!!');
            if($irow['jid'] && $irow['jiid']) continue; #pred($irow);

            #Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' remove files for IID:'. $irow['iid'] .' IIID:'. $irow['iiid'] .' #69');

            $r = self::remove_imagefile($irow); #pred($r);
            $rc++; pre($rc); #usleep(10000); pre($cc);
            if($irow['iiid']) $iis_ids[] = $irow['iiid'];
            if($irow['jiid']) $jiis_ids[] = $irow['jiid'];
            if($irow['iid']) $is_ids[] = $irow['iid'];
            if($rc === $step){
                if(hand){ pre($k .'/'. $tc); pre($irow); pre($step .' REMOVES'); pre('Removing: jiis_ids: '. count($jiis_ids) . ' | is_ids:'. count($is_ids) . ' | iis_ids:'. count($iis_ids)); }
                ImageItem::delete_bids($iis_ids);
                JournalImage::delete_bids($jiis_ids);
                Image::delete_bids($is_ids);
                $iis_ids = []; $jiis_ids = []; $is_ids = [];
                $rc = 0; if(hand) sleep(1);
            }
        }
        if(hand){ pre($k .'/'. $tc); pre($irow); }
        ImageItem::delete_bids($iis_ids);
        JournalImage::delete_bids($jiis_ids);
        Image::delete_bids($is_ids);
        if(hand){ pre($irow); pre($k); pre('REMOVED: '. $rc); }
        $et = microtime(1);
        self::$times[] = date("H:i:s", $et - $st); # 1 3h
        if(hand){ pre(self::$times); pre(__CLASS__ .'::'. __FUNCTION__ .' ENDed '); } # if(self::$repeat) self::init();
        if($rc) self::init();
    }
}