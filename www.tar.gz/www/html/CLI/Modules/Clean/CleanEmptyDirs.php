<?php

namespace CLI\Modules\Clean;

use Common\Modules\Date;
use Core\Modules\Log;
use Configs\DirConfig;

class CleanEmptyDirs { # sudo -u www-data /usr/bin/php7.2 -f "$PWD/index.php" action=cd30 need_log=1 is_test=1 #sudo -u www-data /usr/bin/php /var/www/html/index.php action=cd30 is_test=1 need_log=1

    public static $deleted_jids;
    public static $jid;
    static $day_dpsi = []; # day deleted paths for images
    static $deleted_paths = []; # deleted paths
    static $times = [];
    static $secs_inday = 3600*24;
    static $days = 1;
    static $fd;

    public static function init(){ # $timezones #self::$timezones = $timezones;

        self::$deleted_paths = [];

        Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #25');
        if(hand) pre(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #26');#$curm = Date::get_date(time(), 'm');

        if(1){ #$dp = DR .'/'. DirConfig::$dir_image .'/'. $y .'/'. $m; #pred($dp);
            $idp = DR .'/'. DirConfig::$dir_image;
            foreach(glob($idp .'/*', GLOB_ONLYDIR) as $ydp){ # year delete dir path # pred($ydp);
                foreach(glob($ydp .'/*', GLOB_ONLYDIR) as $mdp){ # month delete dir path
                    foreach(glob($mdp .'/*', GLOB_ONLYDIR) as $ddp){ # day delete dir path pred($ddp); if(hand) pre(scandir($mdp));
                        if(count(scandir($ddp)) === 2){
                            $r = rmdir($ddp);
                            if(!$r){ if(hand) pred('Er: cant delet dir! dp:__'. $ddp); else Log::erlog(__CLASS__ .'::'. __FUNCTION__ .' | Er: cant delet dir! dp:__'. $ddp); }
                        }
                    }
                    if(hand) pre(scandir($mdp));
                    if(count(scandir($mdp)) === 2){
                        $r = rmdir($mdp);
                        if(!$r){ if(hand) pred('Er: cant delet dir! dp:__'. $mdp); else Log::erlog(__CLASS__ .'::'. __FUNCTION__ .' | Er: cant delet dir! dp:__'. $mdp); }
                    }
                }
                if(hand) pre(scandir($ydp));
                if(count(scandir($ydp)) === 2){
                    $r = rmdir($ydp);
                    if(!$r){ if(hand) pred('Er: cant delet dir! dp:__'. $ydp); else Log::erlog(__CLASS__ .'::'. __FUNCTION__ .' | Er: cant delet dir! dp:__'. $ydp); }
                }
            }
        }

        if(1){
            $vdp = DR .'/'. DirConfig::$dir_video;
            foreach(glob($vdp .'/*', GLOB_ONLYDIR) as $ydp){ # year delete dir path # pred($ydp);
                foreach(glob($ydp .'/*', GLOB_ONLYDIR) as $mdp){ # month delete dir path
                    foreach(glob($mdp .'/*', GLOB_ONLYDIR) as $ddp){ # day delete dir path pred($ddp); if(hand) pre(scandir($mdp));
                        if(count(scandir($ddp)) === 2){
                            $r = rmdir($ddp);
                            if(!$r){ if(hand) pred('Er: cant delet dir! dp:__'. $ddp); else Log::erlog(__CLASS__ .'::'. __FUNCTION__ .' | Er: cant delet dir! dp:__'. $ddp); }
                        }
                    }
                    if(count(scandir($mdp)) === 2){
                        $r = rmdir($mdp);
                        if(!$r) pred('Er: cant delete dir! dp:__'. $mdp);
                    }
                }
                if(count(scandir($ydp)) === 2){
                    $r = rmdir($ydp);
                    if(!$r) pred('Er: cant delete dir! dp:__'. $ydp);
                }
            }
        }

        foreach(self::$deleted_paths as $k => $v) Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' deleted path: '. $v .' for time: '. $k);
        if(hand){ pre(self::$deleted_paths); pre(__CLASS__ .'::'. __FUNCTION__ .' ENDed '); } #        pre(self::$times);
    }
}