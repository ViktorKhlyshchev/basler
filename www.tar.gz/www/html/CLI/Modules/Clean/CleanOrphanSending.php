<?php

namespace CLI\Modules\Clean;

use Core\Module\Db\Db;
use Core\Modules\Log;
use Common\Models\Sending;

class CleanOrphanSending { # private static $timezones = 0;

    static $times = [];

    public static function init(){ # $timezones #self::$timezones = $timezones;

        $repeat = true;
        if(count(self::$times) > 10) self::$times = [];
        Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #162222');
        pre(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #1722222');
        $st = microtime(1); # pred(self::boundries());

        $limitn = 100000; # $limitn = 100000; #$limitn = 1005; #$limitn = 15;
        $tn = '__sending as s';
        $sel = ['s.id as sid', 's.jid as sjid', 's.created_at',  'j.id as jid'];
        $join = ' LEFT JOIN journal as j ON  j.id = s.jid ';
        $order = ' ORDER BY s.id ASC'; #$order = ' ORDER BY i.id DESC';
        $limit = ' LIMIT '. $limitn .' '; #pred($limit);
        $q = 'SELECT '. implode(', ', $sel). ' FROM '. $tn . $join . $order . $limit; pre($q);
        $dbr = Db::get_results($q); #pred($dbr);
        $c = count($dbr); #pre($dbr[0]); pre($dbr[$c-1]); pre($c);
        $et = microtime(1); # pre($dbr); # pre($st);  pre($et);
        self::$times[] = date("H:i:s", $et - $st); # 1 00:13:59

        $st = microtime(1);
        $s_ids = [];
        $cc = 0;
        $step = 10000;
        foreach($dbr as $k => $row){ #pre($row);
            $cc++;
            if($row['jid']){ pre('END!!!'); $repeat = false; break; } #continue;
            $s_ids[] = $row['sid'];
            if($cc === $step){
                if(hand){ pre($k .'/'. $c); pre($row); pre('REMOVING '. $step); } #pre(count($s_ids));
                Sending::delete_bids($s_ids);
                $s_ids = [];
                $cc = 0; # sleep(10);
            }
        }
        if(hand){ pre('REMOVING '. $cc);
        if($dbr){ pre($k .'/'. $c); pre($row); }}
        Sending::delete_bids($s_ids);
        if(hand){ if($dbr){ pre($dbr[0]); pre($dbr[$c-1]); } pre($c); }
        $et = microtime(1);
        self::$times[] = date("H:i:s", $et - $st); # 1 3h
        pre(self::$times);
        pre('END!' . __FILE__);
        if($repeat) self::init();
    }
}