<?php

namespace CLI\Modules\Clean;

use Core\Module\Db\Db;
use Common\Modules\Date;
use Common\Models\Image\Image;
use Common\Models\Image\ImageItem;
use Core\Module\Video\Video;
use Core\Module\Video\VideoItem;
use Common\Models\JournalImage;
use Common\Models\JournalVideo;
use Common\Models\Journal;
use Core\Modules\Dir;
use Core\Modules\Log;
use Configs\DirConfig;
use Common\Models\Packing;
use Common\Models\Processing;
use Common\Models\Sending;

class CleanTables { # private static $timezones = 0;

    public static $deleted_jids;
    public static $jid;
    static $day_dpsi = []; # day deleted paths for images
    static $day_dpsv = []; # day deleted paths for videos
    static $day_dpsp = []; # day deleted paths for packets
    static $cleaned_days = [];
    static $times = [];
    static $secs_inday = 3600*24;
    static $days = 30;
    static $fd;

    private static $onegb = 1073741824; # 1 Gigabytes = 1073741824 Bytes # 1024*1024*1024 private static $need_free_space = 139586437120; private static $need_free_spacer = 1073741824; # 1 Gigabytes = 1073741824 Bytes private static $need_free_space = 139586437120;
    private static $need_free_space = 1073741824 * 2; # 1 Gigabytes = 1073741824 Bytes private static $need_free_space = 139586437120; private static $remove_journal_count = 100; #private static $timeout = 60; private static $disk_total; private static $disk_usage;
    private static $disk_free; #    private static $ext_total;    private static $ext_usage;
    private static $drive_path;
    static $inwork = false;

    public static function init(){
        CleanTables::$inwork = true;
        while(self::need_remove()) self::clean();
        CleanTables::$inwork = false; #pred(321);
    }


    public static function remove_imagefile($row){

        $dp = Date::get_date_pathwoc($row['idate'], DirConfig::$dir_image) .'/'. $row['iid'];        #pre($dp);
        $imgdp = Dir::get_global_dirn($dp); #pre($imgdp);

        $gdp = dirname($imgdp); #pre($gdp);
        if(!in_array($gdp, self::$day_dpsi)){ #pre($imgdp);
            $rr = Dir::remove_dirn($gdp); # pre($rr);
            if($rr){ $txt = __CLASS__ .'::'. __FUNCTION__ .' | Dir removed:__'. $gdp; Log::clean_log($txt); if(hand){ pre($txt); } } else { $txt = __CLASS__ .'::'. __FUNCTION__ .' cant removedir! #55 dp:__'. $gdp; Log::erlog($txt); if(hand){ pre($txt); pred('critERRR!'); }} #if(!$rr){ $files = scandir($gdp); pre($files); }
            self::$day_dpsi[] = $gdp; pre(self::$day_dpsi); pre($rr);
            return $rr;
        } else return true;
    }

    public static function remove_videofile($row){

        $dp = Date::get_date_pathwoc($row['vdate'], DirConfig::$dir_video) .'/'. $row['vid'];        #pre($dp);
        $viddp = Dir::get_global_dirn($dp); #pre($viddp);

        $gdp = dirname($viddp); #pre($gdp);
        if(!in_array($gdp, self::$day_dpsv)){ #pre($dp);
            $rr = Dir::remove_dirn($gdp); #pre($rr);
            if($rr){ $txt = __CLASS__ .'::'. __FUNCTION__ .' | Dir removed:__'. $gdp; Log::clean_log($txt); if(hand){ pre($txt); } } else { $txt = __CLASS__ .'::'. __FUNCTION__ .' cant removedir! #69 dp:__'. $gdp; Log::erlog($txt); if(hand){ pre($txt); pred('critERRR!'); }} #            if(!$rr){ $files = scandir($gdp); pre($files); }
            self::$day_dpsv[] = $gdp; pre(self::$day_dpsv); pre($rr);
            return $rr;
        } else return true;
    }

    public static function remove_packet($row){

        $r = @unlink($row['pfp']); #pre($r); pred($row['pfp']);
        $gdp = dirname($row['pfp']); #pre($gdp);
        if($gdp === DR .'/'. DirConfig::$dir_cafap_package_tar) return; #  '/var/www/html/Resource/CafapPackage/tar'
        if(!in_array($gdp, self::$day_dpsp)){ pre($row['pfp']);
            $rr = Dir::remove_dirn($gdp); pre($rr);
            if(!$rr){ $files = scandir($gdp); pre($files); }
            self::$day_dpsp[] = $gdp; pre(self::$day_dpsp); pre($rr);
            return $rr;
        } else return true;
    }

    public static function need_remove(){
        if(loc) $cmd = 'df ' .__DIR__ .' | awk \'NR>1\''; else $cmd = 'df /var/www/html/Resource | awk \'NR>1\''; #pre($cmd);# df $PWD | awk 'NR>1{print $4}'
        $df = shell_exec($cmd);
        $df = preg_replace('/ {2,}/', ' ', $df);#$df = str_replace('  ', ' ', $df); #pre(File::hrfs($data['ext_usage']));
        $df = explode(' ', $df); # pred($df);
        self::$disk_free = (int)$df[3] * 1024;

        if(nl){ #echo"--->>>\n"; #$du = number_format(self::$disk_usage / self::$onegb, 2, '.', '');
            $df = number_format(self::$disk_free / self::$onegb, 2, '.', '');
            $nfs = number_format(self::$need_free_space / self::$onegb, 2, '.', ''); #$dt = number_format(self::$disk_total / self::$onegb, 2, '.', '');
            $du = ''; $dt = ''; #echo crc32(mt_rand(0, time()));echo"--->>>\n";
            echo date("Y.m.d H:i:s");
            echo " --->>>\n";
            echo "drive path: ".self::$drive_path ." disk need freespace: ". $nfs ."Gb\n";
            echo "disk total: ". $dt ." disk usage: ". $du ." disk free: ". $df ."Gb\n";
            echo "--->>>\n";
            $whoami = exec('whoami');
            if(exec('whoami') !== 'www-data'){
                echo "--->>>\n"; echo '$whoami:'. $whoami."\n"; echo"--->>>\n";
                pred('Launch from www-data!! FE: sudo -u www-data /usr/bin/php7.2 -f /var/www/html/index.php action=cleaning is_test=1 need_log=1 need_dlog=1');
            }
        }
        return self::$disk_free < self::$need_free_space;
    }

    public static function clean(){ # $timezones #self::$timezones = $timezones;

        Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' laucnhed #115');

        self::$times[] = []; /*
        $et = microtime(1);  # pre($st);  pre($et);        #pre($dbr);
        if(!loc) $r = self::remove_records_from_table_greater_nds('statistics', 5); #        pre($r);
        if(!loc) $r = self::remove_records_from_table_greater_nds('setting_debug', 5); #        pre($r);
        $st = microtime(1); self::$times[] = date("H:i:s", $et - $st); pred(self::$times);*/

        $tn = 'journal'; # $where = ['date_create' => ['column' => 'date_create', 'method' => '<', 'value' => self::$fd]];
        $q = ['select' => ['id', 'date_create'], 'table' => $tn, 'order' => [['column' => 'id', 'direction' => 'asc']],'limit' => 1];
        $dbr = Db::select($q); $dbr[0]['date_create'] = explode(' ', $dbr[0]['date_create'])[0];
        $date = \DateTime::createFromFormat('Y-m-d', $dbr[0]['date_create']);
        $date->modify('+1 day');
        self::$fd = $date->format('Y-m-d');
        if(hand){ pre(self::$fd); echo 'sleep(1)'; sleep(1); pre('CleanTables laucnhed!'); }

        $st = microtime(1);  #$limitn = 500000;  #$limitn = 10;
        $tn = 'journal as j';
        $sel = ['j.id as jid', 'j.date_create as jdate', 'ji.id as jiid', 'i.id as iid', 'i.date_create as idate', 'ii.id as iiid', 'ii.file_extension',
            'jv.id as jvid', 'v.id as vid', 'v.date_create as vdate', 'vii.id as viid', 'pr.id as prid', 'p.id as pid', 'p.file_path as pfp', 's.id as sid']; #'ii.id',
        $where = ['1=1', 'j.date_create<\''. self::$fd .'\'']; #'ii.id='. $iirow['id'], 'ji.id IS NULL',
        # SELECT i.id, i.date_create, ii.file_extension, ji.id FROM _image as i LEFT JOIN journal_image as ji ON  ii.image_id = ji.image_id  WHERE 1=1 AND date_create<'2021-11-10 08:49:43'  ORDER BY i.id ASC LIMIT 10
        $join = ' LEFT JOIN journal_image as ji ON  j.id = ji.journal_id ';
        $join .= ' LEFT JOIN _image as i ON  ji.image_id = i.id ';
        $join .= ' LEFT JOIN _image_item as ii ON  ii.image_id = i.id ';
        $join .= ' LEFT JOIN journal_video as jv ON jv.journal_id = j.id ';
        $join .= ' LEFT JOIN _video as v ON v.id = jv.video_id ';
        $join .= ' LEFT JOIN _video_item as vii ON vii.video_id = v.id ';
        $join .= ' LEFT JOIN __processing as pr ON pr.id = j.id ';
        $join .= ' LEFT JOIN __packing as p ON p.jid = j.id ';
        $join .= ' LEFT JOIN __sending as s ON s.jid = j.id ';
        $where = ' WHERE '. implode(' AND ', $where). ' ';
        $order = ' ORDER BY j.id ASC'; #$limit = ' LIMIT '. $limitn .' '; #pred($limit);
        $q = 'SELECT '. implode(', ', $sel). ' FROM '. $tn . $join . $where . $order; pre($q); #  . $limit
        $dbr = Db::get_results($q);  #pre(count($dbr));
        if(!$dbr){ pre('ZERO RESULTS!'); return; }
        $c = count($dbr); pre($c); pre($dbr[0]); pre($dbr[$c-1]);
        if(hand){ echo 'sleep(1)'; sleep(1); }
        $et = microtime(1);  # pre($st);  pre($et);        #pre($dbr);
        self::$times[] = date("H:i:s", $et - $st); #00:15:42
        $st = microtime(1);

        $cc = 0;
        $step = 5000; #$step = 4;
        $jids = [];
        $iis_ids = []; $jiis_ids = []; $is_ids = [];
        $vis_ids = []; $jvis_ids = []; $vs_ids = [];
        $pr_ids = []; $p_ids = []; $s_ids = [];

        foreach($dbr as $k => $row){ #pred($row);
            $cc++;
            #pre($k .'/'. $c);
            /*$traffic_violation_ts = Date::get_ts_from_date_time_ms($jrow['date_traffic_violation']);
            $timestamp = (int)$traffic_violation_ts + self::$timezones; #pred($this->timestamp);
            $traffic_violation_date = \DateTime::createFromFormat('U', $timestamp);
            $ymdp = Date::get_ymd_path($traffic_violation_date);
            $tar_dp = DR .'/'. DirConfig::$dir_cafap_package_tar .'/'. $ymdp;
            if(is_dir($tar_dp)){
                if(nl) pre("->> remove tar: ". $tar_dp ."\n");
                Dir::remove_dirn($tar_dp);
            } else pre($tar_dp);*/            #if(\Config::$servername === 'aist6' || \Config::$servername === 'aist1'){


            /* if(\Config::$servername === 'aist1') $minjd = 913321;
            if(\Config::$servername === 'aist6') $minjd = 358330;
            if(\Config::$servername === 'aist8') $minjd = 474762;
            if((int)$row['jid'] > $minjd){
                $tn = '__sending';
                $where = ['id' => $row['jid']];
                $q = ['table' => $tn, 'where' => $where]; # pred($q); #, 'limit' => 1
                $r = Db::delete($q); #pre($r);

                $tn = '__packing';
                $q = ['select' => ['file_path'], 'table' => $tn, 'where' => $where];
                $dbrp = Db::select($q);

                foreach($dbrp as $roww){ $r = @unlink($roww['file_path']); pre($r);} # $fp = '/mnt/data/0git/aist/Resource/CafapPackage/tar/9aa31694ef52905b7510821d7e077a135261e9a2.tar';
                #$row['file_path'] = $fp;
                if(isset($roww['file_path'])){
                    $gdp = dirname($roww['file_path']); # global dir path
                    pre($gdp);
                    if($gdp !== '/var/www/html/Resource/CafapPackage/tar'){
                        $files = scandir($gdp); #pre($files);pre($gdp);                pre($files);
                        #if(count($files < 3)){ pred(33); $r = Dir::remove_dirn($gdp); pre($r); }
                        if(count($files) < 3){ $r = Dir::remove_dirn($gdp); pre($r); } #                pred($files);
                    }
                }
                $q = ['table' => $tn, 'where' => $where]; # pred($q); #, 'limit' => 1
                $r = Db::delete($q); #pre($r);
            }*/

            Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' deleting '. $row['jid']); # Log::clean_log('CleanTables self::remove_packet'. $row['jid']);

            if($row['idate']) self::remove_imagefile($row);
            if($row['vdate']) self::remove_videofile($row); #pre($v);
            if($row['pfp']) self::remove_packet($row); #pre($v);

            $jids[] = $row['jid'];
            if($row['iiid']) $iis_ids[] = $row['iiid'];
            if($row['jiid']) $jiis_ids[] = $row['jiid'];
            if($row['iid']) $is_ids[] = $row['iid'];

            if($row['viid']) $vis_ids[] = $row['viid'];
            if($row['jvid']) $jvis_ids[] = $row['jvid'];
            if($row['vid']) $vs_ids[] = $row['vid'];
            if($row['vid']) $vs_ids[] = $row['vid'];
            if($row['prid']) $pr_ids[] = $row['prid'];
            if($row['pid']) $p_ids[] = $row['pid'];
            if($row['sid']) $s_ids[] = $row['sid'];

            if($cc === $step){
                pre($row);
                pre($k .'/'. $c);
                pre('REMOVING '. $step); # pre($jids);
                pre('$jids:'. count($jids)); pre('$jiis_ids:'. count($jiis_ids)); pre('$is_ids:'. count($is_ids)); pre('$iis_ids:'. count($iis_ids));
                pre('$jvis_ids:'. count($jvis_ids)); pre('$vs_ids:'. count($vs_ids)); pre('$vis_ids:'. count($vis_ids));
                pre('$s_ids:'. count($s_ids)); pre('$p_ids:'. count($p_ids)); pre('$pr_ids:'. count($pr_ids));

                Sending::delete_bids($s_ids);
                Packing::delete_bids($p_ids);
                Processing::delete_bids($pr_ids);
                ImageItem::delete_bids($iis_ids);
                JournalImage::delete_bids($jiis_ids);
                Image::delete_bids($is_ids);
                VideoItem::delete_bids($vis_ids);
                JournalVideo::delete_bids($jvis_ids);
                Video::delete_bids($vs_ids);
                Journal::delete_bids($jids);

                $jids = [];
                $iis_ids = []; $jiis_ids = []; $is_ids = [];
                $vis_ids = []; $jvis_ids = []; $vs_ids = [];
                $pr_ids = []; $p_ids = []; $s_ids = [];
                $cc = 0;                #echo 'sleep(2)'; sleep(2);
            }
            #if(!in_array($jid, self::$deleted_jids)){ $r = Journal::delete_bid($jid); #pred($r);  $deleted_jids[] = $jid;  }
            #pre('sleep(2)'); sleep(2);
        }

        pre('REMOVING '. $cc);
        pre(count($jids)); pre(count($jiis_ids)); pre(count($is_ids)); pre(count($iis_ids));
        pre(count($jvis_ids)); pre(count($vs_ids)); pre(count($vis_ids));
        pre(count($pr_ids)); pre(count($p_ids)); pre(count($s_ids));

        Sending::delete_bids($s_ids);
        Packing::delete_bids($p_ids);
        Processing::delete_bids($pr_ids);
        ImageItem::delete_bids($iis_ids);
        Image::delete_bids($is_ids);
        JournalImage::delete_bids($jiis_ids);
        VideoItem::delete_bids($iis_ids);
        Video::delete_bids($is_ids);
        JournalVideo::delete_bids($jiis_ids);
        Journal::delete_bids($jids);

        Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' ended #270');

        if(hand){
            $et = microtime(1); #pre(date("H:i:s", $et - $st));
            pre($c); pre($dbr[0]); pre($dbr[$c-1]);
            self::$times[] = date("H:i:s", $et - $st);
            pre(self::$times);
            pre('END!' . __FILE__);
            echo 'sleep(1)'; sleep(1);
        }
    }
}