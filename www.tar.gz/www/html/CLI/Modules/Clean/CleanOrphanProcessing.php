<?php

namespace CLI\Modules\Clean;

use Core\Module\Db\Db;
use Core\Modules\Log;
use Common\Models\Processing;

class CleanOrphanProcessing { # private static $timezones = 0; sudo -u www-data /usr/bin/php7.2 $PWD/index.php action=copr need_log=1

    static $times = [];

    public static function init(){ # $timezones #self::$timezones = $timezones;

        Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #151515');
        pre(__CLASS__ .'::'. __FUNCTION__ .' laucnhed #161616');
        $st = microtime(1);
        #self::boundries(); DIFF:5.660.381 00:24:31
        $et = microtime(1); # pre($dbr); # pre($st);  pre($et);
        self::$times[] = date("H:i:s", $et - $st); # 1 00:15:42

        $st = microtime(1); # pred(self::boundries());

        $limitn = 500000; #$limitn = 100000; #$limitn = 1005; #$limitn = 15;
        $tn = '__processing as pr';
        $sel = ['pr.id as prid', 'pr.created_at',  'j.id as jid'];
        $join = ' LEFT JOIN journal as j ON  j.id = pr.id ';
        $order = ' ORDER BY pr.id ASC'; #$order = ' ORDER BY i.id DESC';
        $limit = ' LIMIT '. $limitn .' '; #pred($limit);
        $q = 'SELECT '. implode(', ', $sel). ' FROM '. $tn . $join . $order . $limit; pre($q);
        $dbr = Db::get_results($q); #pred($dbr);
        $c = count($dbr); #pre($dbr[0]); pre($dbr[$c-1]); pre($c);

        $et = microtime(1); # pre($dbr); # pre($st);  pre($et);
        self::$times[] = date("H:i:s", $et - $st); # 1 00:13:59

        $st = microtime(1);
        $pr_ids = [];
        $cc = 0;
        $step = 10000;
        foreach($dbr as $k => $row){ #pre($row);
            $cc++;
            if($row['jid']){ pre('END!!!'); break; } #continue;
            $pr_ids[] = $row['prid'];
            if($cc === $step){
                if(hand){ pre($k .'/'. $c); pre($row); pre('REMOVING '. $step); } # pre(count($pr_ids));
                Processing::delete_bids($pr_ids);
                $pr_ids = [];
                $cc = 0; # sleep(10);
            }
        }
        if(hand){ pre('REMOVING '. $cc); pre($k .'/'. $c); pre($row); }
        Processing::delete_bids($pr_ids);
        if(hand){ pre($dbr[0]); pre($dbr[$c-1]); pre($c); }
        $et = microtime(1);
        self::$times[] = date("H:i:s", $et - $st); # 1 3h
        if(hand){ pre(self::$times); pre(__CLASS__ .'::'. __FUNCTION__ .' ENDed '); }
    }
}