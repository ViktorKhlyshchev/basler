<?php

namespace CLI\Modules\Clean;

use Core\Module\Db\Db;
use Common\Modules\Date;
use Common\Models\Image\Image;
use Common\Models\Image\ImageItem;
use Core\Module\Video\Video;
use Core\Module\Video\VideoItem;
use Common\Models\JournalImage;
use Common\Models\JournalVideo;
use Common\Models\Journal;
use Core\Modules\Dir;
use Core\Modules\Log;
use Configs\DirConfig;
use Common\Models\Packing;
use Common\Models\Processing;
use Common\Models\Sending;

class CleanTables30 { # private static $timezones = 0;

    public static $deleted_jids;
    public static $jid;
    public static $jids;
    static $day_dpsi = []; # day deleted paths for images
    static $day_dpsv = []; # day deleted paths for videos
    static $day_dpsp = []; # day deleted paths for packets
    static $times = [];
    static $secs_inday = 3600*24;
    static $days = 30;
    static $fd;
    static $repeat = true;

    public static function remove_imagefile($row){
        $dp = Date::get_date_pathwoc($row['idate'], DirConfig::$dir_image) .'/'. $row['iid'];        #pre($dp);
        $imgdp = Dir::get_global_dirn($dp); #pre($imgdp);

        $gdp = dirname($imgdp); #pre($gdp);
        if(!in_array($gdp, self::$day_dpsi)){ #pre($imgdp);
            $rr = Dir::remove_dirn($gdp); # pre($rr);
            if($rr){ $txt = __CLASS__ .'::'. __FUNCTION__ .' | Dir removed:__'. $gdp; Log::clean_log($txt); if(hand){ pre($txt); } } else { $txt = __CLASS__ .'::'. __FUNCTION__ .' cant removedir! #40 dp:__'. $gdp; Log::erlog($txt); if(hand){ pre($txt); pred('critERRR!'); }} #  if(!$rr){ $files = scandir($gdp); pre($files); }
            self::$day_dpsi[] = $gdp; pre(self::$day_dpsi); pre($rr);
            return $rr;
        } else return true;

        $gdp = dirname($imgdp); pre($gdp);
        if(is_dir($imgdp)){
            if(nl) pre("->> remove image_dir: ". $imgdp ."\n"); pred($imgdp);
            $r = Dir::remove_dirn($imgdp); pre($r);
            if(!$r) pred('Cant remove dir!'. $imgdp);
        }

        $is_dir_gdp = is_dir($gdp);
        pred('is_dir($gdp)'. (int)$is_dir_gdp);
        # $gdpr = '/var/www/html/Resource/Image/2021/09/07'; pre($gdp);echo '_______';print_r($gdp);echo '_______';  pre($gdp);  pre($gdp === $gdpr); $cmd = 'stat \''. $gdp .'\''; pre(exec($cmd, $o, $r)); pre($o); pre($r); pre(is_dir($gdp));  pre(file_exists($gdp));  pre(file_exists($gdp));
        if($is_dir_gdp){
            $files = scandir($gdp); #pre($files); pre(count($files) < 3);
            if(count($files) < 3){ $rr = Dir::remove_dirn($gdp); pre($rr); return $rr; }
        }
        return $r;
    }

    public static function remove_videofile($row){

        $dp = Date::get_date_pathwoc($row['vdate'], DirConfig::$dir_video) .'/'. $row['vid'];        #pre($dp);
        $viddp = Dir::get_global_dirn($dp); #pre($viddp);

        $gdp = dirname($viddp); #pre($gdp);
        if(!in_array($gdp, self::$day_dpsv)){ pre($gdp);
            $rr = Dir::remove_dirn($gdp); # pre($rr);
             if($rr){ $txt = __CLASS__ .'::'. __FUNCTION__ .' | Dir removed:__'. $gdp; Log::clean_log($txt); if(hand){ pre($txt); } } else { $txt = __CLASS__ .'::'. __FUNCTION__ .' cant removedir! #70 dp:__'. $gdp; Log::erlog($txt); if(hand){ pre($txt); pred('critERRR!'); }} # if(!$rr){ $files = scandir($gdp); pre($files); }
            self::$day_dpsv[] = $gdp; pre(self::$day_dpsv); pre($rr);
            return $rr;
        } else return true;

        $gdp = dirname($viddp); #pre($gdp);
        if(is_dir($viddp)){
            if(nl) pre("->> remove image_dir: ". $viddp ."\n"); pred($viddp);
            $r = Dir::remove_dirn($viddp); pre($r);
            if(!$r) pred('Cant remove dir!'. $viddp);
        }

        $is_dir_gdp = is_dir($gdp);
        pred('is_dir($gdp)'. (int)$is_dir_gdp);
        # $gdpr = '/var/www/html/Resource/Image/2021/09/07'; pre($gdp);echo '_______';print_r($gdp);echo '_______';  pre($gdp);  pre($gdp === $gdpr); $cmd = 'stat \''. $gdp .'\''; pre(exec($cmd, $o, $r)); pre($o); pre($r); pre(is_dir($gdp));  pre(file_exists($gdp));  pre(file_exists($gdp));
        if($is_dir_gdp){
            $files = scandir($gdp); #pre($files); pre(count($files) < 3);
            if(count($files) < 3){ $rr = Dir::remove_dirn($gdp); pre($rr); return $rr; }
        }
        return $r;
    }

    public static function remove_packet($row){

        $r = @unlink($row['pfp']); #pre($r); pred($row['pfp']);
        $gdp = dirname($row['pfp']); #pre($gdp);
        if($gdp === '/var/www/html/Resource/CafapPackage/tar') return;
        if(!in_array($gdp, self::$day_dpsp)){ pre($row['pfp']);
            $rr = Dir::remove_dirn($gdp); pre($rr);
            if(!$rr){ $files = scandir($gdp); pre($files); }
            self::$day_dpsp[] = $gdp; pre(self::$day_dpsp); pre($rr);
            return $rr;
        } else return true;
    }

    public static function gethist(){
        $tn = '_history'; pre('cleaning table '. $tn);
        $where = ['date_create<fd' => ['column' => 'date_create', 'method' => '<', 'value' =>  self::$fd]]; pre($where);
        $q = ['table' => $tn, 'select' => ['id'], 'where' => $where, 'order' => [['column' => 'id', 'direction' => 'asc']], 'limit' => 10000]; # pred($q); #, 'limit' => 1
        $dbr = Db::select($q); pre(count($dbr)); # pred($dbr);
        $ids = [];
        if(!$dbr) return;
        foreach($dbr as $row) $ids[] = $row['id']; #pre($ids);
        $c = count($ids); pre($c); if($c < 100) pre($ids);
        return $ids;
    }

    public static function remove_records_from_table_greater_nds(string $tn = null, int $days = 30){ # greater N days

        if(empty($tn)){ pre('CWarining! Need table name!'); return; } #  && \Config::$is_query_debug
        # $days = 150; #$date = new \DateTime(); $date->modify('-'.$days .' day'); pred($date->format('Y-m-d'));
        $where = [['function' => "date_create < now() - interval '". $days ." days'"]]; # 2021-09-15 12:43:55 2021-09-15 12:43:19.689471 'function' => "date_create > now() - interval '24 hours'" #return Db::isset_row($tn, null, $where);
        if(0 && \Config::$is_debug){
            $q = ['select' => [['function' => 'COUNT(date_create)', 'rename' => 'len']], 'table' => $tn, 'where' => $where]; pred(Db::select($q)); #array( #'date_create'# 'limit' => 1 #
        }
        $q = ['table' => $tn, 'where' => $where]; pre($q);
        return Db::delete($q);
    }

    public static function clean_others(){
        #self::$days = 29; self::$fd = Date::get_date(time() - self::$secs_inday*self::$days, 'Y-m-d');

        $tn = 'statistics'; pre('cleaning table '. $tn);
        $where = ['date_create<fd' => ['column' => 'date_create', 'method' => '<', 'value' =>  self::$fd]];
        $q = ['table' => $tn, 'where' => $where]; # pred($q); #, 'limit' => 1
        $r = Db::delete($q); #pre($r);

        $tn = '_history';
        while($ids = self::gethist()){
            $q = ['table' => $tn, 'where' => ['id' =>  $ids]]; #pre($q);
            $r = Db::delete($q); #pre($r);
        }

        $tn = '_session'; pre('cleaning table '. $tn);
        $where = ['date_create<fd' => ['column' => 'date_create', 'method' => '<', 'value' =>  self::$fd]];
        $q = ['table' => $tn, 'where' => $where]; # pred($q); #, 'limit' => 1
        $r = Db::delete($q); #pre($r);

        $tn = '_token'; pre('cleaning table '. $tn);
        $where = ['date_create<fd' => ['column' => 'date_create', 'method' => '<', 'value' =>  self::$fd]];
        $q = ['table' => $tn, 'where' => $where]; # pred($q); #, 'limit' => 1
        $r = Db::delete($q); #pre($r);

        if(!loc) $r = self::remove_records_from_table_greater_nds('statistics', 5); # pre($r);
        if(!loc) $r = self::remove_records_from_table_greater_nds('setting_debug', 5);  #pred($r);
    }

    public static function init(){ # $timezones #self::$timezones = $timezones;

        if(count(self::$times) > 10) self::$times = [];
        self::$repeat = true;
        self::$jids = [];
        Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' laucnhed #159');
        if(hand) pre(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #160'); # self::$deleted_jids = [];
        self::$fd = Date::get_date(time() - self::$secs_inday*self::$days, 'Y-m-d');

        $st = microtime(1);  #self::$days = 30; #$fd = Date::get_date_time_full(time() - 3600*24*$days); pre($fd);
        self::clean_others();
        $et = microtime(1);
        self::$times[] = date("H:i:s", $et - $st);

        $st = microtime(1);

        $limitn = 100000; #$limitn = 10;
        $tn = 'journal as j';
        $sel = ['j.id as jid', 'j.date_create as jdate', 'ji.id as jiid', 'i.id as iid', 'i.date_create as idate', 'ii.id as iiid', 'ii.file_extension',
            'jv.id as jvid', 'v.id as vid', 'v.date_create as vdate', 'vii.id as viid', 'pr.id as prid', 'p.id as pid', 'p.file_path as pfp', 's.id as sid']; #'ii.id',
        $where = ['1=1', 'j.date_create<\''. self::$fd .'\'']; #'ii.id='. $iirow['id'], 'ji.id IS NULL',
        # SELECT i.id, i.date_create, ii.file_extension, ji.id FROM _image as i LEFT JOIN journal_image as ji ON  ii.image_id = ji.image_id  WHERE 1=1 AND date_create<'2021-11-10 08:49:43'  ORDER BY i.id ASC LIMIT 10
        $join = ' LEFT JOIN journal_image as ji ON  j.id = ji.journal_id ';
        $join .= ' LEFT JOIN _image as i ON  ji.image_id = i.id ';
        $join .= ' LEFT JOIN _image_item as ii ON  ii.image_id = i.id ';
        $join .= ' LEFT JOIN journal_video as jv ON jv.journal_id = j.id ';
        $join .= ' LEFT JOIN _video as v ON v.id = jv.video_id ';
        $join .= ' LEFT JOIN _video_item as vii ON vii.video_id = v.id ';
        $join .= ' LEFT JOIN __processing as pr ON pr.id = j.id ';
        $join .= ' LEFT JOIN __packing as p ON p.jid = j.id ';
        $join .= ' LEFT JOIN __sending as s ON s.jid = j.id ';
        $where = ' WHERE '. implode(' AND ', $where). ' ';
        $order = ' ORDER BY j.id ASC';
        $limit = ' LIMIT '. $limitn .' '; #pred($limit);
        $q = 'SELECT '. implode(', ', $sel). ' FROM '. $tn . $join . $where . $order . $limit; pre($q);
        $dbr = Db::get_results($q);  #pre(count($dbr));
        $c = count($dbr);
        pre($c);
        if($c){ pre($dbr[0]); pre($dbr[$c-1]); } else self::$repeat = false;
        $et = microtime(1);  # pre($st);  pre($et);#pre($dbr);
        self::$times[] = date("H:i:s", $et - $st); #00:15:42
        $st = microtime(1);

        $cc = 0;
        $step = 5000; #$step = 4;
        $jids = [];
        $iis_ids = []; $jiis_ids = []; $is_ids = [];
        $vis_ids = []; $jvis_ids = []; $vs_ids = [];
        $pr_ids = []; $p_ids = []; $s_ids = [];

        foreach($dbr as $k => $row){ #pred($row);

            if(!isset(self::$jids[$row['jid']])){ self::$jids[$row['jid']] = 1; Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' deleting '. $row['jid']); }
            $cc++;
            #pre($k .'/'. $c);
            /*$traffic_violation_ts = Date::get_ts_from_date_time_ms($jrow['date_traffic_violation']);
            $timestamp = (int)$traffic_violation_ts + self::$timezones; #pred($this->timestamp);
            $traffic_violation_date = \DateTime::createFromFormat('U', $timestamp);
            $ymdp = Date::get_ymd_path($traffic_violation_date);
            $tar_dp = DR .'/'. DirConfig::$dir_cafap_package_tar .'/'. $ymdp;
            if(is_dir($tar_dp)){
                if(nl) pre("->> remove tar: ". $tar_dp ."\n");
                Dir::remove_dirn($tar_dp);
            } else pre($tar_dp);*/


            #if(\Config::$servername === 'aist6' || \Config::$servername === 'aist1'){
            #if(\Config::$servername === 'aist1') $minjd = 913321; if(\Config::$servername === 'aist6') $minjd = 358330; if(\Config::$servername === 'aist8') $minjd = 474762;


            if($row['idate']) self::remove_imagefile($row);
            if($row['vdate']) self::remove_videofile($row); #pre($v);
            if($row['pfp']) self::remove_packet($row); #pre($v);

            $jids[] = $row['jid'];
            if($row['iiid']) $iis_ids[] = $row['iiid'];
            if($row['jiid']) $jiis_ids[] = $row['jiid'];
            if($row['iid']) $is_ids[] = $row['iid'];

            if($row['viid']) $vis_ids[] = $row['viid'];
            if($row['jvid']) $jvis_ids[] = $row['jvid'];
            if($row['vid']) $vs_ids[] = $row['vid'];

            if($row['prid']) $pr_ids[] = $row['prid'];
            if($row['pid']) $p_ids[] = $row['pid'];
            if($row['sid']) $s_ids[] = $row['sid'];

            if($cc === $step){
                pre($row);
                pre($k .'/'. $c);
                pre($step .' REMOVES!!'); # pre($jids);
                pre('$jids:'. count($jids)); pre('$jiis_ids:'. count($jiis_ids)); pre('$is_ids:'. count($is_ids)); pre('$iis_ids:'. count($iis_ids));
                pre('$jvis_ids:'. count($jvis_ids)); pre('$vs_ids:'. count($vs_ids)); pre('$vis_ids:'. count($vis_ids));
                pre('$s_ids:'. count($s_ids)); pre('$p_ids:'. count($p_ids)); pre('$pr_ids:'. count($pr_ids));

                Sending::delete_bids($s_ids);
                Packing::delete_bids($p_ids);
                Processing::delete_bids($pr_ids);

                ImageItem::delete_bids($iis_ids);
                JournalImage::delete_bids($jiis_ids);
                Image::delete_bids($is_ids);
                VideoItem::delete_bids($vis_ids);
                JournalVideo::delete_bids($jvis_ids);
                Video::delete_bids($vs_ids);
                Journal::delete_bids($jids);

                $jids = [];
                $iis_ids = []; $jiis_ids = []; $is_ids = [];
                $vis_ids = []; $jvis_ids = []; $vs_ids = [];
                $pr_ids = []; $p_ids = []; $s_ids = [];
                $cc = 0;                #echo 'sleep(2)'; sleep(2);
            } #if(!in_array($jid, self::$deleted_jids)){ $r = Journal::delete_bid($jid); #pred($r);  $deleted_jids[] = $jid;  } #pre('sleep(2)'); sleep(2);
        }

        pre(count($jids)); pre(count($jiis_ids)); pre(count($is_ids)); pre(count($iis_ids));
        pre(count($jvis_ids)); pre(count($vs_ids)); pre(count($vis_ids));
        pre(count($pr_ids)); pre(count($p_ids)); pre(count($s_ids));

        Sending::delete_bids($s_ids);
        Packing::delete_bids($p_ids);
        Processing::delete_bids($pr_ids);
        ImageItem::delete_bids($iis_ids);
        JournalImage::delete_bids($jiis_ids);
        Image::delete_bids($is_ids);
        VideoItem::delete_bids($iis_ids);
        JournalVideo::delete_bids($jiis_ids);
        Video::delete_bids($is_ids);
        Journal::delete_bids($jids);
        Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' ended #280');

        if(self::$repeat) self::init();
        if(hand){
            $et = microtime(1); #pre(date("H:i:s", $et - $st));
            pre($c); if($c){ pre($dbr[0]); pre($dbr[$c-1]); }
            self::$times[] = date("H:i:s", $et - $st);
            pre(self::$times);
            pre('END!' . __FILE__);
        }
    }
}