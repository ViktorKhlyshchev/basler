<?php

namespace CLI\Modules\Clean;

use Core\Module\Db\Db;
use Common\Modules\Date;
use Core\Module\Video\Video;
use Core\Module\Video\VideoItem;
use Core\Modules\Dir; #use Configs\DirConfig;
use Core\Modules\Log;
use Configs\DirConfig;
use Common\Models\JournalVideo;

class CleanOrphanVideos30 { # sudo -u www-data /usr/bin/php7.2 /var/www/html/index.php action=cov30 is_test=1 need_log=1
    # sudo -u www-data /usr/bin/php7.2 $PWD/index.php action=cov30 need_log=1

    static $day_dps = [];

    public static function remove_videofile($video){
        #$video_data = videoPathAction::get_video_path_data($video_id, true, true, true, false); pred($video_data);
        #if(empty($video_data) || empty($video_data['video_dir'])) return;

        $dp = Date::get_date_pathwoc($video['date_create'], DirConfig::$dir_video) .'/'. $video['vid'];        #pre($dp);
        $viddp = Dir::get_global_dirn($dp); pre($viddp);

        $gdp = dirname($viddp); #pre($gdp);
        if(!in_array($gdp, self::$day_dps)){
            $rr = Dir::remove_dirn($gdp); pre($rr);
            if(!$rr){ $files = scandir($gdp); pre($files); }
            self::$day_dps[] = $gdp; #pre(self::$day_dps);            pred($rr);
            return $rr;
        } else return true;

        if(is_dir($viddp)){
            if(nl) pre("->> remove video_dir: ". $viddp ."\n");
            $r = Dir::remove_dirn($viddp); pre($r);
            if(!$r) pred('Cant remove dir!'. $viddp);
        }
        #$gdp = '/var/www/html/Resource/video/2021/09/07';pre('is_dir($gdp)'. (int)is_dir($gdp));

        #if($gdp === '/var/www/html/Resource/video/2021/09/07') return true;
        $is_dir_gdp = is_dir($gdp);
        pre('is_dir($gdp)'. (int)$is_dir_gdp);
        # $gdpr = '/var/www/html/Resource/video/2021/09/07'; pre($gdp);echo '_______';print_r($gdp);echo '_______';  pre($gdp);  pre($gdp === $gdpr); $cmd = 'stat \''. $gdp .'\''; pre(exec($cmd, $o, $r)); pre($o); pre($r); pre(is_dir($gdp));  pre(file_exists($gdp));  pre(file_exists($gdp));
        if($is_dir_gdp){
            $files = scandir($gdp); #pre($files); pre(count($files) < 3);
            if(count($files) < 3){ $rr = Dir::remove_dirn($gdp); pre($rr); return $rr; }
        }
        return $r;
    }

    public static function init(){ # $timezones #self::$timezones = $timezones; $ar = [1]; pred($ar[2]);

        Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #54');
        pre(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #55');
        $st = microtime(1); # pred(self::boundries());

        $days = 30; #$fd = Date::get_date_time_full(time() - 3600*24*$days); #pred($fd);
        $fd = Date::get_date(time() - 3600*24*$days, 'Y-m-d');

        $limitn = 300000; #$limitn = 3;

        $tn = '_video as v';
        $sel = ['v.id as vid', 'v.date_create', 'vi.id as viid', 'vi.file_extension', 'jv.id as jvid', 'j.id as jid']; #'ii.id',
        $where = ['1=1', 'v.date_create<\''. $fd .'\'']; #'ii.id='. $iirow['id'], 'ji.id IS NULL',
        # SELECT i.id, i.date_create, ii.file_extension, ji.id FROM _video as i LEFT JOIN journal_video as ji ON  ii.video_id = ji.video_id  WHERE 1=1 AND date_create<'2021-11-10 08:49:43'  ORDER BY i.id ASC LIMIT 10
        $join = ' LEFT JOIN _video_item as vi ON  vi.video_id = v.id ';
        $join .= ' LEFT JOIN journal_video as jv ON  v.id = jv.video_id ';
        $join .= ' LEFT JOIN journal as j ON  j.id = jv.journal_id ';
        $where = ' WHERE '. implode(' AND ', $where). ' ';
        $order = ' ORDER BY v.id ASC';
        $limit = ' LIMIT '. $limitn .' '; #pred($limit);
        $q = 'SELECT '. implode(', ', $sel). ' FROM '. $tn . $join . $where . $order . $limit; pre($q);
        $dbr = Db::get_results($q);
        $c = count($dbr);
        $et = microtime(1); # pre($dbr); # pre($st);  pre($et);
        pre(date("H:i:s", $et - $st));

        foreach($dbr as $k => $vrow){ pre($vrow);
            pre($k .'/'. $c);
            $vid = $vrow['vid']; #pre($jid);$jvideos_ids = JournalVideo::get_all_videos_ids($jid); pred($jvideos_ids);
            pre('$vid:'. $vid);
            if($vrow['jid'] && $vrow['jvid']) pred('END!!!');#continue; #continue;

            $r = self::remove_videofile($vrow); #pred($r);
            if($vrow['viid']) $r = VideoItem::delete_bid($vrow['viid']); #pre($r);
            if($vrow['jvid']) $r = JournalVideo::delete_bid($vrow['jvid']); #pre($r);
            if($vrow['vid']) $r = Video::delete_bid($vrow['vid']); #pre($r);
            #pred(self::$day_dps);
            #pred('sleep(2)');            sleep(2);
        }
        if($dbr){ pre($dbr[0]); pre($dbr[$c-1]); pre($c); }
        pre('END!' . __FILE__);
    }
}