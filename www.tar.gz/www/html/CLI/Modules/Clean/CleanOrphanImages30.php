<?php

namespace CLI\Modules\Clean;

use Core\Module\Db\Db;
use Common\Modules\Date;
use Common\Models\JournalImage;
use Common\Models\Image\Image;
use Common\Models\Image\ImageItem;
use Core\Modules\Dir;
use Core\Modules\Log;
use Configs\DirConfig;

class CleanOrphanImages30 { # private static $timezones = 0;

    static $day_dps = [];
    static $times = [];

    public static function remove_imagefile($image){
        #$image_data = ImagePathAction::get_image_path_data($image_id, true, true, true, false); pred($image_data);
        #if(empty($image_data) || empty($image_data['image_dir'])) return;

        $dp = Date::get_date_pathwoc($image['date_create'], DirConfig::$dir_image) .'/'. $image['iid'];        #pre($dp);
        $imgdp = Dir::get_global_dirn($dp); #pre($imgdp);

        $gdp = dirname($imgdp);
        if(!in_array($gdp, self::$day_dps)){ pre('REMOVING:' .$gdp);
            $rr = Dir::remove_dirn($gdp); pre($rr);
            if(!$rr){ $files = scandir($gdp); pre($files); }
            self::$day_dps[] = $gdp; #pre(self::$day_dps);            pred($rr);
            return $rr;
        } else return true;

        if(is_dir($imgdp)){
            if(nl) pre("->> remove image_dir: ". $imgdp ."\n");
            $r = Dir::remove_dirn($imgdp); pre($r);
            if(!$r) pred('Cant remove dir!'. $imgdp);
        }
        #$gdp = '/var/www/html/Resource/Image/2021/09/07';pre('is_dir($gdp)'. (int)is_dir($gdp));

        #if($gdp === '/var/www/html/Resource/Image/2021/09/07') return true;
        $is_dir_gdp = is_dir($gdp);
        pre('is_dir($gdp)'. (int)$is_dir_gdp);
        # $gdpr = '/var/www/html/Resource/Image/2021/09/07'; pre($gdp);echo '_______';print_r($gdp);echo '_______';  pre($gdp);  pre($gdp === $gdpr); $cmd = 'stat \''. $gdp .'\''; pre(exec($cmd, $o, $r)); pre($o); pre($r); pre(is_dir($gdp));  pre(file_exists($gdp));  pre(file_exists($gdp));
        if($is_dir_gdp){
            $files = scandir($gdp); #pre($files); pre(count($files) < 3);
            if(count($files) < 3){ $rr = Dir::remove_dirn($gdp); pre($rr); return $rr; }
        }
        return $r;
    }

    public static function boundries(){ # $timezones #self::$timezones = $timezones;

        $days = 30;
        #$fd = Date::get_date_time_full(time() - 3600*24*$days); #pred($fd);
        $fd = Date::get_date_time_full(time() - 3600*24*$days); #pred($fd);

        $limitn = 1;
        $tn = '_image as i';
        $sel = ['i.id', 'i.date_create', 'ji.id as jiid']; #'ii.id',
        $where = ['1=1', 'i.date_create<\''. $fd .'\''];
        #$join = ' JOIN journal_image as ji ON  ji.image_id = i.id '; # NOT LEFT!!!!
        $join = ' LEFT JOIN journal_image as ji ON  ji.image_id = i.id '; # NOT LEFT!!!!
        $where = ' WHERE '. implode(' AND ', $where). ' ';
        $order = ' ORDER BY i.id ASC';
        $limit = ' LIMIT '. $limitn .' '; #pred($limit);
        $q = 'SELECT '. implode(', ', $sel). ' FROM '. $tn . $join . $where . $order . $limit; pre($q);
        $dbrf = Db::get_results($q); # 26850619 2021-10-26 21:17:43.234651	666564

        pre($dbrf);

        $sel = ['i.id', 'i.date_create', 'ji.id as jiid']; #'ii.id',
        $where = ['1=1', 'i.date_create<\''. $fd .'\''];
        $join = ' LEFT JOIN journal_image as ji ON  ji.image_id = i.id ';
        $where = ' WHERE '. implode(' AND ', $where). ' ';
        $order = ' ORDER BY i.id DESC';
        $limit = ' LIMIT '. $limitn .' '; #pred($limit);
        $q = 'SELECT '. implode(', ', $sel). ' FROM '. $tn . $join . $where . $order . $limit; pre($q);
        $dbrl = Db::get_results($q);
        pre($dbrl);
        if($dbrf && $dbrl) pre('DIFF:'. number_format(($dbrl[0]['id'] - $dbrf[0]['id']) , 0, ',', '.')); else pre('DIFF ZER0!!');
        sleep(5);
    }

    public static function init(){ # $timezones #self::$timezones = $timezones;

        Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #87');
        pre(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #88');
        $st = microtime(1);
        #self::boundries(); DIFF:5.660.381 00:24:31
        $et = microtime(1); # pre($dbr); # pre($st);  pre($et);
        self::$times[] = date("H:i:s", $et - $st); # 1 00:15:42

        $st = microtime(1); # pred(self::boundries());

        $days = 30; #$fd = Date::get_date_time_full(time() - 3600*24*$days); #pred($fd);
        $fd = Date::get_date(time() - 3600*24*$days, 'Y-m-d'); #pred($fd);

        $limitn = 500000; #$limitn = 100000; #$limitn = 1005; #$limitn = 15;
        $tn = '_image as i';
        $sel = ['i.id as iid', 'i.date_create', 'ii.id as iiid', 'ii.file_extension', 'ji.id as jiid', 'j.id as jid']; #'ii.id',
        $where = ['1=1', 'i.date_create<\''. $fd .'\'' #'ii.id='. $iirow['id'], 'ji.id IS NULL',
        ];
        # SELECT i.id, i.date_create, ii.file_extension, ji.id FROM _image as i LEFT JOIN journal_image as ji ON  ii.image_id = ji.image_id  WHERE 1=1 AND date_create<'2021-11-10 08:49:43'  ORDER BY i.id ASC LIMIT 10
        $join = ' LEFT JOIN _image_item as ii ON  ii.image_id = i.id ';
        $join .= ' LEFT JOIN journal_image as ji ON ji.image_id = i.id ';
        $join .= ' LEFT JOIN journal as j ON  j.id = ji.journal_id ';
        $where = ' WHERE '. implode(' AND ', $where). ' ';
        $order = ' ORDER BY i.id ASC'; #$order = ' ORDER BY i.id DESC';
        $limit = ' LIMIT '. $limitn .' '; #pred($limit);
        $q = 'SELECT '. implode(', ', $sel). ' FROM '. $tn . $join . $where . $order . $limit; pre($q);
        $dbr = Db::get_results($q);
        $c = count($dbr); #pre($dbr[0]); pre($dbr[$c-1]); pred($с);

        $et = microtime(1); # pre($dbr); # pre($st);  pre($et);
        self::$times[] = date("H:i:s", $et - $st); # 1 00:13:59

        $st = microtime(1);
        $iis_ids = []; $jiis_ids = []; $is_ids = [];
        $cc = 0;
        $step = 10000;
        foreach($dbr as $k => $irow){ #pre($irow);
            $cc++;
            #pre($k .'/'. $c); # $iid = $irow['iid']; #pre($jid);$jvideos_ids = JournalVideo::get_all_videos_ids($jid); pred($jvideos_ids);
            #pre('$iid:'. $iid); # if($irow['jiid']) pred('END!!!');
            if($irow['jid'] && $irow['jiid']){ pre('END!!!'); break; } #continue;
            $r = self::remove_imagefile($irow); #pred($r);
            if($irow['iiid']) $iis_ids[] = $irow['iiid'];
            if($irow['jiid']) $jiis_ids[] = $irow['jiid'];
            if($irow['iid']) $is_ids[] = $irow['iid'];
            if($cc === $step){
                if(hand){ pre($k .'/'. $c); pre($irow); pre($step .' REMOVES'); pre('Removing: jiis_ids: '. count($jiis_ids) . ' | is_ids:'. count($is_ids) . ' | iis_ids:'. count($iis_ids)); }
                ImageItem::delete_bids($iis_ids);
                JournalImage::delete_bids($jiis_ids);
                Image::delete_bids($is_ids);
                $iis_ids = []; $jiis_ids = []; $is_ids = [];
                $cc = 0; # sleep(10);
            }
        }
        if(hand){ pre($k .'/'. $c); pre($irow); }
        ImageItem::delete_bids($iis_ids);
        JournalImage::delete_bids($jiis_ids);
        Image::delete_bids($is_ids);
        if(hand){ pre($dbr[0]); pre($dbr[$c-1]); pre($c); }
        $et = microtime(1);
        self::$times[] = date("H:i:s", $et - $st); # 1 3h
        if(hand){ pre(self::$times); pre('END!' . __FILE__); }
    }
}