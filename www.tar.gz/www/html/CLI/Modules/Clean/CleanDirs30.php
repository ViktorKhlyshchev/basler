<?php

namespace CLI\Modules\Clean;

use Common\Modules\Date;
use Core\Modules\Dir;
use Core\Modules\Log;
use Configs\DirConfig;

class CleanDirs30 { # sudo -u www-data /usr/bin/php7.2 -f "$PWD/index.php" action=cd30 need_log=1 is_test=1 hand=1
    #sudo -u www-data /usr/bin/php /var/www/html/index.php action=cd30 is_test=1 need_log=1

    public static $deleted_jids;
    public static $jid;
    static $day_dpsi = []; # day deleted paths for images
    static $deleted_paths = []; # deleted paths
    static $times = [];
    static $secs_inday = 3600*24;
    static $days = 30;
    static $fd;

    public static function init(){ # $timezones #self::$timezones = $timezones;

        self::$deleted_paths = [];

        Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #26');
        if(hand) pre(__CLASS__ .'::'. __FUNCTION__ .' laucnhed! #27');#$curm = Date::get_date(time(), 'm');        $curd = time(); # current date
        $cts = time() - self::$secs_inday * self::$days; # clean timestamp $cury = Date::get_date($curd, 'Y'); #pred($curm);
        $y = Date::get_date($cts, 'Y'); #pred($curm); $yint = (int)$y;
        $m = Date::get_date($cts, 'm'); #$mint = (int)$m;
        $d = Date::get_date($cts, 'd'); #$dint = (int)$d;
        pre('<'. $d .'.'. $m .'.' .$y);# pre($d);  pre($m); pre($y); pre($d); $py = $yint-1; #pred($py); #$mint = (int)$m; #pred($mint); # pred(DirConfig::$dir_image); #if($mint > 1){ # /mnt/data/Resource/Image/2022/01

        if(1){ #$dp = DR .'/'. DirConfig::$dir_image .'/'. $y .'/'. $m; #pred($dp);
            $idp = DR .'/'. DirConfig::$dir_image;
            foreach(glob($idp .'/*', GLOB_ONLYDIR) as $ydp){ # year delete dir path # pred($ydp);
                foreach(glob($ydp .'/*', GLOB_ONLYDIR) as $mdp){ # month delete dir path
                    foreach(glob($mdp .'/*', GLOB_ONLYDIR) as $ddp){ # day delete dir path pred($ddp);
                        $explode = explode('/', $ddp); #  pred($explode);
                        $dd = ($explode[count($explode) - 3]) .'.'. ($explode[count($explode) - 2]) .'.'. ($explode[count($explode) - 1]);
                        $dts = \DateTime::createFromFormat('Y.m.d', $dd);
                        if(!$dts) continue;
                        $dts = $dts->getTimestamp(); #pred($dts);
                        if($dts < $cts){
                            $st = microtime(1);
                            if(hand) pre('Removing dir:__'. $ddp);
                            $r = Dir::remove_dirn($ddp);
                            if(!$r){ if(hand) pred('Er: cant delet dir! dp:__'. $ddp); else Log::erlog(__CLASS__ .'::'. __FUNCTION__ .' | Er: cant delet dir! dp:__'. $ddp); }
                            $et = microtime(1);
                            self::$times[] = date("H:i:s", $et - $st);
                            self::$deleted_paths[date("H:i:s", $et - $st)] = $ddp;
                        }
                    }
                    if(count(scandir($mdp)) === 2){
                        $r = rmdir($mdp);
                        if(!$r){ if(hand) pred('Er: cant delet dir! dp:__'. $mdp); else Log::erlog(__CLASS__ .'::'. __FUNCTION__ .' | Er: cant delet dir! dp:__'. $mdp); }
                    }
                }
                if(count(scandir($ydp)) === 2){
                    $r = rmdir($ydp);
                    if(!$r){ if(hand) pred('Er: cant delet dir! dp:__'. $ydp); else Log::erlog(__CLASS__ .'::'. __FUNCTION__ .' | Er: cant delet dir! dp:__'. $ydp); }
                }
            }
        }

        if(1){
            $vdp = DR .'/'. DirConfig::$dir_video;
            foreach(glob($vdp .'/*', GLOB_ONLYDIR) as $ydp){ # year delete dir path # pred($ydp);
                foreach(glob($ydp .'/*', GLOB_ONLYDIR) as $mdp){ # month delete dir path
                    foreach(glob($mdp .'/*', GLOB_ONLYDIR) as $ddp){ # day delete dir path pred($ddp);
                        $explode = explode('/', $ddp); #  pred($explode);
                        $dd = ($explode[count($explode) - 3]) .'.'. ($explode[count($explode) - 2]) .'.'. ($explode[count($explode) - 1]);
                        $dts = \DateTime::createFromFormat('Y.m.d', $dd);
                        if(!$dts) continue;
                        $dts = $dts->getTimestamp(); #pred($dts);
                        if($dts < $cts){ #self::$deleted_paths[] = $ddp;
                            $st = microtime(1);
                            $r = Dir::remove_dirn($ddp);
                            if(!$r){ if(hand) pred('Er: cant delet dir! dp:__'. $ddp); else Log::erlog(__CLASS__ .'::'. __FUNCTION__ .' | Er: cant delet dir! dp:__'. $ddp); }
                            $et = microtime(1);
                            self::$times[] = date("H:i:s", $et - $st);
                            self::$deleted_paths[date("H:i:s", $et - $st)] = $ddp;
                        }
                    }
                    if(count(scandir($mdp)) === 2){
                        $r = rmdir($mdp);
                        if(!$r) pred('Er: cant delete dir! dp:__'. $mdp);
                    }
                }
                if(count(scandir($ydp)) === 2){
                    $r = rmdir($ydp);
                    if(!$r) pred('Er: cant delete dir! dp:__'. $ydp);
                }
            }
        }

        if(1) foreach(glob(DR .'/'. DirConfig::$dir_cafap_package_tar .'/*', GLOB_ONLYDIR) as $dp){
            $date = basename($dp);
            $date = \DateTime::createFromFormat('Y.m.d', $date);
            if(!$date) continue; # pred($date);
            if($date->getTimestamp() < $cts){
                $st = microtime(1); #pred($dp);
                $rr = Dir::remove_dirn($dp);
                if(!$r){ if(hand) pred('Er: cant delet dir! dp:__'. $dp); else Log::erlog(__CLASS__ .'::'. __FUNCTION__ .' | Er: cant delet dir! dp:__'. $dp); }
                $et = microtime(1);
                self::$times[] = date("H:i:s", $et - $st);
                self::$deleted_paths[date("H:i:s", $et - $st)] = $ddp;
            }
        }

        if(1) foreach(glob(DR .'/'. DirConfig::$dir_duplo_xml .'/*', GLOB_ONLYDIR) as $dp){
            $date = basename($dp);
            $date = \DateTime::createFromFormat('Y.m.d', $date); pre($date);
            if(!$date) continue;
            if($date->getTimestamp() < $cts){
                $st = microtime(1); #pred($dp);
                $rr = Dir::remove_dirn($dp);
                if(!$r){ if(hand) pred('Er: cant delet dir! dp:__'. $dp); else Log::erlog(__CLASS__ .'::'. __FUNCTION__ .' | Er: cant delet dir! dp:__'. $dp); }
                $et = microtime(1);
                self::$times[] = date("H:i:s", $et - $st);
                self::$deleted_paths[date("H:i:s", $et - $st)] = $ddp;
            }
        }

        foreach(self::$deleted_paths as $k => $v) Log::clean_log(__CLASS__ .'::'. __FUNCTION__ .' deleted path: '. $v .' for time: '. $k);
        if(hand){ if(!empty(self::$deleted_paths)) pre(self::$deleted_paths); pre(__CLASS__ .'::'. __FUNCTION__ .' ENDed '); } #        pre(self::$times);
    }
}