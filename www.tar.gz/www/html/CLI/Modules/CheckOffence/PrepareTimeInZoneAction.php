<?php

namespace CLI\Modules\CheckOffence;

use Core\Module\Polygon\Polygon;

class PrepareTimeInZoneAction{

    /** @var bool */
    private static $is_inside_zone=false;

    /** @var array */
    private static $track_list = [];

    /** @var array */
    private static $zone_list = [];

    /** @var array */
    private static $result_list = [];

    /**
     * @return bool
     */
    private static function reset_data(){

        self::$is_inside_zone =false;
        self::$track_list = [];
        self::$zone_list = [];
        self::$result_list = [];

        return true;

    }

    /**
     * @return bool
     */
    private static function set_result_list(){

        for($zone_index=0;$zone_index<count(self::$zone_list);$zone_index++){

            $is_inside_zone =false;
            $zone_list = [
                'is_inside_zone' => false,
                'timestamp_limit' => self::$zone_list[$zone_index]['timestamp'],
                'timestamp_in_zone' => 0,
                'list' => [],
            ];
            $zone_data = null;

            for($track_index=0;$track_index<count(self::$track_list['converted_track_list']);$track_index++)
                if(Polygon::is_point_inside_zone(self::$track_list['converted_track_list'][$track_index]['x'], self::$track_list['converted_track_list'][$track_index]['y'], self::$zone_list[$zone_index]['list'])){

                    if(!$is_inside_zone){

                        $zone_data = [
                            'timestamp_start' => self::$track_list['converted_track_list'][$track_index]['timestamp'],
                            'timestamp_finish' => self::$track_list['converted_track_list'][$track_index]['timestamp'],
                            'len' => 1
                        ];

                        $is_inside_zone=true;

                    }
                    else{

                        $zone_data['timestamp_finish'] =self::$track_list['converted_track_list'][$track_index]['timestamp'];
                        $zone_data['len']               ++;

                    }

                }
                else if(!empty($zone_data)&&$is_inside_zone){

                    if($zone_data['len']>1){

                        $zone_list['list'][] = $zone_data;
                        $timestamp_in_zone = $zone_data['timestamp_finish']-$zone_data['timestamp_start'];

                        if($timestamp_in_zone>$zone_list['timestamp_in_zone'])
                            $zone_list['timestamp_in_zone'] = $timestamp_in_zone;

                    }

                    $is_inside_zone =false;
                    $zone_data = null;

                }

            if(!empty($zone_data)&&$is_inside_zone)
                if($zone_data['len']>1){

                    $zone_list['list'][] = $zone_data;
                    $timestamp_in_zone = $zone_data['timestamp_finish']-$zone_data['timestamp_start'];

                    if($timestamp_in_zone>$zone_list['timestamp_in_zone'])
                        $zone_list['timestamp_in_zone'] = $timestamp_in_zone;

                }

            $zone_list['timestamp_in_zone']/=1000;

            if(count($zone_list['list']) > 0){

                $zone_list['is_inside_zone'] = $zone_list['timestamp_in_zone']>$zone_list['timestamp_limit'];
                self::$result_list[] = $zone_list;

                if($zone_list['is_inside_zone'])
                    self::$is_inside_zone=true;

            }

        }

        return true;

    }

    /**
     * @return array
     */
    private static function set(){

        self::set_result_list();

        return self::set_return();

    }

    /**
     * @return array
     */
    private static function set_return(){

        return [
            'is_inside_zone' => self::$is_inside_zone,
            'list' => self::$result_list,
        ];

    }

    /**
     * @param array $track_list
     * @param array $zone_list
     * @return array
     */
    public static function init(array $track_list = [], array $zone_list = array()){

        self::reset_data();

        self::$track_list = $track_list;
        self::$zone_list = $zone_list;

        return self::set();

    }

}