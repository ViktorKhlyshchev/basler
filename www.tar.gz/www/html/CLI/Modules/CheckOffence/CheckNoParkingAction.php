<?php

namespace CLI\Modules\CheckOffence;

class CheckNoParkingAction{

    /** @var array */
    private static $track_list = [];

    /** @var array */
    private static $zone_list = [];

    /** @var string */
    private static $traffic_violation_key='no_parking';

    /** @var array */
    private static $is_inside_zone=false;

    /** @var array */
    private static $result_list = [];

    /**
     * @return bool
     */
    private static function reset_data(){

        self::$is_inside_zone =false;
        self::$track_list = [];
        self::$zone_list = [];
        self::$result_list = [];

        return true;

    }

    /**
     * @return bool
     */
    private static function prepare_zone(){

        $r = PrepareTimeInZoneAction::init(self::$track_list, self::$zone_list);

        if(empty($r)) return false;

        self::$is_inside_zone = $r['is_inside_zone'];
        self::$result_list = $r['list'];

        return true;

    }

    /**
     * @return array
     */
    private static function set(){

        self::prepare_zone();

        return self::set_return();

    }

    /**
     * @return array
     */
    private static function set_return(){

        return [
            'is_inside_zone' => self::$is_inside_zone,
            'traffic_violation_zone' => self::$traffic_violation_key,
            'list' => self::$result_list,
        ];

    }

    /**
     * @param array $track_list
     * @param array $zone_list
     * @return array
     */
    public static function init(array $track_list = [], array $zone_list = array()){

        self::reset_data();

        self::$track_list = $track_list;
        self::$zone_list = $zone_list;

        return self::set();

    }

}