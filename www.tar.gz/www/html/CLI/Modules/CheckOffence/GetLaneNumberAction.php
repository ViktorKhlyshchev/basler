<?php

namespace CLI\Modules\CheckOffence;

use Core\Module\Polygon\Polygon;

class GetLaneNumberAction{

    /** @var array */
    private static $track_list = [];

    /** @var array */
    private static $zone_list = [];

    /** @var int */
    private static $lane_number;

    /** @var array */
    private static $result_list = [];

    /**
     * @return bool
     */
    private static function reset_data(){

        self::$lane_number = null;
        self::$track_list = [];
        self::$zone_list = [];
        self::$result_list = [];

        return true;

    }

    /**
     * @return bool
     */
    private static function prepare_zone(){

        self::$result_list = [];

        for($zone_index=0;$zone_index<count(self::$zone_list);$zone_index++){

            $zone_data = null;

            for($track_index=0;$track_index<count(self::$track_list['converted_track_list']);$track_index++)
                if(Polygon::is_point_inside_zone(self::$track_list['converted_track_list'][$track_index]['x'], self::$track_list['converted_track_list'][$track_index]['y'], self::$zone_list[$zone_index]['list'])){

                    if(!isset(self::$result_list[self::$zone_list[$zone_index]['lane']]))
                        self::$result_list[self::$zone_list[$zone_index]['lane']] = 0;

                    self::$result_list[self::$zone_list[$zone_index]['lane']]++;

                }

        }

        arsort(self::$result_list);

        if(!empty(self::$result_list)){

            $result_key_list =array_keys(self::$result_list);
            self::$lane_number = $result_key_list[0];

        }

        if(nl&&!empty($_POST['journal_id'])&&!empty($_POST['is_test'])){

            echo "lane number: ".self::$lane_number."\n";

            print_r(self::$result_list);die;

        }

        return true;

    }

    /**
     * @return array
     */
    private static function set(){

        self::prepare_zone();

        return self::set_return();

    }

    /**
     * @return array
     */
    private static function set_return(){

        return [
            'lane' => self::$lane_number,
            'list' => self::$result_list,
        ];

    }

    /**
     * @param array $track_list
     * @param array $zone_list
     * @return array
     */
    public static function init(array $track_list = [], array $zone_list = array()){

        self::reset_data();

        self::$track_list = $track_list;
        self::$zone_list = $zone_list;

        return self::set();

    }

}