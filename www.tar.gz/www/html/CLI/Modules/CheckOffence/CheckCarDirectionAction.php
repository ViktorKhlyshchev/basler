<?php

namespace CLI\Modules\CheckOffence;

use Project\Aist\Admin\Action\Xavier\CheckOffenceAction;

class CheckCarDirectionAction{

    /** @var string */
    private static $car_direction;

    /** @var array */
    private static $track_list = [];

    /** @var array */
    private static $direction_history_list = [];

    /** @var array */
    private static $direction_list = [];

    /**
     * @return bool
     */
    private static function reset_data(){

        self::$car_direction = null;
        self::$track_list = [];
        self::$direction_history_list = [];
        self::$direction_list = [];

        return true;

    }

    private static function prepare_direction_new(){

        if(count(self::$track_list)<2){

            self::$car_direction = null;

            return false;

        }

        $car_direction = null;
        $direction_history_list = [];
        $direction_list = [
            'up' => 0,
            'down' => 0,
            'neutral' => 0,
        ];

        for($index=1;$index<count(self::$track_list['default_track_list']);$index++){

            $current_direction = null;
            $delta =self::$track_list['default_track_list'][$index]['y']-self::$track_list['default_track_list'][$index-1]['y'];

            if(self::$track_list['default_track_list'][$index]['y']>self::$track_list['default_track_list'][$index-1]['y'])
                $current_direction='down';
            else if(self::$track_list['default_track_list'][$index]['y']<self::$track_list['default_track_list'][$index-1]['y'])
                $current_direction='up';

            if(!empty($current_direction)){

                if(empty($car_direction))
                    $car_direction = $current_direction;

                if($car_direction != $current_direction
                    &&empty(self::$car_direction)
                )
                    self::$car_direction = $car_direction;

                if(empty($direction_history_list))
                    $direction_history_list[] = [
                        'direction' => $current_direction,
                        'len' => 0,
                        'delta_sum' => 0,
                        'delta_list' => [],
                        'timestamp_from' => self::$track_list['default_track_list'][$index]['timestamp'],
                        'timestamp_to' => self::$track_list['default_track_list'][$index]['timestamp'],
                    ];

                if($direction_history_list[count($direction_history_list)-1]['direction'] == $current_direction){

                    $direction_history_list[count($direction_history_list)-1]['len']                ++;
                    $direction_history_list[count($direction_history_list)-1]['delta_list'][] = $delta;
                    $direction_history_list[count($direction_history_list)-1]['delta_sum']          +=abs($delta);
                    $direction_history_list[count($direction_history_list)-1]['timestamp_to'] =self::$track_list['default_track_list'][$index]['timestamp'];

                }
                else
                    $direction_history_list[] = [
                        'direction' => $current_direction,
                        'len' => 1,
                        'delta_sum' => abs($delta),
                        'delta_list' => [
                            $delta
                        ],
                        'timestamp_from' => self::$track_list['default_track_list'][$index]['timestamp'],
                        'timestamp_to' => self::$track_list['default_track_list'][$index]['timestamp'],
                    ];

            }

        }

        if(count($direction_history_list) > 0){

            for($index=count($direction_history_list)-1;$index>=0;$index--)
                if($direction_history_list[$index]['len']<CheckOffenceAction::$direction_point_len_min)
                    array_splice($direction_history_list,$index,1);

            for($index=0;$index<count($direction_history_list);$index++){

                $direction_list[$direction_history_list[$index]['direction']]+ = $direction_history_list[$index]['len'];

                unset($direction_history_list[$index]['delta_list']);

            }

            for($index=0;$index<count($direction_history_list);$index++)
                if($direction_history_list[$index]['len']>CheckOffenceAction::$direction_point_len_min){

                    self::$car_direction = $direction_history_list[$index]['direction'];

                    break;

                }

        }

        if(count($direction_history_list) > 0){

            self::$direction_history_list[] = $direction_history_list[0];

            if(count($direction_history_list)>1){

                for($index=1;$index<count($direction_history_list);$index++)
                    if($direction_history_list[$index]['direction'] == $direction_history_list[$index-1]['direction']){

                        self::$direction_history_list[count(self::$direction_history_list)-1]['len']            + = $direction_history_list[$index]['len'];
                        self::$direction_history_list[count(self::$direction_history_list)-1]['delta_sum']      + = $direction_history_list[$index]['delta_sum'];
                        self::$direction_history_list[count(self::$direction_history_list)-1]['timestamp_to'] = $direction_history_list[$index]['timestamp_to'];

                    }
                    else
                        self::$direction_history_list[] = $direction_history_list[$index];

            }

        }

        if(count(self::$direction_history_list) === 0)
            self::$car_direction = null;
        else
            self::$car_direction=self::$direction_history_list[0]['direction'];

        self::$direction_list = $direction_list;

        return true;

    }

    /**
     * @return array
     */
    private static function set(){

        self::prepare_direction_new();

        return self::set_return();

    }

    /**
     * @return array
     */
    private static function set_return(){

        return [
            'point_len' => count(self::$track_list['default_track_list']),
            'car_direction' => self::$car_direction,
            'direction_history_list' => self::$direction_history_list,
            'direction_list' => self::$direction_list,
        ];

    }

    /**
     * @param array $track_list
     * @return array
     */
    public static function init(array $track_list = []){

        self::reset_data();

        self::$track_list = $track_list;

        return self::set();

    }

}