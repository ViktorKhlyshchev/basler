<?php

namespace CLI\Modules\CheckOffence;

use Core\Module\Polygon\Polygon;

class CheckOncomingLaneAction{

    /** @var string */
    private static $car_direction;

    /** @var array */
    private static $track_list = [];

    /** @var array */
    private static $zone_list = [];

    /** @var array */
    private static $result_list = [];

    /** @var string */
    private static $traffic_violation_key='lane_opposite';

    /** @var array */
    private static $is_oncoming_lane=false;

    /** @var array */
    private static $history_list = [];

    /** @var int */
    private static $timestamp_from;

    /** @var int */
    private static $timestamp_to;

    /**
     * @return bool
     */
    private static function reset_data(){

        self::$is_oncoming_lane =false;
        self::$timestamp_from = null;
        self::$timestamp_to = null;
        self::$result_list = [];

        return true;

    }

    /**
     * @return bool
     */
    private static function prepare_zone(){

        $zone_list = [];

        for($zone_index=0;$zone_index<count(self::$zone_list);$zone_index++)
            if(self::$zone_list[$zone_index]['direction']!=self::$car_direction){

                $zone_list[] = self::$zone_list[$zone_index];

                break;

            }

        if(empty($zone_list)) return false;

        self::$history_list = [
            [
                'is_oncoming_lane' => null,
                'len' => 0,
                'timestamp_from' => null,
                'timestamp_to' => null,
            ]
        ];

        $track_key_list =array_keys(self::$track_list);
        $track_list = [
            'default_car_number_coords' => self::$track_list['default_car_number_coords'],
            'converted_car_number_coords' => self::$track_list['converted_car_number_coords'],
        ];

        for($zone_index=0;$zone_index<count($zone_list);$zone_index++){

            for($index=0;$index<count(self::$track_list['default_track_list']);$index++){

                foreach($track_key_list as $track_key)
                    if($track_key!='default_car_number_coords'
                        &&$track_key!='converted_car_number_coords'
                    )
                        $track_list[$track_key] = [
                            self::$track_list[$track_key][$index]
                        ];

                if(Polygon::is_point_list_with_key_list_inside_zone($zone_list[$zone_index]['list'],$track_list,['left_up','left_down','right_up','left_down'])){
//                if(Polygon::is_point_list_inside_zone($zone_list[$zone_index]['list'],$track_list)){

                    if(!self::$is_oncoming_lane){

                        self::$is_oncoming_lane =true;
                        self::$result_list[] = $zone_list[$zone_index]['lane'];

                    }

                    if(is_null(self::$history_list[count(self::$history_list)-1]['is_oncoming_lane'])){

                        self::$history_list[count(self::$history_list)-1]['is_oncoming_lane'] =true;
                        self::$history_list[count(self::$history_list)-1]['timestamp_from'] =self::$track_list['default_track_list'][$index]['timestamp'];
                        self::$history_list[count(self::$history_list)-1]['timestamp_to'] =self::$track_list['default_track_list'][$index]['timestamp'];

                    }
                    else if(!self::$history_list[count(self::$history_list)-1]['is_oncoming_lane'])
                        self::$history_list[] = [
                            'is_oncoming_lane' => true,
                            'len' => 0,
                            'timestamp_from' => self::$track_list['default_track_list'][$index]['timestamp'],
                            'timestamp_to' => self::$track_list['default_track_list'][$index]['timestamp'],
                        ];
                    else
                        self::$history_list[count(self::$history_list)-1]['timestamp_to'] = self::$track_list['default_track_list'][$index]['timestamp'];

                }
                else{

                    if(is_null(self::$history_list[count(self::$history_list)-1]['is_oncoming_lane'])){

                        self::$history_list[count(self::$history_list)-1]['is_oncoming_lane'] =false;
                        self::$history_list[count(self::$history_list)-1]['timestamp_from'] =self::$track_list['default_track_list'][$index]['timestamp'];
                        self::$history_list[count(self::$history_list)-1]['timestamp_to'] =self::$track_list['default_track_list'][$index]['timestamp'];

                    }
                    else if(self::$history_list[count(self::$history_list)-1]['is_oncoming_lane']){

                        self::$history_list[] = [
                            'is_oncoming_lane' => false,
                            'len' => 0,
                            'timestamp_from' => self::$track_list['default_track_list'][$index]['timestamp'],
                            'timestamp_to' => self::$track_list['default_track_list'][$index]['timestamp'],
                        ];

                    }
                    else
                        self::$history_list[count(self::$history_list)-1]['timestamp_to'] = self::$track_list['default_track_list'][$index]['timestamp'];

                }

                self::$history_list[count(self::$history_list)-1]['len']++;

            }

        }

        for($index=0;$index<count(self::$history_list);$index++)
            if(self::$history_list[$index]['is_oncoming_lane']){

                self::$timestamp_from=self::$history_list[$index]['timestamp_from'];

                break;

            }

        for($index=count(self::$history_list)-1;$index>=0;$index--)
            if(self::$history_list[$index]['is_oncoming_lane']){

                self::$timestamp_to=self::$history_list[$index]['timestamp_to'];

                break;

            }

        return true;

    }

    /**
     * @return array
     */
    private static function set(){

        self::prepare_zone();

        return self::set_return();

    }

    /**
     * @return array
     */
    private static function set_return(){

        return [
            'is_oncoming_lane' => self::$is_oncoming_lane,
            'traffic_violation_zone' => self::$traffic_violation_key,
            'list' => self::$result_list,
            'history_list' => self::$history_list,
            'timestamp_from' => self::$timestamp_from,
            'timestamp_to' => self::$timestamp_to,
        ];

    }

    /**
     * @param array $journal_data
     * @param array $zone_list
     * @return array
     */
    public static function init(array $journal_data = [], array $zone_list = array()){

        self::reset_data();

        self::$car_direction = $journal_data['direction'];
        self::$track_list = $journal_data['track_list'];
        self::$zone_list = $zone_list;

        return self::set();

    }

}