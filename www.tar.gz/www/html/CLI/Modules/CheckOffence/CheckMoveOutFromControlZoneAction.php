<?php

namespace CLI\Modules\CheckOffence;

use Core\Module\Polygon\Polygon;

class CheckMoveOutFromControlZoneAction{

    /** @var string */
    private static $car_direction;

    /** @var array */
    private static $track_list = [];

    /** @var array */
    private static $zone_list = [];

    /** @var array */
    private static $result_list = [];

    /** @var array */
    private static $is_move_out_from_zone=false;

    /**
     * @return bool
     */
    private static function reset_data(){

        self::$is_move_out_from_zone =false;
        self::$result_list = [];
        self::$car_direction = null;

        return true;

    }

    /**
     * @return bool
     */
    private static function prepare_zone(){

        for($zone_index=0;$zone_index<count(self::$zone_list);$zone_index++){

            switch(self::$car_direction){

                case 'up':{

                    $is_inside_buffer_up =Polygon::is_point_list_with_key_list_inside_zone(self::$zone_list[$zone_index]['buffer_zones']['up'], self::$track_list,['right_up']);
                    $is_inside_buffer_right =Polygon::is_point_list_with_key_list_inside_zone(self::$zone_list[$zone_index]['buffer_zones']['right'], self::$track_list,['right_up']);

                    self::$is_move_out_from_zone = $is_inside_buffer_up || $is_inside_buffer_right;

                    if($is_inside_buffer_up)
                        self::$result_list[] = 'up';

                    if($is_inside_buffer_right)
                        self::$result_list[] = 'right';

                    break;

                }

                case 'down':{

                    $is_inside_buffer_down =Polygon::is_point_list_with_key_list_inside_zone(self::$zone_list[$zone_index]['buffer_zones']['down'], self::$track_list,['left_down']);
                    $is_inside_buffer_left =Polygon::is_point_list_with_key_list_inside_zone(self::$zone_list[$zone_index]['buffer_zones']['left'], self::$track_list,['left_down']);

                    self::$is_move_out_from_zone = $is_inside_buffer_down || $is_inside_buffer_left;

                    if($is_inside_buffer_down)
                        self::$result_list[] = 'down';

                    if($is_inside_buffer_left)
                        self::$result_list[] = 'left';

                    break;

                }

            }

            if(self::$is_move_out_from_zone)
                return true;

        }

        return true;

    }

    /**
     * @return array
     */
    private static function set(){

        self::prepare_zone();

        return self::set_return();

    }

    /**
     * @return array
     */
    private static function set_return(){

        return [
            'is_move_out_from_zone' => self::$is_move_out_from_zone,
            'list' => self::$result_list,
        ];

    }

    /**
     * @param array $track_list
     * @param array $zone_list
     * @param string|null $car_direction
     * @return array
     */
    public static function init(array $track_list = [], array $zone_list = array(),string $car_direction = null){

        self::reset_data();

        self::$car_direction = $car_direction;
        self::$track_list = $track_list;
        self::$zone_list = $zone_list;

        return self::set();

    }

}