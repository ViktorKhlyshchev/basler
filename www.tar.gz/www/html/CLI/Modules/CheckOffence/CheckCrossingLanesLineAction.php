<?php

namespace CLI\Modules\CheckOffence;

use Core\Module\Lines\Lines;

class CheckCrossingLanesLineAction{

    /** @var array */
    private static $track_list = [];

    /** @var array */
    private static $zone_list = [];

    /** @var array */
    private static $result_list = [];

    /** @var string */
    private static $traffic_violation_key='lane';

    /** @var array */
    private static $is_crossing_lanes_lines=false;

    /** @var int */
    private static $timestamp;

    /**
     * @return bool
     */
    private static function reset_data(){

        self::$is_crossing_lanes_lines =false;
        self::$timestamp = null;
        self::$result_list = [];

        return true;

    }

    /**
     * @return bool
     */
    private static function prepare_zone(){

        for($zone_index=0;$zone_index<count(self::$zone_list);$zone_index++)
            if(isset(self::$zone_list[$zone_index]['denied_line_list']))
                foreach(self::$zone_list[$zone_index]['denied_line_list'] as $direction_key => $zone_line){

                    $r = Lines::is_crossing_lines_from_track_list(self::$track_list,$zone_line);

                    if(!empty($r)){

                        self::$is_crossing_lanes_lines =true;
                        self::$timestamp = $r['timestamp'];
                        self::$result_list[] = $direction_key;

                    }

                }

        return true;

    }

    /**
     * @return array
     */
    private static function set(){

        self::prepare_zone();

        return self::set_return();

    }

    /**
     * @return array
     */
    private static function set_return(){

        return [
            'is_crossing_lanes_lines' => self::$is_crossing_lanes_lines,
            'traffic_violation_zone' => self::$traffic_violation_key,
            'list' => self::$result_list,
            'timestamp' => self::$timestamp,
        ];

    }

    /**
     * @param array $track_list
     * @param array $zone_list
     * @return array
     */
    public static function init(array $track_list = [], array $zone_list = array()){

        self::reset_data();

        self::$track_list = $track_list;
        self::$zone_list = $zone_list;

        return self::set();

    }

}