<?php

namespace CLI\Modules; # namespace Project\Aist\Admin\Action\Image;

use Core\Modules\Dir;
use Configs\DirConfig;
use Common\Models\Image\Image;
use Common\Models\Image\ImageItem;
use Common\Modules\ImagePathAction;

class CloneImageAction {

    private static $source_image_id;
    private static $result_image_id;
    public static $error;
    public static $errors;

    public static function init(int $image_id = null){
        self::$error = null;
        self::$errors = [];
        if(empty($image_id)) return null;
        self::$source_image_id = $image_id;
        if(self::prepare_image()) return self::$result_image_id;
    }

    private static function get_image_mime_type(string $image_type = null){
        switch($image_type){
            case 'jpg':
            case 'jpeg':{
                $image_mime_type = 'image/jpeg';
                $image_extension = 'jpg';
                break;
            }
            case 'png':{
                $image_mime_type = 'image/png';
                $image_extension = 'png';
                break;
            }
            default: return null;
        }
        return ['image_mime_type' => $image_mime_type, 'image_extension' => $image_extension ];
    }

    private static function prepare_image(){ #pred(debug_backtrace());
        $r = ImagePathAction::get_image_path_data(self::$source_image_id,true,true,true);
        if(empty($r)) return false;
        $image_path = $r['image_dir'].'/'.$r['image_item_id_list']['source']['id'];
        if(!file_exists($image_path)){ #trigger_error("file not exist!! Path:_".$image_path, E_USER_WARNING);
            self::$error = __FUNCTION__ .': file not exist!! ImageID: '. self::$source_image_id .' Path:_'.$image_path;
            self::$errors[] = self::$error;
            return;
        }
        $image_type = Image::get_image_type_from_file_path($image_path);
        if(isset($image_type['error'])){
            self::$error = $image_type['error'];
            self::$errors[] = $image_type['error'];
            return;
        }
        $image_size = Image::get_image_pixel_size_from_file_path($image_path);
        if(!$image_size){
            self::$error = error_get_last();
            self::$errors[] = self::$error; #  pred($error);
            return; # pred($image_size);
        }
        $image_type_data = self::get_image_mime_type($image_type);
        $image_mime_type = $image_type_data['image_mime_type'];
        $image_extension = $image_type_data['image_extension'];
        $image_data = Image::add_image(
            null,
            $image_mime_type,
            filesize($image_path),
            $image_mime_type,
            $image_extension,
            false,
            true,
            true,
            false,
            true,
            $image_size['width'],
            $image_size['height']
        );
        self::$result_image_id = $image_data['id'];
        $result_image_date_create = $image_data['date_create'];
        if(empty(self::$result_image_id)) return false;
        $image_item_id = ImageItem::add_image_item(
            null,
            self::$result_image_id,
            $image_size['width'],
            $image_size['height'],
            'source',
            $image_mime_type,
            filesize($image_path),
            $image_mime_type,
            $image_extension,
            false, true, true, false
        );
        $dir_image = Dir::get_dir_from_date(DirConfig::$dir_image, $result_image_date_create) .'/'. self::$result_image_id;
        $result_image_path = $dir_image .'/'. $image_item_id .'.'. $image_extension;
        $r = Dir::create_dirn($dir_image); if(!$r) pred("cant create dir!!". $dir_image); #pred($r);
        if(!copy($image_path,$result_image_path)) return false;
        return true;
    }
}