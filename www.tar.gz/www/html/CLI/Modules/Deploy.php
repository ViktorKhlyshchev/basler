<?php

namespace CLI\Modules;

use Configs\DirConfig;

class Deploy {

    static $inwork = false;

    public static function init(){ # statistics и setting_debug?
        self::create_dirs();
    }

    public static function create_dirs(){ # subdir
        $dp = DR .'/'. DirConfig::$dir_log;
        $dp = DR .'/'. DirConfig::$dir_log .'/'. $sdir;
    }

}