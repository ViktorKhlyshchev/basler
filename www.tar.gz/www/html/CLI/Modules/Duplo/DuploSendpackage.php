<?php

namespace CLI\Modules\Duplo;

use Common\Models\Journal;
use Common\Models\Sending;

class DuploSendpackage {

    public $error = false;
    public $object_name;
    public $jid;
    public $journal_ftp_send_id;
    public $journal_hash;
    public $dir_box;
    public $dir_box_source;
    public $dir_box_keys;
    public $dir_box_tar;
    public $tar_file_path;
    public $file_size;
    public $date_create;
    public $offence;
    public $timestamp;
    public $is_all_ftp_send;
    public $strys;
    public $errors = [];
    public $log = [];
    public $duplo_data = false;
    public $test;

    public $ftp_list = [];
    public $timezone;

    function set_error($error){
        $this->errors = $error;
        Journal::update_journal_to_error($this->jid, $this->errors, 0);
    }

    function set_cerror($error){ # set_crucial_error
        $this->errors = $error;
        Journal::update_journal_to_error($this->jid, $this->errors, 1);
    }

    function __construct(array $data = [], array $serv = []){ #pred($data);
        $this->log[] = 'DuploSendpackage INIT start';
        if(isset($data['id'])) $this->id = $data['id'];
        if(isset($data['jid'])) $this->jid = $data['jid'];
        $this->data = $data;
        $this->serv = $serv;
    }

    function send(string $extra_headers = ''){        #pred($this->serv);        #pred($this); #$remove_all = true;        if(isset(\Config::$remove_all)) $remove_all = \Config::$remove_all;

        $this->log[] = 'b send_package_list()'; # XavierInfo::increment_trysend(); #pre($this->data); pred($this->serv);  #function send_curl(&$url, &$xml, &$xml_size){  # CURL $r = CreateBoxAction::check_source_image_files($tid);
        $this->url = $this->serv['protocol'] .'://'. $this->serv['ip_address'];
        $purl = parse_url($this->url); #pre($purl);
        #if((cli && hand) || ajax) pre($purl);
        if((cli && hand)) pre($purl);
        $xml = file_get_contents($this->data['file_path']); #pre($this->data['file_path']); pt($xml); pred($xml);
        if(!$xml){ $txt = __CLASS__ .'::'. __FUNCTION__ .': Cant load xml file, fp:__'. $this->data['file_path']; $this->set_cerror($txt); if((cli && hand) || ajax) pre($txt); return; }
        if(!$this->data['file_size']){
            $this->data['file_size'] = filesize($this->data['file_path']);
            if(!$this->data['file_size']){ $er = '! filesize is wrong $this->data[file_size]'; pre($er); $this->set_cerror($er); return; }
        }
        $headers = [
            'Host: '. $purl['host'],
            "Content-Type: application/soap+xml;charset=utf-8",
            "Content-Length: ". $this->data['file_size'] # mb_strlen($xml) #pre(strlen($xml));        #pred(mb_strlen($xml));
        ]; #pred(ajax);
        if($extra_headers) $headers[] = $extra_headers; # User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 pred($headers); User-Agent
        #if((cli && hand) || ajax){ pre($headers); pre($this->url); } #pre($xml);
        if(cli && hand){ pre($headers); pre($this->url); } #pre($xml);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->url);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_TIMEOUT,       10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true); #curl_setopt($ch, CURLOPT_VERBOSE, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $response = curl_exec($ch); # pred($response);
        #if((cli && hand) || ajax) pre($response); #pred($response);
        if((cli && hand)) pre($response); #pred($response);
        $r = (bool)strpos($response, '<return>true</return>'); # pre((bool)strpos($r, '<return>true</return>'));
        if(!$r) $this->log[] = '| send_curl $response:__'. $response .' |';
        curl_close($ch); #pred($response);
        $r = strpos($response, '<return>true</return>'); #pre($this->test); pred(!$this->test);
        if(!$this->test) Sending::update_log($this->id, implode("|\n", $this->log));

        if($r !== false) return true;

        if(!$this->test){
            $this->set_cerror($response);
            $this->set_cerror('!send_xml()');
        }
        return;
        $response1 = str_replace("<soap:Body>","",$response);
        $response2 = str_replace("</soap:Body>","",$response1);pred($response2);
        $parser = simplexml_load_string($response2);
        #pred($parser->{0});        pred($parser[0]);        pred($parser['0']);        pred($parser[0]);        pred($parser);
    }
}