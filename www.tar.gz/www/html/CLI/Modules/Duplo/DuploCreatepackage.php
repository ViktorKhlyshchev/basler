<?php

namespace CLI\Modules\Duplo;

use Core\Modules\Dir;
use Configs\DirConfig;
use Common\Modules\ImagePathListAction;
use Project\Aist\Admin\Action\Video\VideoPathListAction;
use Common\Models\Journal;
use Common\Models\JournalImage;
use Common\Models\JournalVideo;
use Common\Models\XavierInfo;
use Common\Models\Zone;
use Common\Models\Packing;
use Common\Models\PackingQ;
use Common\Models\Processing;
use Common\Models\Image\Image;
use Project\Aist\Admin\Module\Car\CarNumberValidation;
use Common\Modules\Date;
use Core\Module\Geo\Country;

class DuploCreatepackage {

    public $sets;
    public $error = false;
    public $jid;
    public $journal_hash;
    public $xml;
    public $country_code;
    public $date;
    public $address;
    public $coords;
    public $timezone;

    public $duplo_ids = [];
    public $video_list = [];
    public $image_list = [];

    public $errors = [];
    public $log = [];
    public $flog = [];
    public $data = [];
    public $car_number_width;
    public $car_number_height;
    public $car_number_coords;

    public $doffence_list = [  #'none' => 'Без нарушений.',
        'route_vehicles' => 5,
        'speed_20' => 2,
        'speed_40' => 2,
        'speed_60' => 2,
        'speed_80' => 2,
        'lane_opposite' => 4
    ];

    function set_error($error = null){ # $this->error = $error; $error
        if(!$error) $errors[] = $error; pred($error);  #if(loc) pred($this->errors); else pre($this->errors);
        Journal::update_error($this->jid, implode('|', $this->errors));
        Packing::update_error($this->id, implode('|', $this->errors));
        Processing::update_error($this->jid, implode('|', $this->errors));
        $this->errors = [];
    }

    function set_cerror($error = null){ #unset($this->track_number_list); unset($this->image_list); unset($this->car_number_coords); unset($this->files_paths); unset($this->video_list); unset($this->log); unset($this->combo_car_number_coords); #pred(debug_backtrace()); pred($this->errors);
        if($error) $this->errors[] = $error; #pred($this->errors);
        #if(loc) pred(debug_backtrace());
        if(loc) pre($this->errors); else pre($this->errors);
        Journal::update_error($this->jid, implode("\n", $this->errors));
        PackingQ::update_error($this->id, implode("\n", $this->errors)); # Processing::update_cerror($this->jid, implode("\n", $this->errors));
        $this->errors = [];
    }

    function __construct(array $data = [], array $serv = [], &$dpmt){ #pred($data);

        $this->log[] = 'DuploCreatepackage INIT start';

        $this->sets = $dpmt->sets;

        $this->id = $data['id'];
        $this->jid = $data['jid'];
        $this->serv = $serv;
        $this->pdata = &$data; #pred($this->jdata);
        $this->offence = &$data['offence']; #pred($this->jdata);
        if($this->offence === 'none') $this->offence = null;
    }

    function create(){

        if(!$this->prepare_dir()){ $this->set_cerror('!prepare_dir()'); return; }
        $this->getdata(); #pred($data);
        $this->getxmldata();  #pred($this->xmldata);
        $duploxml = new DuploXML($this->xmldata); #        pred($this->xml);
        if(!$duploxml->fill()){ $this->set_cerror('!$duploxml->fill()'); return; } # pred($this->traffic_violation_date); pred(array_keys($this->data));  pred($this->data); #pred($this->$data['date_traffic_violation']
        $ymdp = Date::get_ymd_path($this->traffic_violation_date); #pred($this->files_paths);  pred($ymdp); #$this->tar_dp = DR .'/'. DirConfig::$dir_cafap_package_tar .'/'. $ymdp; #$fp = $this->dir_package .'/duplo_'. $this->jid .'.xml';#pred($this->xml);
        $dp = $this->dir_package .'/'. $ymdp;
        if(!Dir::create_dirn($dp)) er('cant create dir for XML #93 '. __FUNCTION__ .' dir:__'. $dp);
        $fp = $this->dir_package .'/'. $ymdp .'/duplo_'. $this->jid .'.xml'; #pred($this->xml);
        $r = file_put_contents($fp, $duploxml->xml);
        if(!$r){ $this->set_cerror('Cant save xml file! fp__'. $fp); return; }
        return $fp;
    }

    function prepare_dir(){
        $this->log[] = 'prepare_dir()';
        if(!Dir::create_dirn(DirConfig::$dir_duplo_xml)){ $this->set_cerror('cant create dir '. __FUNCTION__ .'#1 dir:__'. DirConfig::$dir_cafap_package); return; }
        $this->dir_package = DR .'/'. DirConfig::$dir_duplo_xml;
        return true;
    }

    function getdata(){

        $select = [
            'id', 'car_number',
            'camera_id', 'country_id',
            'speed', 'lane',
            'speed_quality',
            'direction',
            'traffic_violation',
            'date_create', 'date_traffic_violation'
        ];
        $data = Journal::getbid($this->jid, $select);
        if(!$data){ $this->set_cerror('Xavier info is empty '. __FUNCTION__); return; } #        $this->jdata = $data;
        $this->data = &$data;

        $image_id_list = $this->get_source_image_files($this->jid); #pre(count($image_id_list)); pred($image_id_list);
        if(!$image_id_list){ $this->set_cerror('! get_source_image_files($this->jid)'); return; }   #$this->get_lpn_coords($this->jid); #pre(count($image_id_list)); pred($image_id_list);

        if($this->offence){
            $video_id_list = JournalVideo::get_videos_ids($this->jid); #pred($video_id_list); //if(!$video_id_list){ $this->set_cerror('! JournalVideo::get_videos_ids($this->jid)'); return; }
        } else $video_id_list = null;

        $xr = XavierInfo::get_list_from_group('about'); # TODO FOR OPTIMIZATION - MOVE THIS TO DuploPackMThread and check this not every time, but about after 10 iters
        if(empty($xr)){ $this->set_cerror('Xavier info is empty '. __FUNCTION__); return; }
        $this->timezone = $xr['about']['timezone'];
        if($xr['about']['coords'] === '-'){ $coords = ''; pre('Xavier coords info is empty'); } else  $coords = explode(',', $xr['about']['coords']);
        if($xr['about']['address']) $address = $xr['about']['address']; else $address = ''; #pred($xr); # about	address #$date = $data['date_traffic_violation'];
        $this->traffic_violation_ts = Date::get_ts_from_date_time_ms($data['date_traffic_violation']);

        if(strpos($this->timezone, ':') !== false){
            $date1 = \DateTime::createFromFormat('H:i', $this->timezone);
            $interval = $date1->diff(\DateTime::createFromFormat('H:i', '00:00'));
            $this->timestamp = (int)$this->traffic_violation_ts + $interval->h * 3600 + $interval->i * 60; #pred($this->timestamp);
        } else {
            $this->timestamp = (int)$this->traffic_violation_ts + (int)$this->timezone * 3600; #pred($this->timestamp);
        } #$this->xmltimestamp = (int)$this->traffic_violation_ts;

        $this->traffic_violation_date = \DateTime::createFromFormat('U', $this->timestamp); #pred($this->traffic_violation_date); #$date = date("Y-m-d\TH:i:s\Z", strtotime($date)); #pred($date); #if(!$data['traffic_violation']){ $this->set_cerror('Отсутствует нарушение для дупла! #1'); return; }
        $date = date("Y-m-d\TH:i:s", $this->timestamp);

        $data['coords'] = $coords;
        $data['address'] = $address;
        $data['date'] = $date;
        $data['image_coords_list'] = $image_id_list; # 'image_list' => ImagePathListAction::get_image_path_list($image_id_list,true,true,true,['source']),
        $data['image_id_list'] = &$image_id_list;
        $data['video_id_list'] = &$video_id_list;
        return true;
    }

    function get_source_image_files($tid){ # $source_image_list = JournalImage::get_image_list_from_keys_src($tid, ['middle']); pred($source_image_list);
        $source_image_list = JournalImage::get_image_list_from_keys_src($tid, ['middle', 'prepared_combo']); #pred($source_image_list);
        #$source_image_list = JournalImage::get_image_list_from_keys_src($tid, ['prepared_combo']); #pred($source_image_list);
        foreach($source_image_list as $k => &$v) unset($v['track_coords']);
        if(empty($source_image_list)){ $this->set_cerror('Journal image list is empty #161'); return; }
        $image_id_list = [];
        foreach($source_image_list as $k => $image_row){
            if(!empty($image_row['image_id'])) $image_id_list[] = $image_row['image_id']; else pre($image_row);
            $source_image_list[$image_row['image_id']] = $image_row;
        }        #pre($source_image_list); pred($image_id_list);
        if(empty($image_id_list)) pred($tid, 'Journal image id list is empty', 1);
        $image_path_list = ImagePathListAction::get_image_path_list($image_id_list, true, true, true); #pred($image_path_list);
        foreach($image_path_list as $k => &$image_row){
           if(isset($source_image_list[$image_row['image_id']]['car_number_coords'])) $image_path_list[$k]['nc'] = $source_image_list[$image_row['image_id']]['car_number_coords']; # nc - number coords - car number coords for cutting car number!
            $file_path = Dir::get_global_dir($image_row['image_dir']) .'/'. $image_row['image_item_id_list']['source']['id'];
            if(!file_exists($file_path)){ $this->set_cerror('Image is not exists:__'. $file_path); return; }
            $file_size = filesize($file_path); #pred($file_size);
            if($file_size < 100){ $this->set_cerror('Image have not valid file size:__'. $file_size .' path: '. $file_path); return; }
            $image_row['imagefp'] = $file_path;
        } #pred($image_path_list);
        return $image_path_list;
    }

    /*function get_lpn_coords($tid){ # $source_image_list = JournalImage::get_image_list_from_keys_src($tid, ['middle']); pred($source_image_list);
        $source_image_list = JournalImage::get_image_list_from_keys_src($tid, ['middle']);#pred($source_image_list);
        foreach($source_image_list as $k => &$v) unset($v['track_coords']);
        if(empty($source_image_list)){ $this->set_cerror('Journal image list is empty #161'); return; }
        $image_id_list = [];
        foreach($source_image_list as $k => $image_row){
            if(!empty($image_row['image_id'])) $image_id_list[] = $image_row['image_id']; else pre($image_row);
            $source_image_list[$image_row['image_id']] = $image_row;
        }        #pre($source_image_list); pred($image_id_list);
        if(empty($image_id_list)) pred($tid, 'Journal image id list is empty #194', 1);
        $this->car_number_coords = $source_image_list[0]['car_number_coords']; #pre($this->car_number_coords); pred($source_image_list[0]);
    }*/

    function getxmldata(){

        $data = &$this->data; #pred($data);

        $video_id_list = $data['video_id_list']; #pred($data); pred($video_id_list);
        $image_id_list = $data['image_id_list'];
        unset($data['image_id_list']); #pred($image_id_list);
        unset($data['video_id_list']); #pred($image_id_list);
        $lpn_jpg = null;
        foreach($image_id_list as $v){ #pred($v);
            $image = Image::get_image_object_from_file_path($v['imagefp']); # set_source_image_path
            $image_vehicle = $image;
            if(0){
                header('Content-Type: image/jpeg');
                imagejpeg($image_vehicle); #imagejpeg($image_cropped);
                die;
            }            #pred($image_before_object);   #pred($v['nc']); #76x19 148x37 72x16

            if(isset($v['nc'])){
                $v['nc'][0]['x']-=36; $v['nc'][0]['y']-=9;
                $v['nc'][1]['x']+=36; $v['nc'][1]['y']+=9;
                $v['nc'][2]['x']-=36; $v['nc'][2]['y']-=9;
                $v['nc'][3]['x']+=36; $v['nc'][3]['y']+=9;
                $car_number_width = $v['nc'][3]['x']-$v['nc'][0]['x'];
                $car_number_height = $v['nc'][3]['y']-$v['nc'][0]['y'];
                $image_size_list = ['x' => $v['nc'][0]['x'], 'y' => $v['nc'][0]['y'], 'width' => $car_number_width, 'height' => $car_number_height]; #pred($image_size_list);
                $image_cropped = imagecrop($image, $image_size_list);
                $image_res = imagecreatetruecolor($car_number_width, $car_number_height);
                #imagecopyresized($image_before_result, $image_before_object_cropped, 0, 0, 0, 0, $image_before_cropped_w, $image_before_cropped_h, $image_size_list['width'], $image_size_list['height']); #
                imagecopy($image_res, $image_cropped, 0, 0, 0, 0, $car_number_width, $car_number_height); #$jpgi = imagejpeg($image_res); #pred($jpgi); #pred($image_cropped);
                if(0){
                    header('Content-Type: image/jpeg');
                    imagejpeg($image_res); #header("Content-type: image/png");imagepng($image_cropped);
                    imagedestroy($image_res);
                    die;
                }
                $lpn_jpg = base64_encode($this->imagejpeg_tostring($image_res));
                continue;
            } else { #

               /* pred($this->car_number_coords);
                $this->car_number_coords[0]['x']-=36; $this->car_number_coords[0]['y']-=9;
                $this->car_number_coords[1]['x']+=36; $this->car_number_coords[1]['y']+=9;
                $this->car_number_coords[2]['x']-=36; $this->car_number_coords[2]['y']-=9;
                $this->car_number_coords[3]['x']+=36; $this->car_number_coords[3]['y']+=9;
                $car_number_width = $this->car_number_coords[3]['x']-$this->car_number_coords[0]['x'];
                $car_number_height = $this->car_number_coords[3]['y']-$this->car_number_coords[0]['y'];
                $image_size_list = ['x' => $this->car_number_coords[0]['x'], 'y' => $this->car_number_coords[0]['y'], 'width' => $car_number_width, 'height' => $car_number_height]; #pred($image_size_list);
                $image_cropped = imagecrop($image, $image_size_list);
                $image_res = imagecreatetruecolor($car_number_width, $car_number_height);
                #imagecopyresized($image_before_result, $image_before_object_cropped, 0, 0, 0, 0, $image_before_cropped_w, $image_before_cropped_h, $image_size_list['width'], $image_size_list['height']); #
                imagecopy($image_res, $image_cropped, 0, 0, 0, 0, $car_number_width, $car_number_height); #$jpgi = imagejpeg($image_res); #pred($jpgi); #pred($image_cropped);
                if(0){
                    header('Content-Type: image/jpeg');
                    imagejpeg($image_res); #header("Content-type: image/png");imagepng($image_cropped);
                    imagedestroy($image_res);
                    die;
                }
                $lpn_jpg = base64_encode($this->imagejpeg_tostring($image_res));*/
            }


            $vehicle_jpg = base64_encode($this->imagejpeg_tostring($image_vehicle));
        } #pred($jpgi); #pred($image_list); #pred($data); #pre($video_id_list);

        if($this->offence){
            $video_path_list = VideoPathListAction::get_video_path_list($video_id_list, true, true, true); #pre($video_path_list); #pred($data['photo_extra']);
            $data['photo_extra'] = [];
            foreach($video_path_list as $row){
                $source_video_path = Dir::get_global_dirn($row['video_dir']. '/'. $row['video_item_id_list']['source']['id']);
                $vid = file_get_contents($source_video_path);
                if(!$vid){ $this->set_cerror('Cant get source_video, fp:__'. $source_video_path); continue; }
                $data['photo_extra'][] = [
                    'v_frame_datetime' => $data['date'],
                    'v_photo_extra' => base64_encode($vid),
                    'v_type_photo' => 3
                ];
            }
            #if(!$data['photo_extra']){ $this->set_cerror('! $data[photo_extra]'); return; }
        } #pred($vid); #pred($lpn_jpg); /*<v_frame_datetime>$v_frame_datetime</v_frame_datetime><v_photo_extra>$v_photo_extra</v_photo_extra><v_type_photo>$v_type_photo</v_type_photo>*/
        $data['v_time_check'] = &$data['date'];
        $data['v_camera'] = $this->serv['camera_cid'];
        $data['v_regno_color_id'] = 0;
        $data['v_azimut'] = 0;
        $data['v_regno_country_id'] = empty($data['country_id']) ? 'RU' : strtoupper(Country::get_country_code_from_country_id($data['country_id']));
        #$data['v_regno_country_id'] = strtoupper($data['country_code']); #'RUS' if(is_array($data['v_regno_country_id'])) $data['v_regno_country_id'] = 'RU';
        $data['v_recognition_accuracy'] = &$data['speed_quality'];
        $data['v_photo_grz'] = $lpn_jpg;
        $data['v_photo_ts'] = $vehicle_jpg;  #pred($data['speed']);

        #pre($this->sets['common_pack']['min_speed_quality_for_speed_na']); pre($this->sets['common_pack']['max_speed_for_speed_na']); pre($data['speed_quality']); pred($data['speed']);
        if($data['speed'] > $this->sets['common_pack']['max_speed_for_speed_na'] || $data['speed'] < 0){
            $data['v_speed'] = 'n/a';
        } else {
            if($data['speed_quality'] < $this->sets['common_pack']['min_speed_quality_for_speed_na']){
                if($data['speed'] > $this->sets['zone']['speed_permissible']) $data['v_speed'] = 'n/a';
            }
        }

        if(!isset($data['v_speed']) || $data['v_speed'] !== 'n/a') $data['v_speed'] = explode('.', $data['speed'])[0]; else $data['v_speed'] = null;

        $data['v_lane_num'] = &$data['lane'];
        $data['v_regno'] = mb_strtoupper(CarNumberValidation::get_cyr_car_number($data['car_number'])); #pred($data);
        if($data['address']) $data['v_camera_place'] = &$data['address']; #pred($data);
        if(!$data['v_camera']){ $this->set_cerror('Укажите id камеры для дупла!'); return; }

        if(isset($this->doffence_list[$data['traffic_violation']])) $data['v_pr_viol'] = $this->doffence_list[$data['traffic_violation']];
        $data['v_direction'] = '';
        if($data['direction'] === 'down') $data['v_direction'] = 1;
        if($data['direction'] === 'up') $data['v_direction'] = 0; #pred($data['date']);
        $xmldata = [
            'v_time_check' => $data['v_time_check'],
            'v_camera' => $data['v_camera'], # 'v_camera' => 'Aist1',
            'v_speed' => $data['v_speed'], #'v_azimut' => $data['v_azimut'],
            'v_direction' => $data['v_direction'],
            'v_regno_country_id' => $data['v_regno_country_id'], # RUS 'v_regno_color_id' => $data['v_regno_color_id'], # 0
            'v_recognition_accuracy' => $data['v_recognition_accuracy'],
            'v_regno' => $data['v_regno'],
            'v_camera_place' => $data['v_camera_place'],
            'v_photo_grz' => $data['v_photo_grz'],
            'v_photo_ts' => $data['v_photo_ts'],
            'v_lane_num' => $data['v_lane_num'],            #'v_pr_viol' => $data['v_pr_viol'],
        ];
        if(isset($data['photo_extra'])) $xmldata['photo_extra'] = $data['photo_extra']; #pred($data); pred($data['coords']);
        if(isset($data['coords'])){
            $xmldata['v_gps_x'] = $data['coords'][1]; # TODO WARNING
            $xmldata['v_gps_y'] = $data['coords'][0];
        } #pred($xmldata);
        if(isset($data['v_pr_viol']) !== false) $xmldata['v_pr_viol'] = $data['v_pr_viol'];

        if(isset($data['traffic_violation']) && strpos($data['traffic_violation'], 'speed_') !== false){
            $xmldata['v_speed_limit'] = Zone::get_zone_speed_max($data['camera_id']); # was set_zone_data(){
            if(!$xmldata['v_speed_limit']){ $this->set_cerror('Не указано ограничение скорости!'); return; }
        } #pred($xmldata);
        $this->xmldata = $xmldata;
        return true;
    }

    function imagejpeg_tostring($im){
        ob_start(); //Stdout --> buffer
        imagejpeg($im); // output ... #$imgString = ob_get_contents(); //store stdout in $imgString
        $imgString = ob_get_clean(); //clear buffer
        imagedestroy($im); //destroy img
        return $imgString;
    }
}