<?php

namespace CLI\Modules\Duplo;

class DuploXML {    # Message part {http://schemas.xmlsoap.org/wsdl/}definitions was not recognized

	public $data;
	public $xml;

    public function __construct($data = []){
		if(!$data) return;
		$this->data = &$data;
	}

    public function fill(){ #pred($this->data);
		extract($this->data);

		$photo_extras = '';
		if(isset($photo_extra)) foreach($photo_extra as $pe){ extract($pe); #pred($pe);
			$photo_extras .= <<<PE
<photo_extra>
	<v_frame_datetime>$v_frame_datetime</v_frame_datetime>
	<v_photo_extra>$v_photo_extra</v_photo_extra>
	<v_type_photo>$v_type_photo</v_type_photo>
</photo_extra>
PE;
		}

		if(isset($v_pr_viol)) $v_pr_viol = '<v_pr_viol>'. $v_pr_viol .'</v_pr_viol>'; else $v_pr_viol = ''; #pred($v_pr_viol);
		if($v_gps_x) $v_gps_x = '<v_gps_x>'. $v_gps_x .'</v_gps_x>'; else $v_gps_x = ''; #pred($v_pr_viol);
		if($v_gps_y) $v_gps_y = '<v_gps_y>'. $v_gps_y .'</v_gps_y>'; else $v_gps_y = '';
		if(is_null($v_speed)) $v_speed = ''; else $v_speed = '<v_speed>'. $v_speed .'</v_speed>';

    	$xml = <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ser="http://service/">
   <soap:Header/>
   <soap:Body>
      <ser:process>
         <message>
			<tr_checkIn>
				<v_time_check>$v_time_check</v_time_check>
				<v_camera>$v_camera</v_camera>$v_gps_x$v_gps_y
				<v_direction>$v_direction</v_direction>$v_speed
				<v_regno_country_id>$v_regno_country_id</v_regno_country_id>
				<v_recognition_accuracy>$v_recognition_accuracy</v_recognition_accuracy>
				<v_regno>$v_regno</v_regno>$v_pr_viol
				<v_lane_num>$v_lane_num</v_lane_num>
				<v_camera_place>$v_camera_place</v_camera_place>
				<v_photo_grz>$v_photo_grz</v_photo_grz>
				<v_photo_ts>$v_photo_ts</v_photo_ts>
			</tr_checkIn>$photo_extras
         </message>
      </ser:process>
   </soap:Body>
</soap:Envelope>
XML;
		$this->xml = $xml;
		return true;
    }
}