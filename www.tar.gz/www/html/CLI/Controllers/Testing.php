<?php

namespace CLI\Controllers;

use CLI\Modules\CLIController;
use Common\Models\Packing;

class Testing extends CLIController {

    function __construct($action = null){       #global $req;
        parent::__construct();     #$req::init();         pred($this->action);
        if(!$action) $action = $this->req->post('action'); #pred($action);
        if($action === 'priw') $this->priw(); # package reset in work        #if(!$action) $this->page();
        if($action === 'pgriw') $this->pgriw();
    }

    function priw(){
        $tid = (int)$this->req->post('tid'); #pred($tid);
        $r = Packing::reset_inwork($tid, 11122233); if(hand){ pre($r); pre(count($r)); } # $r = Packing::reset_inwork_to_nocreate($this->tid, $prid); if(hand && $r) pre($r);
    }

    function pgriw(){
        $tid = (int)$this->req->post('tid'); #pred($tid);
        $r = Packing::get_resets_inwork($tid); if(hand){ pre($r); pre(count($r)); } #$r = Packing::reset_inwork_to_nocreate($this->tid, $prid); if(hand && $r) pre($r);
    }
}