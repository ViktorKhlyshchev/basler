<?php

namespace CLI\Controllers; # namespace Project\Aist\Admin\Shell\Journal;

use CLI\Modules\Clean\CleanTables;
use CLI\Modules\Clean\CleanTables30;
use CLI\Modules\Clean\CleanOrphanImages;
use CLI\Modules\Clean\CleanOrphanVideos30;
use CLI\Modules\Clean\CleanOrphanJImages30;
use CLI\Modules\Clean\CleanOrphanJVideos30;
use CLI\Modules\Clean\CleanDirs30;
use CLI\Modules\Clean\CleanEmptyDirs; # use CLI\Modules\Clean\CleanDirs1;
use CLI\Modules\Clean\CleanLogs; # use CLI\Modules\Clean\CleanTemps;
use CLI\Modules\Clean\CleanTempTmp;
use CLI\Modules\Clean\CleanOrphanProcessing;
use CLI\Modules\Clean\CleanOrphanSending;
use CLI\Modules\Clean\CleanOrphanPacking;
use Common\Models\XavierInfo;
use CLI\Modules\Clean\CleanResources;
use CLI\Modules\Clean\CleanOrphanImagesFiles;
use CLI\Modules\Clean\CleanTemps;
use Core\Modules\Log;

class Cleaning {

    # http://aist.loc/admin/sh?action=remove_journal_list&is_test=1&need_log=1
    # sudo -u www-data /usr/bin/php /var/www/html/index.php "action=remove_journal_list" "is_test=1"
    # sudo -u www-data /usr/bin/php /home/alex/0git/aist.loc/index.php "action=remove_journal_list" "is_test=1"
    # check ls -l /var/www/html/Resource/Image/2021/09/23/ | wc -l
    # sudo -u www-data /usr/bin/php /var/www/html/index.php "action=remove_journal_list" "is_test=1" >> /dev/null 2>&1 & echo $
    # sudo -u www-data /usr/bin/php7.2 $PWD/index.php action=remove_journal_list need_log=1 is_test=1 >> /dev/null 2>&1 & echo $
    # sudo -u www-data /usr/bin/php7.2 $PWD/index.php action=cleaning need_log=1 is_test=1

    private static $timeoutt = 0;
    private static $timeout = 60;
    private static $timezone = 0; #    private static $timezones = 0;
    private static $dayar = [];
    private static $today;
    private static $nightclean_inwork;
    private static $sets;
    private static $cts; # current timestamp
    private static $pts; # previous timestamp
    private static $tsd; # timestamps difference

    public static function init(){ # systemctl status aist_remove

        if(hand) pre(__CLASS__ .'::'. __FUNCTION__ .' laucnhed #41');
        self::get_sets();

        while(true){ #pred(loc); #pre(date('H'));            pre((int)date('i'));

            self::$cts = time();
            self::$tsd = self::$cts - self::$pts;
            $date = new \DateTime();
            $date->modify('+'. self::$timezone .' hour');
            self::$today = $date->format('Y.m.d');
            $today = &self::$today;
            $dayar = &self::$dayar;
            if(!isset($dayar[$today])) $dayar = [$today => []];
            $h = (int)$date->format('H');
            $m = (int)$date->format('i');
            if(hand){ pre($dayar); pre('Hour: '. $h .' Min: ' . $m); }
            #$h = '04'; $m = 1;
           /* if(!loc) if($h === '04' && $m > 1 && $m < 5)# if(!self::$CleanTables_launched){
                if(!isset(self::$dayar[$today]['CleanTables_launched'])){
                    self::$dayar[$today]['CleanTables_launched'] = 1;
                    CleanTables::init();
                }*/
            #pre($h === '13');            pre($m > 20 && $m < 40);
           # if(!loc) if($h === '14' && $m > 50 && $m < 59) #if(!self::$CleanTables30_launched){
            if(!loc)
                if($h === 4 || $h === 5) #  && $m > 1 && $m < 5
                    if(!isset($dayar[$today]['nightclean_launched'])){
                        self::$nightclean_inwork = 0;
                        $dayar[$today]['nightclean_launched'] = 1;
                        self::nightclean();
                    } else {
                        if(!self::$nightclean_inwork){
                            if($dayar[$today]['nightclean_launched'] < 5){
                                $dayar[$today]['nightclean_launched']+=1;
                                self::nightclean();
                            }
                        }
                    } #pre($dayar);  } #pre(date('d.m.Y H:i:s'));

            if(!loc) if(!CleanTables::$inwork) CleanTables::init(); #if(!loc) if(!CleanTableJournal::$inwork) CleanTableJournal::init(self::$drive_path);
            #if(!loc) if($h === '04') if($m > 1 && $m < 30) if(!CleanLogs::$inwork) CleanLogs::init();

            /*if(loc) #if($h === '14' && $m > 0 && $m < 20)
                if(!isset(self::$dayar[$today]['CleanOrphanImages30'])){
                    self::$dayar[$today]['CleanOrphanImages30'] = 1; # $gdp = '/var/www/html/Resource/Image/2021/09/07';pred(is_dir($gdp));
                    CleanOrphanImages30::init();
                    pre(self::$dayar[$today]);
                } #pre(date('d.m.Y H:i:s'));

            if(loc) #if($h === '14' && $m > 0 && $m < 20)
                if(!isset(self::$dayar[$today]['CleanOrphanVideos30'])){
                    self::$dayar[$today]['CleanOrphanVideos30'] = 1; # $gdp = '/var/www/html/Resource/Image/2021/09/07';pred(is_dir($gdp));
                    CleanOrphanVideos30::init();
                    pre(self::$dayar[$today]);
                } #pre(date('d.m.Y H:i:s'));
*/
             #if(date('H') === );  #pre(date('d.m.Y H:i:s')); pre((int)date('H')); pre((int)date('i'));
            #if(loc) CleanTables::init();

            /*if($h === '05' && (int)date('i') < 2) {
                self::$CleanTables_launched = true;
                self::$CleanTables30_launched = true;
                CleanTables30::init();            #pre(date('d.m.Y H:i:s'));
            }*/
            #if(!loc) CleanTables30::init();            #pre(date('d.m.Y H:i:s'));
            #if(date('H') === '04' && (int)date('i') < 7) pred(date('d.m.Y H:i:s'));
            if(loc) self::$timeout = 1;
            self::$timeoutt++;
            #if(!loc) if(self::$timeoutt % 2 === 0) CleanTempTmp::init();
            if(!loc) if(self::$tsd > 600) CleanTempTmp::init();
            if(loc) CleanTempTmp::init();
            if(self::$timeoutt > 10000) self::$timeoutt = 0;
            pre(self::$timeoutt);
            pre(self::$tsd);

            self::$pts = self::$cts;
            pre('sleep('. self::$timeout .')'."\n");
            sleep(self::$timeout);
        }

        if(nl) pre("finish test\n");
        return true;
    }

    static function get_sets(){
        self::$sets['about'] = XavierInfo::get_groupa('about');
        self::$timezone = self::$sets['about']['timezone']; #self::$sets['balancer'] = XavierInfo::get_groupa('balancer');
        self::$sets['common_pack'] = XavierInfo::get_groupa('common_pack');
        self::$sets['common_pack']['remove_sources_after_creating'] = (int)self::$sets['common_pack']['remove_sources_after_creating'];
    }

    static function nightclean(){

        if(!self::$sets) self::get_sets();
        self::$nightclean_inwork = 1;
        $today = &self::$today;
        $dayar = &self::$dayar; # pre(self::$sets); pred(self::$sets['common_pack']['remove_sources_after_creating']);
        $txt = __CLASS__ .'::'. __FUNCTION__ .' laucnhed! #126'. json_encode(self::$dayar);
        Log::clean_log($txt);
        if(hand) pre($txt); # if(!CleanLogs::$inwork)
        CleanLogs::init();
        CleanTables30::init(); #if(self::$sets['common_pack']['remove_sources_after_creating']) CleanDirs1::init();
        CleanDirs30::init();
        CleanOrphanImages::init(); # CleanOrphanImages30::init();
        CleanOrphanVideos30::init();
        CleanOrphanJImages30::init();
        CleanOrphanJVideos30::init();
        CleanOrphanSending::init();
        CleanOrphanPacking::init();
        CleanOrphanProcessing::init();
        CleanTemps::init();
        if(self::$sets['common_pack']['remove_sources_after_creating']) (new CleanResources())->all(); # CleanTemps::init();
        if(self::$sets['common_pack']['remove_sources_after_creating']) CleanOrphanImagesFiles::init();
        CleanEmptyDirs::init();
        self::$nightclean_inwork = 0;
    }
}