<?php

namespace CLI\Controllers;

use CLI\Modules\CLIController;
use Common\Models\UploadServer;
use Common\Models\Packing;
use Common\Models\PackingQ;
use Common\Models\Sending;
use Common\Models\SendingQ;
use CLI\Modules\Cafap\CafapCreatepackage;
use Common\Models\Processing;
use Core\Modules\Dir;
use Configs\DirConfig;
use Common\Models\XavierInfo;
use CLI\Modules\Clean\CleanResources;
use Common\Models\Journal;
use Common\Models\Zone;

class CafapPackMThread extends CLIController { # MultiThread
    // sudo -u www-data php /var/www/html/index.php "action=createbox_thread" "thread_id=3" "is_test=1" "need_log=1" >> /dev/null 2>&1 & echo $
    # sudo -u www-data /usr/bin/php7.2 /var/www/html/index.php action=cafap_pack_thread tid=1 need_log=1
    # sudo -u www-data /usr/bin/php7.2 -f "$PWD/index.php" action=cafap_pack_thread need_log=1
    # sudo -u www-data /usr/bin/php7.2 -f "$PWD/index.php" action=cafap_pack_thread tid=0 need_log=1
    # sudo -u www-data /usr/bin/php7.2 -f "$PWD/index.php" action=cafap_pack_thread tid=1 need_log=1

    public $tid; # thread_id
    public $sets; # settings
    public $proc_id;  /* private static $speed_quality_min;  private static $journal_limit;   static $journal_limit_max = 1000;    static $strys_limit_max = 10;*/
    public $night_mode;
    public $dayar = [];

    public function __construct(){

        if(loc) $this->check_perms();
        $this->tid = !isset($_REQUEST['tid']) ? 1 : (int)$_REQUEST['tid'];

        if(loc) $this->tid = 0;
        pre('self::$tid__', $this->tid); #pre('cli', cli); pre('self::$thread_id === 0', $this->tid === 0); #pred($_REQUEST);

        $ms_for_sleep2 = 2 * 1000 * 100; # 10 * 1000 * 100 one second #pred($ms_for_sleep); # $ms_for_sleep4 = 4 * 1000 * 100; #pred($ms_for_sleep);
        $ms_for_sleep4 = 4 * 1000 * 100; #pred($ms_for_sleep);
        $ms_for_sleep12 = 12 * 1000 * 100; #pred($ms_for_sleep);

        if(!Dir::create_dirn(DirConfig::$dir_cafap_package_temp)) er('cant create dir '. __FUNCTION__ .'#1 dir:__'. DirConfig::$dir_cafap_package_temp);
        if(!Dir::create_dirn(DirConfig::$dir_cafap_package_tar)) er('cant create dir '. __FUNCTION__ .'#1 dir:__'. DirConfig::$dir_cafap_package_tar);

        #$servs = UploadServer::get_for_pack('cafap'); # pred($servs);
        $servs = $this->get_servs(); #pre($servs);
        $this->get_sets(); #pre($servs);
        $this->time_update();

        $c = 0;
        $cc = 0;
        $d = $ms_for_sleep12/$ms_for_sleep2; #pred($d);
        $prid = getmypid();

        do {

            $c++; $cc++; #pre($cc);

            if(hand){
                pre('$c: '. $c);
                pre('$cc: '. $cc); # pre('$this->night_mode: '. $this->night_mode);
            }

            if(!$servs){
                if(hand) pre('sleep('. \Config::$upload_servs_break .') . UploadServer !$servs <SKIP#1>');
                sleep(\Config::$upload_servs_break);
                $servs = $this->get_servs();
                continue;
            }

            if($c > 2000){
                $c = 0; # 2000/5 400 secs, 6.6 mins
                $servs = $this->get_servs(); # $this->get_sets();
            } #$r = Sending::get_cafap_readies(); # $r = Packing::get_cafap_readies(); #if($r > 1000){ pre('readies > 1000! sleep(60)'); sleep(60); continue; }

            if($cc > 200){ #pre($c);
                $cc = 0;
                $r = PackingQ::reset_inwork($this->tid, $prid);
                if(hand && $r) pre($r);
                #$r = PackingQ::reset_inwork_to_nocreate($this->tid, $prid); if(hand && $r) pre($r);
                #Packing::copy_packingq($this->tid);
                #$r = PackingQ::delete_bids($this->tid, $prid); if(hand && $r) pre($r);
                $this->time_update();
                if($this->h > 1 && $this->h < 5){
                    $this->night_mode = true;
                } elseif($this->h > 5){
                    $this->night_mode = false;
                }
            }

            $rows = PackingQ::hold_for_cafap($this->tid); # $where = 'tid='. $tid . ' AND inwork IS NULL AND created IS NULL AND us_type=\'cafap\'';     #pred($rows) #pred($servs);
            if(!$rows){
                $c+=$d;
                $cc+=$d;
                if($this->night_mode) sleep(5); else sleep(1);
                if(hand) pre('usleep($ms_for_sleep12) Journal !$rows <SKIP#2> c:' . $c .' | cc: '. $cc);
                continue;
            }            #pred($rows);

            XavierInfo::update_data('create_stat', 'cafap_last_holded', $rows[0]['jid']);

            $keys_created = [];

            foreach($rows as $row){ #pred($row);
                $c++;
                $cc++;
                if(!isset($keys_created[$row['jid']])) $keys_created[$row['jid']] = [];
                if(!$servs[$row['us_id']]['need_send']){ #if(1){ #Packing::update_need_send_ch($row['id']);
                    PackingQ::update_need_send_ch($row['id']);
                    PackingQ::update_log($row['id'], 'Server changed to NOSEND');
                    Packing::delete_bids([$row['id']]);
                    Packing::copy_packingq($row['id']);
                    PackingQ::delete_bids([$row['id']]);
                    Processing::update_need_send_ch($row['jid']);
                    continue;
                } # $row['hash_updated'] = false;

                $serv = &$servs[$row['us_id']]; #pred($serv);  pre($c);#pre($keys_created);                    #pred($servs);  pred($row);

                if(!isset($keys_created[$row['jid']][$serv['key_id']])){ #pre($row);  pred($serv);
                    $this->proc_id = uniqid(1);
                    $ccp = new CafapCreatepackage($row, $serv, $this);
                    $tar_fp = $ccp->create(); #pred($tar_fp); pred($ccp->dir_gpackage);
                    if(\Config::$cafap_remove_temp_source_dir_for_tar && $ccp->dir_gpackage) Dir::remove_dirn($ccp->dir_gpackage); #pred($tar_fp);
                    if(!$tar_fp){
                        pre($ccp->aerrors);
                        XavierInfo::increment_value('create_stat', 'cafap_alltime_not_created_qty');
                        XavierInfo::increment_value('create_stat', 'cafap_not_created_qty');
                        continue; #$keys_created[$row['jid']][$serv['key_id']] = $tar_fp;                    #$row['hash_updated'] = true;
                    } else pre('CAFAP CREATED! '. $row['jid'].' for us:'. $row['us_id'] .' fp:__'. $tar_fp);
                    $keys_created[$row['jid']][$serv['key_id']] = ['tar_fp' => $tar_fp, 'hash' => $ccp->journal_hash, 'file_size' => filesize($tar_fp)];                   #$row['hash_updated'] = true;
                }

                $row['fp'] = $keys_created[$row['jid']][$serv['key_id']]['tar_fp'];
                $row['hash'] = $keys_created[$row['jid']][$serv['key_id']]['hash'];
                $row['file_size'] = $keys_created[$row['jid']][$serv['key_id']]['file_size'];
                #copy($row['fp'] , DR .'/Resource/tar/'. $row['hash'].'.tar'); # if(loc)  else copy($row['fp'] , '/mnt/data/Resource/tar/'. $row['hash'].'.tar');
                $row['tid'] = $this->tid;/*
                PackingQ::update_created($row);
                Packing::copy_packingq($row['id']);
                PackingQ::delete_bids([$row['id']]);*/

                PackingQ::update_created($row);
                Packing::delete_bids([$row['id']]);
                Packing::copy_packingq($row['id']);
                PackingQ::delete_bids([$row['id']]);

                $all = $this->createall_check_set($row['jid']); #pre($all); pred($this->sets['common_pack']['remove_sources_after_creating']);                #pred($all);

                if($all) if($this->sets['common_pack']['remove_sources_after_creating']){
                    Journal::update_log($row['jid'], '| sources removed from CAFAP |');
                    if(!loc) new CleanResources($row['jid']); #new CleanResources($row['jid']);
                }

                if(hand) pre('$row[nosend]:'. $row['nosend']);
                if($row['nosend']) continue;
                $r = Sending::add($row, $serv); if(hand) pre('SENDING ADDED!! id: '. $r['id']);
                $row['sid'] = $r['id'];
                $r = SendingQ::add($row, $serv); if(hand) pre('SENDINGQ ADDED!! id: '. $r['id']);
                Packing::update_sid($row);
            } #pred($keys_created); #pre($r->errors); pred($r->log);
            if(loc){
                sleep(1);
            } else {
                if(hand) pre(' usleep($ms_for_sleep2)');
                if($this->night_mode) sleep(1); else usleep($ms_for_sleep4);
            }
        } while(true);
        return ['success' => true]; #return ResponseSuccess::init(['success' => true,'data' => []]);
    }

    public function get_servs(){  #$r = UploadServer::get_cafap(['need_send' => true]);
        $r = UploadServer::get_cafap();
        $servs = []; #pred($row);
        foreach($r as $row) if(!empty($row['key_id'])) $servs[$row['id']] = $row;# ['id' => $row['id'], 'key_id' => $row['key_id'], 'need_send' => $row['need_send']]; #  #pred(self::$ftp_id_list);
        return $servs;
    }

    public function get_sets(){  #$r = UploadServer::get_cafap(['need_send' => true]);
        $this->sets['cafap_pack'] = XavierInfo::get_groupa('cafap_pack'); #pred($this->sets);
        $this->sets['cafap_upload'] = XavierInfo::get_groupa('cafap_upload'); #pred($r);
        $this->sets['upload'] = XavierInfo::get_groupa('upload'); #pred($this->sets);
        $this->sets['common_pack'] = XavierInfo::get_groupa('common_pack');
        $this->sets['common_pack']['remove_sources_after_creating'] = (int)$this->sets['common_pack']['remove_sources_after_creating'];
        $this->sets['common_pack']['min_speed_quality_for_speed_na'] = (int)$this->sets['common_pack']['min_speed_quality_for_speed_na'];
        $this->sets['common_pack']['max_speed_for_speed_na'] = (int)$this->sets['common_pack']['max_speed_for_speed_na'];
        $this->sets['zone'] = Zone::get_zone_list(1, ['speed_permissible']); #pred($this->sets);
        $this->sets['about'] = XavierInfo::get_groupa('about');
        $this->timezone = (float)$this->sets['about']['timezone'];
    }

    public function createall_check_set($jid = null){ #pre($row);
        if(!$jid) return true;
        $rows = Packing::get_all_jid($jid); #pred($rows); #        $r = Processing::update_allsent($row['jid']);
        $all = true;
        if(!$rows) $all = false;
        foreach($rows as $r) if(!$r['created']) $all = false; #pred($all);
        if($all) $r = Processing::update_allcreate($jid);#pred($all);
        return $all;
    }

    function check_perms(){
        $tdp = DR .'/'. DirConfig::$dir_cafap_package_temp .'/000perms_test';
        if(Dir::create_dirn($tdp)) rmdir($tdp); else pred('cant create dir for CAFAP pack!! '. __FUNCTION__ .'#1 dir:__'. $tdp);
    }

    public function time_update(){  #$r = UploadServer::get_cafap(['need_send' => true]);
        $date = new \DateTime();
        $date->modify('+'. $this->timezone .' hour');
        $this->today = $date->format('Y.m.d');
        $today = $this->today;
        $dayar = $this->dayar;
        if(!isset($dayar[$today])) $dayar = [$today => []];
        $this->h = (int)$date->format('H'); # pred($h); # $h = '02';# pred($h);        $h = (int)'02';
        $this->m = (int)$date->format('i');
        if(hand){ pre($dayar); pre('Hour: '. $this->h .' Min: ' . $this->m); }
    }
}