<?php

namespace CLI\Controllers;

use CLI\Modules\CLIController;
use Common\Models\UploadServer;
use Common\Models\Packing;
use Common\Models\Sending;
use Common\Models\SendingQ;
use CLI\Modules\Duplo\DuploSendpackage;
use Common\Models\Processing;
use Common\Models\XavierInfo;

class DuploSendMThread extends CLIController { # MultiThread
    // sudo -u www-data php /var/www/html/index.php "action=createbox_thread" "thread_id=3" "is_test=1" "need_log=1" >> /dev/null 2>&1 & echo $
    # sudo -u www-data /usr/bin/php7.2 -f "$PWD/index.php" action=duplo_send_thread need_log=1
    # sudo -u www-data /usr/bin/php7.2 -f "$PWD/index.php" action=duplo_send_thread tid=0 need_log=1
    # sudo -u www-data /usr/bin/php7.2 /var/www/html/index.php action=duplo_pack_thread tid=1 need_log=1
    # sudo -u www-data /usr/bin/php7.2 /var/www/html/index.php action=duplo_send_thread tid=1 need_log=1

    public $tid;
    public $night_mode;
    public $sets;
    public $dayar = [];

    public function __construct($action = null){

        $this->tid = !isset($_REQUEST['tid']) ? 1 : (int)$_REQUEST['tid'];
        if(loc) $this->tid = 0;
        pre('self::$tid__', $this->tid); #        pre('cli', cli);
        pre('self::$thread_id === 0', $this->tid === 0); #pred($_REQUEST);

        $ms_for_sleep2 = 2 * 1000 * 100; #pred($ms_for_sleep);
        $ms_for_sleep4 = 4 * 1000 * 100; #pred($ms_for_sleep);

        $servs = $this->get_servs(); #pred($servs);
        $this->get_sets();
        $this->time_update();

        pre('$strys_limit_max:'. \Config::$strys_limit_max);

        $c = 0;

        do {

            $c++;

            if(!$servs){
                if(hand) pre('sleep('. \Config::$upload_servs_break .')'. 'UploadServer !$servs <SKIP>');
                sleep(\Config::$upload_servs_break);
                $servs = $this->get_servs();
                continue;
            }

            if($c > 200){ #pre($c);

                $r = SendingQ::get_limited($this->tid, 'duplo'); #pred($r);

                $delids = [];
                foreach($r as $rr){
                    Sending::copy_sendingq($rr['id']);
                    $delids[] = $rr['id'];
                }
                SendingQ::delete_bids($delids);

                $c = 0;
                $this->time_update();
                if($this->h > 1 && $this->h < 5){
                    $this->night_mode = true;
                } elseif($this->h > 5){
                    $this->night_mode = false;
                }
            }

            $rows = SendingQ::hold_for_duplo($this->tid); #pred($rows);           #pred($servs);
            if(!$rows){
                pre('usleep $ms_for_sleep4: Journal !$rows <SKIP>#1'. rand());
                if($this->night_mode) sleep(5); else sleep(1);
                continue;
            } #pred($rows);

            $keys_created = [];

            foreach($rows as $row){ #pred($row);
                $c++;
                if(!isset($keys_created[$row['jid']])) $keys_created[$row['jid']] = [];
                if(!$servs[$row['us_id']]['need_send']){
                    Packing::update_need_send_ch($row['id']);
                    Packing::update_log($row['id'], 'Server changed to NOSEND');
                    Processing::update_need_send_ch($row['jid']);
                    SendingQ::update_need_send_ch($row['jid']);
                    SendingQ::update_log($row['id'], 'Server changed to NOSEND');
                    Sending::delete_bids([$row['id']]);
                    Sending::copy_sendingq($row['id']);
                    SendingQ::delete_bids([$row['id']]);
                    continue;
                } # $row['hash_updated'] = false;

                $serv = &$servs[$row['us_id']]; # if(hand){  pre(strpos('admin/duplo/emul', '10.0.1.4/admin/duplo/emul')); pre(strpos('admin/duplo/emul', $serv['ip_address'])); pred($serv); } #$this->prepare_path($serv); #if(nl) pre('=============================Sending: '.$row['id']);
                $dsp = new DuploSendpackage($row, $serv);
                if(strpos($serv['ip_address'], 'admin/duplo/emul') !== false) $r = $dsp->send('User-Agent: DuploTEST'. __CLASS__); else $r = $dsp->send();  # pred($serv); $r = $dsp->send();
                if($r){
                    if(nl) pre('=================== Duplo Sent! '. $row['jid'] .' us_url:'. $dsp->url .' '. $row['file_path']);
                    SendingQ::update_sent($row['id']);
                    Sending::delete_bids([$row['id']]);
                    Sending::copy_sendingq($row['id']);
                    SendingQ::delete_bids([$row['id']]);
                    $this->sendall_check_set($row);
                    UploadServer::update_date_last_send($row['us_id']);
                    XavierInfo::increment_sent_duplo();
                } else {
                    if(nl) pre('=================== Duplo NOT Sent! '. $row['jid'] .' us_url:'. $dsp->url .' '. $row['file_path']);
                    SendingQ::update_notsent($row['id']);
                    Sending::delete_bids([$row['id']]);
                    Sending::copy_sendingq($row['id']);
                    SendingQ::delete_bids([$row['id']]);
                    XavierInfo::increment_notsent_duplo();
                }
            }

            if(loc){
                sleep(1);
            } else {
                if(hand) pre('usleep($ms_for_sleep2)');
                if($this->night_mode) sleep(1); else usleep($ms_for_sleep2);
            }
        } while(true);
        return ['success' => true]; # return ResponseSuccess::init(['success' => true,'data' => []]);
    }

    public function get_servs(){  #$r = UploadServer::get_duplo(['need_send' => true]);
        $servs = UploadServer::get_duplo();
        return $servs;
    }

    public function sendall_check_set($row){
        $r = Packing::update_sent($row['pid']);
        $all = Packing::get_all_for_sent($row['jid']);
        $allsent = Packing::get_sent($row['jid']);
        if(count($all) !== count($allsent)) return;
        $r = Processing::update_allsent($row['jid']);
        $r = Packing::update_allsentc($row['jid']);
    }

   /*public function prepare_path(&$serv){
        $serv['ftp_dp'] = str_replace(['%device_name%', '%year%', '%month%', '%day%', '%traffic_violation%'],
            [$this->device_name, $year, $month, $day, $key],
            $serv['path']
        );
    }*/

    public function get_sets(){  #$r = UploadServer::get_cafap(['need_send' => true]);
        $this->sets['about'] = XavierInfo::get_groupa('about');
        $this->timezone = (float)$this->sets['about']['timezone'];
    }

    public function time_update(){  #$r = UploadServer::get_cafap(['need_send' => true]);
        $date = new \DateTime();
        $date->modify('+'. $this->timezone .' hour');
        $this->today = $date->format('Y.m.d');
        $today = $this->today;
        $dayar = $this->dayar;
        if(!isset($dayar[$today])) $dayar = [$today => []];
        $this->h = (int)$date->format('H'); # pred($h); # $h = '02';# pred($h);        $h = (int)'02';
        $this->m = (int)$date->format('i');
        if(hand){ pre($dayar); pre('Hour: '. $this->h .' Min: ' . $this->m); }
    }
}