<?php

namespace CLI\Controllers; # namespace Project\Aist\Admin\Shell\Journal;

use Core\Module\Curl\CurlPost;
use Core\Modules\Json;
use Core\Module\Response\ResponseSuccess;
use Common\Models\Journal;
use Common\Models\XavierInfo;

class SendJournalDataForAvgSpeedShell { # Project/Aist/Admin/Shell/Journal/SendJournalDataForAvgSpeedShell.php
    // sudo -u www-data /usr/bin/php /var/www/html/index.php "action=send_potok_for_avg_speed" "is_test=1" "need_log=1"
    // sudo -u www-data /usr/bin/php /var/www/html/index.php "action = send_potok_for_avg_speed" >> /dev/null 2>&1 & echo $
    // sudo -u www-data /usr/bin/php /var/www/html/index.php "action = send_potok_for_avg_speed" "is_test=1" >> /dev/null 2>&1 & echo $
    // sudo systemctl start aist_upload_avg_speed
    // sudo systemctl restart aist_upload_avg_speed
    // sudo systemctl stop aist_upload_avg_speed
    /*
(
    [serial_number] => 00113
    [data] => [{"ID":22454,"camera_id":1,"country_id":42,"country_code":"ru","car_number":"o9168717","car_type":"other","car_firm":null,"car_model":null,"direction":"down","speed":null,"speed_quality":null,"join_count":0,"point_count":48,"point_recognized_count":1,"hash":"b0dd3472584ea869be34e5249082f23a9ddaf71d","traffic_violation":"none","light_sensor":99316,"frame_bright":103,"recognize_type":0,"lane":0,"distance":"0","is_plate_invert":false,"is_parent":false,"date_traffic_violation":1633935234640,"date_start_track":1633935230678,"date_create":"2021-10-11 06:53:59.412661"}]
)
*/
    private static $timeout = 5;
    private static $journal_len = 20;
    private static $serial_number;
    private static $journal_id_list = [];
    private static $journal_list = [];
    private static $traffic_violation_list = ['none'];

    private static $url = 'http://10.0.0.1:8888/api/json/add_journal_list'; # private static $url = 'http://192.168.2.71:8888/api/json/add_journal_list';

    private static function set_journal_id_list(){
        self::$journal_id_list = [];
        foreach(self::$journal_list as $row) self::$journal_id_list[] = $row['id'];
        return true;
    }

    private static function update_journal_list_to_sending(){
        if(!empty(self::$journal_id_list)) Journal::update_journal_list_to_sending_avg_speed(self::$journal_id_list);
        return true;
    }

    private static function update_journal_list_to_send(){
        if(!empty(self::$journal_id_list)) Journal::update_journal_list_to_send_avg_speed(self::$journal_id_list);
        return true;
    }

    private static function update_journal_list_to_default(){
        if(!empty(self::$journal_id_list)) Journal::update_journal_list_to_default_send_avg_speed(self::$journal_id_list);
        return true;
    }

    private static function send_journal_data(){
        $data = ['serial_number' => self::$serial_number, 'data' => Json::encode(self::$journal_list)];
        $r = CurlPost::init(self::$url, [], $data);
        if(!empty($_REQUEST['need_log'])) pre($r);
        return $r['status'] == 200;
    }

    public static function init(){

        \Config::$is_debug = true;

        self::$serial_number = XavierInfo::get_value('about', 'serial_number');

        do {
            self::$journal_list = Journal::get_journal_data_list(self::$traffic_violation_list, self::$journal_len);
            if(!empty($_REQUEST['need_log'])) pre(self::$journal_list);
            if(!empty(self::$journal_list)){
                self::set_journal_id_list();
                self::update_journal_list_to_sending();
                if(self::send_journal_data())
                    self::update_journal_list_to_send();
                else
                    self::update_journal_list_to_default();
            }
            if(empty($journal_list)) sleep(self::$timeout);
        } while(true);

        $data = ['success' => true,  'data' => []];
        return ResponseSuccess::init($data);
    }
}