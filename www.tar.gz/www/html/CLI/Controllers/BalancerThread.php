<?php

namespace CLI\Controllers;

use Core\Module\Response\ResponseSuccess; # use Core\Module\Exception\ParametersException;
use Common\Models\Journal;
use Common\Models\JournalV;
use CLI\Modules\CLIController;
use CLI\Modules\CheckOffenceAction;
use Common\Models\UploadServer;
use Common\Models\Packing;
use Common\Models\PackingQ;
use Common\Models\Processing;
use Common\Models\XavierInfo;
use CLI\Modules\Clean\CleanResources;
use CLI\Modules\PreparingImages\PrepareImages;
use Common\Models\Zone;
use Admin\Controllers\TrackController;
use Core\Modules\Log;
use Common\Models\Sending;
use Common\Models\SendingQ;
use Common\Modules\Request; # for debug
use Common\Models\JournalImage; # for debug

class BalancerThread extends CLIController { # /admin/cli/balancer?si=1

    # SELECT count("id") FROM "public"."journal" WHERE "processed" IS NULL
    # SELECT count("id") FROM "public"."__sending_queue";

    public $createbox_thread_limit;
    public $sendbox_thread_limit;
    public $create_pids = [];
    public $send_pids = [];
    public $blancer_pids = [];
    public $sets = []; # public $max_threads = 3;
    public $max_speed = 301;
    public $timezone = 0;
    public $h;
    public $m;
    public $night_mode;
    public $get_for_balancer_at_once = 20;
    public $dayar = [];

    public function __construct($action = null){

        global $req; #$_POST['id'] = 1131358;
        if(!cli){ $_POST['tids'] = '800522,137089,1131358,1932871,2256781,724662,2312884,2256781'; $req::init(); $tc = new TrackController('fnull'); } # $req = new Request();

        if(loc) $this->sets['balancer']['threads_qty'] = 1; # sudo -u www-data /usr/bin/php7.2 $PWD/index.php action=balancer need_log=1 # while true; do ps aux | grep index.php; sleep 2; done
        # sudo -u www-data php /var/www/html/index.php "action=sendbox_thread_list" "thread_limit=3" "is_test=1" >> /dev/null 2>&1 & echo $
        $ms_for_sleep2 = 2 * 1000 * 100;  # 10 * 1000 * 100 one second         # $ms_for_sleep0 = 1 * 1000; # $ms_for_sleep1 = 1 * 1000 * 100;
        $ms_for_sleep4 = 4 * 1000 * 100; # $ms_for_sleep12 = 12 * 1000 * 100;  # #pred($ms_for_sleep); #$ms_for_sleep10 = 10 * 1000 * 100;

        $servs = UploadServer::get_for_balancer(); #pred($servs);
        $this->get_sets();
        #$this->reinit_tids();
        $this->time_update();

        $c = 0;
        $cc = 0;
        $tc = 0;
        $t = 1;

        if(cli) $forwhile = true; else $forwhile = false; #$ms_for_sleep = 20 * 1000 * 100; usleep($ms_for_sleep); pred($ms_for_sleep);
        $lid = 0; # last id
        do { #$r = SendingQ::test();  pred($r);
            if(hand) pre('$lid:'. $lid);
            $sets_updated = 0;
            $c++; $cc++;
            if(hand){ pre('C:'. $c); pre('CC:'. $cc); pre('TC:'. $tc); }
            if($c > 2000){ #if($c > 10){
                $c = 0; # 2000/5 400 secs, 6.6 mins
                $servs = UploadServer::get_for_balancer();
                $this->get_sets();
                $sets_updated = 1;
            }

            if(!$sets_updated && $tc > 10){
                $tc = 0; # 2000/5 400 secs, 6.6 mins
                $servs = UploadServer::get_for_balancer();
                $this->get_sets();
            }

            if($cc > 100){ #  pre($this->h);
                $this->time_update();
                if($this->h > 1 && $this->h < 5){
                    $this->night_mode = true;
                } elseif($this->h > 5){
                    $this->night_mode = false;
                }
            }

            if($cc > 100){
                $cc = 0;
                if(hand){ pre('sleep(1) Sending::reset_inwork | Sending::reset_inwork_to_nosend hand'); sleep(1); }
                SendingQ::reset_inwork(); # SendingQ::reset_inwork_to_nosend();
            }

            if(!$servs){
                pre('UploadServer !$servs <SKIP#1> sleep(10)');
                if($this->night_mode) sleep(60); else sleep(10);
                $servs = UploadServer::get_for_balancer();
                continue;
            } #pre($c); #pre($servs);            #pred($this->sets);

            $rows = Journal::get_for_balancer($this->get_for_balancer_at_once, $lid); #
            if(hand) pre($rows);
            if(!$rows){
                $c++;
                if($this->night_mode) sleep(2); else usleep($ms_for_sleep4);
                if(hand) pre(' usleep($ms_for_sleep4) Journal !$rows <SKIP#2> (USUALLY IF NO SPACE LEFT OR PYTHON NOT WORKING');
                continue;
            }

            foreach($rows as $row){ #pred($row); pred($row['type']);
                $tc++; if($tc%10 === 0) $cc++; if(hand) pre('TC:'. $tc);
                $nocreate = false;
                $nosend = false;
                if(!loc && $this->sets['dev']['journal_virgin']) $r = JournalV::copy($row['id']); #pred($row); pre('\Config::$journal_virgin'); #$imagesb = JournalImage::get_all_images_bjid($row['id']); pre($imagesb); pred($row['type']);

                /*if($row['type'] === 2){
                    Journal::update_log($row['id'], ' | TYPE |'. $row['type'] .'| FROM PYTHON! jid: '. $row['id'] .'| ');
                    $jd = Journal::get_one_for_balancer_typed($row['id']); # JOURNAL DATA !! #pred($jd);;pre($jd); #Log::sbl('CheckOffenceAction::init sets to type1? jid: '. $row['id'] ."\n");
                    $jd['speedq'] = (int)$jd['speed_quality'];
                    if($jd['traffic_violation'] !== 'none') $jd['offence'] = $jd['traffic_violation']; else $jd['offence'] = null;
                    $adar = ['tid' => 222, 'nocreate' => 1, 'nocreatecom' => 'TYPE |'. $row['type'] .'| FROM PYTHON! jid: '. $jd['id']];
                    $r = Processing::add_for_balancer(['jd' => $jd, 'adar' => $adar]);# pre($r);
                    $r = Journal::set_processed($row['id']);
                    continue;
                }*/

                $r = CheckOffenceAction::init([$row['id']]); #pred($r); #$r = Journal::get_journal_data(self::$journal_id); #$imagesa = JournalImage::get_all_images_bjid($row['id']); #pre($imagesb); pred($imagesa);
                #pred($r);
                if(!$r || CheckOffenceAction::$error){ # CheckOffenceAction::$error){ #pred(CheckOffenceAction::$errors);
                    $jd = Journal::get_one_for_balancer_typed($row['id']); #pred($jd);

                    $jd['speedq'] = (int)$jd['speed_quality'];
                    if($jd['traffic_violation'] !== 'none') $jd['offence'] = $jd['traffic_violation']; else $jd['offence'] = null;

                    $adar = ['tid' => 404, 'nocreate' => 1, 'nocreatecom' => 'CheckOffenceAction::init error: '. json_encode(CheckOffenceAction::$errors)];
                    $r = Processing::add_for_balancer(['jd' => $jd, 'adar' => $adar]);# pre($r);
                    $r = Journal::set_processed($row['id']);
                    continue;
                } #pred(CheckOffenceAction::$error);

                $ppi = new PrepareImages($row['id'], $this); #pred($ppi->error); # creates prepared_* images in journal_image || TODO combo_car_number_coords
                if($ppi->error){ # || empty($ppi->combo_car_number_coords)
                    #if(is_string($ppi->error) && strpos($ppi->error, 'Image collage was not created') === false) if(hand) pre($ppi);
                    if(!is_string($ppi->error)) $ppi->error = json_encode($ppi->error);
                    if(hand){ pre($row['id']); pre($ppi->error); }
                    $jd = Journal::get_one_for_balancer_typed($row['id']); # JOURNAL DATA !! #pred($jd);;pre($jd); #Log::sbl('CheckOffenceAction::init sets to type1? jid: '. $row['id'] ."\n");
                    if($jd['traffic_violation'] !== 'none') $jd['offence'] = $jd['traffic_violation']; else $jd['offence'] = null;
                    if($ppi->error) $adar = ['tid' => 100, 'nocreate' => 1, 'nocreatecom' => '$ppi->error: '. $ppi->error];
                    $r = Processing::add_for_balancer(['jd' => $jd, 'adar' => $adar]);# pre($r);
                    $r = Journal::set_processed($row['id']);
                    continue;
                } #pred($ppi->error);

                $jd = Journal::get_one_for_balancer($row['id']); # journal data  pred($jd);

                if(!$jd){
                    $jd['speed'] = (int)$jd['speed'];
                    $jd['speedq'] = (int)$jd['speed_quality'];
                    $jd = Journal::get_one_for_balancer_typed($row['id']); # JOURNAL DATA !! #pred($jd);;pre($jd); #Log::sbl('CheckOffenceAction::init sets to type1? jid: '. $row['id'] ."\n");
                    if($jd['traffic_violation'] !== 'none') $jd['offence'] = $jd['traffic_violation']; else $jd['offence'] = null;
                    $adar = ['tid' => 999, 'nocreate' => 1, 'nocreatecom' => 'CheckOffenceAction::init sets to type1?']; #pred($adar);
                    $r = Processing::add_for_balancer(['jd' => $jd, 'adar' => $adar]);# pre($r);
                    $r = Journal::set_processed($row['id']);
                    continue;
                } #pred($jd);

                $jd['speed'] = (int)$jd['speed'];
                $jd['speedq'] = (int)$jd['speed_quality'];
                if($jd['traffic_violation'] !== 'none') $jd['offence'] = $jd['traffic_violation']; else $jd['offence'] = null;
                if($jd['offence']) $tid = 0; else $tid = $t;
                if(loc) $tid = 0;
                if(hand) pre('TID:'. $tid);

                if($jd['offence']){
                    if(
                        $jd['speedq'] < $this->sets['cafap_upload']['min_speed_quality_offence'] ||
                        $jd['speed'] < $this->sets['upload']['min_speed_offence'] ||
                        $jd['speed'] > $this->sets['upload']['max_speed_offence']
                    ){
                        if($jd['speedq'] < $this->sets['cafap_upload']['min_speed_quality_offence']) $nocreatecom = 'min_speed_quality_offence: '. $jd['speedq'] .' < '. $this->sets['cafap_upload']['min_speed_quality_offence'];
                        if($jd['speed'] < $this->sets['upload']['min_speed_offence']) $nocreatecom = 'min_speed_offence: '. $jd['speed'] .' < '. $this->sets['upload']['min_speed_offence'];
                        if($jd['speed'] > $this->sets['upload']['max_speed_offence']) $nocreatecom = 'max_speed_offence: '. $jd['speed'] .' < '. $this->sets['upload']['max_speed_offence'];
                        $nocreate = true;
                        $nosend = true;
                        $adar = ['tid' => 998, 'nocreate' => 1, 'nocreatecom' => $nocreatecom];
                        $r = Processing::add_for_balancer(['jd' => $jd, 'adar' => $adar]);# pre($r);
                        $r = Journal::set_processed($row['id']);
                        $r = Journal::set_type1($row['id']);
                        Journal::update_log($row['id'], '| typed 1 for '. $nocreatecom .'|');
                        if($this->sets['balancer']['delete_res_for_min_speed_quality_offence']) new CleanResources($jd['id']); #  || min_speed_offence || max_speed_offence'
                        continue;
                    }
                }

                $adarpr = ['tid' => $tid];
                $jid = &$jd['id']; #pred($jd);

                # RULES in config
                /*  [min_speed_quality_offence] => 21
                    [min_speed_quality_noffence] => 1
                    [forbid_not_detected_number] => 1
                    [forbid_offence_lane] => 1
                    [forbid_offence_lane_opposite] => 1 */

                /*if($this->sets['cafap_upload']['forbid_not_detected_number'] && $jd['car_number'] === 'no detect'){
                    $nosend = 1;
                    $nosendcom = 'forbid_not_detected_number';
                    $adarpr = ['nosend' => $nosend, 'nosendcom' => $nosendcom, 'tid' => $tid];
                }*/

                if(!$this->sets['upload']['unrecognized_lpn'] && $jd['recognize_type'] === 2){
                    $nosend = 1;
                    $nosendcom = 'unrecognized_lpn';
                    $adarpr = ['nosend' => $nosend, 'nosendcom' => $nosendcom, 'tid' => $tid];
                }

                if(!$this->sets['upload']['partly_recognized_lpn'] && $jd['recognize_type'] === 1){
                    $nosend = 1;
                    $nosendcom = 'partly_recognized_lpn';
                    $adarpr = ['nosend' => $nosend, 'nosendcom' => $nosendcom, 'tid' => $tid];
                }

                if($jd['offence']){ #pre($jd['speed']); pred($this->sets['upload']['max_speed_offence']);

                    if($jd['offence'] === 'lane' || $jd['offence'] === 'lane_opposite'){
                        if(($this->sets['cafap_upload']['forbid_offence_lane'] && $jd['offence'] === 'lane') || ($this->sets['cafap_upload']['forbid_offence_lane_opposite'] && $jd['offence'] === 'lane_opposite')){
                            $nosend = 1;
                            $nosendcom = 'forbid_offence'. $jd['offence'];
                            $adarpr = ['nosend' => $nosend, 'nosendcom' => $nosendcom, 'tid' => $tid];
                        }
                    }
                    /*if(loc) if($jd['offence'] === 'rroute_vehicles'){
                        $nosend = 1;
                        $nosendcom = 'forbid_offence'. $jd['offence'];
                        $adarpr = ['nosend' => $nosend, 'nosendcom' => $nosendcom, 'tid' => $tid];
                    }*/

                } else {

                    if($jd['speedq'] < $this->sets['cafap_upload']['min_speed_quality_noffence']){
                        $nosend = 1;
                        $nosendcom = 'min_speed_quality_noffence: '. $jd['speedq'] .' < '. $this->sets['cafap_upload']['min_speed_quality_noffence'];
                        $adarpr = ['nosend' => $nosend, 'nosendcom' => $nosendcom, 'tid' => $tid];
                    }
                } # /RULES

                try {
                    $r = Processing::add_for_balancer(['jd' => $jd, 'adar' => $adarpr]);
                    if(isset($r['error'])) pre($r['error']->getMessage()); else { if(hand) pre($r); }
                } catch(\Exception $e){ #catch(\PDOException $e){  #catch(DbPdoException $e){
                    pred($e->getMessage());
                    if(strpos($e->getMessage(), 'already exists') !== false){
                        $r = Journal::set_processed($jid);
                        continue;
                    }
                } #pred($r);  # new PreparedImages($jid);

                $r = Journal::set_processed($jid);

                if(!$nocreate) foreach($servs as $v){
                    $nosendc = 0;
                    $adarpack = ['tid' => $tid, 'us_id' => $v['id'], 'us_type' => $v['ctype']]; # pred($v['need_send']);
                    if($nosend){
                        $adarpack['nosend'] = $nosend;
                        $adarpack['nosendcom'] = $nosendcom;
                    }
                    if($v['need_send'] === 2){
                        $nosendc = 1;
                        if(isset($adarpack['nosendcom'])) $adarpack['nosendcom'].= ' | nosend connection'; else $adarpack['nosendcom'] = 'nosend connection';
                    }
                    if($nosendc) $adarpack['nosend'] = $nosendc;
                    $r = Packing::add_for_balancer(['jd' => $jd, 'adar' => $adarpack]);
                    if(hand) pre($r); # TODO may be need check if alcreated added and in queue! $adarpack['id'] = $r['id'];
                    $r = PackingQ::add_for_balancer(['id' => $r['id'], 'jd' => $jd, 'adar' => $adarpack]); #pred($r); # TODO may be need check if alcreated added and in queue!
                }
                if(!$jd['offence']){ $t++; if($t > $this->sets['balancer']['threads_qty']) $t = 1; }
                pre('T:'. $t);
            } #pred($r);  #

            if(!loc && $row) $lid = (int)$row['id'];
            if(hand) pre('usleep($ms_for_sleep2)'); # if($this->night_mode) sleep(1); else usleep($ms_for_sleep2);
            if($this->night_mode) sleep(20); else sleep(10);
        } while($forwhile);
        if(!cli) pred(321);
        return ResponseSuccess::init(['success' => true, 'data' => []]);
    }

    public function get_sets(){  #$r = UploadServer::get_cafap(['need_send' => true]);

        $exts = get_loaded_extensions();
        if(!in_array('SimpleXML', $exts)){
            $er = __CLASS__ .'::'. __FUNCTION__ .' | Need install SimpleXML! sudo apt install php7.2-xml';
            Log::erlog($er); pred($er);
        }

        $r = XavierInfo::get_groupa('cafap_upload'); #pred($r);
        if(isset($r['min_speed_quality_offence'])) $r['min_speed_quality_offence'] = (int)$r['min_speed_quality_offence']; else $r['min_speed_quality_offence'] = 0;
        if(isset($r['min_speed_quality_noffence'])) $r['min_speed_quality_noffence'] = (int)$r['min_speed_quality_noffence']; else $r['min_speed_quality_noffence'] = 0;
        $this->sets['cafap_upload'] = $r;
        $this->sets['balancer'] = XavierInfo::get_groupa('balancer');
        $this->sets['balancer']['threads_qty'] = (int)$this->sets['balancer']['threads_qty'];
        $this->sets['balancer']['threads_qty'] = $this->sets['balancer']['threads_qty'] - 1; # because one always must be for offences, one for traffic
        if($this->sets['balancer']['threads_qty'] < 1) $this->sets['balancer']['threads_qty'] = 1;
        $this->sets['upload'] = XavierInfo::get_groupa('upload');
        if(isset($this->sets['upload']['max_speed_offence'])) $this->sets['upload']['max_speed_offence'] = (int)$this->sets['upload']['max_speed_offence'];
        $this->sets['imaging'] = XavierInfo::get_groupa('imaging');
        $this->sets['imaging']['crop_height'] = (float)$this->sets['imaging']['crop_height'];
        $this->sets['imaging']['crop_x'] = (float)$this->sets['imaging']['crop_x'];
        $this->sets['imaging']['crop_zoom'] = (float)$this->sets['imaging']['crop_zoom']; #pred($this->sets['imaging']['crop_zoom']); #pred($this->sets['imaging']['car_number_border_padding_x']);
        $this->sets['imaging']['car_number_border_padding_x'] = (int)$this->sets['imaging']['car_number_border_padding_x'];#pred($this->sets['imaging']['car_number_border_padding_x']);
        $this->sets['imaging']['car_number_border_padding_y'] = (int)$this->sets['imaging']['car_number_border_padding_y'];
        $this->sets['imaging']['border_width'] = (int)$this->sets['imaging']['border_width'];

        $this->sets['common_pack'] = XavierInfo::get_groupa('common_pack');
        $this->sets['common_pack']['min_speed_quality_for_speed_na'] = (int)$this->sets['common_pack']['min_speed_quality_for_speed_na'];
        $this->sets['common_pack']['max_speed_for_speed_na'] = (int)$this->sets['common_pack']['max_speed_for_speed_na'];
        $this->sets['zone'] = Zone::get_zone_list(1, ['speed_permissible']); #pred($this->sets);
        $this->sets['dev'] = XavierInfo::get_groupa('dev');
        $this->sets['dev']['journal_virgin'] = (int)$this->sets['dev']['journal_virgin']; #      pred($this->sets['imaging']);

        $this->sets['about'] = XavierInfo::get_groupa('about');
        $this->timezone = (float)$this->sets['about'];
        return true;
    }

    public function reinit_tids(){  #$r = UploadServer::get_cafap(['need_send' => true]);
        $maxt = $this->sets['balancer']['threads_qty']; # $maxt = $maxt - 1; if($maxt < 1) $maxt = 1; pred($maxt);

        if($maxt === 1){
            $rows = Processing::reinit_tids_to1();
            $rows = Packing::reinit_tids_to1();
            $rows = PackingQ::reinit_tids_to1();
            $rows = Sending::reinit_tids_to1();
            $rows = SendingQ::reinit_tids_to1();
            return;
        }

        $rows = Processing::get_for_reinit_tids($maxt);
        $count_to_reinit = count($rows);
        pre('$maxt:'. $maxt);
        pre('count($rows) for reinit:'. $count_to_reinit);

        $c = 0;
        $t = 0;
        foreach($rows as $row){ #pred($row);
            $t++;
            if($t > $maxt) $t = 1;
            if(hand){ $c++; pre('Reinited: '. $c .'/'. $count_to_reinit .' | JID:'. $row['id'] .' | $t:'. $t); }
            Processing::set_tid($row['id'], $t);
            Packing::set_tid_bjid($row['id'], $t);
            PackingQ::set_tid_bjid($row['id'], $t);
            Sending::set_tid_bjid($row['id'], $t);
            SendingQ::set_tid_bjid($row['id'], $t);
        } # pred($rows);
    }

    public function time_update(){  #$r = UploadServer::get_cafap(['need_send' => true]);
        $date = new \DateTime();
        $date->modify('+'. $this->timezone .' hour');
        $this->today = $date->format('Y.m.d');
        $today = $this->today;
        $dayar = $this->dayar;
        if(!isset($dayar[$today])) $dayar = [$today => []];
        $this->h = (int)$date->format('H'); # pred($h); # $h = '02';# pred($h);        $h = (int)'02';
        $this->m = (int)$date->format('i');
        if(hand){ pre($dayar); pre('Hour: '. $this->h .' Min: ' . $this->m); }
    }
}