<?php

namespace CLI\Controllers;

use Core\Module\Db\Db;

class TCleaning {

    # sudo -u www-data /usr/bin/php7.2 $PWD/index.php action=tclean need_log=1 is_test=1 hand=1 debug=1

    private static $sets;

    public static function init(){

        if(hand) pre(__CLASS__ .'::'. __FUNCTION__ .' laucnhed #41');

        $days = 3;
        $tn = '_image_item';
        $where = [['function' => "date_create < now() - interval '". $days ." days'"]];
        if(isset($_REQUEST['debug'])){
            $q = ['select' => [['function' => 'COUNT(date_create)', 'rename' => 'len']], 'table' => $tn, 'where' => $where];
            $r = Db::select($q);
            pre($r); #            pred(count($r)); pred(Db::select($q)); #array( #'date_create'# 'limit' => 1 #
        }
        $q = ['table' => $tn, 'where' => $where]; pre($q);
        $r = Db::delete($q);
        pre($r);

        $days = 3;
        $tn = '_image';
        $where = [['function' => "date_create < now() - interval '". $days ." days'"]];
        if(isset($_REQUEST['debug'])){
            $q = ['select' => [['function' => 'COUNT(date_create)', 'rename' => 'len']], 'table' => $tn, 'where' => $where];
            $r = Db::select($q);
            pre($r); #            pred(count($r)); pred(Db::select($q)); #array( #'date_create'# 'limit' => 1 #
        }
        $q = ['table' => $tn, 'where' => $where]; pre($q);
        $r = Db::delete($q);
        pre($r);

        $days = 3;
        $tn = 'journal_image';
        $where = [['function' => "date_create < now() - interval '". $days ." days'"]];
        if(isset($_REQUEST['debug'])){
            $q = ['select' => [['function' => 'COUNT(date_create)', 'rename' => 'len']], 'table' => $tn, 'where' => $where];
            $r = Db::select($q);
            pre($r); #            pred(count($r)); pred(Db::select($q)); #array( #'date_create'# 'limit' => 1 #
        }
        $q = ['table' => $tn, 'where' => $where]; pre($q);
        $r = Db::delete($q);
        pred($r);

        if(nl) pre("finish test\n");
        return true;
    }
}