<?php

namespace CLI\Controllers;

class AATesting {

    public function __construct(){ # systemctl status aist_front

        if(nl) pre("start test\n");        #pred(self::$timeout);

        $res = &$this->res;
        $whoami = trim(shell_exec('whoami'));
        pre($whoami);
        if(loc) $cmd = DR .'/tools/autoupdate/autoupdate_loc'; else $cmd = DR .'/tools/autoupdate/autoupdate';
        if(ERP === 'autoupdatef') $cmd .= ' '. ERP; pre($cmd);
        $r = shell_exec($cmd);# pre($ls);
        pred($r);

        if(nl) pre("finish test\n");
        return true;
    }
}