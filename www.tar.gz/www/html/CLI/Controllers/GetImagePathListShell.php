<?php

namespace CLI\Controllers; # namespace Project\Aist\Admin\Shell\Image;

use Core\Module\Exception\ParametersException;
use Core\Module\Exception\ParametersValidationException;
use Core\Module\Exception\PhpException;
use Common\Models\Image\Image;
use Common\Models\Image\ImageItem;
use Core\Modules\Json;
use Core\Module\Response\ResponseSuccess;
use Common\Modules\ImagePathListAction;

class GetImagePathListShell { # Project/Aist/Admin/Shell/Image/GetImagePathListShell.php // sudo -u www-data /usr/bin/php /var/www/html/index.php "action=get_image_path_list" json='{}'
    private static $json_list = [];
    private static $image_list = [];

    private static function get_image_mime_type(string $image_type = null){
        switch($image_type){
            case 'jpg':
            case 'jpeg':{
                $image_mime_type ='image/jpeg';
                $image_extension ='jpg';
                break;
            }
            case 'png':{
                $image_mime_type ='image/png';
                $image_extension ='png';
                break;
            }
            default:{
                $error = [
                    'title' => ParametersValidationException::$title,
                    'info' => 'Image type is not valid'
                ];
                throw new ParametersValidationException($error);
                break;
            }
        }
        return [
            'image_mime_type' => $image_mime_type,
            'image_extension' => $image_extension
        ];
    }

    private static function get_image_id(int $width = null, int $height = null, int $file_size = null, string $image_type = null){
        $mime_data =self::get_image_mime_type($image_type);
        $image_mime_type = $mime_data['image_mime_type'];
        $image_extension = $mime_data['image_extension'];
        $r = Image::add_image(null,$image_type,$file_size,$image_mime_type,$image_extension,false,true,true,false,true,null,$width,$height);
        if(empty($r)){
            $error = [
                'title' => PhpException::$title,
                'info' => 'Image was not registration'
            ];
            throw new PhpException($error);
        }
        return $r;
    }

    private static function get_image_item_id(int $image_id = null, int $width = null, int $height = null, int $file_size = null, string $image_type = null){
        $mime_data =self::get_image_mime_type($image_type);
        $image_mime_type = $mime_data['image_mime_type'];
        $image_extension = $mime_data['image_extension'];
        $r = ImageItem::add_image_item(null,$image_id,$width,$height,'source',$image_type,$file_size,$image_mime_type,$image_extension,false,true,true,false);
         if(empty($r)){
            $error = [
                'title' => PhpException::$title,
                'info' => 'Image item was not registration'
            ];
            throw new PhpException($error);
        }
        return $r;
    }

    private static function prepare_json_list(){
        if(!count(self::$json_list)){ $error = ['title' => ParametersValidationException::$title, 'info' => 'Json list is empty'];  throw new ParametersValidationException($error); }
        $image_id_list = [];
        foreach(self::$json_list as $row){
            $error_info_list = [];
            if(empty($row['width'])) $error_info_list[] = 'Width is empty';
            if(empty($row['height'])) $error_info_list[] = 'Height is empty';
            if(empty($row['file_size'])) $error_info_list[] = 'ile_size is empty';
            if(empty($row['image_type'])) $error_info_list[] = 'Image type is empty';
            if(count($error_info_list) > 0){
                $error = ['title' => ParametersValidationException::$title, 'info' => $error_info_list];
                throw new ParametersValidationException($error);
            }
            $r = self::get_image_id($row['width'],$row['height'],$row['file_size'],$row['image_type']);
            if(empty($r['id'])){
                $error = [
                    'title' => PhpException::$title,
                    'info' => 'Image was not registration'
                ];
                throw new PhpException($error);
            }
            $image_id = $r['id'];
            $image_date_create = $r['date_create'];
            $image_item_id =self::get_image_item_id($image_id,$row['width'],$row['height'],$row['file_size'],$row['image_type']);
            if(empty($image_item_id)){
                $error = [
                    'title' => PhpException::$title,
                    'info' => 'Image was not registration'
                ];
                throw new PhpException($error);
            }
            $image_id_list[] = $image_id;
        }
        if(!count($image_id_list)) return true;
        $r = ImagePathListAction::get_image_path_list($image_id_list,false,true,true);
        foreach($r as $row)
            self::$image_list[] = [
                'image_id' => $row['image_id'],
                'path' => $row['image_dir'].'/'.$row['image_item_id_list']['source']['id']
            ];
        return true;
    }

    public static function init(){ # \Config::$is_debug=true;
        if(empty($_POST['json'])){ $error = ['title' => ParametersException::$title, 'info' => 'JSON is empty']; throw new ParametersException($error); }
        self::$json_list = Json::decode($_POST['json']);
        self::prepare_json_list();
        $data = ['success' => true, 'data' => ['image_list' => self::$image_list]];
        return ResponseSuccess::init($data);
    }
}