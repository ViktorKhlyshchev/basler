<?php

namespace CLI\Controllers;

use Core\Modules\Dir;
use Configs\DirConfig;
use Common\Models\XavierInfo;
use Core\Modules\Log;
use Common\Models\UploadServer;

class AistUpload { # MAIN!! tid - thread id, pid - process id

    // sudo -u www-data /usr/bin/php7.2 -f /home/alex/0git/aist/index.php action=aist_upload need_log=1 hand=1
    // sudo -u www-data /usr/bin/php7.2 -f /home/alex/0git/aist/index.php action=aist_upload need_log=1 >> /dev/null 2>&1 & echo $
    // sudo -u www-data /usr/bin/php7.2 -f /var/www/html/index.php action=aist_upload need_log=1 hand=1
    // sudo -u www-data /usr/bin/php7.2 -f /var/www/html/index.php action=aist_upload thread_limit=1 need_log=1
    // sudo -u www-data /usr/bin/php7.2 $PWD/index.php action=aist_upload need_log=1
    // while true; do ps aux | grep index.php; sleep 2; done
    // sudo -u www-data php /var/www/html/index.php "action=sendbox_thread_list" "thread_limit=3" "is_test=1" >> /dev/null 2>&1 & echo $
    # /usr/bin/php7.2 -f '/var/www/html/index.php' action=balancer > /dev/null 2>&1 & echo $!
    # /usr/bin/php7.2 -f "$PWD/index.php" action=balancer
    # ps a | grep index | awk '{print $1}' | xargs kill -9 $1
    public $cafap_pack_thread_limit;
    public $cafap_send_thread_limit;
    public $duplo_pack_thread_limit;
    public $duplo_send_thread_limit;
    public $limits = ['balancer' => 1, 'cafap_pack_thread' => 3, 'cafap_send_thread' => 3, 'duplo_pack_thread' => 3, 'duplo_send_thread' => 3]; # 'resender' => 1,
    public $sets = [];
    public $pids = ['balancer' => [], 'cafap_pack_thread' => [], 'cafap_send_thread' => [], 'duplo_pack_thread' => [], 'duplo_send_thread' => []]; # public $procs_types = ['balancer', 'cafap_pack_thread', 'cafap_send_thread', 'duplo_pack_thread', 'duplo_send_thread']; # 'resender',
    public $procs_types_or = ['cafap_pack_thread', 'cafap_send_thread', 'duplo_pack_thread', 'duplo_send_thread']; # 'resender',
    public $procs_types = ['cafap_pack_thread', 'cafap_send_thread', 'duplo_pack_thread', 'duplo_send_thread']; # 'resender',
    public $procs = [];
    public $died_ctr = ['balancer' => 0, 'cafap_pack_thread' => 0, 'cafap_send_thread' => 0, 'duplo_pack_thread' => 0, 'duplo_send_thread' => 0]; # 'resender' => 0,

    function Rset_limits(){
        $r = XavierInfo::get_list_from_group('aist_upload'); #pred($r);
        if($r) foreach($this->procs_types as $pt){
            $this->limits[$pt] = isset($r['aist_upload'][$pt]) ? (int)$r['aist_upload'][$pt] : 3;
            if(!isset($this->limits[$pt]) || $this->limits[$pt] < 4 || $this->limits[$pt]  > 5) $this->limits[$pt] = 4;
        }
        $this->limits['balancer'] = 1; #pred($this->limits);
        return true;
    }

    public function get_sets(){  #$r = UploadServer::get_cafap(['need_send' => true]);
        $this->sets['balancer'] = XavierInfo::get_groupa('balancer'); # pred($this->sets['balancer']);
        $this->sets['balancer']['threads_qty'] = (int)$this->sets['balancer']['threads_qty'];
        return true;
    }

    function check_deploy(){
        $dp = DR .'/Temp';
        $dirs = array_filter(glob($dp .'/*'), 'is_dir');# pred($dirs);
        if(!count($dirs)) require DR .'/tools/deploy/index.php';
    }

    function check_perms(){
        if(!Dir::create_dirn(DirConfig::$dir_duplo_xml)){ pred('cant create dir '. __FUNCTION__ .'#1 dir:__'. DirConfig::$dir_cafap_package); return; }
        $this->dir_package = DR .'/'. DirConfig::$dir_duplo_xml;
        $fn = '/000perms_test.txt';
        $fp = $this->dir_package . $fn;
        $r = file_put_contents($fp, $fn);
        if($r) unlink($fp); else pred('Cant put file for DUPLO dir! Fp:__'. $fp);
        $tdp = DR .'/'. DirConfig::$dir_cafap_package_temp .'/000perms_test';
        if(Dir::create_dirn($tdp)) rmdir($tdp); else pred('cant create dir for CAFAP pack!! '. __FUNCTION__ .'#1 dir:__'. $tdp);
    }

    function exec(string $pt = null, int $tid = null){ # pt - process type
        $pids = [];
        $test = ''; if($test) $test = ' is_test=1 ';
        if($pt === 'balancer') $cmd = '/usr/bin/php'. \Config::$phpv .'  -f \''. DR .'/index.php\' action=balancer > /dev/null 2>&1 & echo $!'; #  > /dev/null 2>&1 & echo $!
        elseif($pt === 'resender') $cmd = '/usr/bin/php'. \Config::$phpv .'  -f \''. DR .'/index.php\' action=resender > /dev/null 2>&1 & echo $!';
        else
            $cmd = '/usr/bin/php'. \Config::$phpv .'  -f \''. DR .'/index.php\' action='. $pt .' tid='. $tid . ' > /dev/null 2>&1 & echo $!'; #  > /dev/null 2>&1 & echo $!
        if(\Config::$aist_upload_logging) Log::log('aist_upload', 'exec '. $cmd); pre($cmd);
        exec($cmd, $pids); # , $is_success
        if(!empty($pids)){
            $this->pids[$pt][(int)$pids[0]] = $tid;
            $this->procs[$pids[0]] = $pt;
        }
        pre($this->pids);
    }

    function check_pid($pt, $pid, $tid){ #if(file_exists("/proc/$pid")) Log::au($pid.' '. $tid .' exist');
        if(file_exists("/proc/$pid")) return;
        #Log::au($pid.' '. $pt .' died');
        #if(nl){ echo $this->procs[$pid] .'_'. $pid." died\n"; }
        if(nl){ echo $pt .'_'. $pid." died\n"; }
        unset($this->procs[$pid]);
        unset($this->pids[$pt][$pid]);
        $this->died_ctr[$pt]++;
        #Log::au(json_encode($this->died_ctr));
        $this->exec($pt, $tid);
    }

    function check_servs(){ #if(file_exists("/proc/$pid")) Log::au($pid.' '. $tid .' exist');

        $this->procs_types = $this->procs_types_or;

        $pautina_servs = UploadServer::get_duplo(); #pre($pautina_servs);
        $cafap_servs = UploadServer::get_cafap(); # pred($cafap_servs);

        $pautina_need_send = false;
        if($pautina_servs){
            foreach($pautina_servs as $v) if($v['need_send']) $pautina_need_send = true;
            if(!$pautina_need_send){
                unset($this->procs_types['duplo_pack_thread']);
                unset($this->procs_types['duplo_send_thread']);
            }
        }
        if(!$pautina_need_send){
            foreach($this->procs_types as $k => $v){
                if($v === 'duplo_pack_thread' || $v === 'duplo_send_thread') unset($this->procs_types[$k]);
            } # unset($this->procs_types['duplo_pack_thread']);            unset($this->procs_types['duplo_send_thread']);
        }

        $cafap_need_pack = false;
        $cafap_need_send = false;
        if($cafap_servs){
            foreach($cafap_servs as $v){ #pre($v);
                $ns = (int)$v['need_send'];
                if($ns === 1){
                    $cafap_need_pack = true;
                    $cafap_need_send = true;
                }
                if($ns === 2) $cafap_need_pack = true;
            }
            if(!$cafap_need_send) unset($this->procs_types['cafap_send_thread']);
            if(!$cafap_need_pack) unset($this->procs_types['cafap_pack_thread']);
        }
        if(!$cafap_need_send || !$cafap_need_pack){
            foreach($this->procs_types as $k => $v){
                if(!$cafap_need_pack && $v === 'cafap_pack_thread') unset($this->procs_types[$k]);
                if(!$cafap_need_send && $v === 'cafap_send_thread') unset($this->procs_types[$k]);
            }
        } #foreach($this->pids as $k => $v){     }        pre($this->pids);
    }

    function __construct(){

        $exts = get_loaded_extensions();
        if(!in_array('SimpleXML', $exts)){
            $er = __CLASS__ .'::'. __FUNCTION__ .' | Need install SimpleXML! sudo apt install php7.2-xml';
            Log::erlog($er); pred($er);
        }

        $this->check_deploy();
        $this->get_sets();
        $this->check_perms();
        $this->check_servs();

        if(loc) $this->sets['balancer']['threads_qty'] = 1;

        if(!loc) $this->exec('balancer');

        foreach($this->procs_types as $pt){ #pre($pt);
           for($tid = 0; $tid < $this->sets['balancer']['threads_qty']; $tid++) $this->exec($pt, $tid);
        } #pred($this->pids);

        #Log::au(json_encode($this->pids));

        do {
            foreach($this->procs_types as $pt){
                /*foreach($this->pids[$pt] as $pid => $tid){
                    if(!file_exists("/proc/$pid")){
                        Log::au($pid.' '. $tid .' died');
                        if(nl) echo $this->procs[$pid];
                        if(nl) echo $pid." died\n";
                        unset($this->procs[$pid]);
                        $this->exec($pt, $tid);
                        sleep(1);
                    } else Log::au($pid.' '. $tid .' exist');
                }*/
                if(!loc) foreach($this->pids[$pt] as $pid => $tid) $this->check_pid($pt, $pid, $tid);
                foreach($this->pids[$pt] as $pid => $tid) $this->check_pid($pt, $pid, $tid);
            }


            #pre($this->died_ctr);
            #pre($this->pids); if(nl) pre(rand());
            #$pids = array_merge($this->create_pids, $this->send_pids);            pred($this->create_pids);            pred($pids);
            #foreach($pids as $pid => $tid) Log::au($pid.' '. $tid .' died');
            #Log::au(implode(',', array_keys($this->create_pids)));

            $this->get_sets();
            $this->check_servs();

            if(loc){
                pre('sleep(2) rand():'. rand()); sleep(2);
            } else {
                pre('sleep(30) rand():'. rand()); sleep(30);
            }
        } while(true); #} while(0); ok();
    }
}