<?php

namespace CLI\Controllers;

use CLI\Modules\CLIController;
use Common\Models\UploadServer;
use Common\Models\Packing;
use Common\Models\PackingQ;
use Common\Models\Sending;
use Common\Models\SendingQ;
use CLI\Modules\Duplo\DuploCreatepackage;
use Common\Models\Processing;
use Common\Models\XavierInfo;
use CLI\Modules\Clean\CleanResources;
use Common\Models\Journal;
use Core\Modules\Dir;
use Configs\DirConfig;
use Common\Models\Zone;

class DuploPackMThread extends CLIController { # MultiThread
    // sudo -u www-data php /var/www/html/index.php "action=createbox_thread" "thread_id=3" "is_test=1" "need_log=1" >> /dev/null 2>&1 & echo $
    # sudo -u www-data /usr/bin/php7.2 -f "$PWD/index.php" action=duplo_pack_thread need_log=1
    # sudo -u www-data /usr/bin/php7.2 -f "$PWD/index.php" action=duplo_pack_thread tid=0 need_log=1
    # sudo -u www-data /usr/bin/php7.2 -f "$PWD/index.php" action=duplo_pack_thread tid=1 need_log=1
    # LOCAL TEST aist.loc/duplo

    public $tid; # $thread_id
    public $sets; # settings
    public $night_mode;
    public $dayar = [];
    /*private static $journal_id_list;
    private static $thread_id;
    private static $speed_quality_min;
    private static $journal_limit;
    static $journal_limit_max = 1000;
    static $strys_limit_max = 10;*/

    public function __construct($action = null){

        if(loc) $this->check_perms();

        $this->tid = !isset($_REQUEST['tid']) ? 1 : (int)$_REQUEST['tid'];
        if(loc) $this->tid = 0;
        pre('self::$tid__', $this->tid); #        pre('cli', cli);
        pre('self::$thread_id === 0', $this->tid === 0); #pred($_REQUEST);

        $ms_for_sleep2 = 2 * 1000 * 100; #pred($ms_for_sleep);
        $ms_for_sleep4 = 4 * 1000 * 100; #pred($ms_for_sleep);
        $ms_for_sleep4 = 12 * 1000 * 100; #pred($ms_for_sleep);

        #$servs = UploadServer::get_for_pack('duplo'); # pred($servs);
        $servs = $this->get_servs(); #pred($servs);
        $this->get_sets();
        $this->time_update();

        $c = 0;
        $cc = 0;

        do {
            $c++; $cc++;

            if(!$servs){
                if(hand) pre('sleep('. \Config::$upload_servs_break .') . UploadServer !$servs <SKIP#1>');
                sleep(\Config::$upload_servs_break);
                $servs = $this->get_servs();
                continue;
            }

            if($c > 200){
                $c = 0;
                $this->time_update();
                if($this->h > 1 && $this->h < 5){
                    $this->night_mode = true;
                } elseif($this->h > 5){
                    $this->night_mode = false;
                }
            }

            if($cc > 2000){
                $cc = 0; # 2000/5 400 secs, 6.6 mins
                $servs = $this->get_servs();
                $this->get_sets();
            } # pred($this->tid); #$r = Packing::get_duplo_readies(); #if($r > 1000){ pre('readies>1000'); sleep(10); continue; }

            $rows = Packing::hold_for_duplo($this->tid); # pred($rows);           #pred($servs);

            if(!$rows){
                if(hand) pre('usleep($ms_for_sleep4); Journal !$rows <SKIP>#1'. rand());
                if($this->night_mode) sleep(5); else sleep(1);
                continue;
            } #pred($rows);

            XavierInfo::update_data('create_stat', 'duplo_last_holded', $rows[0]['jid']);

            foreach($rows as $row){ #pred($row);
                $c++; $cc++;

                if(!$servs[$row['us_id']]['need_send']){ #if(1){
                    PackingQ::update_need_send_ch($row['id']);
                    PackingQ::update_log($row['id'], 'Server changed to NOSEND');
                    Packing::delete_bids([$row['id']]);
                    Packing::copy_packingq($row['id']);
                    PackingQ::delete_bids([$row['id']]);
                    Processing::update_need_send_ch($row['jid']);
                    continue;
                } # $row['hash_updated'] = false;

                $serv = &$servs[$row['us_id']]; #pred($serv);  pre($c);#pre($keys_created);                    #pred($servs);  pred($row);

                $dcp = new DuploCreatepackage($row, $serv, $this);
                $row['fp'] = $dcp->create();  #Dir::remove_dirn($ccp->dir_package); #pre($tar_fp);
                if($row['fp']){
                    pre('DUPLO CREATED! '. $row['jid'] .' fp:__'. $row['fp']);
                } else {
                    XavierInfo::increment_value('create_stat', 'duplo_alltime_not_created_qty');
                    XavierInfo::increment_value('create_stat', 'duplo_not_created_qty');
                    continue;
                }

                XavierInfo::increment_value('create_stat', 'duplo_alltime_created_qty');
                XavierInfo::increment_value('create_stat', 'duplo_created_qty');

                $row['file_size'] = filesize($row['fp']); #pred($row['size']);
                $row['tid'] = $this->tid;
                if(!$row['nosend']){
                    $r = Sending::add($row, $serv); if(hand) pre('SENDING ADDED!! id: '. $r['id']);
                    $row['sid'] = $r['id'];
                    $r = SendingQ::add($row, $serv); if(hand) pre('SENDINGQ ADDED!! id: '. $r['id']);
                }

                PackingQ::update_created($row);
                Packing::delete_bids([$row['id']]);
                Packing::copy_packingq($row['id']);
                PackingQ::delete_bids([$row['id']]);

                $all = $this->createall_check_set($row);
                if($all) if($this->sets['common_pack']['remove_sources_after_creating']){
                    Journal::update_log($row['jid'], '| sources removed from DUPL0 |');
                    if(!loc) new CleanResources($row['jid']);
                }
            }
            #pred($keys_created);
            #pre($r->errors); pred($r->log);
            if(loc){
                sleep(1);
            } else {
                if(hand) pre('usleep($ms_for_sleep2)');
                if($this->night_mode) sleep(1); else usleep($ms_for_sleep4); # usleep($ms_for_sleep2);
            }
        } while(true);
        return ['success' => true]; #return ResponseSuccess::init(['success' => true,'data' => []]);
    }

    public function get_servs(){
        $servs = UploadServer::get_duplo();
        return $servs;
    }

    public function get_sets(){  #$r = UploadServer::get_duplo(['need_send' => true]);
        $this->sets['duplo_pack'] = XavierInfo::get_groupa('duplo_pack');
        $this->sets['common_pack'] = XavierInfo::get_groupa('common_pack');
        $this->sets['common_pack']['min_speed_quality_for_speed_na'] = (int)$this->sets['common_pack']['min_speed_quality_for_speed_na'];
        $this->sets['common_pack']['max_speed_for_speed_na'] = (int)$this->sets['common_pack']['max_speed_for_speed_na']; #pred($this->sets);
        $this->sets['zone'] = Zone::get_zone_list(1, ['speed_permissible']); #pred($this->sets);

        $this->sets['about'] = XavierInfo::get_groupa('about');
        $this->timezone = (float)$this->sets['about']['timezone'];
    }

    public function createall_check_set($row){ #pre($row);
        $rows = Packing::get_all_jid($row['jid']); #pred($rows); #        $r = Processing::update_allsent($row['jid']);
        $all = true;
        if(!$rows) $all = false;
        foreach($rows as $r) if(!$r['created']) $all = false; #pred($all);
        if($all) $r = Processing::update_allcreate($row['jid']);
        return $all;
    }

    function check_perms(){
        if(!Dir::create_dirn(DirConfig::$dir_duplo_xml)){ pred('cant create dir '. __FUNCTION__ .'#1 dir:__'. DirConfig::$dir_cafap_package); return; }
        $this->dir_package = DR .'/'. DirConfig::$dir_duplo_xml;
        $fn = '/000perms_test.txt';
        $fp = $this->dir_package . $fn;
        $r = file_put_contents($fp, $fn);
        if($r) unlink($fp); else pred('Cant put file for DUPLO dir! Fp:__'. $fp);
    }

    public function time_update(){  #$r = UploadServer::get_cafap(['need_send' => true]);
        $date = new \DateTime();
        $date->modify('+'. $this->timezone .' hour');
        $this->today = $date->format('Y.m.d');
        $today = $this->today;
        $dayar = $this->dayar;
        if(!isset($dayar[$today])) $dayar = [$today => []];
        $this->h = (int)$date->format('H'); # pred($h); # $h = '02';# pred($h);        $h = (int)'02';
        $this->m = (int)$date->format('i');
        if(hand){ pre($dayar); pre('Hour: '. $this->h .' Min: ' . $this->m); }
    }
}