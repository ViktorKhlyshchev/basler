<?php

namespace CLI\Controllers; # namespace Project\Aist\Admin\Shell\Journal;

use Common\Models\Statistics;
use Common\Models\XavierInfo;
use Core\Modules\Log;

class AistFront { # Autochange GPS and timezone

    # sudo -u www-data /usr/bin/php /var/www/html/index.php action=aist_front need_log=1 is_test=1 >> /dev/null 2>&1 & echo $
    # sudo -u www-data /usr/bin/php7.2 $PWD/index.php action=aist_front need_log=1 is_test=1 >> /dev/null 2>&1 & echo $

    private static $timeout = 60 * 5;
    private static $about;
    private static $data1;
    private static $data2;
    private static $data3;

    private static $timezone;
    private static $dayar = [];
    private static $today;

    public static function compute_distance($lat1, $lng1, $lat2, $lng2, $radius = 6378137){ #pre(func_get_args());

        static $x = M_PI / 180;
        $lat1 *= $x; $lng1 *= $x;
        $lat2 *= $x; $lng2 *= $x;
        $distance = 2 * asin(sqrt(pow(sin(($lat1 - $lat2) / 2), 2) + cos($lat1) * cos($lat2) * pow(sin(($lng1 - $lng2) / 2), 2)));
        return $distance * $radius; # meters
    } #[0] => 48.74963033    [1] => 44.48560083    [2] => 48.74961883    [3] => 44.48559200

    public static function check_coords(){ # 1 was 48.74963033,44.48560083 10 was 55.99162917,92.93595083
            #pre(self::$data1['coordinates']); pre(self::$data2['coordinates']); pre(self::$data3['coordinates']);  #if(self::$data1['coordinates'] ===  self::$data2['coordinates'] && self::$data2['coordinates'] === self::$data3['coordinates']){
        if(nl) pre(self::$about['coords']);
        if(self::$data1['coordinates'] === '0.00000000,0.00000000') return;
        if(!self::$about['coords']){
            XavierInfo::update_data('about', 'coords', self::$data1['coordinates']);
            return;
        } # pred($coords);   #pred(self::$about);

        if(nl){
            pre(self::$data1['coordinates']);
            pre(self::$data2['coordinates']);
            pre(self::$data3['coordinates']);
            pre(self::$about['coords'] === self::$data1['coordinates']);
        }

        #if(self::$about['coords'] === self::$data1['coordinates']) return;
        #pre(self::$data1['coordinates'] === self::$data2['coordinates']);
        #if(self::$data1['coordinates'] === self::$data2['coordinates']) return;
        #pre(self::$data2['coordinates'] === self::$data3['coordinates']);
        #if(self::$data2['coordinates'] === self::$data3['coordinates']) return;

        $coordinates = explode(',', self::$data1['coordinates']);
        $coords = explode(',', self::$about['coords']);

        $d = self::compute_distance($coords[0], $coords[1], $coordinates[0], $coordinates[1]); pre($d);

        if($d > 100){

            $coordinates2 = explode(',', self::$data2['coordinates']);
            $d = self::compute_distance($coordinates[0], $coordinates[1], $coordinates2[0], $coordinates2[1]); pre($d);

            if($d < 100){

                $coordinates3 = explode(',', self::$data3['coordinates']);
                $d = self::compute_distance($coordinates2[0], $coordinates2[1], $coordinates3[0], $coordinates3[1]); pre($d);

                if($d < 100){
                    pre('COORDS > 100m.!! CHANGING COORDS!'. $d .' meters');
                    XavierInfo::update_data('about', 'coords', self::$data1['coordinates']); #pred($r);  XavierInfo::update_data('about', 'coords', null); pred($r);
                }
            }
        }
    }

    public static function check_upload(){ #Log::af($pid.' '. $pt .' died');

        $date = new \DateTime();
        $date->modify('+'. self::$timezone .' hour');
        self::$today = $date->format('Y.m.d');
        $today = &self::$today;
        $dayar = &self::$dayar;
        if(!isset($dayar[$today])) $dayar = [$today => []];
        $h = (int)$date->format('H'); # pred($h); # $h = '02';# pred($h);        $h = (int)'02';
        $m = (int)$date->format('i');
        if(hand){ pre($dayar); pre('Hour: '. $h .' Min: ' . $m); }

        #if(!loc){
            if(!isset($dayar[$today]['thread_decrease'])){ #if($h> 1 && $h < 5){
                if($h > 1 && $h < 5){
                    $dayar[$today]['thread_decrease'] = 1;
                    Log::log('aist_upload', json_encode($dayar[$today]['thread_decrease']));
                    XavierInfo::update_data('balancer', 'threads_qty', 2); # $rr = shell_exec(DR .'/Xavier/restart_service.sh'); #$rr = shell_exec(DR .'/tools/services/restart_upload.sh');
                    $service = 'aist_upload';
                    $service_action = 'restart';
                    if(loc) $cmd = DR .'/tools/servicesctl_loc/ssetuid '. $service .' '. $service_action; else $cmd = DR .'/tools/servicesctl/ssetuid '. $service .' '. $service_action; pre($cmd);
                    $r = shell_exec($cmd);# pre($ls);
                    pre($r);
                }
            }

            if(!isset($dayar[$today]['thread_increase'])){ #if($h> 1 && $h < 5){
                if($h > 5){
                    $dayar[$today]['thread_increase'] = 1;
                    Log::log('aist_upload', json_encode($dayar[$today]['thread_increase']));
                    XavierInfo::update_data('balancer', 'threads_qty', 3); # $rr = shell_exec(DR .'/Xavier/restart_service.sh'); #$rr = shell_exec(DR .'/tools/services/restart_upload.sh');
                    $service = 'aist_upload';
                    $service_action = 'restart';
                    if(loc) $cmd = DR .'/tools/servicesctl_loc/ssetuid '. $service .' '. $service_action; else $cmd = DR .'/tools/servicesctl/ssetuid '. $service .' '. $service_action; pre($cmd);
                    $r = shell_exec($cmd);# pre($ls);
                    pre($r);
                }
            }
        #}

    }

    public static function init(){ # systemctl status aist_front

        if(nl) pre("start test\n");        #pred(self::$timeout);
        while(true){

            $r = Statistics::get_last(3); # desc # pred($r);
            $data1 = json_decode($r[0]['data'], 1);        # pre($data1['uptime']); pred($data2['uptime']);
            $data2 = json_decode($r[1]['data'], 1);
            $data3 = json_decode($r[2]['data'], 1);  #pre($data1); pre($data2); pre($data3);  #$res['data'] = &$data;  #pre($data1['timezone']); pre($data2['timezone']); pre($data3['timezone']);  #$res['data'] = &$data;
            $r = XavierInfo::get_list_from_group('about');
            $ctz = (float)$r['about']['timezone']; #pred($r); #pre($ctz); pred($data1['timezone']);

            self::$timezone = $ctz;

            self::check_upload($ctz);# if(!($c%2))

            self::$about = &$r['about'];
            self::$data1 = &$data1;
            self::$data2 = &$data2;
            self::$data3 = &$data3;

            self::check_coords();

            if(nl){ pre($data1['timezone']); pre($data2['timezone']); pre($data3['timezone']); pre($ctz); }
            if($data1['timezone'] !== $ctz && $data1['timezone'] === $data2['timezone'] && $data2['timezone'] === $data3['timezone']) XavierInfo::update_data('about', 'timezone', (int)$data1['timezone']); #pred($r);
            #pred($r);
            if(loc) self::$timeout = 1;
            echo 'sleep('. self::$timeout .')'."\n";
            sleep(self::$timeout);
        }

        if(nl) pre("finish test\n");
        return true;
    }
}