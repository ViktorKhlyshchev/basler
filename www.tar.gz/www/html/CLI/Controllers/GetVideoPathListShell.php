<?php

namespace CLI\Controllers; # namespace Project\Aist\Admin\Shell\Video;

use Core\Module\Exception\ParametersException;
use Core\Module\Exception\ParametersValidationException;
use Core\Module\Exception\PhpException;
use Core\Module\Video\Video;
use Core\Module\Video\VideoItem;
use Core\Modules\Json;
use Core\Module\Response\ResponseSuccess;
use Project\Aist\Admin\Action\Video\VideoPathListAction;

class GetVideoPathListShell {  // sudo -u www-data /usr/bin/php /var/www/html/index.php "action=get_video_path_list" json='{}'

    private static $json_list = [];
    private static $video_list = [];

    private static function get_video_mime_type(string $video_type = null){
        switch($video_type){
            case 'mp4':{
                $video_mime_type ='video/mp4';
                $video_extension ='mp4';
                break;
            }
            default:{
                $error = [
                    'title' => ParametersValidationException::$title,
                    'info' => 'Video type is not valid'
                ];
                throw new ParametersValidationException($error);
                break;
            }
        }
        return [
            'video_mime_type' => $video_mime_type,
            'video_extension' => $video_extension
        ];
    }

    private static function get_video_id(int $width = null, int $height = null, int $file_size = null, string $video_type = null, int $duration = null){
        $mime_data =self::get_video_mime_type($video_type);
        $video_mime_type = $mime_data['video_mime_type'];
        $video_extension = $mime_data['video_extension'];
        $r = Video::add_video(null,$video_type,$file_size,$video_mime_type,$video_extension,false,true,true,false,true,null,$width,$height,$duration);
        if(empty($r)){
            $error = [
                'title' => PhpException::$title,
                'info' => 'Video was not registration'
            ];
            throw new PhpException($error);
        }
        return $r;
    }

    private static function get_video_item_id(int $video_id = null, int $width = null, int $height = null, int $file_size = null, string $video_type = null, int $duration = null){
        $mime_data =self::get_video_mime_type($video_type);
        $video_mime_type = $mime_data['video_mime_type'];
        $video_extension = $mime_data['video_extension'];
        $r = VideoItem::add_video_item(null,$video_id,$width,$height,'source',$video_type,$file_size,$video_mime_type,$video_extension,false,true,true,false,$duration);
         if(empty($r)){
            $error = [
                'title' => PhpException::$title,
                'info' => 'Video item was not registration'
            ];
            throw new PhpException($error);
        }
        return $r;
    }

    private static function prepare_json_list(){
        if(count(self::$json_list) === 0){
            $error = [
                'title' => ParametersValidationException::$title,
                'info' => 'Json list is empty'
            ];
            throw new ParametersValidationException($error);
        }
        $video_id_list = [];
        foreach(self::$json_list as $row){
            $error_info_list = [];
            if(empty($row['width'])) $error_info_list[] = 'Width is empty';
            if(empty($row['height'])) $error_info_list[] = 'Height is empty';
            if(empty($row['file_size'])) $error_info_list[] = 'ile_size is empty';
            if(empty($row['video_type'])) $error_info_list[] = 'Video type is empty';
            if(count($error_info_list) > 0){
                $error = [
                    'title' => ParametersValidationException::$title,
                    'info' => $error_info_list
                ];
                throw new ParametersValidationException($error);
            }
            $duration = empty($row['duration']) ? null : (int)$row['duration'];
            $r = self::get_video_id($row['width'],$row['height'],$row['file_size'],$row['video_type'],$duration);
            if(empty($r['id'])){
                $error = [
                    'title' => PhpException::$title,
                    'info' => 'Video was not registration'
                ];
                throw new PhpException($error);
            }
            $video_id = $r['id'];
            $video_date_create = $r['date_create'];
            $video_item_id =self::get_video_item_id($video_id,$row['width'],$row['height'],$row['file_size'],$row['video_type']);
            if(empty($video_item_id)){
                $error = [
                    'title' => PhpException::$title,
                    'info' => 'Video was not registration'
                ];
                throw new PhpException($error);
            }
            $video_id_list[] = $video_id;
        }
        if(count($video_id_list) === 0) return true;
        $r = VideoPathListAction::get_video_path_list($video_id_list,false,true,true);
        foreach($r as $row)
            self::$video_list[] = [
                'video_id' => $row['video_id'],
                'path' => $row['video_dir'].'/'.$row['video_item_id_list']['source']['id']
            ];
        return true;
    }

    private static function set_return(){
        $data = [
            'success' => true,
            'data' => [
                'video_list' => self::$video_list
            ]
        ];
        return ResponseSuccess::init($data);
    }

    public static function init(){ # \Config::$is_debug=true;
        if(empty($_POST['json'])){
            $error = [
                'title' => ParametersException::$title,
                'info' => 'JSON is empty'
            ];
            throw new ParametersException($error);
        }
        self::$json_list=Json::decode($_POST['json']);
        self::prepare_json_list();
        return self::set_return();
    }
}