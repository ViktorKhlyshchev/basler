<?php

use Core\Module\Url\Url;

class Config {

    public static $db = [ #'ftype' => 'postgresql', # full type
        'type' => 'pgsql', # short type
        'host' => 'localhost',
        'name' => 'aist',
        'login' => 'postgres',
        'password' => 'postgres',
        'port' => 5432
    ];

    public static $saddr = '127.0.0.1'; # server address
    public static $phpv = '7.2'; # php version for executable path /usr/bin/php /usr/bin/php7.2 /usr/bin/php7.4 etc.
    public static $url_for_email_notification = 'info.aist.ru';

    public static $is_debug = false;
    public static $is_query_debug = false;
    public static $is_geo_debug = false;
    public static $is_test_param = true;
    public static $is_geo_determine = false;
    public static $show_worktime = false;
    public static $servername = null;
    public static $onethread_upload = false;

    public static $project_name = 'Aist.ru';
    public static $email_log = ['fenicks88@gmail.com'];
    public static $email_no_replay = 'no-reply@aist.ru';
    public static $email_default = 'no-reply@aist.ru';
    public static $email_payment = 'fenicks88@gmail.com';
    public static $email_feedback = 'fenicks88@gmail.com';
    public static $http_type = 'http';
    public static $is_need_recaptcha = false;
    public static $need_google_recaptcha = false;

    public static $ip_tcp = '127.0.0.1';  #public static $ip_tcp = '188.243.174.207';
    public static $ip_tcp_port = 5055;
    public static $ip_web_port = 2020;

    // custom config
    public static $is_need_xml_in_box = true;
    public static $is_need_json_in_box = true;
    public static $is_need_save_xml_in_resources = false;
    public static $is_need_test_xml_in_box = false;
    public static $is_need_track_list_in_xml = false;
    public static $is_need_send_no_detect_box = false;
    public static $is_need_filter_speed_quality = false;
    # public static $is_need_always_send_none_traffic_violation = true;
    public static $speed_quality_min = 20;
    public static $is_need_ftp_send_boxes_with_passive_mode = false;
    public static $is_need_traffic_violation_video = true;

    // PACKAGE
    public static $upload_servs_break = 30;
    public static $readies_limit = 1000;
    public static $prows_at_iter = 20;
    // PACKAGE

    // UPLOAD
    public static $upload_duplo = false;
    public static $upload_duplo_save_resp_to_log = false;

    # CAFAP
    public static $cafap_remove_temp_source_dir_for_tar = true;
    public static $cafap_upload_min_speed_quality_offence = 0;
    public static $cafap_upload_min_speed_quality_noffence = 0;
    public static $cafap_upload_forbid_not_detected_number = false;
    public static $cafap_upload_forbid_lane_opposite = false;
    public static $cafap_upload_forbid_lane = false;

    public static $image_keys_for_cafap = [ # Какие изображения будут в архиве ЦАФАП #'prepared_middle_number', 'prepared_after_number', 'prepared_before_number', 'prepared_middle_zoom', 'prepared_after_zoom',  'prepared_before_zoom',
            'prepared_before',
            'prepared_after',
            'prepared_middle',
            'prepared_combo',
            'number_coords_collage'/*
            'prepared_before',
            'prepared_after',
            'prepared_middle',
            'prepared_combo',
            'number_coords_collage'   */
        ]; # 'number_coords_collage' - for $image_keys_for_cafap - for self::$track_number_list

    public static $cafap_exclude_debug_collage = false;

    # OLD

    public static $upload_speed_quality_min_for_offences = 0;
    public static $upload_speed_quality_min_for_non_offences = 0;
    public static $upload_forbid_not_detected_number = false;
    public static $upload_forbid_lane_opposite = false;
    public static $upload_forbid_lane = false;
    public static $ptrys_limit_max = 3;
    public static $strys_limit_max = 5;
    // UPLOAD

    // LOGGING
    public static $log_dir = false;
    public static $dir_box_logging = false;
    public static $aist_upload_logging = false; # public static $max_days = 7; public static $max_bytes = 1024 * 1024 * 25; # 1024 = kb
    // LOGGING

    // DEV
    public static $show_all_menu = false;

    public static $journal_virgin = false;
    public static $save_duplo_xml = false;
    public static $test_api_key = '11c22a3333a444c55c6666aece7777b888ff4b99';
    // DEV

    public static $remove_all = true;
    public static $check_work_timeout = 12; # CheckOffenceAction
    public static $timezone = 0;
    public static $timezones = 0;

    public static function init(){

        global $config; #pred($config);
        #if(isset($_SERVER['argv'])) if(in_array('is_test=1', $_SERVER['argv'])) $_POST['need_log'] = 1;

        define('site_url', Url::site_url());

        @include DR .'/lconfig.php';

        if(isset($config)) foreach($config as $k => $v){
            self::${$k} = $v; #pred(self::$car_number_no_detect_ftp_send);
        }
        if(isset($_REQUEST['is_debug'])) \Config::$is_debug = $_REQUEST['is_debug'];
        if(isset($_REQUEST['debug'])) \Config::$is_debug = $_REQUEST['debug'];
        if(isset($_REQUEST['is_query_debug'])) \Config::$is_query_debug = $_REQUEST['is_query_debug'];

        #$rc = new \ReflectionClass(get_called_class());   $props = $rc->getProperties(); #pred($props);        foreach($props as $k => $v) $config[$v->name] = self::${$v->name};
        #pred($config);
        #pred(\Config::$is_debug);  #if(isset($_REQUEST['is_query_debug'])) define('sil', false);
        return true;
    }

    public static function json(){

        global $config; #pred($config);
        #if(isset($_SERVER['argv'])) if(in_array('is_test=1', $_SERVER['argv'])) $_POST['need_log'] = 1;

        $cr = new \ReflectionClass(get_called_class());
        $props = $cr->getProperties(ReflectionProperty::IS_PUBLIC);

        $jsonArray = array();
        foreach($props as $k => $v) $jsonArray[$k] = self::${$v->name};
        return json_encode($jsonArray);
    }

    public static function dbn(){
        return self::$db['name'];
    }
}