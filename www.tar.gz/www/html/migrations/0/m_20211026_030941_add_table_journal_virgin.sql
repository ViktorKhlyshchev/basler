CREATE TABLE public.journal_virgin (
    id bigint NOT null,
    user_id bigint,
    camera_id bigint,
    car_number character varying,
    car_type character varying(255),
    car_firm character varying(255),
    car_model character varying(255),
    traffic_violation text,
    system_data text,
    date_traffic_violation timestamp(6) without time zone,
    date_create timestamp(6) without time zone,
    date_update timestamp(6) without time zone,
    date_remove timestamp(6) without time zone,
    date_recovery timestamp(6) without time zone,
    type smallint DEFAULT 0 NOT null,
    speed double precision,
    is_send smallint DEFAULT 0 NOT null,
    is_create smallint DEFAULT 0 NOT null,
    hash character varying(255),
    is_sending smallint DEFAULT 0 NOT null,
    date_send timestamp(0) without time zone,
    is_creating smallint DEFAULT 0 NOT null,
    speed_quality double precision,
    direction character varying(255),
    join_count bigint DEFAULT 0 NOT null,
    point_count bigint DEFAULT 0 NOT null,
    point_recognized_count bigint DEFAULT 0 NOT null,
    is_error smallint DEFAULT 0 NOT null,
    error text,
    glue_journal_id bigint,
    is_track_glued smallint DEFAULT 0 NOT null,
    track_glued_count bigint DEFAULT 0 NOT null,
    date_start_track timestamp(6) without time zone,
    parent_journal_id bigint,
    light_sensor bigint,
    frame_bright bigint,
    is_updated_traffic_violation smallint DEFAULT 0 NOT null,
    description text,
    recognize_type smallint,
    thread_id bigint,
    is_thread_create smallint DEFAULT 0 NOT null,
    is_thread_send smallint DEFAULT 0 NOT null,
    lane integer,
    is_parent smallint DEFAULT 0 NOT null,
    country_id bigint,
    is_plate_invert smallint DEFAULT 0 NOT null,
    distance double precision,
    is_sending_avg_speed smallint DEFAULT 0 NOT null,
    is_send_avg_speed smallint DEFAULT 0 NOT null,
    nosend boolean,
    nosendcom character varying(255),
    strys smallint DEFAULT 0 NOT null,
    CONSTRAINT journal_strys_check CHECK ((strys >= 0))
);

ALTER TABLE ONLY public.journal_virgin
    ADD CONSTRAINT journal_virgin_id_key UNIQUE (id);


--
-- Name: journal journal_pkey; Type: CONSTRAINT; Schema: public; Owner: aist
--

ALTER TABLE ONLY public.journal_virgin
    ADD CONSTRAINT journal_virgin_pkey PRIMARY KEY (id);


--
-- Name: journal_car_firm_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_car_firm_idx ON public.journal_virgin USING btree (car_firm);


--
-- Name: journal_car_model_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_car_model_idx ON public.journal_virgin USING btree (car_model);


--
-- Name: journal_car_number_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_car_number_idx ON public.journal_virgin USING btree (car_number);


--
-- Name: journal_car_type_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_car_type_idx ON public.journal_virgin USING btree (car_type);


--
-- Name: journal_date_create_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_date_create_idx ON public.journal_virgin USING btree (date_create);


--
-- Name: journal_date_traffic_violation_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_date_traffic_violation_idx ON public.journal_virgin USING btree (date_traffic_violation);


--
-- Name: journal_date_update_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_date_update_idx ON public.journal_virgin USING btree (date_update);


--
-- Name: journal_direction_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_direction_idx ON public.journal_virgin USING btree (direction);


--
-- Name: journal_virgin__glue_journal_id_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX "journal_virgin__glue_journal_id_idx" ON public.journal_virgin USING btree (glue_journal_id);


--
-- Name: journal_hash_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_hash_idx ON public.journal_virgin USING btree (hash);


--
-- Name: journal_is_create_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_is_create_idx ON public.journal_virgin USING btree (is_create);


--
-- Name: journal_is_error_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_is_error_idx ON public.journal_virgin USING btree (is_error);


--
-- Name: journal_is_send_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_is_send_idx ON public.journal_virgin USING btree (is_send);


--
-- Name: journal_is_sending_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_is_sending_idx ON public.journal_virgin USING btree (is_sending);


--
-- Name: journal_is_thread_create_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_is_thread_create_idx ON public.journal_virgin USING btree (is_thread_create);


--
-- Name: journal_is_thread_send_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_is_thread_send_idx ON public.journal_virgin USING btree (is_thread_send);


--
-- Name: journal_is_track_glued_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_is_track_glued_idx ON public.journal_virgin USING btree (is_track_glued);


--
-- Name: journal_is_updated_traffic_violation_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_is_updated_traffic_violation_idx ON public.journal_virgin USING btree (is_updated_traffic_violation);


--
-- Name: journal_parent_journal_id_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_parent_journal_id_idx ON public.journal_virgin USING btree (parent_journal_id);


--
-- Name: journal_speed_quality_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_speed_quality_idx ON public.journal_virgin USING btree (speed_quality);


--
-- Name: journal_thread_id_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_thread_id_idx ON public.journal_virgin USING btree (thread_id);


--
-- Name: journal_traffic_violation_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_traffic_violation_idx ON public.journal_virgin USING btree (traffic_violation);


--
-- Name: journal_type_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_type_idx ON public.journal_virgin USING btree (type);


--
-- Name: journal_user_id_idx; Type: INDEX; Schema: public; Owner: aist
--

CREATE INDEX journal_virgin_user_id_idx ON public.journal_virgin USING btree (user_id);





--
-- Name: journal_is_send_avg_speed_idx; Type: INDEX; Schema: public; Owner: aist
--
CREATE INDEX journal_virgin_is_send_avg_speed_idx ON public.journal USING btree (is_send_avg_speed);
--
-- Name: journal_is_sending_avg_speed_idx; Type: INDEX; Schema: public; Owner: aist
--
CREATE INDEX journal_virgin_is_sending_avg_speed_idx ON public.journal USING btree (is_sending_avg_speed);

--
-- PostgreSQL database dump complete
--

