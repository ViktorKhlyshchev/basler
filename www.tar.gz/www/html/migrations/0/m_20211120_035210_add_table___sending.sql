CREATE TABLE IF NOT EXISTS public.__sending (
    id serial PRIMARY KEY,
    jid integer NOT NULL,
    us_id integer NOT NULL,
    hash character varying,
    file_size bigint,
    file_path character varying,
    offence character varying,
    speedq smallint,
    car_number character varying,
    tid smallint,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    pid bigint,
    nosend boolean,
    us_type character varying,
    trys smallint DEFAULT 0,
    inwork smallint,
    sent smallint,
    error text,
    log text
);
ALTER TABLE ONLY public.__sending ALTER COLUMN id SET DEFAULT nextval('public.__sending_id_seq'::regclass);