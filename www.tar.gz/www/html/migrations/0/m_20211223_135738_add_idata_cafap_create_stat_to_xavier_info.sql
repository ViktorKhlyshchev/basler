INSERT INTO public.xavier_info VALUES ('cafap_create_stat', 'created_qty', 0, 'NOW()', 'NOW()', null, null, 0);
INSERT INTO public.xavier_info VALUES ('cafap_create_stat', 'not_created_qty', 0, 'NOW()', 'NOW()', null, null, 0);
INSERT INTO public.xavier_info VALUES ('cafap_create_stat', 'alltime_created_qty', 0, 'NOW()', 'NOW()', null, null, 0);
INSERT INTO public.xavier_info VALUES ('cafap_create_stat', 'alltime_not_created_qty', 0, 'NOW()', 'NOW()', null, null, 0);