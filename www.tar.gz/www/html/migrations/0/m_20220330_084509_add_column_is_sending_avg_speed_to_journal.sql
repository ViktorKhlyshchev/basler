ALTER TABLE journal ADD COLUMN IF NOT EXISTS is_sending_avg_speed smallint;
ALTER TABLE journal_virgin ADD COLUMN IF NOT EXISTS is_sending_avg_speed smallint;