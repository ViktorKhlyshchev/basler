CREATE INDEX __processing_tid_idx ON public.__processing USING btree (tid);
CREATE INDEX __processing_offence_idx ON public.__processing USING btree (offence);
CREATE INDEX __processing_nosend_idx ON public.__processing USING btree (nosend);

CREATE INDEX __packing_tid_idx ON public.__packing USING btree (tid);
CREATE INDEX __packing_inwork_idx ON public.__packing USING btree (inwork);
CREATE INDEX __packing_us_type_idx ON public.__packing USING btree (us_type);
CREATE INDEX __packing_trys_idx ON public.__packing USING btree (trys);
CREATE INDEX __packing_created_idx ON public.__packing USING btree (created);
CREATE INDEX __packing_allsentc_idx ON public.__packing USING btree (allsentc);
CREATE INDEX __packing_sid_idx ON public.__packing USING btree (sid);

CREATE INDEX __sending_tid_idx ON public.__sending USING btree (tid);
CREATE INDEX __sending_inwork_idx ON public.__sending USING btree (inwork);
CREATE INDEX __sending_us_type_idx ON public.__sending USING btree (us_type);
CREATE INDEX __sending_trys_idx ON public.__sending USING btree (trys);
CREATE INDEX __sending_sent_idx ON public.__sending USING btree (sent);
CREATE INDEX __sending_nosend_idx ON public.__sending USING btree (nosend);