CREATE TABLE public.__sending (
    id integer DEFAULT nextval('public.create_id_seq'::regclass) NOT NULL,
    jid integer NOT NULL,
    us_id integer NOT NULL,
    hash character varying,
    file_size bigint,
    file_path character varying,
    offence character varying,
    car_number character varying,
    tid smallint,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    pid smallint,
    nosend boolean,
    us_type character varying,
    trys smallint DEFAULT 0,
    inwork smallint,
    sent smallint,
    error text,
    log text
);


ALTER TABLE public.__sending OWNER TO aist;

--
-- Name: __sending __send_pkey; Type: CONSTRAINT; Schema: public; Owner: aist
--

ALTER TABLE ONLY public.__sending
    ADD CONSTRAINT __send_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

