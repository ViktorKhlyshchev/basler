CREATE TABLE public.__packing (
    id integer NOT NULL,
    jid integer NOT NULL,
    us_id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    hash character varying,
    file_size bigint,
    file_path character varying,
    tid smallint,
    car_number character varying,
    nosend boolean,
    trys smallint DEFAULT 0,
    sid regtype,
    offence character varying,
    allsentc smallint,
    us_type character varying,
    inwork smallint,
    sent smallint,
    created smallint,
    log text,
    error text
);


ALTER TABLE public.__packing OWNER TO aist;

--
-- Name: __package_trys_seq; Type: SEQUENCE; Schema: public; Owner: aist
--

CREATE SEQUENCE public.__package_trys_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.__package_trys_seq OWNER TO aist;

--
-- Name: __package_trys_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aist
--

ALTER SEQUENCE public.__package_trys_seq OWNED BY public.__packing.trys;


--
-- Name: create_id_seq; Type: SEQUENCE; Schema: public; Owner: aist
--

CREATE SEQUENCE public.create_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.create_id_seq OWNER TO aist;

--
-- Name: create_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aist
--

ALTER SEQUENCE public.create_id_seq OWNED BY public.__packing.id;


--
-- Name: create_is_creating_seq; Type: SEQUENCE; Schema: public; Owner: aist
--

CREATE SEQUENCE public.create_is_creating_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.create_is_creating_seq OWNER TO aist;

--
-- Name: create_is_creating_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aist
--

ALTER SEQUENCE public.create_is_creating_seq OWNED BY public.__packing.inwork;


--
-- Name: create_us_id_seq; Type: SEQUENCE; Schema: public; Owner: aist
--

CREATE SEQUENCE public.create_us_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.create_us_id_seq OWNER TO aist;

--
-- Name: create_us_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aist
--

ALTER SEQUENCE public.create_us_id_seq OWNED BY public.__packing.us_id;


--
-- Name: __packing id; Type: DEFAULT; Schema: public; Owner: aist
--

ALTER TABLE ONLY public.__packing ALTER COLUMN id SET DEFAULT nextval('public.create_id_seq'::regclass);


--
-- Name: __packing create_pkey; Type: CONSTRAINT; Schema: public; Owner: aist
--

ALTER TABLE ONLY public.__packing
    ADD CONSTRAINT create_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

