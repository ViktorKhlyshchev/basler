CREATE TABLE public.__processing (
    id bigint NOT NULL,
    nocreate smallint,
    nocreatecom character varying,
    nosend smallint,
    nosendcom character varying,
    excluded smallint,
    excluded_com character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    car_number character varying,
    offence character varying,
    tid smallint,
    allcreate smallint,
    allsent smallint
);


ALTER TABLE public.__processing OWNER TO aist;

--
-- Name: __processing_is_create_seq; Type: SEQUENCE; Schema: public; Owner: aist
--

CREATE SEQUENCE public.__processing_is_create_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.__processing_is_create_seq OWNER TO aist;

--
-- Name: __processing_is_create_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aist
--

ALTER SEQUENCE public.__processing_is_create_seq OWNED BY public.__processing.allcreate;


--
-- Name: __processing __processing_pkey; Type: CONSTRAINT; Schema: public; Owner: aist
--

ALTER TABLE ONLY public.__processing
    ADD CONSTRAINT __processing_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

