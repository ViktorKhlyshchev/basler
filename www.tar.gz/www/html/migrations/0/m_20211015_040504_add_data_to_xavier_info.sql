INSERT INTO public.xavier_info VALUES ('sent_stat', 'cafap_sent_trys_qty', 0, 'NOW()', 'NOW()', null, null, 0);
INSERT INTO public.xavier_info VALUES ('sent_stat', 'cafap_sent_qty', 0, 'NOW()', 'NOW()', null, null, 0);
INSERT INTO public.xavier_info VALUES ('sent_stat', 'cafap_notsent_qty', 0, 'NOW()', 'NOW()', null, null, 0);
INSERT INTO public.xavier_info VALUES ('sent_stat', 'alltime_cafap_sent_qty', 0, 'NOW()', 'NOW()', null, null, 0);
INSERT INTO public.xavier_info VALUES ('sent_stat', 'alltime_cafap_notsent_qty', 0, 'NOW()', 'NOW()', null, null, 0);