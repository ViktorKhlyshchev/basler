ALTER TABLE _token DROP COLUMN device_firm_id;
ALTER TABLE _token DROP COLUMN continent_id;
ALTER TABLE _token DROP COLUMN country_id;
ALTER TABLE _token DROP COLUMN region_id;
ALTER TABLE _token DROP COLUMN city_id;
ALTER TABLE _token DROP COLUMN device_model_id;
ALTER TABLE _token DROP COLUMN user_device_token_id;
ALTER TABLE _token DROP COLUMN app_version_id;