CREATE TABLE IF NOT EXISTS public.__processing (
    id bigint NOT NULL PRIMARY KEY,
    nocreate smallint,
    nocreatecom character varying,
    nosend smallint,
    nosendcom character varying,
    excluded smallint,
    excluded_com character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    car_number character varying,
    offence character varying,
    speedq smallint,
    tid smallint,
    allcreate smallint,
    allsent smallint
);