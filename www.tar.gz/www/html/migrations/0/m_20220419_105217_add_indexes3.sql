CREATE INDEX __packing_queue_tid_idx ON public.__packing_queue USING btree (tid);
CREATE INDEX __packing_queue_us_type_idx ON public.__packing_queue USING btree (us_type);
CREATE INDEX __packing_queue_trys_idx ON public.__packing_queue USING btree (trys);
CREATE INDEX __packing_queue_created_idx ON public.__packing_queue USING btree (created);
CREATE INDEX __packing_queue_sid_idx ON public.__packing_queue USING btree (sid);

CREATE INDEX __sending_queue_tid_idx ON public.__sending_queue USING btree (tid);
CREATE INDEX __sending_queue_us_type_idx ON public.__sending_queue USING btree (us_type);
CREATE INDEX __sending_queue_trys_idx ON public.__sending_queue USING btree (trys);
CREATE INDEX __sending_queue_sent_idx ON public.__sending_queue USING btree (sent);
CREATE INDEX __sending_queue_nosend_idx ON public.__sending_queue USING btree (nosend);