ALTER TABLE xavier_info DROP CONSTRAINT gkv;
ALTER TABLE "public"."xavier_info" ADD CONSTRAINT "gk" UNIQUE ("group","key");