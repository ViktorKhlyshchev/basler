CREATE TABLE IF NOT EXISTS public.__packing_queue (
    id serial PRIMARY KEY,
    jid integer NOT NULL,
    us_id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    hash character varying,
    file_size bigint,
    file_path character varying,
    offence character varying,
    speedq smallint,
    car_number character varying,
    tid smallint,
    nosend boolean,
    trys smallint DEFAULT 0,
    us_type character varying,
    inwork smallint,
    created smallint,
    error text,
    nosendcom VARCHAR(255),
    prid bigint,
    sid regtype, -- allpacked smallint,
    log text
);
ALTER TABLE ONLY public.__packing_queue ADD CONSTRAINT __packing_queue_id_key UNIQUE (id);
CREATE INDEX __packing_queue_inwork_idx ON public.__packing_queue USING btree (inwork);