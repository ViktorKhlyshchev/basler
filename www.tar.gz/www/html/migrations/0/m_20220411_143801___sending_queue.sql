CREATE TABLE IF NOT EXISTS public.__sending_queue (
    id serial PRIMARY KEY,
    jid integer NOT NULL,
    us_id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    hash character varying,
    file_size bigint,
    file_path character varying,
    offence character varying,
    speedq smallint,
    car_number character varying,
    tid smallint,
    nosend boolean,
    trys smallint DEFAULT 0,
    us_type character varying,
    inwork smallint,
    sent smallint,
    error text, -- nosendcom VARCHAR(255),
    prid bigint,
    pid bigint,
    log text
);
ALTER TABLE ONLY public.__sending_queue ADD CONSTRAINT __sending_queue_id_key UNIQUE (id);
CREATE INDEX __sending_queue_inwork_idx ON public.__sending_queue USING btree (inwork);