<?php

use Core\Module\Db\Db;
use Core\Modules\Dir;
use Configs\DirConfig;
use Common\Models\XavierInfo; # /migrations/0/

# sudo -u www-data /usr/bin/php7.2 $PWD/index.php page=admin/migration action=apply
# sudo -u www-data /usr/bin/php7.2 -f /var/www/html/index.php page=admin/migration action=apply && systemctl restart aist_upload && systemctl restart aist_remove

function flatten(&$array){
    $return = [];
    while(count($array)){
        $value = array_shift($array);
        if(is_array($value))
            foreach($value as $sub)
                $array[] = $sub;
        else
            $return [] = $value;
    }
    return $return;
}

function find_in_arr(&$arr, $k, $val){
    foreach($arr as $key => $value) if($value[$k] == $val) return $value;
    return null;
}

function alter0(){
    $q = "SELECT to_json(json_populate_record(null::public.xavier_info, '{}'::JSON))";
    $r = Db::get_results($q); #pre($r[0]['to_json']);
    $r = json_decode($r[0]['to_json'], 1);
    if(in_array('id', $r)) return;
    pred($r);
}

function check_mtable_exist(){
    $q = "SELECT to_json(json_populate_record(null::public.migration, '{}'::JSON))";
    try { $r = Db::execr($q); return true; } #catch(\PDOException $e){
    catch(\PDOException $e){
        $m = $e->errorInfo[count($e->errorInfo)-1];
        if(strpos($m, 'does not exist') !== false) return false;
    }
}

function get_applied(){
    if(!mtable_exist) return [];
    $tn = 'migration';
    $q = ['table' => $tn, 'select' => ['id', 'name']];
    $r = Db::select($q);
    $names = [];
    foreach($r as $v) $names[] = $v['name'];
    return $names;
}

function set_applied($mn){
    if(!mtable_exist) return [];
    $tn = 'migration';
    $q = ['table' => $tn, 'values' => ['name' => $mn, 'date_create' => 'NOW()', 'date_update' => 'NOW()']];
    $r = Db::insert($q);
    if(!$r) pred($r);
}

$mtable_exist = check_mtable_exist();
define('mtable_exist', $mtable_exist);
global $applied;
$applied = get_applied(); pre($applied);

$mnu = null;

function alter1(){

    global $applied, $mnu;

    foreach(glob(__DIR__.'/*.sql') as $fp){

        if(strpos($fp, 'add_data') !== false) continue; # $mbn = basename($fp);
        $mn = pathinfo($fp)['filename']; # migration name
        if(mtable_exist && in_array($mn, $applied)) continue;
        $mnu = mb_strtoupper($mn); # $mcn = explode('__', $mn)[1]; # migration cutted name

        if($mn === 'm_20211015_040404_alter_table_xavier_info'){ #            pre("call_user_func('check_'. $mn)");            pre(call_user_func('check_'. $mn));
            if(call_user_func('check_'. $mn)){
                if(cli) echo("skipping ================= ". $mnu ."\n"); else pre('skipping ================= '. $mnu);
                if(mtable_exist) set_applied($mn);
                continue;
            }
        }

        if($mn === 'm_20211013_040604_add_column_id_to_xavier_info'){ #pre("call_user_func('check_'. $mn)");            pre(call_user_func('check_'. $mn));
            if(!call_user_func('check_'. $mn)){
                if(cli) echo "skipping ================= ". $mnu ."\n"; else pre('skipping ================= '. $mnu);
                if(mtable_exist) set_applied($mn);
                continue;
            }
        }

        if($mn === 'm_20211013_040704_add_column_strys_to_journal'){ #pre("call_user_func('check_'. $mn)");            pre(call_user_func('check_'. $mn));
            if(!call_user_func('check_'. $mn)){
                if(cli) echo "skipping ================= ". $mnu ."\n"; else pre('skipping ================= '. $mnu);
                if(mtable_exist) set_applied($mn);
                continue;
            }
        }

        if($mn === 'RRRm_20211030_075434_add_constraint_to_xavier_info'){
            if(!call_user_func('check_'. $mn)){
                if(cli) echo "skipping ================= ". $mnu ."\n"; else pre('skipping ================= '. $mnu);
                if(mtable_exist) set_applied($mn);
                continue;
            }
        }

        if($mn === 'm_20211101_094326_add_rdata_pitch_to_xavier_info'){
            if(!call_user_func('check_'. $mn)){
                if(cli) echo "skipping ================= ". $mnu ."\n"; else pre('skipping ================= '. $mnu);
                if(mtable_exist) set_applied($mn);
                continue;
            }
        }

        if($mn === 'm_20211229_041102_add_idata_promo_radar_to__user_access_type'){
            if(!call_user_func('check_'. $mn)){
                if(cli) echo "skipping ================= ". $mnu ."\n"; else pre('skipping ================= '. $mnu);
                if(mtable_exist) set_applied($mn);
                continue;
            }
        }

        if($mn === 'm_20211229_041103_add_idata_api_statistics_to__user_access_type'){
            if(!call_user_func('check_'. $mn)){
                if(cli) echo "skipping ================= ". $mnu ."\n"; else pre('skipping ================= '. $mnu);
                if(mtable_exist) set_applied($mn);
                continue;
            }
        }

        if($mn === 'm_20211021_055352_create_resource_tar_dir'){ if(call_user_func('do_'. $mn)){ if(mtable_exist) set_applied($mn); continue; }}

        $q = file_get_contents($fp);
        if(cli) echo('APPLYING ================= '. $mnu ."\n"); else pre('APPLYING ================= '. $mnu);

        try { $r = Db::execr($q); pre($r); if(mtable_exist) set_applied($mn); } #catch(\PDOException $e){
        catch(\PDOException $e){ #if($mn === '21.10.13__5_add_column_id_to_xavier_info'){} #pre($mn);             pred($e);
            if($mn === 'm_20211015_040404_alter_table_xavier_info'){
                $er = true; $c = 0;
                while($er){ $c++; if($c > 10000) pred('$c > 10000');
                    try { $r = Db::execr($q); pre($r); } #catch(\PDOException $e){
                    catch(\PDOException $e){
                        $m = $e->errorInfo[count($e->errorInfo)-1];

                        if($m === 'ERROR:  relation "gkv" already exists'){
                            pre('skipping ================= '. $mnu);
                            if(mtable_exist) set_applied($mn);
                            break;
                        }
                        if(strpos($m, 'is duplicated') === false) pred($m);
                        $pos = strpos($m, '=(') + 2;
                        $vals = substr($m, $pos);
                        $pos = strpos($vals, ') is'); #pre($pos);pre($vals);
                        $vals = substr($vals, 0, $pos);
                        $vals = explode(', ', $vals);
                        $tn = 'xavier_info';
                        $qq = ['table' => $tn, 'select' => ['id'], 'order' => [['column' => 'id', 'direction' => 'desc']], 'where' => ['group' => $vals[0], 'key' => $vals[1]]]; #pre($q); # , 'group', 'key', 'value'
                        $r = Db::select($qq); #pre($r);
                        $qq = ['table' => $tn, 'where' => ['id' => $r[0]['id']]];
                        $dr = Db::delete($qq); #pre($dr);
                        if(mtable_exist) set_applied($mn);
                        continue;
                    }
                    $er = false;
                }
                continue;
            }

            /*if($mn === 'm_20211019_071103_add_table_migration'){
                $m = $e->errorInfo[count($e->errorInfo)-1];
                if($m === 'ERROR:  relation "migration" already exists'){
                    pre('skipping ================= '. $mnu);
                    if(mtable_exist) set_applied($mn);
                    continue;
                }
            }*/

            if($mn === 'm_20211025_065044_add_column_log_to_journal_ftp_send'){
                $m = $e->errorInfo[count($e->errorInfo)-1]; #pre($m);pred(333);
                if(strpos($m, 'relation "journal_ftp_send" does not exist') !== false){
                    pre('skipping ================= '. $mnu);
                    if(mtable_exist) set_applied($mn);
                    continue;
                }
            }

            if($mn === 'm_20211020_090501_add_sdata_alltime_notsend_qty_to_xavier_info'){
                $m = $e->errorInfo[count($e->errorInfo)-1]; #pre($m);pred(333);
                if(strpos($m, 'DETAIL:  Key ("group", key, value)=(sent_stat, alltime_notsent_qty, 0) already exist') !== false || strpos($m, 'DETAIL:  Key ("group", key)=(sent_stat, alltime_notsent_qty) already exists') !== false){
                    pre('skipping ================= '. $mnu);
                    if(mtable_exist) set_applied($mn);
                    continue;
                }
            }

            if($mn === 'm_20211030_075434_add_constraint_to_xavier_info'){
                $m = $e->errorInfo[count($e->errorInfo)-1]; #pre($m);pred(333);
                if(strpos($m, 'could not create unique index "gk"') !== false && strpos($m, 'is duplicated') !== false){
                    if(call_user_func('prepeare_for_'. $mn, $q)){
                        if(mtable_exist) set_applied($mn);
                        continue;
                    }
                }
            }

            if($mn === 'm_20211026_030941_add_table_journal_virgin'){
                $m = $e->errorInfo[count($e->errorInfo)-1]; #pre($m);pred(333);
                if(strpos($m, 'Duplicate table: 7 ERROR:  relation "journal_virgin" already exists') !== false || strpos($m, 'ERROR:  relation "journal_virgin" already exists') !== false){
                    pre('skipping ================= '. $mnu);
                    if(mtable_exist) set_applied($mn);
                    continue;
                }
            }

            if($mn === 'm_20211030_075434_add_constraint_to_xavier_info'){
                $m = $e->errorInfo[count($e->errorInfo)-1]; #pre($m); pred(333);
                if(strpos($m, 'Duplicate table: 7 ERROR:  relation "gk" already exists') !== false || strpos($m, 'ERROR:  relation "gk" already exists') !== false){
                    pre('skipping ================= '. $mnu);
                    if(mtable_exist) set_applied($mn);
                    continue;
                }
            }

            /*if($mn === 'm_20211120_031609_add_table___processing'){
                $m = $e->errorInfo[count($e->errorInfo)-1];#pre($m); pred(333);
                if(strpos($m, 'ERROR:  relation "__processing" already exists') !== false){
                    pre('skipping ================= '. $mnu);
                    if(mtable_exist) set_applied($mn);
                    continue;
                }
            }

            if($mn === 'm_20211120_035205_add_table___packing'){
                $m = $e->errorInfo[count($e->errorInfo)-1];#pre($m); pred(333);
                if(strpos($m, 'ERROR:  relation "__packing" already exists') !== false){
                    pre('skipping ================= '. $mnu);
                    if(mtable_exist) set_applied($mn);
                    continue;
                }
            }

            if($mn === 'm_20211126_120509_add_table___sending'){
                $m = $e->errorInfo[count($e->errorInfo)-1];#pre($m); pred(333);
                if(strpos($m, 'ERROR:  relation "__sending" already exists') !== false){
                    pre('skipping ================= '. $mnu);
                    if(mtable_exist) set_applied($mn);
                    continue;
                }
            }*/

            if($mn === 'm_20211126_134535_change_column_journals'){ # Undefined column: 7 ERROR:  column "is_sending" does not exist
                $m = $e->errorInfo[count($e->errorInfo)-1];#pre($m); pred(333);
                if(strpos($m, 'column "is_sending" does not exist') !== false || strpos($m, 'column "is_sending" of relation "journal" does not exist') !== false){
                    pre('skipping ================= '. $mnu);
                    if(mtable_exist) set_applied($mn);
                    continue;
                }
                if(strpos($m, 'column "is_sending" does not exist') !== false){
                    pre('skipping ================= '. $mnu);
                    if(mtable_exist) set_applied($mn);
                    continue;
                }
            }

            if($mn === 'm_20211130_120606_remove_extra_columns_from__token'){ # Undefined column: 7 ERROR:  column "is_sending" does not exist
                $m = $e->errorInfo[count($e->errorInfo)-1];#pre($m); pred(333);
                if(strpos($m, 'does not exist') !== false){ # column "device_firm_id" of relation "_token"
                    pre('skipping ================= '. $mnu);
                    if(mtable_exist) set_applied($mn);
                    continue;
                }
            }

            if($mn === 'm_20211220_195131_add_id_to_statistics'){ # Undefined column: 7 ERROR:  column "is_sending" does not exist
                $m = $e->errorInfo[count($e->errorInfo)-1]; #pre($m); pred(333);
                if(strpos($m, 'multiple primary keys for table "statistics" are not allowed') !== false){ # column "device_firm_id" of relation "_token"
                    pre('skipping ================= '. $mnu);
                    if(mtable_exist) set_applied($mn);
                    continue;
                }
            }

            if($mn === 'm_20211223_135738_add_idata_cafap_create_stat_to_xavier_info'){ # Undefined column: 7 ERROR:  column "is_sending" does not exist
                $m = $e->errorInfo[count($e->errorInfo)-1]; #pre($m); pred(333);
                if(strpos($m, 'duplicate key value violates unique constraint') !== false){ # column "device_firm_id" of relation "_token"
                    pre('skipping ================= '. $mnu);
                    if(mtable_exist) set_applied($mn);
                    continue;
                }
            }

            if($mn === 'm_20211226_150739_add_id_to_connect'){ # Undefined column: 7 ERROR:  column "is_sending" does not exist
                $m = $e->errorInfo[count($e->errorInfo)-1]; #pre($m); pred(333);
                if(strpos($m, 'multiple primary keys for table "connect" are not allowed') !== false){ # column "device_firm_id" of relation "_token"
                    pre('skipping ================= '. $mnu);
                    if(mtable_exist) set_applied($mn);
                    continue;
                }
            }

            if($mn === 'm_20211229_041102_add_idata_promo_radar_to__user_access_type'){ # Undefined column: 7 ERROR:  column "is_sending" does not exist
                $m = $e->errorInfo[count($e->errorInfo)-1]; #pre($m); pred(333);
                if(strpos($m, 'duplicate key value violates unique constraint') !== false){ # column "device_firm_id" of relation "_token"
                    pre('skipping ================= '. $mnu);
                    if(mtable_exist) set_applied($mn);
                    continue;
                }
            }

            if($mn === 'm_20211229_041103_add_idata_api_statistics_to__user_access_type'){ # Undefined column: 7 ERROR:  column "is_sending" does not exist
                $m = $e->errorInfo[count($e->errorInfo)-1]; #pre($m); pred(333);
                if(strpos($m, 'duplicate key value violates unique constraint') !== false){ # column "device_firm_id" of relation "_token"
                    pre('skipping ================= '. $mnu);
                    if(mtable_exist) set_applied($mn);
                    continue;
                }
            }

            if($mn === 'm_20211126_134646_add_idata_aist_upload_to_settings'){ # Undefined column: 7 ERROR:  column "is_sending" does not exist
                $m = $e->errorInfo[count($e->errorInfo)-1]; #pre($m); pred(333);
                if(strpos($m, 'duplicate key value violates unique constraint') !== false){ # column "device_firm_id" of relation "_token"
                    pre('skipping ================= '. $mnu);
                    if(mtable_exist) set_applied($mn);
                    continue;
                }
            }

            if($mn === 'm_20211129_061414_add_idata_cafap_pack_to_settings'){ # Undefined column: 7 ERROR:  column "is_sending" does not exist
                $m = $e->errorInfo[count($e->errorInfo)-1]; #pre($m); pred(333);
                if(strpos($m, 'duplicate key value violates unique constraint') !== false){ # column "device_firm_id" of relation "_token"
                    pre('skipping ================= '. $mnu);
                    if(mtable_exist) set_applied($mn);
                    continue;
                }
            }

            if($mn === 'm_20211130_050003_add_idata_cafap_upload_to_settings'){ # Undefined column: 7 ERROR:  column "is_sending" does not exist
                $m = $e->errorInfo[count($e->errorInfo)-1]; #pre($m); pred(333);
                if(strpos($m, 'duplicate key value violates unique constraint') !== false){ # column "device_firm_id" of relation "_token"
                    pre('skipping ================= '. $mnu);
                    if(mtable_exist) set_applied($mn);
                    continue;
                }
            }

            pre('ERROR at:============ '. $mn); pred($e);
        }
    }
}

function alter2(){
    global $applied;
    $fp = __DIR__ .'/m_20211013_040104_add_data_to_user_hash_type.sql';
    $mn = pathinfo($fp)['filename']; # migration name
    $mnu = mb_strtoupper($mn);

    if(mtable_exist && in_array($mn, $applied)) return;
    $tn = '_user_hash_type';
    $q = ['table' => $tn, 'select' => ['id', 'name']];
    $r = Db::select($q); #pre($r);
    foreach($r as $v){
        if($v['name'] !== 'api_key') continue; pre('api_key exist');
        $q = ['table' => $tn, 'where' => ['id' => $v['id']]];
        $dr = Db::delete($q); pre($dr); #break;
    }    #$fr = flatten($r);


    #if(in_array('api_statistics', flatten($r))){ echo  __FUNCTION__ .' skipped<br/>'; return; }   #pred(arval($r));
    if(in_array('api_statistics', flatten($r))){
        if(cli) echo("skipping ================= ". $mnu."\n") ; else pre('skipping ================= '. $mnu);
        if(mtable_exist) set_applied($mn);
        return;
    }   #pred(arval($r));
    $q = file_get_contents($fp);
    if(cli) echo("APPLYING ================= ". $mnu."\n"); else pre('APPLYING ================= '. $mnu);
    $r = Db::exec($q);  #pre($r);
    if(mtable_exist) set_applied($mn);
}

function alter3(){
    global $applied;

    $fp = __DIR__ .'/m_20211015_040504_add_data_to_xavier_info.sql';
    $mn = pathinfo($fp)['filename']; # migration name
    $mnu = mb_strtoupper($mn);

    if(mtable_exist && in_array($mn, $applied)) return;

    $tn = 'xavier_info';
    $q = ['table' => $tn, 'select' => ['id'], 'where' => ['group' => 'sent_stat', 'key' => 'cafap_sent_trys_qty']];
    $r = Db::select($q);

    if(count($r)){
        if(cli) echo("skipping ================= ". $mnu."\n") ; else pre('skipping ================= '. $mnu);
        if(mtable_exist) set_applied($mn);
        return;
    }
    $q = file_get_contents($fp);
    if(cli) echo("APPLYING ================= ". $mnu."\n"); else pre('APPLYING ================= '. $mnu);
    $r = Db::exec($q);  #pre($r);
    if(mtable_exist) set_applied($mn);
}


function check_m_20211015_040404_alter_table_xavier_info(){
    $q = "SELECT * from information_schema.constraint_column_usage where constraint_name='gkv' AND table_name='xavier_info'";
    $r = Db::get_results($q); #pred(count($r));
    return count($r);
}

function check_m_20211013_040604_add_column_id_to_xavier_info(){
    $q = "SELECT to_json(json_populate_record(null::public.xavier_info, '{}'::JSON))";  #$q = "SELECT json_populate_record(null::public.xavier_info, '{}'::JSON)";
    $r = Db::get_results($q); #pre($r[0]['to_json']);
    $r = json_decode($r[0]['to_json'], 1); # pre($r);
    if(in_array('id', array_keys($r))) return; #if(in_array('id', $r)) return;
    return true;
}

function check_m_20211013_040704_add_column_strys_to_journal(){
    $q = "SELECT * from information_schema.constraint_column_usage where constraint_name='journal_strys_check' AND table_name='journal'";
    /*for($i = 20; $i < 30; $i++){
        $q = "ALTER TABLE journal DROP CONSTRAINT journal_strys_check". $i;
        $r = Db::get_results($q); pre($r);
    }*/ #$q = "ALTER TABLE journal DROP CONSTRAINT journal_strys_check";
    $r = Db::get_results($q);
    if(empty($r)) return true; #pred(333); pred($r);
}

function RRRcheck_m_20211030_075434_add_constraint_to_xavier_info(){
    $q = "SELECT * from information_schema.constraint_column_usage where constraint_name='journal_strys_check' AND table_name='journal'";
    /*for($i = 20; $i < 30; $i++){
        $q = "ALTER TABLE journal DROP CONSTRAINT journal_strys_check". $i;
        $r = Db::get_results($q); pre($r);
    }*/ #$q = "ALTER TABLE journal DROP CONSTRAINT journal_strys_check";
    $r = Db::get_results($q);
    if(empty($r)) return true; #pred(333); pred($r);
}

function check_m_20211101_094326_add_rdata_pitch_to_xavier_info(){
    $gr = 'hardware/pitch';
    $r = XavierInfo::get_list_from_group($gr);
    if(empty($r)) return true;
}

function check_m_20211229_041102_add_idata_promo_radar_to__user_access_type(){
    $q = "SELECT * from _user_access_type where name='promo_radar'";
    /*for($i = 20; $i < 30; $i++){
        $q = "ALTER TABLE journal DROP CONSTRAINT journal_strys_check". $i;
        $r = Db::get_results($q); pre($r);
    }*/ #$q = "ALTER TABLE journal DROP CONSTRAINT journal_strys_check";
    $r = Db::get_results($q); #pred($r);
    if(empty($r)) return true; #pred(333); pred($r);
}

function check_m_20211229_041103_add_idata_api_statistics_to__user_access_type(){
    $q = "SELECT * from _user_access_type where name='api_statistics'";
    /*for($i = 20; $i < 30; $i++){
        $q = "ALTER TABLE journal DROP CONSTRAINT journal_strys_check". $i;
        $r = Db::get_results($q); pre($r);
    }*/ #$q = "ALTER TABLE journal DROP CONSTRAINT journal_strys_check";
    $r = Db::get_results($q); #pred($r);
    if(empty($r)) return true; #pred(333); pred($r);
}

function prepeare_for_m_20211030_075434_add_constraint_to_xavier_info($q){ #pred($q);
    $er = 1; $c = 0; $cmax = 1000;
    while($er){ $c++; if($c > $cmax) pred('C > CMAX');
        try { $r = Db::execr($q); pre($r); return true; } #catch(\PDOException $e){
        catch(\PDOException $e){
            $m = $e->errorInfo[count($e->errorInfo)-1];
            if(strpos($m, 'could not create unique index "gk"') !== false && strpos($m, 'is duplicated') !== false){

                $pos = strpos($m, '=(') + 2;
                $vals = substr($m, $pos);
                $pos = strpos($vals, ') is'); #pre($pos);pre($vals);
                $vals = substr($vals, 0, $pos);
                $vals = explode(', ', $vals);
                #pred($vals);
                $tn = 'xavier_info';
                $qq = ['table' => $tn, 'select' => ['id'], 'order' => [['column' => 'id', 'direction' => 'desc']], 'where' => ['group' => $vals[0], 'key' => $vals[1]]]; #pre($q); # , 'group', 'key', 'value'
                $r = Db::select($qq); #pre($r);
                $qq = ['table' => $tn, 'where' => ['id' => $r[0]['id']]];
                $dr = Db::delete($qq); #pre($dr);
            }
         }
    }
}

function do_m_20211021_055352_create_resource_tar_dir(){
    global $mnu;
    if(cli) echo('APPLYING ================= '. $mnu ."\n"); else pre('APPLYING ================= '. $mnu);
    $r = Dir::create_dir(Dir::get_global_dir(DirConfig::$dir_tar));
    return $r;
}

alter1(); #alter0();
alter2();
alter3();
if(cli) echo("\nMIGRATIONS APPLYING SUCCESSFULL !!! ================\n"); else pre('MIGRATIONS APPLYING SUCCESSFULL !!! ================ ');