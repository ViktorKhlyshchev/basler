ALTER TABLE IF EXISTS ftp_server RENAME TO upload_server;
ALTER TABLE upload_server ADD COLUMN IF NOT EXISTS ctype VARCHAR(255);
ALTER TABLE upload_server ADD COLUMN IF NOT EXISTS camera_cid VARCHAR(255);
UPDATE upload_server SET ctype= CASE WHEN ctype IS NULL THEN 'ftp' END WHERE ctype IS NULL