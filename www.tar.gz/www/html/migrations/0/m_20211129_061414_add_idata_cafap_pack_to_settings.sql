-- group	key	value	date_create	date_update	date_remove	date_recovery	type	id	format	desc

INSERT INTO public.xavier_info VALUES ('cafap_pack', 'need_json', 1, 'NOW()', 'NOW()', null, null, 0, default, null, 'is need json in output package?');
INSERT INTO public.xavier_info VALUES ('cafap_pack', 'json_only_for_offences', 0, 'NOW()', 'NOW()', null, null, 0, default, null, 'is need json in output package only for offences?');
INSERT INTO public.xavier_info VALUES ('cafap_pack', 'need_xml', 1, 'NOW()', 'NOW()', null, null, 0, default, null, 'is need XML in output package?');