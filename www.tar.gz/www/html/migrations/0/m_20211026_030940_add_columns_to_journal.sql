ALTER TABLE journal ADD COLUMN IF NOT EXISTS is_sending_avg_speed smallint DEFAULT 0 NOT null;
ALTER TABLE journal ADD COLUMN IF NOT EXISTS is_send_avg_speed smallint DEFAULT 0 NOT null;