CREATE INDEX __processing_allsent_idx ON public.__processing USING btree (allsent);
CREATE INDEX __processing_allcreate_idx ON public.__processing USING btree (allcreate);
CREATE INDEX __packing_jid_idx ON public.__packing USING btree (jid);
CREATE INDEX __sending_jid_idx ON public.__sending USING btree (jid);