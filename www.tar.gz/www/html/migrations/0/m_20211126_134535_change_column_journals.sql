ALTER TABLE journal ALTER COLUMN is_sending DROP NOT NULL;
ALTER TABLE journal_virgin ALTER COLUMN is_sending DROP NOT NULL;
ALTER TABLE journal RENAME COLUMN is_sending TO processed;
ALTER TABLE journal_virgin RENAME COLUMN is_sending TO processed;