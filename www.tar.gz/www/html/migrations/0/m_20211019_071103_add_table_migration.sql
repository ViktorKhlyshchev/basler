CREATE TABLE IF NOT EXISTS migration (
	id serial PRIMARY KEY,
	name VARCHAR (255) UNIQUE NOT null,
	date_create TIMESTAMP NOT null,
	date_update TIMESTAMP NOT null
);