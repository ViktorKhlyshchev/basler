--group	key	value	date_create	date_update	date_remove	date_recovery	type	id	format	desc
--group	key	value	date_create	date_update	date_remove	date_recovery	type	id	format	desc

INSERT INTO public.xavier_info VALUES ('aist_upload', 'cafap_pack_thread', 3, 'NOW()', 'NOW()', null, null, 0, default, null, 'qty of threads of cafap packing process');
INSERT INTO public.xavier_info VALUES ('aist_upload', 'cafap_send_thread', 3, 'NOW()', 'NOW()', null, null, 0, default, null, 'qty of threads of cafap sending process');
INSERT INTO public.xavier_info VALUES ('aist_upload', 'duplo_pack_thread', 3, 'NOW()', 'NOW()', null, null, 0, default, null, 'qty of threads of duplo packing process');
INSERT INTO public.xavier_info VALUES ('aist_upload', 'duplo_send_thread', 3, 'NOW()', 'NOW()', null, null, 0, default, null, 'qty of threads of duplo sending process');