<?php

use Common\Modules\Php;

# sudo -u www-data /usr/bin/php7.2 -f $PWD/tools/deploy/index.php
# sudo -u www-data /usr/bin/php7.2 -f /var/www/html/index.php page=admin/migration action=apply && systemctl restart aist_upload && systemctl restart aist_remove
# sed -i 's/short_open_tag = Off/short_open_tag = On/' /home/alex/0datah/0aist/1/7.2/cli/php.ini
# sed -i 's/short_open_tag = Off/short_open_tag = On/' /etc/php/7.2/cli/php.ini && sed -i 's/short_open_tag = Off/short_open_tag = On/' /etc/php/7.2/fpm/php.ini && sed -i 's/display_errors = Off/display_errors = On/' /etc/php/7.2/cli/php.ini && sed -i 's/display_errors = Off/display_errors = On/' /etc/php/7.2/fpm/php.ini && service php7.2-fpm restart
# sed -i 's|url = https://git.dev.oriontechnologies.ru/aist/aist-front.git|url = git@git.dev.oriontechnologies.ru:aist/aist-front.git|' /var/www/html/.git/config
ini_set('max_execution_time', 0);

if(!defined('frameworkinit')){
    if(!$_SERVER['DOCUMENT_ROOT']){ # $sdr = 0; if(1){
        $dirs = explode('/', __DIR__);
        $lvl = -1;
        while(!$_SERVER['DOCUMENT_ROOT']){ #while(!$sdr){
            $lvl++; $clvl = 0; $checkdir = '';
            foreach($dirs as $dir){
                if($dir !== '') $checkdir .= '/'. $dir;
                if($clvl === $lvl){ # pre($checkdir);
                    if(file_exists($checkdir .'/aistfroot.php')) $_SERVER['DOCUMENT_ROOT'] = $checkdir; # if(file_exists($checkdir .'/aistfroot.php')) $sdr = $checkdir;
                    break;
                }
                $clvl++;
            }
        }
    } # pred($_SERVER['DOCUMENT_ROOT']); die;

    define('DR', $_SERVER['DOCUMENT_ROOT']);
    if(php_sapi_name() === 'cli') define('cli', true); else define('cli', false);

    require DR .'/preconfig.php';
    require DR .'/Core/Module/Debug/debug.php';
    require DR .'/Core/Module/Autoloader/Autoloader.php';

    \Config::init();
    Php::init();
    error_reporting(E_ERROR); #\Config::$is_debug = true;
    \Core\Module\Db\Db::init();
    define('frameworkinit', true);
}

require __DIR__ .'/migrations/0/index.php';