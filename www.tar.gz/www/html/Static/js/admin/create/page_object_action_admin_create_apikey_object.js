cl = console.log;

page_object.action.admin.create.apikey={

    'init':function(){
        page_object.action.admin.create.apikey.position.init();
        page_object.action.admin.create.apikey.create.init();
        page_object.action.admin.create.apikey.set_action();
        page_object.action.admin.create.apikey.show();
    },
    'position':{
        'init':function(){

        }
    },
    'create':{
        'init':function(){
            cl(page_object.action.admin.data['action'] + ' create loaded');
            switch(page_object.action.admin.data['action']){
                case 'admin_apikey':{
                    page_object.action.admin.create.apikey.create.apikey_content();
                    break;
                }
            }
        },
        'get_apikey_row':function(index){

            let  data =page_object.action.admin.data['data']
                ,timezone =data['timezone']
                ,apikey_list =data['apikey_list']
                ,ftp_data =apikey_list[index]
                ,inner ='';

            inner+='<div id="apikey_item_name_'+index+'" class="apikey_item_col" style="width: 500px;">';
                inner+='<span>'+stripSlashes(ftp_data['name'])+'</span>';
            inner+='</div>';

            /*inner+='<div id="apikey_item_use_'+index+'" class="apikey_item_col" style="width: 300px;">';
                inner+='<span>'+(ftp_data['ip_list'].length==0?'<i>Не используется</i>':stripSlashes(implode(', ',ftp_data['ip_list'])))+'</span>';
            inner+='</div>';*/

            inner+='<div id="apikey_item_date_create_'+index+'" class="apikey_item_col" style="width: 200px;">';
                inner+='<span>'+stripSlashes(get_date_time(ftp_data['date_create']-new Date().getTimezoneOffset()*60,timezone))+'</span>';
                // inner+='<span>'+stripSlashes(get_date_time(ftp_data['date_create']))+'</span>';
            inner+='</div>';

            inner+='<div id="apikey_item_controls_'+index+'" class="apikey_item_col" style="width: 150px;">';
                inner+='<span>';
                    inner+='<div id="apikey_item_edit_button_'+index+'" class="apikey_item_edit_button"></div>';
                    //inner+='<div id="apikey_item_download_button_'+index+'" class="apikey_item_download_button"></div>';
                    inner+='<div id="apikey_item_remove_button_'+index+'" class="apikey_item_remove_button"></div>';
                inner+='</span>';
            inner+='</div>';

            return inner;

        },
        'apikey_content':function(){

            let  el
                ,data =page_object.action.admin.data['data']
                ,apikey_list =data['apikey_list']
                ,index
                ,inner =''
                ,style ='';

            style+='opacity: 1;';

            switch(page_object.action.admin.data['action']){

                case 'admin_apikey':{

                    inner+='<div id="apikey_info" class="apikey_info'+(apikey_list.length === 0?'':'_hide')+'">В системе нет данных</div>';

                    inner+='<div id="apikey_block" class="apikey_block">';

                        inner+='<div id="apikey_controls">';
                            inner+='<div id="apikey_add" style="opacity: 1;">Создать ключ</div>';
                        inner+='</div>';

                        inner+='<div id="apikey_container" class="apikey_container'+(apikey_list.length === 0?'_hide':'')+'">';

                            inner+='<div id="apikey_header" class="apikey_header">';

                                inner+='<div class="apikey_header_col" style="width: 500px;">';
                                    inner+='<div class="apikey_header_col_text">Название ключей</div>';
                                inner+='</div>';

                                /*inner+='<div class="apikey_header_col" style="width: 300px;">';
                                    inner+='<div class="apikey_header_col_text">Используется</div>';
                                inner+='</div>';*/

                                inner+='<div class="apikey_header_col" style="width: 200px;">';
                                    inner+='<div class="apikey_header_col_text">Дата создания</div>';
                                inner+='</div>';

                                inner+='<div class="apikey_header_col" style="width: 150px;">';

                                    inner+='<div class="apikey_header_col_text"></div>';

                                inner+='</div>';

                            inner+='</div>';

                            inner+='<div id="apikey_list" class="apikey_list">';

                            for(index in apikey_list){

                                inner+='<div id="apikey_item_'+index+'" class="apikey_item">';

                                    inner+=page_object.action.admin.create.apikey.create.get_apikey_row(index);

                                inner+='</div>';

                            }

                            inner+='</div>';

                        inner+='</div>';

                    inner+='</div>';
                    break;
                }
            }

            el=addElement({
                'tag':'div',
                'id':'apikey_content',
                'inner':inner,
                'style':style
            });

            $d('all').appendChild(el);

            return true;
        },
    },
    'set_action':function(){

        page_object.action.admin.action.apikey_content.action.init();

        return true;

    },
    'show':function(){

        setTimeout(page_object.action.admin.action.apikey_content.show,40);

    }
};
