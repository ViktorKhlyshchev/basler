cl = console.log;

page_object.action.admin.create.tcp={
    'init':function(){

        page_object.action.admin.create.tcp.position.init();
        page_object.action.admin.create.tcp.create.init();
        page_object.action.admin.create.tcp.set_action();
        page_object.action.admin.create.tcp.show();

    },
    'position':{
        'init':function(){

        }
    },
    'create':{
        'init':function(){
            switch(page_object.action.admin.data['action']){
                case 'admin_tcp':
                case 'admin_tcp_item':{
                    page_object.action.admin.data['data_backup'] = clone_object(page_object.action.admin.data['data']);
                    page_object.action.admin.create.tcp.create.tcp_content();
                    break;
                }
            }

        },
        'get_ipv4_ip':function(index){
            var  inner =''
                ,list =page_object.action.admin.data['data']['data']['ipv4']['ip_address_list'];
            inner+='<div class="tcp_ip_input_container">';
                inner+='<input type="text" id="tcp_ipv4_ip_address_'+index+'" class="tcp_input_ipv4" placeholder="192.168.0.1" value="'+stripSlashes(empty(list[index]['ip'])?'':list[index]['ip'])+'" />';
            inner+='</div>';
            inner+='<div class="tcp_ip_input_container">';
                inner+='<input type="text" id="tcp_ipv4_mask_'+index+'" class="tcp_input_mask_ipv4" placeholder="24 or 255.255.255.0" value="'+stripSlashes(empty(list[index]['mask'])?'':list[index]['mask'])+'" />';
            inner+='</div>';
            inner+='<div class="tcp_ip_control">';
                inner+='<div id="tcp_ipv4_ip_add_'+index+'" class="tcp_ip_add"></div>';
                inner+='<div id="tcp_ipv4_ip_remove_'+index+'" class="tcp_ip_remove"></div>';
            inner+='</div>';
            return inner;
        },
        'get_route_ipv4':function(index, order_number){
            var  inner =''
                ,list =page_object.action.admin.data['data']['data']['route_ipv4_settings'];
            inner+='<div class="tcp_ip_input_container">';
                inner+='<input type="text" id="tcp_route_ipv4_address_'+index+'" class="tcp_input_route" placeholder="192.168.0.1" value="'+stripSlashes(empty(list[index]['ip'])?'':list[index]['ip'])+'" />';
            inner+='</div>';
            inner+='<div class="tcp_ip_input_container">';
                inner+='<input type="text" id="tcp_route_ipv4_order_'+index+'" min="1" max="100" class="tcp_input_order_route" placeholder="1-100" value="'+stripSlashes(empty(list[index]['order'])?order_number:list[index]['order'])+'" />';
            inner+='</div>';
            inner+='<div class="tcp_ip_control">';
                inner+='<div id="tcp_route_ipv4_add_'+index+'" class="tcp_ip_add"></div>';
                inner+='<div id="tcp_route_ipv4_remove_'+index+'" class="tcp_ip_remove"></div>';
            inner+='</div>';
            return inner;
        },
        'get_route_ipv6':function(index, order_number){
            var  inner =''
                ,list =page_object.action.admin.data['data']['data']['route_ipv6_settings'];
            inner+='<div class="tcp_ip_input_container">';
                inner+='<input type="text" id="tcp_route_ipv6_address_'+index+'" class="tcp_input_route" placeholder="2606:4700:4700::1111" value="'+stripSlashes(empty(list[index]['ip'])?'':list[index]['ip'])+'" />';
            inner+='</div>';
            inner+='<div class="tcp_ip_input_container">';
                inner+='<input type="text" id="tcp_route_ipv6_order_'+index+'" min="1" max="100" class="tcp_input_order_route" placeholder="1-100" value="'+stripSlashes(empty(list[index]['order'])?order_number:list[index]['order'])+'" />';
            inner+='</div>';
            inner+='<div class="tcp_ip_control">';
                inner+='<div id="tcp_route_ipv6_add_'+index+'" class="tcp_ip_add"></div>';
                inner+='<div id="tcp_route_ipv6_remove_'+index+'" class="tcp_ip_remove"></div>';
            inner+='</div>';
            return inner;
        },
        'get_ipv4_dns':function(index){
            var  inner =''
                ,list =page_object.action.admin.data['data']['data']['ipv4']['dns_address_list'];
            inner+='<div class="tcp_dns_input_container">';
                inner+='<input type="text" id="tcp_ipv4_dns_address_'+index+'" class="tcp_input_dns" placeholder="1.1.1.1" value="'+stripSlashes(empty(list[index])?'':list[index])+'" />';
            inner+='</div>';
            inner+='<div class="tcp_ip_control">';
                inner+='<div id="tcp_ipv4_dns_add_'+index+'" class="tcp_ip_add"></div>';
                inner+='<div id="tcp_ipv4_dns_remove_'+index+'" class="tcp_ip_remove"></div>';
            inner+='</div>';
            return inner;
        },
        'get_ipv6_ip':function(index){
            var  inner =''
                ,list =page_object.action.admin.data['data']['data']['ipv6']['ip_address_list'];
            inner+='<div class="tcp_ip_input_container">';
                inner+='<input type="text" id="tcp_ipv6_ip_address_'+index+'" class="tcp_input_ipv6" placeholder="2001:db8::" value="'+stripSlashes(empty(list[index]['ip'])?'':list[index]['ip'])+'" />';
            inner+='</div>';
            inner+='<div class="tcp_ip_input_container">';
                inner+='<input type="text" id="tcp_ipv6_mask_'+index+'" class="tcp_input_mask_ipv6" placeholder="32" value="'+stripSlashes(empty(list[index]['mask'])?'':list[index]['mask'])+'" />';
            inner+='</div>';
            inner+='<div class="tcp_ip_control">';
                inner+='<div id="tcp_ipv6_ip_add_'+index+'" class="tcp_ip_add"></div>';
                inner+='<div id="tcp_ipv6_ip_remove_'+index+'" class="tcp_ip_remove"></div>';
            inner+='</div>';
            return inner;
        },
        'get_ipv6_dns':function(index){
            var  inner =''
                ,list =page_object.action.admin.data['data']['data']['ipv6']['dns_address_list'];
            inner+='<div class="tcp_dns_input_container">';
                inner+='<input type="text" id="tcp_ipv6_dns_address_'+index+'" class="tcp_input_dns" placeholder="2606:4700:4700::1111" value="'+stripSlashes(empty(list[index])?'':list[index])+'" />';
            inner+='</div>';
            inner+='<div class="tcp_ip_control">';
                inner+='<div id="tcp_ipv6_dns_add_'+index+'" class="tcp_ip_add"></div>';
                inner+='<div id="tcp_ipv6_dns_remove_'+index+'" class="tcp_ip_remove"></div>';
            inner+='</div>';
            return inner;
        },
        'get_tcp_content':function(){
            cl(page_object.action.admin.data['data']);
            let  data =page_object.action.admin.data['data']
                ,list
                ,content_data
                ,index
                ,inner ='';
            if(isset(data['data']['error'])) return inner;
            switch(page_object.action.admin.data['action']){
                case 'admin_tcp':{
                    break;
                }
                case 'admin_tcp_item':{
                    content_data=data['data'];
                    cl(content_data);
                    inner+='<div class="tcp_row">';
                        inner+='<div class="tcp_row_col" style="width: 700px">';
                            inner+='<div class="tcp_row_item">';
                                inner+='<div class="tcp_row_item_container">';
                                    inner+='<div class="tcp_row_item_label">Статус подключения</div>';
                                    inner+='<div id="tcp_connect_status" class="tcp_row_item_content">'+stripSlashes(empty(content_data['status'])?'Ожидается поключение...':content_data['status'])+'</div>';
                                inner+='</div>';
                                inner+='<div class="tcp_row_item_container">';
                                    inner+='<div class="tcp_row_item_label">Тип подключения</div>';
                                    inner+='<div class="tcp_row_item_content">'+stripSlashes(content_data['tcp_type'])+'</div>';
                                inner+='</div>';
                                inner+='<div class="tcp_row_item_container">';
                                    inner+='<div class="tcp_row_item_label">Название подключения</div>';
                                    inner+='<div class="tcp_row_item_content">';
                                        inner+='<input type="text" id="tcp_name" class="tcp_input_number" value="'+stripSlashes(empty(content_data['name'])?'':content_data['name'])+'" />';
                                    inner+='</div>';
                                inner+='</div>';
                                inner+='<div class="tcp_row_item_container">';
                                    inner+='<div class="tcp_row_item_label">Default MAC address</div>';
                                    inner+='<div class="tcp_row_item_content" style="padding-top: 5px;">'+stripSlashes(empty(content_data['original_mac_address'])?'':content_data['original_mac_address'])+'</div>';
                                inner+='</div>';
                                inner+='<div class="tcp_row_item_container">';
                                    inner+='<div class="tcp_row_item_label">User MAC address</div>';
                                    inner+='<div class="tcp_row_item_content">';
                                        inner+='<input type="text" id="tcp_user_mac_address" class="tcp_input_number" placeholder="00:04:4b:dd:55:ea" value="'+stripSlashes(empty(content_data['user_mac_address'])?'':content_data['user_mac_address'])+'" />';
                                    inner+='</div>';
                                inner+='</div>';
                            inner+='</div>';
                            inner+='<div id="tcp_ipv4_block" class="tcp_row_item">';
                                inner+='<div class="tcp_row_item_container">';
                                    inner+='<div class="tcp_row_item_label">Режим IPv4</div>';
                                    inner+='<div class="tcp_row_item_content">';
                                        inner+='<select id="tcp_ipv4_mode" class="tcp_input_number">';
                                            //inner+='<option value="0"></option>';
                                            inner+='<option value="dhcp"'+(content_data['ipv4']['mode'] === 'dhcp'?' selected="selected"':'')+'>DHCP</option>';
                                            inner+='<option value="static"'+(content_data['ipv4']['mode'] === 'static'?' selected="selected"':'')+'>Static IP</option>'; // Статичный
                                            inner+='<option disabled value="disabled"'+(content_data['ipv4']['mode'] === 'disabled'?' selected="selected"':'')+'>Отключено</option>';
                                        inner+='</select>';
                                    inner+='</div>';
                                inner+='</div>';
                                inner+='<div id="tcp_ipv4_settings" class="tcp_row_item_settings'+(content_data['ipv4']['mode'] === 'disabled'?'_hide':'')+'">';
                                    inner+='<div id="tcp_ipv4_ip_block" class="tcp_row_item_container'+(content_data['ipv4']['mode'] === 'dhcp'?'_hide':'')+'">';
                                        inner+='<div class="tcp_row_item_label">IP address</div>';
                                        inner+='<div id="tcp_ipv4_ip_list" class="tcp_row_item_content">';
                        if(empty(content_data['ipv4']['ip_address_list']))
                            content_data['ipv4']['ip_address_list'] = [{}];
                        list=content_data['ipv4']['ip_address_list'];
                            for(index in list){
                                inner+='<div id="tcp_ipv4_ip_item_'+index+'" class="tcp_ip_item">';
                                    inner+=page_object.action.admin.create.tcp.create.get_ipv4_ip(index);
                                inner+='</div>';
                            }
                                        inner+='</div>';
                                    inner+='</div>';
                                    inner+='<div class="tcp_row_item_container">';
                                        inner+='<div class="tcp_row_item_label">DNS address</div>';
                                        inner+='<div id="tcp_ipv4_dns_list" class="tcp_row_item_content">';
                        if(empty(content_data['ipv4']['dns_address_list']))
                            content_data['ipv4']['dns_address_list'] = [""];
                        list=content_data['ipv4']['dns_address_list'];
                            for(index in list){
                                inner+='<div id="tcp_ipv4_dns_item_'+index+'" class="tcp_dns_item">';
                                    inner+=page_object.action.admin.create.tcp.create.get_ipv4_dns(index);
                                inner+='</div>';
                            }
                                        inner+='</div>';
                                    inner+='</div>';
                                    inner+='<div class="tcp_row_item_container">';
                                        inner+='<div class="tcp_row_item_label">Gateway</div>';
                                        inner+='<div class="tcp_row_item_content">';
                                            inner+='<input type="text" id="tcp_ipv4_gateway" class="tcp_input_number" placeholder="192.168.0.254" value="'+stripSlashes(empty(content_data['ipv4']['gateway'])?'':content_data['ipv4']['gateway'])+'" />';
                                        inner+='</div>';
                                    inner+='</div>';
                                inner+='</div>';
                            inner+='</div>';
                            trace('')
                            trace('')
                            trace('ipv6')
                            trace(content_data['ipv6']);
                            inner+='<div id="tcp_ipv6_block" class="tcp_row_item">';
                                inner+='<div class="tcp_row_item_container">';
                                    inner+='<div class="tcp_row_item_label">Режим IPv6</div>';
                                    inner+='<div class="tcp_row_item_content">';
                                        inner+='<select id="tcp_ipv6_mode" class="tcp_input_number">';
                                            inner+='<option value="0"></option>';
                                            inner+='<option value="dhcp"'+(content_data['ipv6']['mode'] === 'dhcp'?' selected="selected"':'')+'>DHCP</option>';
                                            inner+='<option value="static"'+(content_data['ipv6']['mode'] === 'static'?' selected="selected"':'')+'>Static</option>';
                                            inner+='<option value="disabled"'+(content_data['ipv6']['mode'] === 'disabled'?' selected="selected"':'')+'>Отключено</option>';
                                        inner+='</select>';
                                    inner+='</div>';
                                inner+='</div>';
                                inner+='<div id="tcp_ipv6_settings" class="tcp_row_item_settings'+(content_data['ipv6']['mode'] === 'disabled'?'_hide':'')+'">';
                                    inner+='<div id="tcp_ipv6_ip_block" class="tcp_row_item_container'+(content_data['ipv6']['mode'] === 'dhcp'?'_hide':'')+'">';
                                        inner+='<div class="tcp_row_item_label">IP address</div>';
                                        inner+='<div id="tcp_ipv6_ip_list" class="tcp_row_item_content">';
                        if(empty(content_data['ipv6']['ip_address_list']))
                            content_data['ipv6']['ip_address_list'] = [{}];
                        list=content_data['ipv6']['ip_address_list'];
                            for(index in list){
                                inner+='<div id="tcp_ipv6_ip_item_'+index+'" class="tcp_ip_item">';
                                    inner+=page_object.action.admin.create.tcp.create.get_ipv6_ip(index);
                                inner+='</div>';
                            }
                                        inner+='</div>';
                                    inner+='</div>';
                                    inner+='<div class="tcp_row_item_container">';
                                        inner+='<div class="tcp_row_item_label">DNS address</div>';
                                        inner+='<div id="tcp_ipv6_dns_list" class="tcp_row_item_content">';
                        if(empty(content_data['ipv6']['dns_address_list']))
                            content_data['ipv6']['dns_address_list'] = [""];
                        list=content_data['ipv6']['dns_address_list'];
                            for(index in list){
                                inner+='<div id="tcp_ipv6_dns_item_'+index+'" class="tcp_dns_item">';
                                    inner+=page_object.action.admin.create.tcp.create.get_ipv6_dns(index);
                                inner+='</div>';
                            }
                                        inner+='</div>';
                                    inner+='</div>';
                                    inner+='<div class="tcp_row_item_container">';
                                        inner+='<div class="tcp_row_item_label">Gateway</div>';
                                        inner+='<div class="tcp_row_item_content">';
                                            inner+='<input type="text" id="tcp_ipv6_gateway" class="tcp_input_number" placeholder="2001:db8::1234" value="'+stripSlashes(empty(content_data['ipv6']['gateway'])?'':content_data['ipv6']['gateway'])+'" />';
                                        inner+='</div>';
                                    inner+='</div>';
                                inner+='</div>';
                            inner+='</div>';
                            switch(content_data['tcp_type']){
                                case 'gsm':
                                case 'modem':
                                case 'generic':
                                case 'unknown':{
                                    inner+='<div id="tcp_gsm_block" class="tcp_row_item">';
                                        inner+='<div class="tcp_row_item_container">';
                                            inner+='<div class="tcp_row_item_label">Режим GSM</div>';
                                            inner+='<div class="tcp_row_item_content">';
                                                inner+='<select id="tcp_gsm_mode" class="tcp_input_number">';
                                                    inner+='<option value="0"></option>';
                                                    inner+='<option value="manual"'+(content_data['gsm']['mode'] === 'manual'?' selected="selected"':'')+'>Ручной режим</option>';
                                                    inner+='<option value="auto"'+(content_data['gsm']['mode'] === 'auto'?' selected="selected"':'')+'>Автоматический режим</option>';
                                                inner+='</select>';
                                            inner+='</div>';
                                        inner+='</div>';
                                        inner+='<div id="tcp_gsm_settings" class="tcp_row_item_settings'+(content_data['gsm']['mode'] === 'auto'?'_hide':'')+'">';
                                            inner+='<div class="tcp_row_item_container">';
                                                inner+='<div class="tcp_row_item_label">APN</div>';
                                                inner+='<div class="tcp_row_item_content">';
                                                    inner+='<input type="text" id="tcp_gsm_apn" class="tcp_input_number" value="'+stripSlashes(empty(content_data['gsm']['apn'])?'':content_data['gsm']['apn'])+'" />';
                                                inner+='</div>';
                                            inner+='</div>';
                                            inner+='<div class="tcp_row_item_container">';
                                                inner+='<div class="tcp_row_item_label">Username</div>';
                                                inner+='<div class="tcp_row_item_content">';
                                                    inner+='<input type="text" id="tcp_gsm_username" class="tcp_input_number" value="'+stripSlashes(empty(content_data['gsm']['username'])?'':content_data['gsm']['username'])+'" />';
                                                inner+='</div>';
                                            inner+='</div>';
                                            inner+='<div class="tcp_row_item_container">';
                                                inner+='<div class="tcp_row_item_label">Password</div>';
                                                inner+='<div class="tcp_row_item_content">';
                                                    inner+='<input type="text" id="tcp_gsm_password" class="tcp_input_number" value="'+stripSlashes(empty(content_data['gsm']['password'])?'':content_data['gsm']['password'])+'" />';
                                                inner+='</div>';
                                            inner+='</div>';
                                            inner+='<div class="tcp_row_item_container">';
                                                inner+='<div class="tcp_row_item_label">Mobile Network Code</div>';
                                                inner+='<div class="tcp_row_item_content">';
                                                    inner+='<input type="text" id="tcp_gsm_network" class="tcp_input_number" value="'+stripSlashes(empty(content_data['gsm']['network'])?'':content_data['gsm']['network'])+'" />';
                                                inner+='</div>';
                                            inner+='</div>';
                                        inner+='</div>';
                                    inner+='</div>';
                                    break;
                                }
                            }
                        inner+='</div>';
                        inner+='<div id="tcp_route_block" class="tcp_row_item">';
                            inner+='<div id="tcp_route_ipv4_settings" class="tcp_row_item_settings">';
                                inner+='<div id="tcp_route_ipv4_block" class="tcp_row_item_container">';
                                    inner+='<div class="tcp_row_item_label">Маршруты IPv4</div>';
                                    inner+='<div id="tcp_route_ipv4_list" class="tcp_row_item_content">';
                    if(empty(content_data['route_ipv4_settings']))
                        content_data['route_ipv4_settings'] = [{}];
                    list=content_data['route_ipv4_settings'];
                        for(index in list){
                            inner+='<div id="tcp_route_ipv4_item_'+index+'" class="tcp_route_item">';
                                inner+=page_object.action.admin.create.tcp.create.get_route_ipv4(index,parseInt(index)+1);
                            inner+='</div>';
                        }
                                    inner+='</div>';
                                inner+='</div>';
                            inner+='</div>';
                        inner+='</div>';
                        inner+='<div id="tcp_route_block" class="tcp_row_item">';
                            inner+='<div id="tcp_route_ipv6_settings" class="tcp_row_item_settings">';
                                inner+='<div id="tcp_route_ipv6_block" class="tcp_row_item_container">';
                                    inner+='<div class="tcp_row_item_label">Маршруты IPv6</div>';
                                    inner+='<div id="tcp_route_ipv6_list" class="tcp_row_item_content">';
                    if(empty(content_data['route_ipv6_settings']))
                        content_data['route_ipv6_settings'] = [{}];
                    list=content_data['route_ipv6_settings'];
                        for(index in list){
                            inner+='<div id="tcp_route_ipv6_item_'+index+'" class="tcp_route_item">';
                                inner+=page_object.action.admin.create.tcp.create.get_route_ipv6(index,parseInt(index)+1);
                            inner+='</div>';
                        }
                                    inner+='</div>';
                                inner+='</div>';
                            inner+='</div>';
                        inner+='</div>';
                    inner+='</div>';
                    inner+='<div class="tcp_row" style="border: none;">';
                        inner+='<div class="tcp_row_col" style="width: 100%; text-align: right; margin-bottom: 5px;">';
                            inner+='<div id="tcp_cancel" class="tcp_cancel_disable">Отмена</div>';
                            inner+='<div id="tcp_save" class="tcp_save_disable">Сохранить</div>';
                        inner+='</div>';
                    inner+='</div>';
                    break;
                }
            }
            cl(inner);
            return inner;
        },
        'get_menu_list':function(){
            let  data =page_object.action.admin.data['data']
                ,menu_list =data['menu_list']
                ,index
                ,inner ='';
            for(index in menu_list)
                inner+='<div id="tcp_menu_item_'+index+'" class="tcp_menu_item'+(menu_list[index]['connect_name'] === page_object.link.link_list[3]?'_active':'')+'">'+stripSlashes(menu_list[index]['name'])+'</div>';
            return inner;
        },
        'tcp_content':function(){
            let  el
                ,data =page_object.action.admin.data['data']
                ,inner =''
                ,style ='';
            style+='opacity: 1;';
            switch(page_object.action.admin.data['action']){
                case 'admin_tcp':{
                    inner+='<div id="tcp_info" class="tcp_info">Выберите подключение</div>';
                    break;
                }
                case 'admin_tcp_item':{
                    if(isset(data['data']['error']))
                        inner+='<div id="tcp_info" class="tcp_info">'+stripSlashes(data['data']['error'])+'</div>';
                    break;
                }
            }
            inner+='<div class="tcp_block">';
                inner+='<div id="tcp_menu_list">';
                    inner+=page_object.action.admin.create.tcp.create.get_menu_list();
                inner+='</div>';
                inner+='<div id="tcp_container">';
                    inner+=page_object.action.admin.create.tcp.create.get_tcp_content();
                inner+='</div>';
            inner+='</div>';
            cl(inner);
            el=addElement({
                'tag':'div',
                'id':'tcp_content',
                'inner':inner,
                'style':style
            });
            $d('all').appendChild(el);
            return true;
        },
    },
    'set_action':function(){
        page_object.action.admin.action.tcp_content.action.init();
        return true;
    },
    'show':function(){
        setTimeout(page_object.action.admin.action.tcp_content.show,40);
    }
};
