page_object.action.admin.create.radar={
    'init':function(){

        page_object.action.admin.create.radar.position.init();
        page_object.action.admin.create.radar.create.init();
        page_object.action.admin.create.radar.set_action();
        page_object.action.admin.create.radar.show();

    },
    'position':{
        'init':function(){

        }
    },
    'create':{
        'init':function(){

            switch(page_object.action.admin.data['action']){

                case 'admin_radar':{

                    page_object.action.admin.create.radar.create.radar_content();

                    break;

                }

            }

        },
        'get_radar_row':function(index){

            let  data =page_object.action.admin.data['data']
                ,list =data['list']
                ,item_data =list[index]
                ,inner ='';

            inner+='<div class="radar_item_col" style="width: 30px;">';
                inner+='<span>'+(parseInt(index)+1)+'</span>';
            inner+='</div>';

            inner+='<div class="radar_item_col" style="width: 150px;">';
                inner+='<span>'+stripSlashes(item_data['x_point'])+'</span>';
            inner+='</div>';

            inner+='<div class="radar_item_col" style="width: 150px;">';
                inner+='<span>'+stripSlashes(item_data['y_point'])+'</span>';
            inner+='</div>';

            inner+='<div class="radar_item_col" style="width: 150px;">';
                inner+='<span>'+stripSlashes(item_data['speed'])+' m/s ('+(item_data['speed']*3600/1000).toFixed(1)+' km/h)</span>';
            inner+='</div>';

            inner+='<div class="radar_item_col" style="width: 150px;">';
                inner+='<span>'+stripSlashes(item_data['heading'])+'</span>';
            inner+='</div>';

            inner+='<div class="radar_item_col" style="width: 150px;">';
                inner+='<span>'+stripSlashes(item_data['object_len'])+'</span>';
            inner+='</div>';

            inner+='<div class="radar_item_col" style="width: 150px;">';
                inner+='<span>'+stripSlashes(item_data['id'])+'</span>';
            inner+='</div>';

            return inner;

        },
        'radar_content':function(){

            let  el
                ,data =page_object.action.admin.data['data']
                ,radar_list =data['list']
                ,index
                ,inner =''
                ,style ='';

            style+='opacity: 1;';

            switch(page_object.action.admin.data['action']){

                case 'admin_radar':{

                    inner+='<div id="radar_block" class="radar_block">';

                        inner+='<div id="radar_container" class="radar_container">';

                            inner+='<div id="radar_video">';
                                inner+='<iframe id="config_video_iframe" src="'+data['video_link']+'" width="100%" height="100%" style="border: none; outline: none; line-height: 0;"></iframe>';
                            inner+='</div>';

                            inner+='<div id="radar_table_block" class="radar_table_block">';
                                inner+='<div id="radar_header" class="radar_header">';

                                    inner+='<div class="radar_header_col" style="width: 30px;">';
                                        inner+='<div class="radar_header_col_text">#</div>';
                                    inner+='</div>';

                                    inner+='<div class="radar_header_col" style="width: 150px;">';
                                        inner+='<div class="radar_header_col_text">X point, m</div>';
                                    inner+='</div>';

                                    inner+='<div class="radar_header_col" style="width: 150px;">';
                                        inner+='<div class="radar_header_col_text">Y point, m</div>';
                                    inner+='</div>';

                                    inner+='<div class="radar_header_col" style="width: 150px;">';
                                        inner+='<div class="radar_header_col_text">Speed Abs, m/s</div>';
                                    inner+='</div>';

                                    inner+='<div class="radar_header_col" style="width: 150px;">';
                                        inner+='<div class="radar_header_col_text">Heading, deg</div>';
                                    inner+='</div>';

                                    inner+='<div class="radar_header_col" style="width: 150px;">';
                                        inner+='<div class="radar_header_col_text">Length, m</div>';
                                    inner+='</div>';

                                    inner+='<div class="radar_header_col" style="width: 150px;">';
                                        inner+='<div class="radar_header_col_text">Object id</div>';
                                    inner+='</div>';

                                inner+='</div>';

                                inner+='<div id="radar_list" class="radar_list">';

                                if(radar_list.length === 0)
                                    inner+='<div id="radar_info" class="radar_info">Нет данных</div>';

                                for(index in radar_list){

                                    inner+='<div id="radar_item_'+radar_list[index]['id']+'" class="radar_item">';

                                        inner+=page_object.action.admin.create.radar.create.get_radar_row(index);

                                    inner+='</div>';

                                }

                                inner+='</div>';

                            inner+='</div>';

                        inner+='</div>';

                    inner+='</div>';

                    break;

                }

            }

            el=addElement({
                'tag':'div',
                'id':'radar_content',
                'inner':inner,
                'style':style
            });

            $d('all').appendChild(el);

            return true;

        },
    },
    'set_action':function(){

        page_object.action.admin.action.radar_content.action.init();

        return true;

    },
    'show':function(){

        setTimeout(page_object.action.admin.action.radar_content.show,40);

    }
};
