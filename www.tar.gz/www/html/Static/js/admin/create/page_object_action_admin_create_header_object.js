cl = console.log

page_object.action.admin.create.header={
    'init':function(){

        if(isset($d('header'))&&!isset($d('header_profile'))){

            page_object.action.admin.action.header.un_show(true);

            setTimeout(page_object.action.admin.create.header.create.init,300);

        }
        else
            page_object.action.admin.create.header.create.init();

    },
    'position':{
        'header_menu':function(){

            page_object.action.admin.position.header_menu.w=Math.ceil(winSize.winWidth*.63);

        },
        'header':function(){

            page_object.action.admin.position.header.w =winSize.winWidth;
            page_object.action.admin.position.header.x =0;
            page_object.action.admin.position.header.y =-page_object.action.admin.position.header.h;

        },
        'header_profile':function(){

            if(isset($d('header_profile'))){

                page_object.action.admin.position.header_profile.o =0;
                page_object.action.admin.position.header_profile.w =elementSize.width($d('header_profile'));
                page_object.action.admin.position.header_profile.x =winSize.winWidth-page_object.action.admin.position.header_profile.m.r-page_object.action.admin.position.header_profile.w;

                $s('header_profile').opacity =page_object.action.admin.position.header_profile.o;
                $s('header_profile').height =page_object.action.admin.position.header_profile.h+'px';

            }

        }
    },
    'create':{
        'init':function(){

            if(isset($d('header')))
                return false;

            page_object.action.admin.create.header.position.header();
            page_object.action.admin.create.header.position.header_menu();
            page_object.action.admin.create.header.create.header();
            page_object.action.admin.create.header.create.footer();
            page_object.action.admin.create.header.set_action();
            page_object.action.admin.create.header.show();

            return true;

        },
        'header':function(){
            var datar =page_object.action.admin.data['user'];
            cl("data['image_item_id_list']");
            cl("data['image_item_id_list']");
            cl("data['image_item_id_list']");
            cl("data['image_item_id_list']");
            cl("data['image_item_id_list']");
            cl(datar['image_item_id_list']);
            cl(datar);
            let  el
                ,inner =''
                ,header_style =''
                ,profile_style =''
                ,data =page_object.action.admin.data['user']
                ,xavier =page_object.action.admin.data['xavier'] // GetXavierHeaderInfoAction::init(), init_list page_object.action.admin Project/Aist/Admin/Template/Js/System/page_object.js Project/Aist/Admin/Template/Js/Admin/init.js
                ,image_id =data['image_id']
                ,login =data['login']
                ,profile_image =(image_id === 0)?'/Project/Aist/Admin/Template/Images/Avatar/admin_icon.png':'/'+data['image_dir']+'/'+data['image_item_id_list']['preview']['id'];

            inner+='<a href=/ id="logo"></a>';

            inner+='<div id="header_controls">';

                inner+='<div id="device_number" class="header_controls_item">';
                    inner+='<div class="header_controls_coll" style="opacity: .7;">Комплекс:</div>';
                    inner+='<div class="header_controls_coll">'+stripSlashes(empty(xavier['name'])?'-':xavier['name'])+'</div>';
                    if(dblink) inner+= `<div class="header_controls_coll" style="opacity: .7;">DB: <a style=color:cornflowerblue href='${dblink}'>${dbn}</a></div>`;
                inner+='</div>';

            if(!data['is_promo_radar']){

                inner+='<div id="device_address" class="header_controls_item">';
                    inner+='<div class="header_controls_coll" style="opacity: .7;">Адрес:</div>';
                    inner+='<div class="header_controls_coll">'+stripSlashes(xavier['address'])+'</div>';
                inner+='</div>';

                inner+='<div id="device_power" class="header_controls_item">';
                    inner+='<div class="header_controls_coll" style="opacity: .7;">Режим:</div>';
                    inner+='<div class="header_controls_coll">';
                        inner+='<select id="device_power_select" class="dialog_row_select_text" style="width: auto">';
                            inner+='<option value="off"'+(xavier['status'] === 'off'?'selected':'')+'>Не работает</option>';
                            inner+='<option value="no_fixation"'+(xavier['status'] === 'no_fixation'?'selected':'')+'>Без фиксации</option>';
                            inner+='<option value="work"'+(xavier['status'] === 'work'?'selected':'')+'>Работает</option>';
                        inner+='</select>';
                    inner+='</div>';
                    inner+='<div class="header_controls_coll">';
                        inner+='<div id="header_power_submit" class="header_submit_button_disable" style="width: auto">Применить</div>';
                    inner+='</div>';
                inner+='</div>';

            }

            inner+='</div>';

            inner+='<div id="header_profile" class="header_profile" style="'+profile_style+'">';
            inner+='<div id="header_profile_image" style="background: url('+profile_image+') 50% 50% no-repeat; background-size: cover;"></div>';
            inner+='<div id="header_profile_login">'+stripSlashes(login)+'</div>';
            inner+='</div>';

            el=addElement({
                'tag':'div',
                'id':'header',
                'inner':inner
            });

            $d('all').appendChild(el);

        },
        'footer':function(){

            if(loc){
                $('#header').css('hreight', '33px');
                return;
            }

            let  el;

            el=addElement({
                'tag':'div',
                'id':'footer',
                'inner':'© 2019 АИСТ-КОНТРОЛЬ',
                'style':'opacity: 0'
            });

            $d('all').appendChild(el);

        }
    },
    'set_action':function(){

        if(isset($d('header_profile'))) $d('header_profile').onclick=page_object.action.admin.action.header_profile.click;

        if(isset($d('logo'))) $d('logo').onclick=page_object.action.admin.action.header.logo.click;

    },
    'show':function(){

        setTimeout(page_object.action.admin.action.header.show,40);
        setTimeout(page_object.action.admin.create.header.position.header_profile,40);
        setTimeout(page_object.action.admin.action.header_profile.show,400);

    }
};
