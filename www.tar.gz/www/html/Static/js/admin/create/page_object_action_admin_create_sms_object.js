page_object.action.admin.create.sms={
    'init':function(){

        page_object.action.admin.create.sms.position.init();
        page_object.action.admin.create.sms.create.init();
        page_object.action.admin.create.sms.set_action();
        page_object.action.admin.create.sms.show();

    },
    'position':{
        'init':function(){

        }
    },
    'create':{
        'init':function(){

            switch(page_object.action.admin.data['action']){

                case 'admin_sms':{

                    page_object.action.admin.create.sms.create.sms_content();

                    break;

                }

            }

        },
        'get_sms_row':function(index){

            let  data =page_object.action.admin.data['data']
                ,list =data['list']
                ,ftp_data =list[index]
                ,row_id =ftp_data['id']
                ,inner ='';

            inner+='<div id="sms_item_phone_'+row_id+'" class="sms_item_col" style="width: 100px;">';
                inner+='<span>'+stripSlashes(ftp_data['phone'])+'</span>';
            inner+='</div>';

            inner+='<div id="sms_item_content_'+row_id+'" class="sms_item_col" style="width: 400px;">';
                inner+='<span>'+stripSlashes(empty(ftp_data['content'])?'-':ftp_data['content'])+'</span>';
            inner+='</div>';

            inner+='<div id="sms_item_timestamp_'+row_id+'" class="sms_item_col" style="width: 150px;">';
                inner+='<span>'+stripSlashes(get_date_time(ftp_data['date_create']))+'</span>';
            inner+='</div>';

            inner+='<div id="sms_item_incoming_'+row_id+'" class="sms_item_col" style="width: 150px;">';

                inner+='<div class="sms_controls">';

                    inner+='<div id="sms_item_incoming_icon_'+row_id+'" class="sms_'+(ftp_data['is_incoming']?'incoming':'outgoing')+'" title="'+(ftp_data['is_incoming']?'Входящее сообщение':'Исходящее сообщение')+'"></div>';
                    inner+='<div class="sms_send" title="Отправлено"'+(ftp_data['is_send']?'':' style="display: none;"')+'></div>';
                    inner+='<div class="sms_loading" title="Отправка..."'+(ftp_data['is_send'] || ftp_data['is_incoming'] || !empty(ftp_data['error'])?' style="display: none;"':'')+'></div>';
                    inner+='<div class="sms_info_icon"'+(empty(ftp_data['error'])?'':(' title="'+(ftp_data['error'])+'"'))+(empty(ftp_data['error'])?' style="display: none;"':'')+'></div>';

                inner+='</div>';

            inner+='</div>';

            return inner;

        },
        'sms_content':function(){

            let  el
                ,data =page_object.action.admin.data['data']
                ,sms_list =data['list']
                ,index
                ,inner =''
                ,style ='';

            style+='opacity: 1;';

            switch(page_object.action.admin.data['action']){

                case 'admin_sms':{

                    inner+='<div id="sms_info" class="sms_info'+(sms_list.length === 0?'':'_hide')+'">В системе нет данных</div>';

                    inner+='<div id="sms_block" class="sms_block">';

                        inner+='<div id="sms_container" class="sms_container">';

                            inner+='<div id="sms_controls">';
                                inner+='<div id="sms_add" style="opacity: 1;">Отправить SMS сообщение</div>';
                                inner+='<div id="sms_ussd_add" style="opacity: 1;">Отправить USSD команду</div>';
                            inner+='</div>';

                            inner+='<div id="sms_table_block" class="sms_table_block'+(sms_list.length === 0?'_hide':'')+'">';
                                inner+='<div id="sms_header" class="sms_header">';

                                    inner+='<div class="sms_header_col" style="width: 100px;">';
                                        inner+='<div class="sms_header_col_text">Телефон</div>';
                                    inner+='</div>';

                                    inner+='<div class="sms_header_col" style="width: 400px;">';
                                        inner+='<div class="sms_header_col_text">Контент</div>';
                                    inner+='</div>';

                                    inner+='<div class="sms_header_col" style="width: 150px;">';
                                        inner+='<div class="sms_header_col_text">Время</div>';
                                    inner+='</div>';

                                    inner+='<div class="sms_header_col" style="width: 150px;">';
                                        inner+='<div class="sms_header_col_text">Статус</div>';
                                    inner+='</div>';

                                inner+='</div>';

                                inner+='<div id="sms_list" class="sms_list">';

                                for(index in sms_list){

                                    inner+='<div id="sms_item_'+sms_list[index]['id']+'" class="sms_item">';

                                        inner+=page_object.action.admin.create.sms.create.get_sms_row(index);

                                    inner+='</div>';

                                }

                                inner+='</div>';

                            inner+='</div>';

                        inner+='</div>';

                    inner+='</div>';

                    break;

                }

            }

            el=addElement({
                'tag':'div',
                'id':'sms_content',
                'inner':inner,
                'style':style
            });

            $d('all').appendChild(el);

            return true;

        },
    },
    'set_action':function(){

        page_object.action.admin.action.sms_content.action.init();

        return true;

    },
    'show':function(){

        setTimeout(page_object.action.admin.action.sms_content.show,40);

    }
};
