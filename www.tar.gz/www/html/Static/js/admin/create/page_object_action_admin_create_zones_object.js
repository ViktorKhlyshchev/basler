cl = console.log;

g.zones_test = 0;
cl(g);
cl('GGGGGGGGGGGGGGGGGGGGG321');
cl(g.is_root);
cl(g.is_debug);
cl(page_object.action.admin.data);

var htmlloaded = false;
var modal = `
<div class="modal fade calibs_modal" style=font-size:0.9em role="dialog">
    <div class=modal-dialog style=width:800px>
        <div class=modal-content>
            <div class=modal-header>
                <button type="button" class="close string-modal-control" data-dismiss="modal" aria-label="Отменить"><span aria-hidden="true">&times;</span></button>
                <center><h4 class="modal-title" id="fotoLoadModalLabel">Параметры работы комплекса</h4></center>
            </div>
            <div class=modal-body></div>
            <div class=modal-footer>
                <center><button class='btn aist_btn close_calibs_btn'>Закрыть</button></center>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zones_modal" style=font-size:0.9em role="dialog">
    <div class=modal-dialog style=width:800px>
        <div class=modal-content>
            <div class=modal-header>
                <button type="button" class="close string-modal-control" data-dismiss="modal" aria-label="Отменить"><span aria-hidden="true">&times;</span></button>
                <center><h4 class="modal-title" id="fotoLoadModalLabel">Параметры работы комплекса</h4></center>
            </div>
            <div class=modal-body></div>
            <div class=modal-footer>
                <center><button class='btn aist_btn close_zones_btn'>Закрыть</button></center>
            </div>
        </div>
    </div>
</div>

<div class="modal fade loc_save_modal" style=font-size:0.9em role="dialog">
    <div class=modal-dialog style=width:30%;widthr:800px>
        <div class=modal-content>
            <div class=modal-header>
                <button type="button" class="close string-modal-control" data-dismiss="modal" aria-label="Отменить"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="fotoLoadModalLabel">Информация</h4>
            </div>
            <div class=modal-body>Сохранить изменения?</div>
            <div class=modal-footer>
                <button style=float:left class='btn aist_btn loc_save_save_btn'>Сохранить</button>
                <button class='btn aist_btn loc_save_cancel_btn'>Отмена</button>
            </div>
        </div>
    </div>
</div>
`

var htmlint = setInterval(function(){
    if($('.zones_block').length){
        clearInterval(htmlint);
        htmlloaded = true; //$('.zones_block').append(modal);
        $('#all').append(modal);
    }
});

$('body').on('click', '.close_calibs_btn', function(){ $('.calibs_modal').modal('hide'); });

$('body').on('click', '.show_calibs_btn', function(){
    var $this = $(this); $this.blur();
    $this.html('<i class=\'fa fa-circle-o-notch fa-spin\'></i>');
    var data = { action: 'show_calibs' };
    var suc = function(resp){
        req = false; $this.html('Show calibs');
        if(isset(resp) && resp.error === false){ //cl(resp);
            $('.calibs_modal').find('.modal-body').html(resp.data.rend);
            $('.calibs_modal').modal();
            return;
        }
        er(resp.error);
    };
    var err = function(xhr, ajaxOptions, thrownError){ req = false; $this.html('Show calibs'); er('Неизвестная ошибка обновления данных #1');}
    $.ajax({ url: '/admin/zones', type: 'post', dataType: 'json', data: data, success: suc, error: err });
});

$('body').on('click', '.deleteall_calibs_btn', function(){
    var $this = $(this); $this.blur();
    if(!loc) if(!confirm('Are you sure?')) return;
    $this.html('<i class=\'fa fa-circle-o-notch fa-spin\'></i>');
    var data = { action: 'deleteall_calibs' };
    var suc = function(resp){
        req = false; $this.html('Delete all calibs');
        if(isset(resp) && resp.error === false){

            page_object.action.admin.action.zones_content.move_mode = false; //   cl(page_object.action.admin.data.zones.zone_list.calibration_points);
            //page_object.action.admin.data.zones.zone_list.calibration_points = null;
            page_object.action.admin.data.zones.zone_list.calibration_points.layer_list = [];

            if(isset($d('zone_point'))) removeElement($d('zone_point'));
            if(isset($d('zones_control_fix'))) $d('zones_control_fix').setAttribute('class', 'zones_control_item_lock');
            if(isset($d('zones_control_draw'))) $d('zones_control_draw').setAttribute('class', 'zones_control_item_disable');
            if(isset($d('zones_control_choose'))) $d('zones_control_choose').setAttribute('class', 'zones_control_item_disable');
            if(isset($d('zones_control_combo'))) $d('zones_control_combo').setAttribute('class', 'zones_control_item_combo_disable');
            if(isset($d('zones_video_canvas_item_0'))) removeElement($d('zones_video_canvas_item_0'));

            page_object.action.admin.action.zones_content.action.zone.is_edit = false;
            page_object.action.admin.action.zones_content.action.zone.canvas.is_edit = false;
            page_object.action.admin.action.zones_content.action.zone.choose_type.key = null;
            page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index = null;

            page_object.action.admin.action.zones_content.action.zone.choose_type.set_active(null);

            ok('Done!');
            //location.reload();
            return;
        }
        er(resp.error);
    };
    var err = function(xhr, ajaxOptions, thrownError){ req = false; $this.html('Delete all calibs'); er('Неизвестная ошибка обновления данных #1');}
    $.ajax({ url: '/admin/zones', type: 'post', dataType: 'json', data: data, success: suc, error: err });
});

$('body').on('click', '.show_zones_btn', function(){
    var $this = $(this); $this.blur();
    $this.html('<i class=\'fa fa-circle-o-notch fa-spin\'></i>');
    var data = { action: 'show_zones' };
    var suc = function(resp){
        req = false; $this.html('Show zones');
        if(isset(resp) && resp.error === false){ //cl(resp);
            $('.zones_modal').find('.modal-body').html(resp.data.rend);
            $('.zones_modal').modal();
            return;
        }
        er(resp.error);
    };
    var err = function(xhr, ajaxOptions, thrownError){ req = false; $this.html('Show zones'); er('Неизвестная ошибка обновления данных #1');}
    $.ajax({ url: '/admin/zones', type: 'post', dataType: 'json', data: data, success: suc, error: err });
});

page_object.action.admin.create.zones = {
    'init':function(){

        cl('page_object.action.admin.create.zones');
        cl('page_object.action.admin.create.zones');
        cl('page_object.action.admin.create.zones');
        cl(page_object.action.admin.data);
        page_object.action.admin.create.zones.position.init();
        page_object.action.admin.create.zones.create.init();
        page_object.action.admin.create.zones.set_action();
        page_object.action.admin.create.zones.show();

        $('body').on('click', '.test_btn', function(){
            var $this = $(this); $this.blur();
            if(g.zones_test){
                $('.zones_row_center_video').attr('style', '');
                $('#zone_video_container_inner').css({display: 'initial'});
                g.zones_test = 0;
            } else {
                $('.zones_row_center_video').attr('style', 'width:590px;height:495px;background:url(\'/Resource/calst.jpg\') 0 50% no-repeat;');
                $('#zone_video_container_inner').css({display: 'none'});
                g.zones_test = 1;
            }
            //$('.zones_row_center_video').css({width: '590px', height: '495px'});
            //$('.zones_row_center_video').css({background: 'url(\'/Resource/Selection_2022.02.03_16.23.44.jpg\') 0 50% no-repeat;'});
           // $('.zones_row_center_video').css('background', 'url(\'/Resource/Selection_2022.02.03_16.23.44.jpg\') 0 50% no-repeat;');

        })

    },
    'position':{ 'init':function(){ } },
    'create':{
        'init':function(){
            switch(page_object.action.admin.data['action']){
                case'admin_zones':
                case'admin_zones_item':{
                    page_object.action.admin.data['zones']['zone_list_base'] = clone_object(page_object.action.admin.data['zones']['zone_list']);
                    page_object.action.admin.create.zones.create.zones_content(); // page_object.action.admin.action.zones_content.action.zone.save.zone_list.decode_coords(page_object.action.admin.data['zones']['zone_list']);
                    break;
                }
            }
        },
        'get_left_menu':function(){

            let inner='';
            inner+='<div class="zones_row_title">Полосы движения</div>';
            inner+='<div id="zones_menu_line_list" class="zones_menu_list">';
                inner+='<div id="zones_menu_item_control_zone" class="zones_menu_item">Зона контроля</div>';
                inner+='<div id="zones_menu_item_lane" class="zones_menu_item">Полоса движения</div>';
                inner+='<div id="zones_menu_item_route_vehicles" class="zones_menu_item">Полоса для маршрутных ТС</div>';
                inner+='<div id="zones_menu_item_roadside" class="zones_menu_item">Обочина дороги</div>';
                inner+='<div id="zones_menu_item_tram_rails" class="zones_menu_item">Трамвайные пути</div>';
                inner+='<div id="zones_menu_item_no_parking" class="zones_menu_item">Стоянка запрещена</div>';
                inner+='<div id="zones_menu_item_no_stop" class="zones_menu_item">Остановка запрещена</div>';
                inner+='<div id="zones_menu_item_footway_bike_lane" class="zones_menu_item footway_bike_lane">Тротуар, велодорожка</div>';
            inner+='</div>';
            return inner;
        },
        'get_right_menu':function(){

            let inner='';
            inner+='<div class="zones_row_title">Дорожная разметка</div>';
            inner+='<div id="zones_menu_type_list" class="zones_menu_list">';
                inner+='<div id="zones_menu_item_calibration_points" class="zones_menu_item">Калибровочные точки</div>'; // inner+='<div id="zones_menu_item_calibration_line" class="zones_menu_item">Калибровочные линии</div>';
                inner+='<div id="zones_menu_item_stop_line" class="zones_menu_item">Стоп-линия</div>';
                inner+='<div id="zones_menu_item_crosswalk" class="zones_menu_item">Пешеходный переход</div>';
                inner+='<div id="zones_menu_item_waffle_marking" class="zones_menu_item">Вафельная разметка</div>';
                inner+='<div id="zones_menu_item_security_area" class="zones_menu_item">Островок безопасности</div>'; // inner+='<div id="zones_menu_item_perspective" class="zones_menu_item">Перспектива</div>';
                inner+='<div id="zones_menu_item_anchor_points" class="zones_menu_item">Точки привзяки</div>';
                if(g.is_debug){
                    inner+=`<button class="btn aist_btn zones_menu_itemr test_btn">Тест</button>`;
                    inner+=`&nbsp; <button class="btn aist_btn zones_menu_itemr show_zones_btn">Show zones</button>`;
                    inner+=`&nbsp; <button class="btn aist_btn zones_menu_itemr show_calibs_btn">Show calibs</button>`;
                    inner+=`&nbsp; <button class="btn aist_btn zones_menu_itemr deleteall_calibs_btn">Delete all calibs</button>`;
                }
            inner+='</div>';
            return inner;
        },
        'get_left_controls':function(){

            let inner='';

            inner+='<div id="zones_control_choose" class="zones_control_item" title="Выбрать зону контроля или элемент разметки"></div>';
            inner+='<div id="zones_control_draw" class="zones_control_item" title="Создать зону контроля или элемент разметки"></div>';
            inner+='<div id="zones_control_point" class="zones_control_item_disable" title="Изменит положение точки"></div>';
            inner+='<div id="zones_control_arrow" class="zones_control_item" title="Задать направление движения в полосе"></div>';
            inner+='<div id="zones_control_combo" class="zones_control_item_combo_disable" title="Задать направления движения в полосе"></div>';
            inner+='<div id="zones_control_fix" class="zones_control_item_lock" title="Компенсировать изменения положения комплекса"></div>';
            inner+='<div id="zones_control_center" class="zones_control_item" title="Показать центр кадра"></div>';
            inner+='<div id="zones_control_remove" class="zones_control_item" title="Удалить выделенную зону контроля или элемент разметки"></div>';

            return inner;

        },

        'get_right_controls':function(is_revert){

            let inner='';
            if(is_undefined(is_revert)) is_revert=false;
            inner+='<div id="zones_control_zoom'+(is_revert?'_revert':'')+'" class="zones_control_item" title="Увеличить изображение"></div>';
            if(is_revert) inner+='<div id="zones_control_reset_image" class="zones_control_item" title="Обновить изображение с камеры"></div>';
            inner+='<div id="zones_control_save" class="zones_control_item кzones_control_save" title="Локальное сохранение слоя"></div>';
            inner+='<div id="zones_control_front" class="zones_control_item" title="Изменения вперед"></div>';
            inner+='<div id="zones_control_back" class="zones_control_item" title="Изменения назад"></div>';
            return inner;

        },
        'get_video_container':function(is_iframe,link){

            let inner='';

            if(is_undefined(is_iframe))
                is_iframe=false;

            inner+='<div id="zones_video_canvas_list" class="zones_video_canvas_list">';
                inner+='<div id="zones_video_center" class="zones_video_center"'+(page_object.action.admin.action.zones_content.action.zone.canvas.show_center.is_show?' style="display: block;"':'')+'></div>';
                inner+='<div id="zones_video_h_line" class="zones_video_h_line"'+(page_object.action.admin.action.zones_content.action.zone.canvas.show_center.is_show?' style="display: block;"':'')+'></div>';
                inner+='<div id="zones_video_v_line" class="zones_video_v_line"'+(page_object.action.admin.action.zones_content.action.zone.canvas.show_center.is_show?' style="display: block;"':'')+'></div>';
            inner+='</div>';

            inner+='<div id="zone_video_container_inner" class="zones_video_container">';

            if(is_iframe)
                inner+='<iframe id="zone_video_iframe" src="'+link+'" width="100%" style="border: none; outline: none; line-height: 0;"></iframe>';
            else
                inner+='<img id="zone_video_iframe" src="'+link+'" style="border: none; outline: none; line-height: 0;">';

            inner+='</div>';

            return inner;

        },
        'zones_content':function(){

            let  el
                ,data                   =page_object.action.admin.data['zones']
                ,camera_list            =data['camera_list']
                ,light_id               =data['light_id']
                ,light_list             =data['light_list']
                ,speed_max              =data['speed_max']
                ,speed_max_border       =data['speed_max_border']
                ,index
                ,is_active
                ,inner          =''
                ,style          ='';

            style+='opacity: 1;';

            switch(page_object.action.admin.data['action']){
                case'admin_zones':{
                    if(camera_list.length > 0)
                        inner+='<div id="zones_info" class="zones_info">Выберите камеру из списка</div>';
                    else
                        inner+='<div id="zones_info" class="zones_info">В системе нет камер</div>';
                    break;
                }
            }

            inner+='<div class="zones_block">';
                inner+='<div id="camera_menu_list">';
                for(index in camera_list){
                    if(count(page_object.link.link_list) === 4)
                        is_active=parseInt(page_object.link.link_list[3]) === parseInt(camera_list[index]['camera_id']);
                    else
                        is_active=false;
                    inner+='<div id="camera_menu_item_'+index+'" class="camera_menu_item'+(camera_list[index]['is_disable']?'_disable':(is_active?'_active':''))+'">'+stripSlashes(camera_list[index]['name'])+'</div>';
                }

                inner+='</div>';

                switch(page_object.action.admin.data['action']){

                    case'admin_zones_item':{

                        let camera_data=data['camera_data'];
                        inner+='<div id="zones_container">';
                            inner+='<div id="config_work_mask"'+(camera_data['camera_work_mode'] === 2?' style="display: block"':' style="display: none"')+'><span>Камера отключена</span></div>';
                            inner+='<div id="zone_row" class="zones_row">';
                                inner+='<div id="zones_row_left" class="zones_row_left">';
                                    inner+=page_object.action.admin.create.zones.create.get_left_menu();

                                inner+='</div>';
                                inner+='<div id="zones_row_center" class="zones_row_center">';
                                    inner+='<div class="zones_row_center_controls">';
                                        inner+='<div id="zones_row_center_controls_left" class="zones_row_center_controls_left">';
                                            inner+=page_object.action.admin.create.zones.create.get_left_controls();
                                        inner+='</div>';
                                        inner+='<div id="zones_row_center_controls_right" class="zones_row_center_controls_right">';
                                            inner+=page_object.action.admin.create.zones.create.get_right_controls();
                                        inner+='</div>';
                                    inner+='</div>';
                                    inner+='<div id="zones_video_container" class="zones_row_center_video"'+ (camera_data['camera_work_mode'] === 2 ? ' style="display: none"' : '') +'>';

                                        inner+=page_object.action.admin.create.zones.create.get_video_container(true,camera_data['video_link']);
                                        inner+='<div id="zones_video_center" class="zones_video_center"></div>';
                                    inner+='</div>';
                                inner+='</div>';
                                inner+='<div id="zones_row_right" class="zones_row_right">';
                                    inner+=page_object.action.admin.create.zones.create.get_right_menu();
                                inner+='</div>';
                            inner+='</div>';

                            inner+='<div class="zones_row" style="border: none;">';
                            inner+='<div id="zones_speed_block" class="zones_row_col" style="width: 100%">';
                                inner+='<div class="zones_row_item_container" style="margin: 0;">';
                                    inner+='<div class="zones_row_item_label" style="width: 185px;">Разрешенная скорость:</div>';
                                    inner+='<div class="zones_row_item_content" style="width: 83px; margin: 0 5px 0 0">';
                                        inner+='<input style=min-width:auto;max-width:70px type=number id="zones_speed_type" class="zones_input_number" min="0" max="240" value="'+(empty(speed_max)?'':speed_max)+'"/>';
                                    inner+='</div>';
                                    inner+='<div class="zones_row_item_label" style="width: 50px;">км/ч</div>';
                                    inner+='<div class="zones_row_item_label" style="width: 185px; margin: 0 0 0 40px;">Допустимая скорость:</div>';
                                    inner+='<div class="zones_row_item_content" style="width: 83px; margin: 0 5px 0 0">';
                                        inner+='<input style=min-width:auto;max-width:70px type=number id="zones_speed_max_type" class="zones_input_number" min="'+(empty(speed_max)?'0':speed_max)+'" max="300" value="'+(empty(speed_max_border)?'':speed_max_border)+'"/>';
                                    inner+='</div>';
                                    inner+='<div class="zones_row_item_label" style="width: 50px;">км/ч</div>';
                                inner+='</div>';
                            inner+='</div>';

                            inner+='<div id="zones_timer_block" class="zones_row_col" style="margin: 10px 0 0 0; width: 100%">';
                                inner+='<div id="zones_timer_block" class="zones_row_col" style="width: 400px">';
                                    inner+='<div class="zones_row_item_container" style="margin: 0;">';
                                        inner+='<div class="zones_row_item_label" style="width: 175px;">Применить светофор:</div>';
                                        inner+='<div class="zones_row_item_content" style="width: 222px;">';
                                            inner+='<select id="zones_traffic_lights" class="zones_input_number" style="pointer-events: none; opacity: 0.5; color: #999999;">';
                                                inner+='<option value="0">Нет светофора</option>';

                            for(index in light_list)
                                inner+='<option value="'+index+'"'+(parseInt(index) === parseInt(light_id)?' selected="selected"':'')+'>'+stripSlashes(light_list[index])+'</option>';

                                            inner+='</select>';
                                        inner+='</div>';
                                    inner+='</div>';
                                inner+='</div>';

                                inner+='<div class="zones_row_col" style="width: 375px; text-align: right; margin-bottom: 0; float: right;">';
                                    inner+='<div id="zones_cancel" class="zones_cancel">Отмена</div>';
                                    inner+='<div id="zones_save" class="zones_save">Применить параметры</div>';
                                inner+='</div>';
                            inner+='</div>';
                        inner+='</div>';
                        break;
                    }
                }

            inner+='</div>';

            el=addElement({
                'tag':'div',
                'id':'zones_content',
                'inner':inner,
                'style':style
            });

            $d('all').appendChild(el);
            return true;
        },
    },
    'set_action':function(){
        page_object.action.admin.action.zones_content.action.init();
        return true;
    },
    'show':function(){
        setTimeout(page_object.action.admin.action.zones_content.show, 40);
    }
};