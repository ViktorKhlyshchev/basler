page_object.action.admin.create.key={
    'init':function(){

        page_object.action.admin.create.key.position.init();
        page_object.action.admin.create.key.create.init();
        page_object.action.admin.create.key.set_action();
        page_object.action.admin.create.key.show();

    },
    'position':{
        'init':function(){

        }
    },
    'create':{
        'init':function(){

            switch(page_object.action.admin.data['action']){

                case 'admin_key':{

                    page_object.action.admin.create.key.create.key_content();

                    break;

                }

            }

        },
        'get_key_row':function(index){

            let  data =page_object.action.admin.data['data']
                ,timezone =data['timezone']
                ,key_list =data['key_list']
                ,ftp_data =key_list[index]
                ,inner ='';

            inner+='<div id="key_item_name_'+index+'" class="key_item_col" style="width: 500px;">';
                inner+='<span>'+stripSlashes(ftp_data['name'])+'</span>';
            inner+='</div>';

            inner+='<div id="key_item_use_'+index+'" class="key_item_col" style="width: 300px;">';
                inner+='<span>'+(ftp_data['ip_list'].length==0?'<i>Не используется</i>':stripSlashes(implode(', ',ftp_data['ip_list'])))+'</span>';
            inner+='</div>';

            inner+='<div id="key_item_date_create_'+index+'" class="key_item_col" style="width: 200px;">';
                inner+='<span>'+stripSlashes(get_date_time(ftp_data['date_create']-new Date().getTimezoneOffset()*60,timezone))+'</span>';
                // inner+='<span>'+stripSlashes(get_date_time(ftp_data['date_create']))+'</span>';
            inner+='</div>';

            inner+='<div id="key_item_controls_'+index+'" class="key_item_col" style="width: 150px;">';
                inner+='<span>';
                    inner+='<div id="key_item_edit_button_'+index+'" class="key_item_edit_button"></div>';
                    inner+='<div id="key_item_download_button_'+index+'" class="key_item_download_button"></div>';
                    inner+='<div id="key_item_remove_button_'+index+'" class="key_item_remove_button"></div>';
                inner+='</span>';
            inner+='</div>';

            return inner;

        },
        'key_content':function(){

            let  el
                ,data =page_object.action.admin.data['data']
                ,key_list =data['key_list']
                ,index
                ,inner =''
                ,style ='';

            style+='opacity: 1;';

            switch(page_object.action.admin.data['action']){

                case 'admin_key':{

                    inner+='<div id="key_info" class="key_info'+(key_list.length === 0?'':'_hide')+'">В системе нет данных</div>';

                    inner+='<div id="key_block" class="key_block">';

                        inner+='<div id="key_controls">';
                            inner+='<div id="key_add" style="opacity: 1;">Создать ключ</div>';
                        inner+='</div>';

                        inner+='<div id="key_container" class="key_container'+(key_list.length === 0?'_hide':'')+'">';

                            inner+='<div id="key_header" class="key_header">';

                                inner+='<div class="key_header_col" style="width: 500px;">';
                                    inner+='<div class="key_header_col_text">Название ключей</div>';
                                inner+='</div>';

                                inner+='<div class="key_header_col" style="width: 300px;">';
                                    inner+='<div class="key_header_col_text">Используется</div>';
                                inner+='</div>';

                                inner+='<div class="key_header_col" style="width: 200px;">';
                                    inner+='<div class="key_header_col_text">Дата создания</div>';
                                inner+='</div>';

                                inner+='<div class="key_header_col" style="width: 150px;">';

                                    inner+='<div class="key_header_col_text"></div>';

                                inner+='</div>';

                            inner+='</div>';

                            inner+='<div id="key_list" class="key_list">';

                            for(index in key_list){

                                inner+='<div id="key_item_'+index+'" class="key_item">';

                                    inner+=page_object.action.admin.create.key.create.get_key_row(index);

                                inner+='</div>';

                            }

                            inner+='</div>';

                        inner+='</div>';

                    inner+='</div>';

                    break;

                }

            }

            el=addElement({
                'tag':'div',
                'id':'key_content',
                'inner':inner,
                'style':style
            });

            $d('all').appendChild(el);

            return true;

        },
    },
    'set_action':function(){

        page_object.action.admin.action.key_content.action.init();

        return true;

    },
    'show':function(){

        setTimeout(page_object.action.admin.action.key_content.show,40);

    }
};
