// page_object.action.admin.action.admin_menu

cl = console.log; //cl(page_object.action.admin);

page_object.action.admin.create.admin_menu = {
    
    'init':function(){ //cl('page_object'); cl(page_object.action.admin); cl(page_object.action.admin.is_root()); cl(page_object.action.admin.is_admin()); cl(page_object);
        page_object.action.admin.create.admin_menu.create.menu();
        page_object.action.admin.create.admin_menu.set_action.init();
        page_object.action.admin.create.admin_menu.show.init();
    },

    'create':{
        'menu':function(){
            if(isset($d('admin_menu'))) return true;
            $('#all').append(lmenu);
            return true;
        }
    },
    'set_action':{
        'init':function(){ page_object.action.admin.action.admin_menu.init(); }
    },
    'show':{
        'init':function(){ page_object.action.admin.action.admin_menu.show(); }
    }
}; /// /home/alex/0git/aist.loc/Project/Aist/Admin/Template/Js/Admin/Resources/bootstrap_notify.min.js
