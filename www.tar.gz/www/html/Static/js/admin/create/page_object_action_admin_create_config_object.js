page_object.action.admin.create.config={
    'init':function(){

        page_object.action.admin.create.config.position.init();
        page_object.action.admin.create.config.create.init();
        page_object.action.admin.create.config.set_action();
        page_object.action.admin.create.config.show();

    },
    'position':{
        'init':function(){

        }
    },
    'create':{
        'init':function(){

            switch(page_object.action.admin.data['action']){

                case 'admin_config':
                case 'admin_config_item':{

                    page_object.action.admin.create.config.create.config_content();

                    break;

                }

            }

        },
        'config_content':function(){

            let  el
                ,data =page_object.action.admin.data['config']
                ,camera_list =data['camera_list']
                ,index
                ,is_active
                ,inner =''
                ,style ='';

            style+='opacity: 1;';

            switch(page_object.action.admin.data['action']){

                case 'admin_config':{

                    if(camera_list.length>0)
                        inner+='<div id="config_info" class="config_info">Выберите камеру из списка</div>';
                    else
                        inner+='<div id="config_info" class="config_info">В системе нет камер</div>';

                    break;

                }

            }

            inner+='<div class="config_block">';

                inner+='<div id="camera_menu_list">';

                for(index in camera_list){

                    if(count(page_object.link.link_list) === 4){

                        if(parseInt(page_object.link.link_list[3]) === parseInt(camera_list[index]['camera_id']))
                            is_active=true;
                        else
                            is_active=false;

                    }
                    else
                        is_active=false;

                    inner+='<div id="camera_menu_item_'+index+'" class="camera_menu_item'+(camera_list[index]['is_disable']?'_disable':(is_active?'_active':''))+'">'+stripSlashes(camera_list[index]['name'])+'</div>';

                }

                inner+='</div>';

                switch(page_object.action.admin.data['action']){

                    case 'admin_config_item':{

                        let camera_data=data['camera_data'];

                        inner+='<div id="config_container">';

                            inner+='<div id="config_work_mask"'+(camera_data['camera_work_mode'] === 2?' style="display: block"':' style="display: none"')+'><span>Камера отключена</span></div>';

                            inner+='<div class="config_row">';

                                inner+='<div class="config_row_col" style="width: 700px">';

                                    inner+='<div class="config_row_item" style="border-bottom: none; margin: 0;;">';

                                        inner+='<div class="config_row_item_container">';

                                            inner+='<div class="config_row_item_label">Режим работы</div>';
                                            inner+='<div class="config_row_item_content">';

                                                inner+='<div id="config_work_type" class="switch_block">';
                                                    inner+='<div id="config_work_auto" class="switch_item'+(camera_data['camera_work_mode'] === 0?'_active':'')+'">Авто</div>';
                                                    inner+='<div id="config_work_hand" class="switch_item'+(camera_data['camera_work_mode'] === 1?'_active':'')+'">Ручной</div>';
                                                inner+='</div>';

                                            inner+='</div>';

                                        inner+='</div>';

                                    inner+='</div>';

                                    inner+='<div id="config_camera_block" class="config_row_item'+(camera_data['camera_work_mode'] === 0?'_disable':'')+'">';

                                        inner+='<div class="config_row_item_container">';

                                            inner+='<div class="config_row_item_label">Фокус:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="0" max="'+stripSlashes(camera_data['focus_max'])+'" id="config_focus" class="config_input_number" value="'+stripSlashes(camera_data['focus'])+'" />';
                                            inner+='</div>';
                                            inner+='<div class="config_row_item_content_slash">/</div>';
                                            inner+='<div class="config_row_item_content_slash" style="padding-left: 0;">'+stripSlashes(camera_data['focus_max'])+'</div>';

                                        inner+='</div>';

                                        inner+='<div class="config_row_item_container">';

                                            inner+='<div class="config_row_item_label">Диафрагма:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="0" max="'+stripSlashes(camera_data['iris_max'])+'" id="config_iris" class="config_input_number" value="'+stripSlashes(camera_data['iris'])+'" />';
                                            inner+='</div>';
                                            inner+='<div class="config_row_item_content_slash">/</div>';
                                            inner+='<div class="config_row_item_content_slash" style="padding-left: 0;">'+stripSlashes(camera_data['iris_max'])+'</div>';

                                        inner+='</div>';

                                        inner+='<div class="config_row_item_container" style="display: none;">';

                                            inner+='<div class="config_row_item_label">Яркость:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="0" max="100" id="config_bright" class="config_input_number" value="'+stripSlashes(camera_data['bright'])+'" />';
                                            inner+='</div>';

                                        inner+='</div>';

                                        inner+='<div class="config_row_item_container">';

                                            inner+='<div class="config_row_item_label">Время экспозиции:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="29" max="'+stripSlashes(empty(camera_data['exposure_time_max'])?'0':camera_data['exposure_time_max'])+'" id="config_exposure" class="config_input_number" value="'+stripSlashes(empty(camera_data['exposure_time'])?'0':camera_data['exposure_time'])+'" />';
                                            inner+='</div>';
                                            inner+='<div class="config_row_item_content_slash">/</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="29" max="9999999" id="config_exposure_time_max" class="config_input_number" value="'+stripSlashes(empty(camera_data['exposure_time_max'])?'0':camera_data['exposure_time_max'])+'" />';
                                            inner+='</div>';

                                        inner+='</div>';

                                        inner+='<div class="config_row_item_container">';

                                            inner+='<div class="config_row_item_label">Gain:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="0.0" max="'+stripSlashes(empty(camera_data['gain_max'])?'0':camera_data['gain_max'])+'" step="0.1" id="config_gain" class="config_input_number" value="'+stripSlashes(empty(camera_data['gain'])?'0':camera_data['gain'])+'" />';
                                            inner+='</div>';
                                            inner+='<div class="config_row_item_content_slash"> / </div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="0.0" max="36.0" step="0.1" id="config_gain_max" class="config_input_number" value="'+stripSlashes(empty(camera_data['gain_max'])?'0':camera_data['gain_max'])+'" />';
                                            inner+='</div>';

                                        inner+='</div>';

                                        inner+='<div class="config_row_item_container">';

                                            inner+='<div class="config_row_item_label">Gamma:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="0.0" max="'+stripSlashes(empty(camera_data['gamma_min'])?'0':camera_data['gamma_min'])+'" step="0.00001" id="config_gamma" class="config_input_number" value="'+stripSlashes(empty(camera_data['gamma'])?'0':camera_data['gamma'])+'" />';
                                            inner+='</div>';
                                            inner+='<div class="config_row_item_content_slash">/</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="0.0" max="3.99998" step="0.00001" id="config_gamma_min" class="config_input_number" value="'+stripSlashes(empty(camera_data['gamma_min'])?'0':camera_data['gamma_min'])+'" />';
                                            inner+='</div>';

                                        inner+='</div>';

                                        inner+='<div class="config_row_item_container">';

                                            inner+='<div class="config_row_item_label">Digital Shift:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="0" max="4" id="config_digital_shift" class="config_input_number" value="'+stripSlashes(empty(camera_data['digital_shift'])?'0':camera_data['digital_shift'])+'" />';
                                            inner+='</div>';

                                        inner+='</div>';

                                        inner+='<div class="config_row_item_container">';

                                            inner+='<div class="config_row_item_label">Black Level:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="0.0" max="31.9" step="0.1" id="config_black_level" class="config_input_number" value="'+stripSlashes(empty(camera_data['black_level'])?'0':camera_data['black_level'])+'" />';
                                            inner+='</div>';

                                        inner+='</div>';

                                        inner+='<div class="config_row_item_container" style="margin-bottom: 5px;">';

                                            inner+='<div class="config_row_item_label">';
                                                inner+='<div id="config_save_test" class="config_save" style="margin-left: 0;">Тестировать параметры</div>';
                                            inner+='</div>';

                                        inner+='</div>';

                                    inner+='</div>';

                                    inner+='<div id="config_light_block" class="config_row_item">';

                                        inner+='<div class="config_row_item_container">';

                                            inner+='<div class="config_row_item_label">Текущая яркость кадра:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="0" id="config_current_light" class="config_input_number_disable" value="'+stripSlashes(camera_data['current_light'])+'" />';
                                            inner+='</div>';

                                        inner+='</div>';

                                        inner+='<div class="config_row_item_container">';

                                            inner+='<div class="config_row_item_label">Поддерживать яркость днем:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="0" id="config_target_light_day" class="config_input_number" value="'+stripSlashes(camera_data['target_light_day'])+'" />';
                                            inner+='</div>';

                                        inner+='</div>';

                                        inner+='<div class="config_row_item_container">';

                                            inner+='<div class="config_row_item_label">Поддерживать яркость ночью:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="0" id="config_target_light_night" class="config_input_number" value="'+stripSlashes(camera_data['target_light_night'])+'" />';
                                            inner+='</div>';

                                        inner+='</div>';

                                    inner+='</div>';

                                    inner+='<div id="config_ir_block" class="config_row_item'+(camera_data['camera_work_mode'] === 0?'_disable':'')+'">';

                                        inner+='<div class="config_row_item_container'+(camera_data['ir_mode'] === -1?'_disable':'')+'">';

                                            inner+='<div class="config_row_item_label">Инфракрасная подсветка:</div>';
                                            inner+='<div class="config_row_item_content">';

                                                inner+='<div id="config_ir" class="switch_block">';
                                                    inner+='<div id="config_ir_auto" class="switch_item'+(camera_data['ir_mode'] === 0?'_active':'')+'">Авто</div>';
                                                    inner+='<div id="config_ir_hand" class="switch_item'+(camera_data['ir_mode'] === 1?'_active':'')+'">Включена</div>';
                                                    inner+='<div id="config_ir_off" class="switch_item'+(camera_data['ir_mode'] === 2?'_active':'')+'">Выключена</div>';
                                                inner+='</div>';

                                            inner+='</div>';

                                        inner+='</div>';

                                        inner+='<div id="ir_min" class="config_row_item_container'+(camera_data['ir_mode'] === -1?'_disable':'')+'">';

                                            inner+='<div class="config_row_item_label">Включить при освещенности ниже:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="0" max="100000" id="config_ir_min" class="config_input_number" value="'+stripSlashes(camera_data['ir_min'])+'" />';
                                            inner+='</div>';

                                        inner+='</div>';

                                        inner+='<div id="ir_max" class="config_row_item_container'+(camera_data['ir_mode'] === -1?'_disable':'')+'">';

                                            inner+='<div class="config_row_item_label">Выключить при освещенности выше:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="0" max="100000" id="config_ir_max" class="config_input_number" value="'+stripSlashes(camera_data['ir_max'])+'" />';
                                            inner+='</div>';

                                        inner+='</div>';

                                        inner+='<div id="light_sensor" class="config_row_item_container">';

                                            inner+='<div class="config_row_item_label">Освещенность:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" id="config_light_sensor" class="config_input_number_disable" value="'+stripSlashes(empty(camera_data['light_sensor'])?'0':camera_data['light_sensor'])+'" />';
                                            inner+='</div>';

                                        inner+='</div>';

                                    inner+='</div>';

                                    inner+='<div id="config_gen_block" class="config_row_item'+(camera_data['camera_work_mode'] === 0?'_disable':'')+'">';

                                        inner+='<div class="config_row_item_container'+(camera_data['gen_mode'] === -1?'_disable':'')+'">';

                                            inner+='<div class="config_row_item_label">Генерация кадров:</div>';
                                            inner+='<div class="config_row_item_content">';

                                                inner+='<div id="config_gen" class="switch_block">';
                                                    inner+='<div id="config_gen_auto" class="switch_item'+(camera_data['gen_mode'] === 0?'_active':'')+'">Авто</div>';
                                                    // inner+='<div id="config_gen_hand" class="switch_item'+(camera_data['gen_mode'] === 1?'_active':'')+'">Включена</div>';
                                                    inner+='<div id="config_gen_off" class="switch_item'+(camera_data['gen_mode'] === 2?'_active':'')+'">Выключена</div>';
                                                inner+='</div>';

                                            inner+='</div>';

                                        inner+='</div>';

                                        inner+='<div id="gen_period_block" class="config_row_item_container'+(camera_data['gen_mode'] === -1?'_disable':'')+'">';

                                            inner+='<div class="config_row_item_label">Период, мкс:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="20000" max="2000000000" id="config_gen_period" class="config_input_number" value="'+stripSlashes(empty(camera_data['gen_period'])?'0':camera_data['gen_period'])+'" />';
                                            inner+='</div>';

                                        inner+='</div>';

                                        inner+='<div id="gen_cam_delay_block" class="config_row_item_container'+(camera_data['gen_mode'] === -1?'_disable':'')+'">';

                                            inner+='<div class="config_row_item_label">Задержка импульса камеры, мкс:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="0" max="'+stripSlashes(empty(camera_data['gen_period'])?'0':camera_data['gen_period'])+'" id="config_gen_cam_delay" class="config_input_number" value="'+stripSlashes(empty(camera_data['gen_cam_delay'])?'0':camera_data['gen_cam_delay'])+'" />';
                                            inner+='</div>';

                                        inner+='</div>';

                                        inner+='<div id="gen_light_delay_block" class="config_row_item_container'+(camera_data['gen_mode'] === -1?'_disable':'')+'">';

                                            inner+='<div class="config_row_item_label">Задержка импульса подсветки, мкс:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="0" max="'+stripSlashes(empty(camera_data['gen_period'])?'0':camera_data['gen_period'])+'" id="config_gen_light_delay" class="config_input_number" value="'+stripSlashes(empty(camera_data['gen_light_delay'])?'0':camera_data['gen_light_delay'])+'" />';
                                            inner+='</div>';

                                        inner+='</div>';

                                        inner+='<div id="gen_light_time_block" class="config_row_item_container'+(camera_data['gen_mode'] === -1?'_disable':'')+'">';

                                            inner+='<div class="config_row_item_label">Время подсветки, мкс:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="100" max="1000" id="config_gen_light_time" class="config_input_number" value="'+stripSlashes(empty(camera_data['gen_light_time'])?'0':camera_data['gen_light_time'])+'" />';
                                            inner+='</div>';

                                        inner+='</div>';

                                    inner+='</div>';

                                    inner+='<div id="config_heater_block" class="config_row_item'+(camera_data['camera_work_mode'] === 0?'_disable':'')+'">';

                                        inner+='<div class="config_row_item_container'+(camera_data['heater_mode'] === -1?'_disable':'')+'">';

                                            inner+='<div class="config_row_item_label">Нагреватель:</div>';
                                            inner+='<div class="config_row_item_content">';

                                                inner+='<div id="config_heater" class="switch_block">';
                                                    inner+='<div id="config_heater_auto" class="switch_item'+(camera_data['heater_mode'] === 0?'_active':'')+'">Авто</div>';
                                                    inner+='<div id="config_heater_hand" class="switch_item'+(camera_data['heater_mode'] === 1?'_active':'')+'">Включен</div>';
                                                    inner+='<div id="config_heater_off" class="switch_item'+(camera_data['heater_mode'] === 2?'_active':'')+'">Выключен</div>';
                                                inner+='</div>';

                                            inner+='</div>';

                                        inner+='</div>';

                                        inner+='<div id="heater_min_block" class="config_row_item_container'+(camera_data['heater_mode'] === -1?'_disable':'')+'">';

                                            inner+='<div class="config_row_item_label">Включать при, °С:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="-100" max="100" id="config_heater_min" class="config_input_number" value="'+stripSlashes(empty(camera_data['heater_min'])?'0':camera_data['heater_min'])+'" />';
                                            inner+='</div>';

                                        inner+='</div>';

                                        inner+='<div id="heater_max_block" class="config_row_item_container'+(camera_data['heater_mode'] === -1?'_disable':'')+'">';

                                            inner+='<div class="config_row_item_label">Выключать при, °С:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="-100" max="100" id="config_heater_max" class="config_input_number" value="'+stripSlashes(empty(camera_data['heater_max'])?'0':camera_data['heater_max'])+'" />';
                                            inner+='</div>';

                                        inner+='</div>';

                                    inner+='</div>';

                                    inner+='<div id="config_cooler_block"  class="config_row_item'+(camera_data['camera_work_mode'] === 0?'_disable':'')+'">';

                                        inner+='<div class="config_row_item_container'+(camera_data['cooler_mode'] === -1?'_disable':'')+'">';

                                            inner+='<div class="config_row_item_label">Охладитель:</div>';
                                            inner+='<div class="config_row_item_content">';

                                                inner+='<div id="config_cooler" class="switch_block">';
                                                    inner+='<div id="config_cooler_auto" class="switch_item'+(camera_data['cooler_mode'] === 0?'_active':'')+'">Авто</div>';
                                                    inner+='<div id="config_cooler_hand" class="switch_item'+(camera_data['cooler_mode'] === 1?'_active':'')+'">Включен</div>';
                                                    inner+='<div id="config_cooler_off" class="switch_item'+(camera_data['cooler_mode'] === 2?'_active':'')+'">Выключен</div>';
                                                inner+='</div>';

                                            inner+='</div>';

                                        inner+='</div>';

                                        inner+='<div id="cooler_min_block" class="config_row_item_container'+(camera_data['cooler_mode'] === -1?'_disable':'')+'">';

                                            inner+='<div class="config_row_item_label">Включать при, °С:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="-100" max="100" id="config_cooler_min" class="config_input_number" value="'+stripSlashes(empty(camera_data['cooler_min'])?'0':camera_data['cooler_min'])+'" />';
                                            inner+='</div>';

                                        inner+='</div>';

                                        inner+='<div id="cooler_max_block" class="config_row_item_container'+(camera_data['cooler_mode'] === -1?'_disable':'')+'">';

                                            inner+='<div class="config_row_item_label">Выключать при, °С:</div>';
                                            inner+='<div class="config_row_item_content">';
                                                inner+='<input type="number" min="-100" max="100" id="config_cooler_max" class="config_input_number" value="'+stripSlashes(empty(camera_data['cooler_max'])?'0':camera_data['cooler_max'])+'" />';
                                            inner+='</div>';

                                        inner+='</div>';

                                    inner+='</div>';

                                    inner+='<div id="config_glass_heater_block" class="config_row_item'+(camera_data['camera_work_mode'] === 0?'_disable':'')+'">';

                                        inner+='<div class="config_row_item_container'+(camera_data['glass_heater_mode'] === -1?'_disable':'')+'">';

                                            inner+='<div class="config_row_item_label">Подогрев стекла:</div>';
                                            inner+='<div class="config_row_item_content">';

                                                inner+='<div id="config_glass_heater" class="switch_block">';
                                                    inner+='<div id="config_glass_heater_auto" class="switch_item'+(camera_data['glass_heater_mode'] === 0?'_active':'')+'">Авто</div>';
                                                    inner+='<div id="config_glass_heater_hand" class="switch_item'+(camera_data['glass_heater_mode'] === 1?'_active':'')+'">Включен</div>';
                                                inner+='</div>';

                                            inner+='</div>';

                                        inner+='</div>';

                                    inner+='</div>';

                                    inner+='<div id="config_brush_block" class="config_row_item'+(camera_data['camera_work_mode'] === 0?'_disable':'')+'" style="border: none;">';

                                        inner+='<div class="config_row_item_container'+(camera_data['brush_mode'] === -1?'_disable':'')+'" style="margin: 0;">';

                                            inner+='<div class="config_row_item_label">Щетка:</div>';
                                            inner+='<div id="config_brush" class="switch_block">';
                                                inner+='<div id="config_brush_auto" class="switch_item'+(camera_data['brush_mode'] === 0?'_active':'')+'">Авто</div>';
                                                inner+='<div id="config_brush_on" class="switch_item'+(camera_data['brush_mode'] === 1?'_active':'')+'">Включить сейчас</div>';
                                            inner+='</div>';

                                        inner+='</div>';

                                    inner+='</div>';

                                inner+='</div>';

                                inner+='<div class="config_row_col"'+(camera_data['camera_work_mode'] === 2?' style="display: none"':' style="width: 410px;"')+'>';

                                    inner+='<div id="config_video_container" class="config_video_container">';

                                        // inner+='<iframe id="config_video_iframe" src="'+camera_data['video_link']+'" onload="page_object.action.admin.action.config_content.action.iframe.loaded()"></iframe>';
                                        inner+='<iframe id="config_video_iframe" src="'+camera_data['video_link']+'" width="100%" style="border: none; outline: none; line-height: 0;"></iframe>';
                                        // inner+='<iframe id="config_video_iframe" src="http://188.243.174.207:2020/admin/root/video_config" width="100%" style="border: none; outline: none; line-height: 0;"></iframe>';

                                        // inner+='<img src="'+camera_data['video_link']+'" width="100%" />';
                                        // inner+='<video controls><source src="'+camera_data['video_link']+'" type="video/mp4"></video>';

                                    inner+='</div>';

                                    inner+='<div class="config_row_item" style="border: none;">';

                                        inner+='<div id="config_video_shot" class="config_video_shot"><span>Сделать снимок с камеры</span></div>';

                                    inner+='</div>';

                                inner+='</div>';

                            inner+='</div>';

                            inner+='<div class="config_row" style="border: none;">';

                                inner+='<div id="config_timer_block" class="config_row_col'+(camera_data['camera_work_mode'] === 0?'_disable':'')+'" style="width: 660px">';

                                    inner+='<div class="config_row_item_container" style="margin: 0;">';

                                        inner+='<div class="config_row_item_label" style="width: 390px;">Верунться в автоматический режим через:</div>';
                                        inner+='<div class="config_row_item_content" style="width: 270px;">';

                                            inner+='<input type="number" min="0" max="3600" id="config_back_to_auto" class="config_input_number" value="300" style="width: 100px; margin-right: 10px;" />';

                                            inner+='<select id="config_back_to_auto_type" class="config_input_number">';
                                                inner+='<option value="1"'+(camera_data['back_to_auto_type'] === 1?' selected="selected"':'')+'>Сек.</option>';
                                                inner+='<option value="2"'+(camera_data['back_to_auto_type'] === 2?' selected="selected"':'')+'>Мин.</option>';
                                                inner+='<option value="3"'+(camera_data['back_to_auto_type'] === 3?' selected="selected"':'')+'>Час.</option>';
                                            inner+='</select>';

                                        inner+='</div>';

                                    inner+='</div>';

                                inner+='</div>';

                                inner+='<div class="config_row_col" style="width: 458px; text-align: right; margin-bottom: 0;">';

                                    inner+='<div id="config_cancel" class="config_cancel">Отмена</div>';
                                    inner+='<div id="config_save" class="config_save">Применить параметры</div>';
                                    inner+='<div id="config_update" class="config_update">Сохранить</div>';

                                inner+='</div>';

                            inner+='</div>';

                        inner+='</div>';

                        break;

                    }

                }

            inner+='</div>';

            el=addElement({
                'tag':'div',
                'id':'config_content',
                'inner':inner,
                'style':style
            });

            $d('all').appendChild(el);

            return true;

        },
    },
    'set_action':function(){

        page_object.action.admin.action.config_content.action.init();

        return true;

    },
    'show':function(){

        setTimeout(page_object.action.admin.action.config_content.show,40);

    }
};
