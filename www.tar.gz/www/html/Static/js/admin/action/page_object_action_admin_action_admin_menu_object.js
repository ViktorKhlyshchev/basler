cl = console.log;

// page_object.action.admin.create.admin_menu
page_object.action.admin.action.admin_menu = {
    'show':function(){
        if(isset($d('admin_menu'))){
            $s('admin_menu').opacity = 1;
            $s('admin_menu').transform = 'translate(0, 0)';
        }
    },
    'un_show':function(is_remove){
        if(isset($d('admin_menu'))){
            $s('admin_menu').opacity = 0;
            $s('admin_menu').transform = 'translateX(-100%, 0)';
            setTimeout(function(){
                if(is_remove)
                    if(isset($d('admin_menu')))
                        removeElement($d('admin_menu'));
            }, 300);
        }
    },
    'init':function(){
        page_object.action.admin.action.admin_menu.action.init();
    },
    'action':{
        'init':function(){
            page_object.action.admin.action.admin_menu.action.set_class_to_default(page_object.link.link_list[2]);
            if(isset($d('admin_menu'))){
                let  list = $d('admin_menu').getElementsByTagName('a')
                    , index;
                for(index in list)
                    if(isObject(list[index]))
                        switch(list[index].getAttribute('class')){
                            case 'menu_item':{
                                list[index].onclick = page_object.action.admin.action.admin_menu.action.click;
                                //key = list[index].id.split('_')[2];
                                //link = '/admin/'+page_object.action.admin.data['user']['login']+'/'+key;
                                break;
                            }
                            default:{
                                list[index].onclick = function(){};
                                break;
                            }
                        }
            }
        },
        'click': function(key){
            if(!isString(key)) key = this.id.split('_')[2]; //            cl('key');
            let lang_obj = page_object.content[page_object.lang], link = '/admin/'+page_object.action.admin.data['user']['login']+'/'+key;
            page_object.action.admin.action.admin_menu.action.set_class_to_default(key);
            setUrl(lang_obj['title']+' | '+lang_obj['loading'], link);
            return false;
        },
        'set_class_to_default':function(key){
            let  list = $d('admin_menu').getElementsByTagName('a'), index;
            for(index in list)
                if(isObject(list[index])){
                    if(list[index].id.split('_')[2] === key || list[index].getAttribute('class') === 'menu_item_disable'){
                        if(list[index].getAttribute('class') !== 'menu_item_disable') list[index].setAttribute('class', 'menu_item_active');
                        list[index].onclick = function(){};
                    } else {
                        $(list[index]).addClass('menu_item').removeClass('menu_item_active');
                        list[index].onclick = page_object.action.admin.action.admin_menu.action.click;
                    }
                }
        }
    }
};