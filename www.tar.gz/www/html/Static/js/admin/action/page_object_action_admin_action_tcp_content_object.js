cl = console.log;

page_object.action.admin.action.tcp_content={
    'show':function(){
        if(isset($d('tcp_content'))) $s('tcp_content').opacity=1;
        page_object.action.admin.action.tcp_content.action.init();
        page_object.action.admin.action.tcp_content.action.window.init();
        setTimeout(page_object.link.preload.un_show,300);
    },
    'un_show':function(remove){
        if(isset($d('tcp_content'))) $s('tcp_content').opacity=0;
        if(isset(remove))
            if(remove)
                setTimeout(page_object.action.admin.action.tcp_content.remove,300);
    },
    'action':{
        'init':function(){

            let data = page_object.action.admin.data['data']['data'];
            cl(isset(data.error));
            if(isset(data.error)) return;

            page_object.action.admin.action.tcp_content.action.tcp.init();
            page_object.action.admin.action.tcp_content.action.tcp_menu.init();
            page_object.action.admin.action.tcp_content.action.ip.init();
            page_object.action.admin.action.tcp_content.action.route.init();
            page_object.action.admin.action.tcp_content.action.dns.init();
            page_object.action.admin.action.tcp_content.action.mode.init();
            page_object.action.admin.action.tcp_content.action.buttons.init();
            page_object.action.admin.action.tcp_content.action.status.init();
        },
        'buttons':{
            'data':null,
            'is_edit':false,
            'init':function(){
                page_object.action.admin.action.tcp_content.action.buttons.reset();
                page_object.action.admin.action.tcp_content.action.buttons.set_action();
            },
            'error_border':{
                'timeout':1000,
                'timeout_event':null,
                'init':function(el,need_timeout){
                    if(need_timeout === undefined)
                        need_timeout=true;
                    page_object.action.admin.action.tcp_content.action.buttons.error_border.reset();
                    if(isset(el)){
                        el.style.border='1px solid #ff0000';
                        if(need_timeout)
                            page_object.action.admin.action.tcp_content.action.buttons.error_border.timeout_event=setTimeout(function(){
                                page_object.action.admin.action.tcp_content.action.buttons.error_border.reset();
                                page_object.action.admin.action.tcp_content.action.buttons.none_border.init(el);
                            },page_object.action.admin.action.tcp_content.action.buttons.error_border.timeout);
                    }
                },
                'reset':function(){
                    if(!empty(page_object.action.admin.action.tcp_content.action.buttons.error_border.timeout_event))
                        clearTimeout(page_object.action.admin.action.tcp_content.action.buttons.error_border.timeout_event);
                }
            },
            'none_border':{
                'init':function(el){
                    page_object.action.admin.action.tcp_content.action.buttons.error_border.reset();
                    if(isset(el))
                        el.style.border='';
                }
            },
            'valid_border':{
                'init':function(el){
                    page_object.action.admin.action.tcp_content.action.buttons.error_border.reset();
                    if(isset(el))
                        if(!empty(el.value))
                            el.style.border='1px solid #15a845';
                }
            },
            'keydown':function(e){
                e=window.event || e;
                // let  val =getCharFromEventKey(e)
                let  val =e.key
                    ,pattern
                    ,key =e.keyCode;
                console.log(e.keyCode+' || '+e.key);
                switch(key){
                    case 8:
                    case 9:
                    case 16:
                    case 17:
                    case 35:
                    case 36:
                    case 37:
                    case 38:
                    case 39:
                    case 40:
                    case 46:
                    case 86:
                    case 96:
                    case 97:
                    case 98:
                    case 99:
                    case 100:
                    case 101:
                    case 102:
                    case 103:
                    case 104:
                    case 105:
                        return true;
                }
                page_object.action.admin.action.tcp_content.action.buttons.none_border.init(this);
                switch(this.id){
                    case 'tcp_name':{
                        pattern=/[\w\d]/is;
                        if(pattern.test(val))
                            page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                        else {
                            page_object.action.admin.action.tcp_content.action.buttons.error_border.init(this);
                            e.preventDefault();
                            return false;
                        }
                        break;
                    }
                    case 'tcp_user_mac_address':{
                        pattern=/[a-fA-F:\-.]/is;
                        if(pattern.test(val) || key === 186 // : || key === 59 // : || key === 189 // - || key === 190 // .
                        )
                            page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                        else {
                            page_object.action.admin.action.tcp_content.action.buttons.error_border.init(this);
                            e.preventDefault();
                            return false;
                        }
                        break;
                    }
                    case 'tcp_ipv6_gateway':{
                        pattern=/[0-9A-Fa-f:]/is;
                        if(pattern.test(val)
                            // || key === 186 // :
                            // || key === 59 // :
                        )
                            page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                        else {
                            page_object.action.admin.action.tcp_content.action.buttons.error_border.init(this);
                            e.preventDefault();
                            return false;
                        }
                        break;
                    }
                    case 'tcp_ipv4_gateway':{
                        pattern=/[0-9.]/is;
                        if(pattern.test(val)
                            // || key === 190 // .
                        )
                            page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                        else {
                            page_object.action.admin.action.tcp_content.action.buttons.error_border.init(this);
                            e.preventDefault();
                            return false;
                        }
                        break;
                    }
                    case 'tcp_gsm_network':{
                        pattern=/[0-9.]/is;
                        if(pattern.test(val)
                            // || key === 190 // .
                            // || key === 191 // /
                        )
                            page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                        else {
                            page_object.action.admin.action.tcp_content.action.buttons.error_border.init(this);
                            e.preventDefault();
                            return false;
                        }
                        break;
                    }
                    default:{
                        let class_name = this.getAttribute('class');
                        switch(class_name){
                            case 'tcp_input_ipv4':{
                                pattern=/[\d.]/is;
                                if(pattern.test(val)
                                    // || key === 190 // .
                                )
                                    page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                                else {
                                    page_object.action.admin.action.tcp_content.action.buttons.error_border.init(this);
                                    e.preventDefault();
                                    return false;
                                }
                                break;
                            }
                            case 'tcp_input_ipv6':{
                                cl(321);
                                pattern=/[0-9A-Fa-f:]/is;
                                if(pattern.test(val)
                                    // || key === 186 // :
                                    // || key === 59 // :
                                ){ cl(1321);
                                    page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                                    er('/[0-9A-Fa-f:]/is');
                                } else { cl(44321);
                                    page_object.action.admin.action.tcp_content.action.buttons.error_border.init(this);
                                    er('/[0-9A-Fa-f:]/is');
                                    e.preventDefault();
                                    return false;
                                }
                                break;
                            }
                            case 'tcp_input_mask_ipv4':{
                                pattern=/[\d.]/is;
                                if(pattern.test(val)
                                    // || key === 190 // .
                                )
                                    page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                                else { 
                                    page_object.action.admin.action.tcp_content.action.buttons.error_border.init(this);
                                    e.preventDefault();
                                    return false;
                                }
                                break;
                            }
                            case 'tcp_input_mask_ipv6':{
                                cl(333312345);
                                pattern=/[\d]/is;
                                if(pattern.test(val))
                                    page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                                else { cl(9999999999);
                                    page_object.action.admin.action.tcp_content.action.buttons.error_border.init(this);
                                    e.preventDefault();
                                    return false;
                                }
                                break;
                            }
                            case 'tcp_input_dns':{
                                cl(119999999999);
                                let pattern = /[\d.:]/is; //cl(119999999999);          
                                if(pattern.test(val)
                                    // || key === 190 // .
                                ){ cl(12345);
                                    page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                                } else {
                                    cl(987);
                                    page_object.action.admin.action.tcp_content.action.buttons.error_border.init(this);
                                    e.preventDefault();
                                    return false;
                                }
                                break;
                            }
                            case 'tcp_input_order_route':{
                                pattern=/[\d+-]/is;
                                if(pattern.test(val)
                                )
                                    page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                                else {
                                    page_object.action.admin.action.tcp_content.action.buttons.error_border.init(this);
                                    e.preventDefault();
                                    return false;
                                }
                                break;
                            }
                            default:{
                                page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                                break;
                            }
                        }
                        break;
                    }
                }
                return true;
            },
            'keyup':function(){
                var  val=this.value
                    ,pattern;
                switch(this.id){
                    case 'tcp_name':{
                        pattern=/[\w*\d*]/is;
                        if(empty(val))
                            page_object.action.admin.action.tcp_content.action.buttons.none_border.init(this);
                        else if(pattern.test(val))
                            page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                        else
                            page_object.action.admin.action.tcp_content.action.buttons.error_border.init(this,false);
                        break;
                    }
                    case 'tcp_user_mac_address':{
                        if(empty(val))
                            page_object.action.admin.action.tcp_content.action.buttons.none_border.init(this);
                        else if(is_mac_address(val))
                            page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                        else
                            page_object.action.admin.action.tcp_content.action.buttons.error_border.init(this,false);
                        break;
                    }
                    case 'tcp_ipv4_gateway':{
                        if(empty(val))
                            page_object.action.admin.action.tcp_content.action.buttons.none_border.init(this);
                        else if(is_ipv4_address(val))
                            page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                        else
                            page_object.action.admin.action.tcp_content.action.buttons.error_border.init(this,false);
                        break;
                    }
                    case 'tcp_ipv6_gateway':{
                        if(empty(val))
                            page_object.action.admin.action.tcp_content.action.buttons.none_border.init(this);
                        else if(is_ipv6_address(val))
                            page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                        else
                            page_object.action.admin.action.tcp_content.action.buttons.error_border.init(this,false);
                        break;
                    }
                    default:{
                        let class_name=this.getAttribute('class');
                        switch(class_name){
                            case 'tcp_input_route':
                            case 'tcp_input_ipv4':{
                                if(empty(val))
                                    page_object.action.admin.action.tcp_content.action.buttons.none_border.init(this);
                                else if(is_ipv4_address(val) || is_ipv6_address(val))
                                    page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                                else
                                    page_object.action.admin.action.tcp_content.action.buttons.error_border.init(this,false);
                                break;
                            }
                            case 'tcp_input_ipv6':{
                                if(empty(val))
                                    page_object.action.admin.action.tcp_content.action.buttons.none_border.init(this);
                                else if(is_ipv6_address(val))
                                    page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                                else
                                    page_object.action.admin.action.tcp_content.action.buttons.error_border.init(this,false);
                                break;
                            }
                            case 'tcp_input_mask_ipv4':{
                                if(empty(val))
                                    page_object.action.admin.action.tcp_content.action.buttons.none_border.init(this);
                                else if(is_ipv4_address(val) || isNumber(val))
                                    page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                                else
                                    page_object.action.admin.action.tcp_content.action.buttons.error_border.init(this,false);
                                break;
                            }
                            case 'tcp_input_mask_ipv6':{
                                if(empty(val))
                                    page_object.action.admin.action.tcp_content.action.buttons.none_border.init(this);
                                else if(isNumber(val))
                                    page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                                else
                                    page_object.action.admin.action.tcp_content.action.buttons.error_border.init(this,false);
                                break;
                            }
                            case 'tcp_input_dns':{ cl('tcp_input_dns');
                                if(empty(val))
                                    page_object.action.admin.action.tcp_content.action.buttons.none_border.init(this);
                                else if(is_ipv4_address(val) || is_ipv6_address(val))
                                    page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                                else
                                    page_object.action.admin.action.tcp_content.action.buttons.error_border.init(this,false);
                                break;
                            }
                            default:{
                                page_object.action.admin.action.tcp_content.action.buttons.valid_border.init(this);
                                break;
                            }
                        }
                        break;
                    }
                }
                page_object.action.admin.action.tcp_content.action.buttons.is_edit=true;
                page_object.action.admin.action.tcp_content.action.buttons.set_action();
            },
            'set_action':function(){
                if(isset($d('tcp_cancel'))){
                    if(page_object.action.admin.action.tcp_content.action.buttons.is_edit){
                        $d('tcp_cancel').setAttribute('class','tcp_cancel');
                        $d('tcp_cancel').onclick=page_object.action.admin.action.tcp_content.action.cancel.init;
                    }
                    else {
                        $d('tcp_cancel').setAttribute('class','tcp_cancel_disable');
                        $d('tcp_cancel').onclick=function(){};
                    }
                }
                if(isset($d('tcp_save'))){
                    if(page_object.action.admin.action.tcp_content.action.buttons.is_edit){
                        $d('tcp_save').setAttribute('class','tcp_save');
                        $d('tcp_save').onclick=page_object.action.admin.action.tcp_content.action.save.init;
                    }
                    else {
                        $d('tcp_save').setAttribute('class','tcp_save_disable');
                        $d('tcp_save').onclick=function(){};
                    }
                }
            },
            'reset':function(){
                page_object.action.admin.action.tcp_content.action.buttons.data =null;
                page_object.action.admin.action.tcp_content.action.buttons.is_edit =false;
            },
        },
        'tcp_menu':{
            'init':function(){
                let  data =page_object.action.admin.data['data']
                    ,menu_list =data['menu_list']
                    ,index;
                for(index in menu_list)
                    if(isset($d('tcp_menu_item_'+index)))
                        $d('tcp_menu_item_'+index).onclick=page_object.action.admin.action.tcp_content.action.tcp_menu.click;
            },
            'click':function(){
                let  data =page_object.action.admin.data['data']
                    ,menu_list =data['menu_list']
                    ,index =parseInt(this.id.split('_')[3])
                    ,lang_obj =page_object.content[page_object.lang]
                    ,link ='/admin/'+page_object.action.admin.data['user']['login']+'/tcp/'+menu_list[index]['connect_name'];
                page_object.action.admin.action.tcp_content.action.tcp_menu.set_active(index);
                setUrl(lang_obj['title']+' | '+lang_obj['loading'],link);
            },
            'set_active':function(i){
                let  data =page_object.action.admin.data['data']
                    ,menu_list =data['menu_list']
                    ,index;
                for(index in menu_list)
                    if(parseInt(i) === parseInt(index)){
                        $d('tcp_menu_item_'+index).setAttribute('class','tcp_menu_item_active');
                        $d('tcp_menu_item_'+index).onclick=function(){};
                    }
                    else {
                        $d('tcp_menu_item_'+index).setAttribute('class','tcp_menu_item');
                        $d('tcp_menu_item_'+index).onclick=page_object.action.admin.action.tcp_content.action.tcp_menu.click;
                    }
            }
        },
        'error':{
            'init':function(data){
                if(isset($d('tcp_work_mask'))){
                    $s('tcp_work_mask').display ='block';
                    $d('tcp_work_mask').innerHTML ='<span style="color: #ff0000;">Ошибка получения данных</span>'
                }
            }
        },
        'load':{
            'show':function(){
                if(isset($d('tcp_work_mask'))){
                    $s('tcp_work_mask').display ='block';
                    $d('tcp_work_mask').innerHTML ='<span>Загрузка...</span>';
                }
            },
            'un_show':function(){
                if(isset($d('tcp_work_mask'))){
                    $s('tcp_work_mask').display ='none';
                    $d('tcp_work_mask').innerHTML ='<span>Загрузка...</span>';
                }
            }
        },
        'update':{
            'init':function(){
                alert('coming soon');
            }
        },
        'save':{
            'init':function(){
                switch(this.id){
                    case 'tcp_save':{
                        page_object.action.admin.action.tcp_content.action.save.send(false);
                        break;
                    }
                    case 'tcp_update':{
                        page_object.action.admin.action.tcp_content.action.save.send(true);
                        break;
                    }
                    case 'tcp_save_test':{
                        page_object.action.admin.action.tcp_content.action.save.send_test();
                        break;
                    }
                }
            },
            'send':function(is_save){
                let  el_list
                    ,index
                    ,pattern
                    ,val
                    ,is_error =false;
                if(isset($d('tcp_name'))){
                    pattern=/^[a-zA-Z0-9\-]+$/is;
                    if(pattern.test($v('tcp_name'))){
                        page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_name'));
                    }
                    else {
                        is_error=true;
                        page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_name'),false);
                    }
                }
                if(isset($d('tcp_user_mac_address'))){
                    if(empty($v('tcp_user_mac_address'))){
                        page_object.action.admin.action.tcp_content.action.buttons.none_border.init($d('tcp_user_mac_address'));
                    }
                    else if(is_mac_address($v('tcp_user_mac_address'))){
                        page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_user_mac_address'));
                    }
                    else {
                        is_error=true;
                        page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_user_mac_address'),false);
                    }
                }
                if(isset($d('tcp_ipv4_mode'))){
                    switch($v('tcp_ipv4_mode')){
                        case 'dhcp':{
                            el_list = $d('tcp_ipv4_dns_list').getElementsByClassName('tcp_dns_item');
                            for(index in el_list)
                                if(isObject(el_list[index]))
                                    if(isset($d('tcp_ipv4_dns_address_'+index))){
                                        if(is_ipv4_address($v('tcp_ipv4_dns_address_'+index)) || empty($v('tcp_ipv4_dns_address_'+index))){
                                            page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_ipv4_dns_address_'+index));
                                        }
                                        else {
                                            is_error=true;
                                            page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv4_dns_address_'+index),false);
                                        }
                                    }
                            if(isset($d('tcp_ipv4_gateway'))){
                                if(is_ipv4_address($v('tcp_ipv4_gateway')) || empty($v('tcp_ipv4_gateway'))){
                                    page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_ipv4_gateway'));
                                }
                                else {
                                    is_error=true;
                                    page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv4_gateway'),false);
                                }
                            }
                            break;
                        }
                        case 'static':{
                            el_list = $d('tcp_ipv4_ip_list').getElementsByClassName('tcp_ip_item');
                            for(index in el_list)
                                if(isObject(el_list[index])){
                                    if(isset($d('tcp_ipv4_ip_address_'+index))){
                                        if(is_ipv4_address($v('tcp_ipv4_ip_address_'+index))){
                                            page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_ipv4_ip_address_'+index));
                                        }
                                        else {
                                            is_error=true;
                                            page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv4_ip_address_'+index));
                                        }
                                    }
                                    if(isset($d('tcp_ipv4_mask_'+index))){
                                        if(is_ipv4_address($v('tcp_ipv4_mask_'+index))){
                                            page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_ipv4_mask_'+index));
                                        }
                                        else if(isNumber($v('tcp_ipv4_mask_'+index))){
                                            val=parseInt($v('tcp_ipv4_mask_'+index));
                                            if(val>=0&&val<=32)
                                                page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_ipv4_mask_'+index));
                                            else {
                                                is_error=true;
                                                page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv4_mask_'+index));
                                            }
                                        }
                                        else {
                                            is_error=true;
                                            page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv4_mask_'+index));
                                        }
                                    }
                                }
                            if(el_list.length === 1){
                                if(isset($d('tcp_ipv4_ip_address_0')))
                                   if(empty($v('tcp_ipv4_ip_address_0'))){
                                        is_error=true;
                                        page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv4_ip_address_0'));
                                   }
                                if(isset($d('tcp_ipv4_mask_0')))
                                   if(empty($v('tcp_ipv4_mask_0'))){
                                        is_error=true;
                                        page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv4_mask_0'));
                                   }
                            }
                            el_list = $d('tcp_ipv4_dns_list').getElementsByClassName('tcp_dns_item');
                            for(index in el_list)
                                if(isObject(el_list[index]))
                                    if(isset($d('tcp_ipv4_dns_address_'+index))){
                                        if(is_ipv4_address($v('tcp_ipv4_dns_address_'+index))){
                                            page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_ipv4_dns_address_'+index));
                                        }
                                        else {
                                            is_error=true;
                                            page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv4_dns_address_'+index),false);
                                        }
                                    }
                            if(el_list.length === 1){
                                if(isset($d('tcp_ipv4_dns_address_0')))
                                   if(empty($v('tcp_ipv4_dns_address_0'))){
                                        is_error=true;
                                        page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv4_dns_address_0'));
                                   }
                            }
                            if(isset($d('tcp_ipv4_gateway'))){
                                if(empty($v('tcp_ipv4_gateway'))){
                                    is_error=true;
                                    page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv4_gateway'),false);
                                }
                                else if(is_ipv4_address($v('tcp_ipv4_gateway'))){
                                    page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_ipv4_gateway'));
                                }
                                else {
                                    is_error=true;
                                    page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv4_gateway'),false);
                                }
                            }
                            break;
                        }
                    }
                }
                if(isset($d('tcp_ipv6_mode'))){
                    switch($v('tcp_ipv6_mode')){
                        case 'dhcp':{
                            el_list = $d('tcp_ipv6_dns_list').getElementsByClassName('tcp_dns_item');
                            for(index in el_list)
                                if(isObject(el_list[index]))
                                    if(isset($d('tcp_ipv6_dns_address_'+index))){
                                        if(is_ipv6_address($v('tcp_ipv6_dns_address_'+index)) || empty($v('tcp_ipv6_dns_address_'+index)))
                                            page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_ipv6_dns_address_'+index));
                                        else {
                                            is_error=true;
                                            page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv6_dns_address_'+index),false);
                                        }
                                    }
                            if(isset($d('tcp_ipv6_gateway'))){
                                if(is_ipv6_address($v('tcp_ipv6_gateway')) || empty($v('tcp_ipv6_gateway')))
                                    page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_ipv6_gateway'));
                                else if(is_ipv6_address($v('tcp_ipv6_gateway')))
                                    page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_ipv6_gateway'));
                                else {
                                    is_error=true;
                                    page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv6_gateway'),false);
                                }
                            }
                            break;
                        }
                        case 'static':{
                            el_list = $d('tcp_ipv6_ip_list').getElementsByClassName('tcp_ip_item');
                            for(index in el_list)
                                if(isObject(el_list[index])){
                                    if(isset($d('tcp_ipv6_ip_address_'+index))){
                                        if(is_ipv6_address($v('tcp_ipv6_ip_address_'+index))){
                                            page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_ipv6_ip_address_'+index));
                                        }
                                        else {
                                            is_error=true;
                                            page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv6_ip_address_'+index),false);
                                        }
                                    }
                                    if(isset($d('tcp_ipv6_mask_'+index))){
                                        val = $v('tcp_ipv6_mask_'+index);
                                        if(isNumber(val)){
                                            val = parseInt(val);
                                            if(val>=0&&val<=128)
                                                page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_ipv6_mask_'+index));
                                            else {
                                                is_error=true;
                                                page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv6_mask_'+index),false);
                                            }
                                        }
                                        else {
                                            is_error=true;
                                            page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv6_mask_'+index),false);
                                        }
                                    }
                                }
                            if(el_list.length === 1){
                                if(isset($d('tcp_ipv6_ip_address_0')))
                                   if(empty($v('tcp_ipv6_ip_address_0'))){
                                        is_error=true;
                                        page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv6_ip_address_0'));
                                   }
                                if(isset($d('tcp_ipv6_mask_0')))
                                   if(empty($v('tcp_ipv6_mask_0'))){
                                        is_error=true;
                                        page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv6_mask_0'));
                                   }
                            }
                            el_list = $d('tcp_ipv6_dns_list').getElementsByClassName('tcp_dns_item');
                            for(index in el_list)
                                if(isObject(el_list[index]))
                                    if(isset($d('tcp_ipv6_dns_address_'+index))){
                                        if(is_ipv6_address($v('tcp_ipv6_dns_address_'+index))){
                                            page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_ipv6_dns_address_'+index));
                                        }
                                        else {
                                            is_error=true;
                                            page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv6_dns_address_'+index),false);
                                        }
                                    }
                            if(el_list.length === 1){
                                if(isset($d('tcp_ipv6_dns_address_0')))
                                   if(empty($v('tcp_ipv6_dns_address_0'))){
                                        is_error=true;
                                        page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv6_dns_address_0'));
                                   }
                            }
                            if(isset($d('tcp_ipv6_gateway'))){
                                if(empty($v('tcp_ipv6_gateway'))){
                                    is_error=true;
                                    page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv6_gateway'),false);
                                }
                                else if(is_ipv6_address($v('tcp_ipv6_gateway'))){
                                    page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_ipv6_gateway'));
                                }
                                else {
                                    is_error=true;
                                    page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_ipv6_gateway'),false);
                                }
                            }
                            break;
                        }
                    }
                }
                if(isset($d('tcp_gsm_mode'))){
                    switch($v('tcp_gsm_mode')){
                        case 'manual':{
                            if(isset($d('tcp_gsm_apn'))){
                                if(!empty($v('tcp_gsm_apn'))){
                                    if(is_link($v('tcp_gsm_apn')) || is_gsm_apn($v('tcp_gsm_apn'))){
                                        page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_gsm_apn'));
                                    }
                                    else {
                                        is_error=true;
                                        page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_gsm_apn'),false);
                                    }
                                }
                            }
                            if(isset($d('tcp_gsm_network'))){
                                if(!empty($v('tcp_gsm_network'))){
                                    pattern=/^[\d*]$/is;
                                    if(pattern.test($v('tcp_gsm_network'))){
                                        page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_gsm_network'));
                                    }
                                    else {
                                        is_error=true;
                                        page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_gsm_network'),false);
                                    }
                                }
                            }
                            break;
                        }
                    }
                }
                if(isset($d('tcp_route_ipv4_list'))){
                    el_list = $d('tcp_route_ipv4_list').getElementsByClassName('tcp_route_item');
                    if(el_list.length>0){
                        for(index in el_list)
                            if(isObject(el_list[index])){
                                if(isset($d('tcp_route_ipv4_address_'+index))){
                                    if(is_ipv4_address($v('tcp_route_ipv4_address_'+index)) || empty($v('tcp_route_ipv4_address_'+index))){
                                        page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_route_ipv4_address_'+index));
                                    }
                                    else {
                                        is_error=true;
                                        page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_route_ipv4_address_'+index),false);
                                    }
                                }
                                if(isset($d('tcp_route_ipv4_order_'+index))){
                                    if(!empty($v('tcp_route_ipv4_order_'+index))){

                                        pattern=/^(\d+)$/is;
                                        if(pattern.test($v('tcp_route_ipv4_order_'+index))){
                                            page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_route_ipv4_order_'+index));
                                        }
                                        else {
                                            is_error=true;
                                            page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_route_ipv4_order_'+index),false);
                                        }
                                    }
                                    else {
                                        page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_route_ipv4_order_'+index));
                                    }
                                }
                            }
                    }
                }
                if(isset($d('tcp_route_ipv6_list'))){
                    el_list = $d('tcp_route_ipv6_list').getElementsByClassName('tcp_route_item');
                    if(el_list.length>0){
                        for(index in el_list)
                            if(isObject(el_list[index])){
                                if(isset($d('tcp_route_ipv6_address_'+index))){
                                    if(is_ipv6_address($v('tcp_route_ipv6_address_'+index)) || empty($v('tcp_route_ipv6_address_'+index))){
                                        page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_route_ipv6_address_'+index));
                                    }
                                    else {
                                        is_error=true;
                                        page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_route_ipv6_address_'+index),false);
                                    }
                                }
                                if(isset($d('tcp_route_ipv6_order_'+index))){
                                    if(!empty($v('tcp_route_ipv6_order_'+index))){

                                        pattern=/^(\d+|\d+-\d+)$/is;
                                        if(pattern.test($v('tcp_route_ipv6_order_'+index))){
                                            page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_route_ipv6_order_'+index));
                                        }
                                        else {
                                            is_error=true;
                                            page_object.action.admin.action.tcp_content.action.buttons.error_border.init($d('tcp_route_ipv6_order_'+index),false);
                                        }
                                    }
                                    else {
                                        page_object.action.admin.action.tcp_content.action.buttons.valid_border.init($d('tcp_route_ipv6_order_'+index));
                                    }
                                }
                            }
                    }
                }
                if(!is_error){
                    let inner='';
                    inner+='<div class="dialog_row" style="color: #940000;">Изменения могут привести к потере подключения к устройству.</div>';
                    inner+='<div class="dialog_row">Вы уверены, что хотите применить изменения?</div>';
                    var dialog_index=page_object.dialog.init({
                        'title':'Инфорамация',
                        'inner':inner,
                        'ok':function(){
                            page_object.action.admin.action.tcp_content.action.save.action();
                            page_object.dialog.action.un_show.init(dialog_index,true);
                        },
                        'cancel':true,
                    });
                }
            },
            'action':function(){
                let  post =''
                    ,data =page_object.action.admin.data['data']['data']
                    ,ipv4_ip_list = []
                    ,ipv4_dns_list = []
                    ,ipv6_ip_list = []
                    ,ipv6_dns_list = []
                    ,route_ipv4_settings = []
                    ,route_ipv6_settings = []
                    ,el_list
                    ,index;
                page_object.link.preload.show();
                page_object.action.admin.action.tcp_content.action.status.clean();
                el_list = $d('tcp_ipv4_ip_list').getElementsByClassName('tcp_ip_item');
                for(index in el_list)
                    if(isObject(el_list[index]))
                        ipv4_ip_list.push({
                            'ip'    :$v('tcp_ipv4_ip_address_'+index),
                            'mask'  :$v('tcp_ipv4_mask_'+index),
                        });
                el_list = $d('tcp_ipv4_dns_list').getElementsByClassName('tcp_dns_item');
                for(index in el_list)
                    if(isObject(el_list[index]))
                        if(!empty($v('tcp_ipv4_dns_address_'+index)))
                            ipv4_dns_list.push($v('tcp_ipv4_dns_address_'+index));
                el_list = $d('tcp_ipv6_ip_list').getElementsByClassName('tcp_ip_item');
                for(index in el_list)
                    if(isObject(el_list[index]))
                        ipv6_ip_list.push({
                            'ip'    :$v('tcp_ipv6_ip_address_'+index),
                            'mask'  :$v('tcp_ipv6_mask_'+index),
                        });
                el_list = $d('tcp_ipv6_dns_list').getElementsByClassName('tcp_dns_item');
                for(index in el_list)
                    if(isObject(el_list[index]))
                        if(!empty($v('tcp_ipv6_dns_address_'+index)))
                            ipv6_dns_list.push($v('tcp_ipv6_dns_address_'+index));
                el_list = $d('tcp_route_ipv4_list').getElementsByClassName('tcp_route_item');
                for(index in el_list)
                    if(isObject(el_list[index]))
                        if(!empty($v('tcp_route_ipv4_address_'+index)))
                            route_ipv4_settings.push({
                                'ip':$v('tcp_route_ipv4_address_'+index),
                                'order':parseInt($v('tcp_route_ipv4_order_'+index)),
                            });
                el_list = $d('tcp_route_ipv6_list').getElementsByClassName('tcp_route_item');
                for(index in el_list)
                    if(isObject(el_list[index]))
                        if(!empty($v('tcp_route_ipv6_address_'+index)))
                            route_ipv6_settings.push({
                                'ip':$v('tcp_route_ipv6_address_'+index),
                                'order':parseInt($v('tcp_route_ipv6_order_'+index)),
                            });
                post+='&name='+uniEncode(empty($v('tcp_name'))?'':$v('tcp_name'));
                post+='&tcp_name='+uniEncode(data['tcp_name']);
                post+='&tcp_type='+uniEncode(data['tcp_type']);
                post+='&original_mac_address='+uniEncode(data['original_mac_address']);
                post+='&user_mac_address='+uniEncode(empty($v('tcp_user_mac_address'))?'':$v('tcp_user_mac_address'));
                post+='&ipv4_mode='+uniEncode(empty($v('tcp_ipv4_mode'))?'':$v('tcp_ipv4_mode'));
                post+='&ipv4_ip_address_list='+uniEncode(jsonEncode(ipv4_ip_list));
                post+='&ipv4_dns_address_list='+uniEncode(jsonEncode(ipv4_dns_list));
                post+='&ipv4_gateway='+uniEncode(empty($v('tcp_ipv4_gateway'))?'':$v('tcp_ipv4_gateway'));
                post+='&ipv6_mode='+uniEncode(empty($v('tcp_ipv6_mode'))?'':$v('tcp_ipv6_mode'));
                post+='&ipv6_ip_address_list='+uniEncode(jsonEncode(ipv6_ip_list));
                post+='&ipv6_dns_address_list='+uniEncode(jsonEncode(ipv6_dns_list));
                post+='&ipv6_gateway='+uniEncode(empty($v('tcp_ipv6_gateway'))?'':$v('tcp_ipv6_gateway'));
                if(isset($d('tcp_gsm_block'))){
                    post+='&gsm_mode='+uniEncode(empty($v('tcp_gsm_mode'))?'':$v('tcp_gsm_mode'));
                    post+='&gsm_apn='+uniEncode(empty($v('tcp_gsm_apn'))?'':$v('tcp_gsm_apn'));
                    post+='&gsm_username='+uniEncode(empty($v('tcp_gsm_username'))?'':$v('tcp_gsm_username'));
                    post+='&gsm_password='+uniEncode(empty($v('tcp_gsm_password'))?'':$v('tcp_gsm_password'));
                    post+='&gsm_network='+uniEncode(empty($v('tcp_gsm_network'))?'':$v('tcp_gsm_network'));
                }
                post+='&route_ipv4_settings='+uniEncode(jsonEncode(route_ipv4_settings));
                post+='&route_ipv6_settings='+uniEncode(jsonEncode(route_ipv6_settings));
                send({
                    'scriptPath':'/api/json/save_tcp',
                    'postData':post,
                    'onComplete':function(j,worktime){
                        var  dataTemp
                            ,data;
                        dataTemp=j.responseText;
                        trace(dataTemp);
                        data=jsonDecode(dataTemp);
                        trace(data);
                        trace_worktime(worktime,data);
                        if(isset(data['error'])){
                            page_object.action.admin.action.tcp_content.action.error.init(data);
                        }
                        else {
                            page_object.action.admin.data['data'] = data['data'];
                            if(isset($d('tcp_menu_list')))
                                $d('tcp_menu_list').innerHTML=page_object.action.admin.create.tcp.create.get_menu_list();
                            if(isset($d('tcp_container')))
                                $d('tcp_container').innerHTML=page_object.action.admin.create.tcp.create.get_tcp_content();
                        }
                        page_object.action.admin.action.tcp_content.action.init();
                        page_object.action.admin.action.tcp_content.action.buttons.reset();
                        page_object.action.admin.action.tcp_content.action.buttons.set_action();
                        page_object.link.preload.un_show();
                    }
                });
            },
        },
        'cancel':{
            'init':function(){
                let inner='';
                inner+='<div class="dialog_row">Вы уверены, что хотите отменить изменения до сохраненных на сервере?</div>';
                var dialog_index=page_object.dialog.init({
                    'title':'Инфорамация',
                    'inner':inner,
                    'ok':function(){
                        page_object.action.admin.action.tcp_content.action.cancel.action();
                        page_object.dialog.action.un_show.init(dialog_index,true);
                    },
                    'cancel':true,
                });
            },
            'action':function(){
                if(isset($d('tcp_container'))){
                    $d('tcp_container').innerHTML=page_object.action.admin.create.tcp.create.get_tcp_content();
                    page_object.action.admin.action.tcp_content.action.init();
                    page_object.action.admin.action.tcp_content.action.buttons.reset();
                    page_object.action.admin.action.tcp_content.action.buttons.set_action();
                }
            },
        },
        'tcp':{
            'init':function(){
                var  list
                    ,data=page_object.action.admin.data['data']['data']
                    ,index;
                cl(isset(data.error));
                if(isset(data.error)) return;

                if(isset($d('tcp_name'))){
                    $d('tcp_name').onkeydown =page_object.action.admin.action.tcp_content.action.buttons.keydown;
                    $d('tcp_name').onkeyup =page_object.action.admin.action.tcp_content.action.buttons.keyup;
                }
                if(isset($d('tcp_user_mac_address'))){
                    $d('tcp_user_mac_address').onkeydown =page_object.action.admin.action.tcp_content.action.buttons.keydown;
                    $d('tcp_user_mac_address').onkeyup =page_object.action.admin.action.tcp_content.action.buttons.keyup;
                }
                if(isset($d('tcp_gsm_apn'))){
                    $d('tcp_gsm_apn').onkeydown =page_object.action.admin.action.tcp_content.action.buttons.keydown;
                    $d('tcp_gsm_apn').onkeyup =page_object.action.admin.action.tcp_content.action.buttons.keyup;
                }
                if(isset($d('tcp_gsm_username'))){
                    $d('tcp_gsm_username').onkeydown =page_object.action.admin.action.tcp_content.action.buttons.keydown;
                    $d('tcp_gsm_username').onkeyup =page_object.action.admin.action.tcp_content.action.buttons.keyup;
                }
                if(isset($d('tcp_gsm_network'))){
                    $d('tcp_gsm_network').onkeydown =page_object.action.admin.action.tcp_content.action.buttons.keydown;
                    $d('tcp_gsm_network').onkeyup =page_object.action.admin.action.tcp_content.action.buttons.keyup;
                }
                list=data['ipv4']['ip_address_list'];
                for(index in list){
                    if(isset($d('tcp_ipv4_ip_address_'+index))){
                        $d('tcp_ipv4_ip_address_'+index).onkeydown =page_object.action.admin.action.tcp_content.action.buttons.keydown;
                        $d('tcp_ipv4_ip_address_'+index).onkeyup =page_object.action.admin.action.tcp_content.action.buttons.keyup;
                    }
                    if(isset($d('tcp_ipv4_mask_'+index))){
                        $d('tcp_ipv4_mask_'+index).onkeydown =page_object.action.admin.action.tcp_content.action.buttons.keydown;
                        $d('tcp_ipv4_mask_'+index).onkeyup =page_object.action.admin.action.tcp_content.action.buttons.keyup;
                    }
                }
                list=data['ipv4']['dns_address_list'];
                for(index in list)
                    if(isset($d('tcp_ipv4_dns_address_'+index))){
                        $d('tcp_ipv4_dns_address_'+index).onkeydown =page_object.action.admin.action.tcp_content.action.buttons.keydown;
                        $d('tcp_ipv4_dns_address_'+index).onkeyup =page_object.action.admin.action.tcp_content.action.buttons.keyup;
                    }
                if(isset($d('tcp_ipv4_gateway'))){
                    $d('tcp_ipv4_gateway').onkeydown =page_object.action.admin.action.tcp_content.action.buttons.keydown;
                    $d('tcp_ipv4_gateway').onkeyup =page_object.action.admin.action.tcp_content.action.buttons.keyup;
                }
                list=data['ipv6']['ip_address_list'];
                for(index in list){
                    if(isset($d('tcp_ipv6_ip_address_'+index))){
                        $d('tcp_ipv6_ip_address_'+index).onkeydown =page_object.action.admin.action.tcp_content.action.buttons.keydown;
                        $d('tcp_ipv6_ip_address_'+index).onkeyup =page_object.action.admin.action.tcp_content.action.buttons.keyup;
                    }
                    if(isset($d('tcp_ipv6_mask_'+index))){
                        $d('tcp_ipv6_mask_'+index).onkeydown =page_object.action.admin.action.tcp_content.action.buttons.keydown;
                        $d('tcp_ipv6_mask_'+index).onkeyup =page_object.action.admin.action.tcp_content.action.buttons.keyup;
                    }
                }
                list=data['ipv6']['dns_address_list'];
                for(index in list)
                    if(isset($d('tcp_ipv6_dns_address_'+index))){
                        $d('tcp_ipv6_dns_address_'+index).onkeydown =page_object.action.admin.action.tcp_content.action.buttons.keydown;
                        $d('tcp_ipv6_dns_address_'+index).onkeyup =page_object.action.admin.action.tcp_content.action.buttons.keyup;
                    }
                if(isset($d('tcp_ipv6_gateway'))){
                    $d('tcp_ipv6_gateway').onkeydown =page_object.action.admin.action.tcp_content.action.buttons.keydown;
                    $d('tcp_ipv6_gateway').onkeyup =page_object.action.admin.action.tcp_content.action.buttons.keyup;
                }
                list=data['route_ipv4_settings'];
                for(index in list){
                    if(isset($d('tcp_route_ipv4_address_'+index))){
                        $d('tcp_route_ipv4_address_'+index).onkeydown =page_object.action.admin.action.tcp_content.action.buttons.keydown;
                        $d('tcp_route_ipv4_address_'+index).onkeyup =page_object.action.admin.action.tcp_content.action.buttons.keyup;
                    }
                    if(isset($d('tcp_route_ipv4_order_'+index))){
                        $d('tcp_route_ipv4_order_'+index).onchange =page_object.action.admin.action.tcp_content.action.buttons.keyup;
                        $d('tcp_route_ipv4_order_'+index).onkeydown =page_object.action.admin.action.tcp_content.action.buttons.keydown;
                        $d('tcp_route_ipv4_order_'+index).onkeyup =page_object.action.admin.action.tcp_content.action.buttons.keyup;
                    }
                }
                list=data['route_ipv6_settings'];
                for(index in list){
                    if(isset($d('tcp_route_ipv6_address_'+index))){
                        $d('tcp_route_ipv6_address_'+index).onkeydown =page_object.action.admin.action.tcp_content.action.buttons.keydown;
                        $d('tcp_route_ipv6_address_'+index).onkeyup =page_object.action.admin.action.tcp_content.action.buttons.keyup;
                    }
                    if(isset($d('tcp_route_ipv6_order_'+index))){
                        $d('tcp_route_ipv6_order_'+index).onchange =page_object.action.admin.action.tcp_content.action.buttons.keyup;
                        $d('tcp_route_ipv6_order_'+index).onkeydown =page_object.action.admin.action.tcp_content.action.buttons.keydown;
                        $d('tcp_route_ipv6_order_'+index).onkeyup =page_object.action.admin.action.tcp_content.action.buttons.keyup;
                    }
                }
            },
            'show':function(){
                if(isset($d('tcp_camera_block')))
                    $d('tcp_camera_block').setAttribute('class','tcp_row_item')
            },
            'un_show':function(){
                if(isset($d('tcp_camera_block')))
                    $d('tcp_camera_block').setAttribute('class','tcp_row_item_disable')
            }
        },
        'mode':{
            'init':function(){
                if(isset($d('tcp_ipv4_mode')))
                    $d('tcp_ipv4_mode').onchange=page_object.action.admin.action.tcp_content.action.mode.action;
                if(isset($d('tcp_ipv6_mode')))
                    $d('tcp_ipv6_mode').onchange=page_object.action.admin.action.tcp_content.action.mode.action;
                if(isset($d('tcp_gsm_mode')))
                    $d('tcp_gsm_mode').onchange=page_object.action.admin.action.tcp_content.action.mode.action;
            },
            'action':function(){
                var key=this.id.split('_')[1];
                if(isset($d('tcp_'+key+'_settings')))
                    $d('tcp_'+key+'_settings').setAttribute('class','tcp_row_item_settings'+(this.value === 'disabled' || this.value === 'auto'?'_hide':''));
                if(this.id!=='tcp_gsm_mode')
                    switch(this.value){
                        case 'dhcp':{
                            $d('tcp_'+key+'_ip_block').setAttribute('class','tcp_row_item_container_hide');
                            break;
                        }
                        default:{
                            $d('tcp_'+key+'_ip_block').setAttribute('class','tcp_row_item_container');
                            break;
                        }
                    }
                page_object.action.admin.action.tcp_content.action.buttons.is_edit=true;
                page_object.action.admin.action.tcp_content.action.buttons.set_action();
            }
        },
        'ip':{
            'init':function(){

                let data = page_object.action.admin.data['data']['data']
                cl(isset(data.error));
                if(isset(data.error)) return;
                page_object.action.admin.action.tcp_content.action.ip.v4.init();
                page_object.action.admin.action.tcp_content.action.ip.v6.init();
            },
            'v4':{
                'init':function(){
                    var  list=page_object.action.admin.data['data']['data']['ipv4']['ip_address_list']
                        ,index;
                    for(index in list){
                        if(isset($d('tcp_ipv4_ip_add_'+index))){
                            $d('tcp_ipv4_ip_add_'+index).onclick =page_object.action.admin.action.tcp_content.action.ip.v4.add;
                            $s('tcp_ipv4_ip_add_'+index).display ='none';
                        }
                        if(isset($d('tcp_ipv4_ip_remove_'+index)))
                            $d('tcp_ipv4_ip_remove_'+index).onclick=page_object.action.admin.action.tcp_content.action.ip.v4.remove.init;
                    }
                    if(isset($d('tcp_ipv4_ip_remove_0')))
                        $s('tcp_ipv4_ip_remove_0').display=(list.length === 1?'none':'inline-block');
                    if(isset($d('tcp_ipv4_ip_add_'+index)))
                        $s('tcp_ipv4_ip_add_'+index).display='inline-block';
                },
                'add':function(){
                    var  index=page_object.action.admin.data['data']['data']['ipv4']['ip_address_list'].length
                        ,el
                        ,inner;
                    page_object.action.admin.data['data']['data']['ipv4']['ip_address_list'].push({});
                    inner =page_object.action.admin.create.tcp.create.get_ipv4_ip(index);
                    el =addElement({
                        'tag':'div',
                        'id':'tcp_ipv4_ip_item_'+index,
                        'class':'tcp_ip_item',
                        'inner':inner,
                    });
                    $d('tcp_ipv4_ip_list').appendChild(el);
                    page_object.action.admin.action.tcp_content.action.buttons.is_edit=true;
                    page_object.action.admin.action.tcp_content.action.buttons.set_action();
                    page_object.action.admin.action.tcp_content.action.ip.v4.init();
                },
                'rename_index':function(from_index,to_index){
                    if(isset($d('tcp_ipv4_ip_item_'+from_index))){
                        $d('tcp_ipv4_ip_item_'+from_index).setAttribute('id','tcp_ipv4_ip_item_'+to_index);
                        $d('tcp_ipv4_ip_address_'+from_index).setAttribute('id','tcp_ipv4_ip_address_'+to_index);
                        $d('tcp_ipv4_mask_'+from_index).setAttribute('id','tcp_ipv4_mask_'+to_index);
                        $d('tcp_ipv4_ip_add_'+from_index).setAttribute('id','tcp_ipv4_ip_add_'+to_index);
                        $d('tcp_ipv4_ip_remove_'+from_index).setAttribute('id','tcp_ipv4_ip_remove_'+to_index);
                    }
                },
                'remove':{
                    'init':function(){
                        var  index =parseInt(this.id.split('_')[4])
                            ,from_index
                            ,to_index
                            ,inner =''
                            ,list =page_object.action.admin.data['data']['data']['ipv4']['ip_address_list'];
                        inner+='<div class="dialog_row">Вы уверены, что удалить данные?</div>';
                        var dialog_index=page_object.dialog.init({
                            'title':'Инфорамация',
                            'inner':inner,
                            'ok':function(){
                                if(isset($d('tcp_ipv4_ip_item_'+index)))
                                    removeElement($d('tcp_ipv4_ip_item_'+index));
                                for(to_index=index;to_index<list.length-1;to_index++){
                                    from_index=to_index+1;
                                    page_object.action.admin.action.tcp_content.action.ip.v4.rename_index(from_index,to_index)
                                }
                                page_object.action.admin.data['data']['data']['ipv4']['ip_address_list'].splice(index,1);
                                page_object.action.admin.action.tcp_content.action.buttons.is_edit=true;
                                page_object.action.admin.action.tcp_content.action.buttons.set_action();
                                page_object.action.admin.action.tcp_content.action.ip.v4.init();
                                page_object.dialog.action.un_show.init(dialog_index,true);
                            },
                            'cancel':true,
                        });
                    },
                },
            },
            'v6':{
                'init':function(){
                    var  list=page_object.action.admin.data['data']['data']['ipv6']['ip_address_list']
                        ,index;
                    for(index in list){
                        if(isset($d('tcp_ipv6_ip_add_'+index))){
                            $d('tcp_ipv6_ip_add_'+index).onclick =page_object.action.admin.action.tcp_content.action.ip.v6.add;
                            $s('tcp_ipv6_ip_add_'+index).display ='none';
                        }
                        if(isset($d('tcp_ipv6_ip_remove_'+index)))
                            $d('tcp_ipv6_ip_remove_'+index).onclick=page_object.action.admin.action.tcp_content.action.ip.v6.remove.init;
                    }
                    if(isset($d('tcp_ipv6_ip_remove_0')))
                        $s('tcp_ipv6_ip_remove_0').display=(list.length === 1?'none':'inline-block');
                    if(isset($d('tcp_ipv6_ip_add_'+index)))
                        $s('tcp_ipv6_ip_add_'+index).display='inline-block';
                },
                'add':function(){
                    var  index=page_object.action.admin.data['data']['data']['ipv6']['ip_address_list'].length
                        ,el
                        ,inner;
                    page_object.action.admin.data['data']['data']['ipv6']['ip_address_list'].push({});
                    inner =page_object.action.admin.create.tcp.create.get_ipv6_ip(index);
                    el =addElement({
                        'tag':'div',
                        'id':'tcp_ipv6_ip_item_'+index,
                        'class':'tcp_ip_item',
                        'inner':inner,
                    });
                    $d('tcp_ipv6_ip_list').appendChild(el);
                    page_object.action.admin.action.tcp_content.action.buttons.is_edit=true;
                    page_object.action.admin.action.tcp_content.action.buttons.set_action();
                    page_object.action.admin.action.tcp_content.action.ip.v6.init();
                },
                'rename_index':function(from_index,to_index){
                    if(isset($d('tcp_ipv6_ip_item_'+from_index))){
                        $d('tcp_ipv6_ip_item_'+from_index).setAttribute('id','tcp_ipv6_ip_item_'+to_index);
                        $d('tcp_ipv6_ip_address_'+from_index).setAttribute('id','tcp_ipv6_ip_address_'+to_index);
                        $d('tcp_ipv6_mask_'+from_index).setAttribute('id','tcp_ipv6_mask_'+to_index);
                        $d('tcp_ipv6_ip_add_'+from_index).setAttribute('id','tcp_ipv6_ip_add_'+to_index);
                        $d('tcp_ipv6_ip_remove_'+from_index).setAttribute('id','tcp_ipv6_ip_remove_'+to_index);
                    }
                },
                'remove':{
                    'init':function(){
                        var  index =parseInt(this.id.split('_')[4])
                            ,from_index
                            ,to_index
                            ,inner =''
                            ,list =page_object.action.admin.data['data']['data']['ipv6']['ip_address_list'];
                        inner+='<div class="dialog_row">Вы уверены, что удалить данные?</div>';
                        var dialog_index=page_object.dialog.init({
                            'title':'Инфорамация',
                            'inner':inner,
                            'ok':function(){
                                if(isset($d('tcp_ipv6_ip_item_'+index)))
                                    removeElement($d('tcp_ipv6_ip_item_'+index));
                                for(to_index=index;to_index<list.length-1;to_index++){
                                    from_index=to_index+1;
                                    page_object.action.admin.action.tcp_content.action.ip.v6.rename_index(from_index,to_index)
                                }
                                page_object.action.admin.data['data']['data']['ipv6']['ip_address_list'].splice(index,1);
                                page_object.action.admin.action.tcp_content.action.buttons.is_edit=true;
                                page_object.action.admin.action.tcp_content.action.buttons.set_action();
                                page_object.action.admin.action.tcp_content.action.ip.v6.init();
                                page_object.dialog.action.un_show.init(dialog_index,true);
                            },
                            'cancel':true,
                        });
                    },
                },
            }
        },
        'route':{
            'init':function(){

                page_object.action.admin.action.tcp_content.action.route.v4.init();
                page_object.action.admin.action.tcp_content.action.route.v6.init();

            },
            'v4':{
                'init':function(){

                    var  list=page_object.action.admin.data['data']['data']['route_ipv4_settings']
                        ,index;

                    for(index in list){

                        if(isset($d('tcp_route_ipv4_add_'+index))){

                            $d('tcp_route_ipv4_add_'+index).onclick =page_object.action.admin.action.tcp_content.action.route.v4.add;
                            $s('tcp_route_ipv4_add_'+index).display ='none';

                        }

                        if(isset($d('tcp_route_ipv4_remove_'+index)))
                            $d('tcp_route_ipv4_remove_'+index).onclick=page_object.action.admin.action.tcp_content.action.route.v4.remove.init;

                    }

                    if(isset($d('tcp_route_ipv4_remove_0')))
                        $s('tcp_route_ipv4_remove_0').display=(list.length === 1?'none':'inline-block');

                    if(isset($d('tcp_route_ipv4_add_'+index)))
                        $s('tcp_route_ipv4_add_'+index).display='inline-block';

                },
                'add':function(){

                    var  index =page_object.action.admin.data['data']['data']['route_ipv4_settings'].length
                        ,el
                        ,inner
                        ,order_list = $d('tcp_route_ipv4_list').getElementsByClassName('tcp_input_order_route')
                        ,order_index
                        ,order_number =1;

                    for(order_index in order_list)
                        if(isObject(order_list[order_index]))
                            if(parseInt(order_list[order_index].value)>order_number)
                                order_number=parseInt(order_list[order_index].value);

                    page_object.action.admin.data['data']['data']['route_ipv4_settings'].push({});

                    inner =page_object.action.admin.create.tcp.create.get_route_ipv4(index, order_number+1);
                    el =addElement({
                        'tag':'div',
                        'id':'tcp_route_ipv4_item_'+index,
                        'class':'tcp_route_item',
                        'inner':inner,
                    });

                    $d('tcp_route_ipv4_list').appendChild(el);

                    page_object.action.admin.action.tcp_content.action.buttons.is_edit=true;

                    page_object.action.admin.action.tcp_content.action.buttons.set_action();
                    page_object.action.admin.action.tcp_content.action.route.v4.init();

                },
                'rename_index':function(from_index,to_index){

                    if(isset($d('tcp_route_ipv4_item_'+from_index))){

                        $d('tcp_route_ipv4_item_'+from_index).setAttribute('id','tcp_route_ipv4_item_'+to_index);
                        $d('tcp_route_ipv4_address_'+from_index).setAttribute('id','tcp_route_ipv4_address_'+to_index);
                        $d('tcp_route_ipv4_order_'+from_index).setAttribute('id','tcp_route_ipv4_order_'+to_index);
                        $d('tcp_route_ipv4_add_'+from_index).setAttribute('id','tcp_route_ipv4_add_'+to_index);
                        $d('tcp_route_ipv4_remove_'+from_index).setAttribute('id','tcp_route_ipv4_remove_'+to_index);

                    }

                },
                'remove':{
                    'init':function(){

                        var  index =parseInt(this.id.split('_')[4])
                            ,from_index
                            ,to_index
                            ,inner =''
                            ,list =page_object.action.admin.data['data']['data']['route_ipv4_settings'];

                        inner+='<div class="dialog_row">Вы уверены, что удалить данные?</div>';

                        var dialog_index=page_object.dialog.init({
                            'title':'Инфорамация',
                            'inner':inner,
                            'ok':function(){

                                if(isset($d('tcp_route_ipv4_item_'+index)))
                                    removeElement($d('tcp_route_ipv4_item_'+index));

                                for(to_index=index;to_index<list.length-1;to_index++){

                                    from_index=to_index+1;

                                    page_object.action.admin.action.tcp_content.action.route.v4.rename_index(from_index,to_index)

                                }

                                page_object.action.admin.data['data']['data']['route_ipv4_settings'].splice(index,1);

                                page_object.action.admin.action.tcp_content.action.buttons.is_edit=true;

                                page_object.action.admin.action.tcp_content.action.buttons.set_action();
                                page_object.action.admin.action.tcp_content.action.route.v4.init();
                                page_object.dialog.action.un_show.init(dialog_index,true);

                            },
                            'cancel':true,
                        });

                    },
                },

            },
            'v6':{
                'init':function(){

                    var  list=page_object.action.admin.data['data']['data']['route_ipv6_settings']
                        ,index;

                    for(index in list){

                        if(isset($d('tcp_route_ipv6_add_'+index))){

                            $d('tcp_route_ipv6_add_'+index).onclick =page_object.action.admin.action.tcp_content.action.route.v6.add;
                            $s('tcp_route_ipv6_add_'+index).display ='none';

                        }

                        if(isset($d('tcp_route_ipv6_remove_'+index)))
                            $d('tcp_route_ipv6_remove_'+index).onclick=page_object.action.admin.action.tcp_content.action.route.v6.remove.init;

                    }

                    if(isset($d('tcp_route_ipv6_remove_0')))
                        $s('tcp_route_ipv6_remove_0').display=(list.length === 1?'none':'inline-block');

                    if(isset($d('tcp_route_ipv6_add_'+index)))
                        $s('tcp_route_ipv6_add_'+index).display='inline-block';

                },
                'add':function(){

                    var  index =page_object.action.admin.data['data']['data']['route_ipv6_settings'].length
                        ,el
                        ,inner
                        ,order_list = $d('tcp_route_ipv6_list').getElementsByClassName('tcp_input_order_route')
                        ,order_index
                        ,order_number =1;

                    for(order_index in order_list)
                        if(isObject(order_list[order_index]))
                            if(parseInt(order_list[order_index].value)>order_number)
                                order_number=parseInt(order_list[order_index].value);

                    page_object.action.admin.data['data']['data']['route_ipv6_settings'].push({});

                    inner =page_object.action.admin.create.tcp.create.get_route_ipv6(index, order_number+1);
                    el =addElement({
                        'tag':'div',
                        'id':'tcp_route_ipv6_item_'+index,
                        'class':'tcp_route_item',
                        'inner':inner,
                    });

                    $d('tcp_route_ipv6_list').appendChild(el);

                    page_object.action.admin.action.tcp_content.action.buttons.is_edit=true;

                    page_object.action.admin.action.tcp_content.action.buttons.set_action();
                    page_object.action.admin.action.tcp_content.action.route.v6.init();

                },
                'rename_index':function(from_index,to_index){

                    if(isset($d('tcp_route_ipv6_item_'+from_index))){

                        $d('tcp_route_ipv6_item_'+from_index).setAttribute('id','tcp_route_ipv6_item_'+to_index);
                        $d('tcp_route_ipv6_address_'+from_index).setAttribute('id','tcp_route_ipv6_address_'+to_index);
                        $d('tcp_route_ipv6_order_'+from_index).setAttribute('id','tcp_route_ipv6_order_'+to_index);
                        $d('tcp_route_ipv6_add_'+from_index).setAttribute('id','tcp_route_ipv6_add_'+to_index);
                        $d('tcp_route_ipv6_remove_'+from_index).setAttribute('id','tcp_route_ipv6_remove_'+to_index);

                    }

                },
                'remove':{
                    'init':function(){

                        var  index =parseInt(this.id.split('_')[4])
                            ,from_index
                            ,to_index
                            ,inner =''
                            ,list =page_object.action.admin.data['data']['data']['route_ipv6_settings'];

                        inner+='<div class="dialog_row">Вы уверены, что удалить данные?</div>';

                        var dialog_index=page_object.dialog.init({
                            'title':'Инфорамация',
                            'inner':inner,
                            'ok':function(){

                                if(isset($d('tcp_route_ipv6_item_'+index)))
                                    removeElement($d('tcp_route_ipv6_item_'+index));

                                for(to_index=index;to_index<list.length-1;to_index++){

                                    from_index=to_index+1;

                                    page_object.action.admin.action.tcp_content.action.route.v6.rename_index(from_index,to_index)

                                }

                                page_object.action.admin.data['data']['data']['route_ipv6_settings'].splice(index,1);

                                page_object.action.admin.action.tcp_content.action.buttons.is_edit=true;

                                page_object.action.admin.action.tcp_content.action.buttons.set_action();
                                page_object.action.admin.action.tcp_content.action.route.v6.init();
                                page_object.dialog.action.un_show.init(dialog_index,true);

                            },
                            'cancel':true,
                        });

                    },
                },

            },
        },
        'dns':{
            'init':function(){
                page_object.action.admin.action.tcp_content.action.dns.v4.init();
                page_object.action.admin.action.tcp_content.action.dns.v6.init();
            },
            'v4':{
                'init':function(){
                    var  list=page_object.action.admin.data['data']['data']['ipv4']['dns_address_list']
                        ,index;
                    for(index in list){
                        if(isset($d('tcp_ipv4_dns_add_'+index))){

                            $d('tcp_ipv4_dns_add_'+index).onclick =page_object.action.admin.action.tcp_content.action.dns.v4.add;
                            $s('tcp_ipv4_dns_add_'+index).display ='none';

                        }
                        if(isset($d('tcp_ipv4_dns_remove_'+index)))
                            $d('tcp_ipv4_dns_remove_'+index).onclick=page_object.action.admin.action.tcp_content.action.dns.v4.remove.init;
                    }
                    if(isset($d('tcp_ipv4_dns_remove_0')))
                        $s('tcp_ipv4_dns_remove_0').display=(list.length === 1?'none':'inline-block');
                    if(isset($d('tcp_ipv4_dns_add_'+index)))
                        $s('tcp_ipv4_dns_add_'+index).display='inline-block';
                },
                'add':function(){
                    var  index=page_object.action.admin.data['data']['data']['ipv4']['dns_address_list'].length
                        ,el
                        ,inner;
                    page_object.action.admin.data['data']['data']['ipv4']['dns_address_list'].push("");
                    inner =page_object.action.admin.create.tcp.create.get_ipv4_dns(index);
                    el =addElement({
                        'tag':'div',
                        'id':'tcp_ipv4_dns_item_'+index,
                        'class':'tcp_dns_item',
                        'inner':inner,
                    });
                    $d('tcp_ipv4_dns_list').appendChild(el);
                    page_object.action.admin.action.tcp_content.action.buttons.is_edit=true;
                    page_object.action.admin.action.tcp_content.action.buttons.set_action();
                    page_object.action.admin.action.tcp_content.action.dns.v4.init();
                },
                'rename_index':function(from_index,to_index){
                    if(isset($d('tcp_ipv4_dns_item_'+from_index))){
                        $d('tcp_ipv4_dns_item_'+from_index).setAttribute('id','tcp_ipv4_dns_item_'+to_index);
                        $d('tcp_ipv4_dns_address_'+from_index).setAttribute('id','tcp_ipv4_dns_address_'+to_index);
                        $d('tcp_ipv4_dns_add_'+from_index).setAttribute('id','tcp_ipv4_dns_add_'+to_index);
                        $d('tcp_ipv4_dns_remove_'+from_index).setAttribute('id','tcp_ipv4_dns_remove_'+to_index);
                    }
                },
                'remove':{
                    'init':function(){
                        var  index =parseInt(this.id.split('_')[4])
                            ,from_index
                            ,to_index
                            ,inner =''
                            ,list =page_object.action.admin.data['data']['data']['ipv4']['dns_address_list'];
                        inner+='<div class="dialog_row">Вы уверены, что хотите удалить данные?</div>';
                        var dialog_index=page_object.dialog.init({
                            'title':'Инфорамация',
                            'inner':inner,
                            'ok':function(){

                                if(isset($d('tcp_ipv4_dns_item_'+index)))
                                    removeElement($d('tcp_ipv4_dns_item_'+index));

                                for(to_index=index;to_index<list.length-1;to_index++){

                                    from_index=to_index+1;

                                    page_object.action.admin.action.tcp_content.action.dns.v4.rename_index(from_index,to_index)

                                }

                                page_object.action.admin.data['data']['data']['ipv4']['dns_address_list'].splice(index,1);
                                page_object.action.admin.action.tcp_content.action.buttons.is_edit=true;
                                page_object.action.admin.action.tcp_content.action.buttons.set_action();
                                page_object.action.admin.action.tcp_content.action.dns.v4.init();
                                page_object.dialog.action.un_show.init(dialog_index,true);
                            },
                            'cancel':true,
                        });
                    },
                },
            },
            'v6':{
                'init':function(){
                    var  list=page_object.action.admin.data['data']['data']['ipv6']['dns_address_list']
                        ,index;
                    for(index in list){
                        if(isset($d('tcp_ipv6_dns_add_'+index))){

                            $d('tcp_ipv6_dns_add_'+index).onclick =page_object.action.admin.action.tcp_content.action.dns.v6.add;
                            $s('tcp_ipv6_dns_add_'+index).display ='none';

                        }
                        if(isset($d('tcp_ipv6_dns_remove_'+index)))
                            $d('tcp_ipv6_dns_remove_'+index).onclick=page_object.action.admin.action.tcp_content.action.dns.v6.remove.init;
                    }
                    if(isset($d('tcp_ipv6_dns_remove_0')))
                        $s('tcp_ipv6_dns_remove_0').display=(list.length === 1?'none':'inline-block');
                    if(isset($d('tcp_ipv6_dns_add_'+index)))
                        $s('tcp_ipv6_dns_add_'+index).display='inline-block';
                },
                'add':function(){
                    var  index=page_object.action.admin.data['data']['data']['ipv6']['dns_address_list'].length
                        ,el
                        ,inner;
                    page_object.action.admin.data['data']['data']['ipv6']['dns_address_list'].push("");
                    inner =page_object.action.admin.create.tcp.create.get_ipv6_dns(index);
                    el =addElement({
                        'tag':'div',
                        'id':'tcp_ipv6_dns_item_'+index,
                        'class':'tcp_dns_item',
                        'inner':inner,
                    });
                    $d('tcp_ipv6_dns_list').appendChild(el);
                    page_object.action.admin.action.tcp_content.action.buttons.is_edit=true;
                    page_object.action.admin.action.tcp_content.action.buttons.set_action();
                    page_object.action.admin.action.tcp_content.action.dns.v6.init();
                },
                'rename_index':function(from_index,to_index){
                    if(isset($d('tcp_ipv6_dns_item_'+from_index))){
                        $d('tcp_ipv6_dns_item_'+from_index).setAttribute('id','tcp_ipv6_dns_item_'+to_index);
                        $d('tcp_ipv6_dns_address_'+from_index).setAttribute('id','tcp_ipv6_dns_address_'+to_index);
                        $d('tcp_ipv6_mask_'+from_index).setAttribute('id','tcp_ipv6_mask_'+to_index);
                        $d('tcp_ipv6_dns_add_'+from_index).setAttribute('id','tcp_ipv6_dns_add_'+to_index);
                        $d('tcp_ipv6_dns_remove_'+from_index).setAttribute('id','tcp_ipv6_dns_remove_'+to_index);
                    }
                },
                'remove':{
                    'init':function(){
                        var  index =parseInt(this.id.split('_')[4])
                            ,from_index
                            ,to_index
                            ,inner =''
                            ,list =page_object.action.admin.data['data']['data']['ipv6']['dns_address_list'];
                        inner+='<div class="dialog_row">Вы уверены, что хотите удалить данные?</div>';
                        var dialog_index=page_object.dialog.init({
                            'title':'Инфорамация',
                            'inner':inner,
                            'ok':function(){

                                if(isset($d('tcp_ipv6_dns_item_'+index)))
                                    removeElement($d('tcp_ipv6_dns_item_'+index));

                                for(to_index=index;to_index<list.length-1;to_index++){

                                    from_index=to_index+1;

                                    page_object.action.admin.action.tcp_content.action.dns.v6.rename_index(from_index,to_index)

                                }

                                page_object.action.admin.data['data']['data']['ipv6']['dns_address_list'].splice(index,1);
                                page_object.action.admin.action.tcp_content.action.buttons.is_edit=true;
                                page_object.action.admin.action.tcp_content.action.buttons.set_action();
                                page_object.action.admin.action.tcp_content.action.dns.v6.init();
                                page_object.dialog.action.un_show.init(dialog_index,true);
                            },
                            'cancel':true,
                        });
                    },
                },
            }
        },
        'status':{
            'timeout':3000,
            'timeout_event':null,
            'init':function(){
                page_object.action.admin.action.tcp_content.action.status.restart();
            },
            'clean':function(){
                if(!empty(page_object.action.admin.action.tcp_content.action.status.timeout_event))
                    clearTimeout(page_object.action.admin.action.tcp_content.action.status.timeout_event);
            },
            'restart':function(){
                console.log("RESTART");
                page_object.action.admin.action.tcp_content.action.status.clean();
                if(isset($d('tcp_connect_status')))
                    page_object.action.admin.action.tcp_content.action.status.timeout_event=setTimeout(page_object.action.admin.action.tcp_content.action.status.send,page_object.action.admin.action.tcp_content.action.status.timeout);
            },
            'send':function(){
                let post='tcp_name='+uniEncode(page_object.action.admin.data.data.data.tcp_name);
                send({
                    'scriptPath':'/api/json/get_tcp_connect_status',
                    'postData':post,
                    'onComplete':function(j,worktime){
                        var  dataTemp
                            ,data;
                        dataTemp=j.responseText;
                        trace(dataTemp);
                        data=jsonDecode(dataTemp);
                        trace(data);
                        trace_worktime(worktime,data);
                        if(isset(data['error'])){
                            page_object.action.admin.action.tcp_content.action.error.init(data);
                        }
                        else {
                            console.log(data['data']['status']);
                            page_object.action.admin.data.data.data.status=data['data']['status'];
                            if(isset($d('tcp_connect_status')))
                                $d('tcp_connect_status').innerHTML=stripSlashes(data['data']['status']);
                            page_object.action.admin.action.tcp_content.action.status.restart();
                        }
                    }
                });
            }
        },
        'window':{
            'init':function(){
                $w().onfocus=page_object.action.admin.action.tcp_content.action.window.active;
            },
            'active':function(){
                if(isset($d('tcp_content'))){
                    page_object.action.admin.action.tcp_content.action.status.clean();
                    page_object.action.admin.action.tcp_content.action.status.send();
                }
            }
        },
    },
    'remove':function(){
        if(isset($d('tcp_content'))) removeElement($d('tcp_content'));
    },
    'resize':function(){
        if(isset($d('tcp_content'))){
        }
    }
};