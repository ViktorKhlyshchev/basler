page_object.action.admin.action.radar_content={
    'show':function(){

        if(isset($d('radar_content'))) $s('radar_content').opacity=1;

        setTimeout(page_object.link.preload.un_show,300);

    },
    'un_show':function(remove){

        if(isset($d('radar_content'))) $s('radar_content').opacity=0;

        if(isset(remove))
            if(remove)
                setTimeout(page_object.action.admin.action.radar_content.remove,300);

    },
    'action':{
        'action_type':null,
        'init':function(){

            page_object.action.admin.action.radar_content.action.update.init();

            page_object.action.admin.action.radar_content.action.resize();

        },
        'update':{
            'timeout':1,
            'timeout_event':null,
            'init':function(){

                page_object.action.admin.action.radar_content.action.update.restart();

            },
            'reset':function(){

                if(!empty(page_object.action.admin.action.radar_content.action.update.timeout_event))
                    clearTimeout(page_object.action.admin.action.radar_content.action.update.timeout_event);

            },
            'restart':function(){

                if(!isset($d('radar_content')))
                    return;

                page_object.action.admin.action.radar_content.action.update.reset();

                page_object.action.admin.action.radar_content.action.update.timeout_event=setTimeout(page_object.action.admin.action.radar_content.action.update.send,page_object.action.admin.action.radar_content.action.update.timeout);

            },
            'send':function(){

                if(!isset($d('radar_content')))
                    return true;

                var  post='';

                send({
                    'scriptPath':'/api/json/get_update_radar_list',
                    'postData':post,
                    'onComplete':function(j,worktime){

                        var  dataTemp
                            ,data;

                        dataTemp=j.responseText;
                        trace(dataTemp);
                        data=jsonDecode(dataTemp);
                        trace(data);
                        trace_worktime(worktime,data);

                        if(isset(data['error'])){

                            page_object.link.preload.un_show();

                        }
                        else{

                            let  index, list=data['data']['list'];

                            page_object.action.admin.data['data']['list'] = data['data']['list'];

                            if(isset($d('radar_list')))
                                $d('radar_list').innerHTML='';

                            for(index in list){

                                let  inner =page_object.action.admin.create.radar.create.get_radar_row(index)
                                    ,el =addElement({
                                        'tag':'div',
                                        'id':'radar_item_'+list[index]['id'],
                                        'class':'radar_item',
                                        'inner':inner
                                    });

                                if(isset($d('radar_list')))
                                    $d('radar_list').appendChild(el);

                                $d('radar_table_block').setAttribute('class','radar_table_block');

                            }

                            if(list.length === 0)
                                $d('radar_list').innerHTML='<div id="radar_info" class="radar_info">Нет данных</div>';

                            page_object.action.admin.action.radar_content.action.init();

                        }

                        page_object.action.admin.action.radar_content.action.update.restart();

                    }
                });

            },
            'prepare':function(){},
        },
        'resize':function(){

            if(isset($d('radar_list'))){

                let  list = $d('radar_list').getElementsByClassName('radar_item')
                    ,index;

                for(index in list)
                    if(isObject(list[index])){

                        let  el_list =list[index].getElementsByClassName('radar_item_col')
                            ,el_index
                            ,el_h =list[index].scrollHeight;

                        for(el_index in el_list)
                            if(isObject(el_list[el_index]))
                                el_list[el_index].style.height=el_h+'px';

                    }

            }

        }
    },
    'remove':function(){

        if(isset($d('radar_content'))) removeElement($d('radar_content'));

    },
    'resize':function(){

        if(isset($d('radar_content'))){

        }

    }
};