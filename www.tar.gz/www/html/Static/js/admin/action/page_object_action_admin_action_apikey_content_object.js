cl = console.log;
page_object.action.admin.data.data
page_object.action.admin.action.apikey_content={
    'show':function(){
        if(isset($d('apikey_content'))) $s('apikey_content').opacity=1;
        setTimeout(page_object.link.preload.un_show,300);
    },
    'un_show':function(remove){
        if(isset($d('apikey_content'))) $s('apikey_content').opacity=0;
        if(isset(remove)) if(remove) setTimeout(page_object.action.admin.action.apikey_content.remove,300);
    },
    'action':{
        'action_type':null,
        'init':function(){ cl('apikey action loaded');

            page_object.action.admin.action.apikey_content.action.none.init();

            page_object.action.admin.action.apikey_content.action.download.init();
            page_object.action.admin.action.apikey_content.action.add.init();
            page_object.action.admin.action.apikey_content.action.edit.init();
            page_object.action.admin.action.apikey_content.action.remove.init();
            page_object.action.admin.action.apikey_content.action.resize();

        },
        'none':{
            'init':function(){
                cl(page_object.action.admin.data);

                if(page_object.action.admin.data['data']['apikey_list'].length === 0){

                    if(isset($d('apikey_info'))) $d('apikey_info').setAttribute('class','apikey_info');
                    if(isset($d('apikey_container'))) $d('apikey_container').setAttribute('class','apikey_container_hide');

                } else {

                    if(isset($d('apikey_info')))
                        $d('apikey_info').setAttribute('class','apikey_info_hide');

                    if(isset($d('apikey_container')))
                        $d('apikey_container').setAttribute('class','apikey_container');

                }

            }
        },
        'add':{
            'index':null,
            'init':function(){
                cl(isset($d('apikey_add')));
                if(isset($d('apikey_add'))) $d('apikey_add').onclick=page_object.action.admin.action.apikey_content.action.add.box.init;

            },
            'box':{
                'dialog_index':null,
                'init':function(){ // page_object.action.admin.action.apikey_content.action.add.box.init

                    let  inner='';

                    inner+='<div class="dialog_row">';
                        inner+='<div class="dialog_row_label" style="width: 240px;">';
                            inner+='<span>Название ключа</span>';
                        inner+='</div>';
                        inner+='<div class="dialog_row_input" style="width: 360px;">';
                            inner+='<input type="text" id="dialog_name_input_text" class="dialog_row_input_text" value="" />';
                        inner+='</div>';
                    inner+='</div>';

                    page_object.action.admin.action.apikey_content.action.add.box.dialog_index=page_object.dialog.init({
                        'title':'Добавление нового',
                        'inner':inner,
                        'w':600,
                        'add':function(){
                            page_object.action.admin.action.apikey_content.action.add.save.init();
                        },
                        'cancel':true,
                        'on_create':function(dialog_index){
                            page_object.action.admin.action.apikey_content.action.edit.box.input.init(dialog_index);
                        }
                    });

                }
            },
            'save':{
                'init':function(){ // page_object.action.admin.action.apikey_content.action.add.save.init
                    let is_error=page_object.action.admin.action.apikey_content.action.edit.save.check_error();
                    if(!is_error) page_object.action.admin.action.apikey_content.action.add.save.send();

                },
                'error':function(data){

                    page_object.action.admin.action.apikey_content.action.edit.test_apikeyion.error();

                },
                'send':function(){

                    var  index
                        ,data =page_object.action.admin.data['data']
                        ,apikey_list =data['apikey_list']
                        ,apikey_data =apikey_list[index]
                        ,post ='';

                    page_object.link.preload.show();

                    post+='&name='+uniEncode($v('dialog_name_input_text'));

                    send({
                        'scriptPath':'/api/json/add_apikey',
                        'postData':post,
                        'onComplete':function(j,worktime){

                            var  dataTemp, data;

                            dataTemp=j.responseText;
                            trace(dataTemp);
                            data=jsonDecode(dataTemp);
                            trace(data);
                            trace_worktime(worktime,data);

                            if(isset(data['error'])){

                                page_object.link.preload.un_show();

                            } else {

                                let data_obj={
                                    'id':data['data']['id'],
                                    'ip_list':data['data']['ip_list'],
                                    'name':$v('dialog_name_input_text'),
                                    'date_create':data['data']['date_create'],
                                    'tar_file':data['data']['tar_file']
                                };

                                page_object.action.admin.action.apikey_content.action.add.index=page_object.action.admin.data['data']['apikey_list'].length;

                                page_object.action.admin.data['data']['apikey_list'].push(data_obj);

                                page_object.action.admin.action.apikey_content.action.add.save.prepare();

                            }

                        }
                    });

                },
                'prepare':function(){

                    var  index =page_object.action.admin.action.apikey_content.action.add.index
                        ,dialog_index =(page_object.action.admin.action.apikey_content.action.action_type === 'add')
                            ?page_object.action.admin.action.apikey_content.action.add.box.dialog_index
                            :page_object.action.admin.action.apikey_content.action.edit.box.dialog_index
                        ,inner =page_object.action.admin.create.apikey.create.get_apikey_row(index)
                        ,el =addElement({
                            'tag':'div',
                            'id':'apikey_item_'+index,
                            'class':'apikey_item',
                            'inner':inner
                        });

                    if(isset($d('apikey_list'))) $d('apikey_list').appendChild(el);

                    page_object.action.admin.action.apikey_content.action.init();

                    page_object.dialog.action.un_show.init(dialog_index,true);
                    page_object.link.preload.un_show();

                }
            }
        },
        'edit':{
            'index':null,
            'init':function(){

                let  list=page_object.action.admin.data['data']['apikey_list']
                    ,index;

                for(index in list)
                    if(isset($d('apikey_item_edit_button_'+index)))
                        $d('apikey_item_edit_button_'+index).onclick=page_object.action.admin.action.apikey_content.action.edit.box.init;

            },
            'box':{
                'dialog_index':null,
                'init':function(){  // page_object.action.admin.action.apikey_content.action.add.box.init
                    cl(333333);
                    let  inner =''
                        ,id_list =this.id.split('_')
                        ,data =page_object.action.admin.data['data']
                        ,apikey_list =data['apikey_list']
                        ,apikey_data =apikey_list[parseInt(id_list[4])];

                    page_object.action.admin.action.apikey_content.action.edit.index=parseInt(id_list[4]);

                    inner+='<div class="dialog_row">';
                        inner+='<div class="dialog_row_label" style="width: 240px;">';
                            inner+='<span>Название ключей</span>';
                        inner+='</div>';
                        inner+='<div class="dialog_row_input" style="width: 360px;">';
                            inner+='<input type="text" id="dialog_name_input_text" class="dialog_row_input_text" value="'+stripSlashes(empty(apikey_data['name'])?'':apikey_data['name'])+'" />';
                        inner+='</div>';
                    inner+='</div>';

                    page_object.action.admin.action.apikey_content.action.edit.box.dialog_index=page_object.dialog.init({
                        'title':'Редактирование ключей',
                        'inner':inner,
                        'w':600,
                        'save':function(){

                            page_object.action.admin.action.apikey_content.action.edit.save.init(page_object.action.admin.action.apikey_content.action.edit.box.dialog_index);

                        },
                        'cancel':true,
                        'on_create':function(dialog_index){

                            page_object.action.admin.action.apikey_content.action.edit.box.input.init(dialog_index);

                        }
                    });

                },
                'input':{
                    'init':function(dialog_index){ cl(dialog_index);

                        if(isset($d('dialog_submit_save_'+dialog_index)))
                            page_object.action.admin.action.apikey_content.action.action_type='edit';

                        if(isset($d('dialog_submit_add_'+dialog_index)))
                            page_object.action.admin.action.apikey_content.action.action_type='add';

                        if(isset($d('dialog_name_input_text'))){

                            $d('dialog_name_input_text').onapikeyup =page_object.action.admin.action.apikey_content.action.edit.box.input.action;
                            $d('dialog_name_input_text').onchange =page_object.action.admin.action.apikey_content.action.edit.box.input.action;
                            $d('dialog_name_input_text').onfocus =page_object.action.admin.action.apikey_content.action.edit.box.input.action;
                            $d('dialog_name_input_text').onblur =page_object.action.admin.action.apikey_content.action.edit.box.input.action;

                        }

                    },
                    'apikeypress':function(e){

                        e=window.event || e;

                        let val=getCharFromEventapikey(e);

                        switch(this.id){

                            default:{

                                this.style.border='1px solid #1b93db';

                                break;

                            }

                        }

                    },
                    'action':function(){

                        switch(this.id){

                            case 'dialog_name_input_text':{

                                if(!empty(this.value)){

                                    this.style.border='1px solid #16f52f';

                                    return true;

                                }

                                this.style.border='1px solid #ff0000';

                                return false;

                            }

                        }

                    }
                }
            },
            'save':{
                'check_error':function(){

                    let is_error=false;

                    if(isset($d('dialog_name_input_text'))){

                        if(empty($v('dialog_name_input_text'))){

                            $s('dialog_name_input_text').border='1px solid #ff0000';

                            is_error=true;

                        }

                    }

                    return is_error;

                },
                'init':function(){
                    let is_error=page_object.action.admin.action.apikey_content.action.edit.save.check_error();  cl('is_error');         cl(is_error);
                    if(!is_error) page_object.action.admin.action.apikey_content.action.edit.save.send();
                },
                'send':function(){

                    var  index =page_object.action.admin.action.apikey_content.action.edit.index
                        ,data =page_object.action.admin.data['data']
                        ,apikey_list =data['apikey_list']
                        ,apikey_data =apikey_list[index]
                        ,post ='';

                    page_object.link.preload.show();

                    post+='&apikey_id='+uniEncode(apikey_data['id']);
                    post+='&name='+uniEncode($v('dialog_name_input_text'));

                    send({
                        'scriptPath':'/api/json/save_apikey',
                        'postData':post,
                        'onComplete':function(j,worktime){

                            var  dataTemp, data;

                            dataTemp=j.responseText;
                            trace(dataTemp);
                            data=jsonDecode(dataTemp);
                            trace(data);
                            trace_worktime(worktime,data);

                            if(isset(data['error'])){

                                page_object.action.admin.action.apikey_content.action.edit.save.error(data);
                                page_object.link.preload.un_show();

                            } else {

                                let index=page_object.action.admin.action.apikey_content.action.edit.index;

                                // trace('_1');
                                page_object.action.admin.data['data']['apikey_list'][index]['name'] = $v('dialog_name_input_text');
                                // trace('_2');
                                //page_object.action.admin.data['data']['apikey_list'][index]['ip_list'] =data['data']['ip_list'];
                                // trace('_3');

                                page_object.action.admin.action.apikey_content.action.edit.save.prepare();
                                /*let dialog_index = page_object.action.admin.action.apikey_content.action.edit.box.dialog_index;
                                page_object.dialog.action.un_show.init(dialog_index,true);
                                page_object.link.preload.un_show();*/
                            }
                        }
                    });

                },
                'prepare':function(){
                    //cl(3214121); return;
                    var  index =page_object.action.admin.action.apikey_content.action.edit.index
                        ,dialog_index =(page_object.action.admin.action.apikey_content.action.action_type === 'add')
                            ?page_object.action.admin.action.apikey_content.action.add.box.dialog_index
                            :page_object.action.admin.action.apikey_content.action.edit.box.dialog_index
                        ,data =page_object.action.admin.data['data']
                        ,apikey_list =data['apikey_list']
                        ,apikey_data =apikey_list[index];

                    if(isset($d('apikey_item_'+index))){  cl(88888888);
                        $d('apikey_item_name_'+index).innerHTML='<span>'+stripSlashes(apikey_data['name'])+'</span>';
                        //$d('apikey_item_use_'+index).innerHTML='<span>'+stripSlashes(apikey_data['ip_list'].length === ''?'':implode(', ',apikey_data['ip_list']))+'</span>'; cl(86768687);
                       // cl($d('apikey_item_use_'+index));
                        //$d('apikey_item_use_'+index).innerHTML='<span>'+'</span>'; cl(86768687);
                    } cl(66666666663214121);
                    page_object.dialog.action.un_show.init(dialog_index,true);
                    page_object.link.preload.un_show();
                }
            }
        },
        'download':{
            'init':function(){

                let  list=page_object.action.admin.data['data']['apikey_list']
                    ,index;

                for(index in list)
                    if(isset($d('apikey_item_download_button_'+index)))
                        $d('apikey_item_download_button_'+index).onclick=page_object.action.admin.action.apikey_content.action.download.action;

            },
            'action':function(){

                let  index =this.id.split('_')[4]
                    ,apikey_list =page_object.action.admin.data['data']['apikey_list']

                window.open(apikey_list[index]['tar_file'],"_blank");

            }
        },
        'remove':{
            'init':function(){

                let  list =page_object.action.admin.data['data']['apikey_list']
                    ,index;

                for(index in list)
                    if(isset($d('apikey_item_remove_button_'+index)))
                        $d('apikey_item_remove_button_'+index).onclick=page_object.action.admin.action.apikey_content.action.remove.box.init;

            },
            'box':{
                'init':function(){

                    let  inner =''
                        ,index =this.id.split('_')[4]
                        ,data =page_object.action.admin.data['data']
                        ,apikey_data =data['apikey_list'][index];

                    inner+='<div class="dialog_row">';
                        inner+='Удалить ключ с названием: '+apikey_data['name']+'?';
                    inner+='</div>';

                    var dialog_index=page_object.dialog.init({
                        'title':'Удаление ключей',
                        'inner':inner,
                        'remove':function(){

                            page_object.action.admin.action.apikey_content.action.remove.remove.init(dialog_index,index);

                        },
                        'on_create':function(){

                        },
                        'cancel':true
                    });

                }
            },
            'action':{
                'move_down':function(){

                    let  list =page_object.action.admin.data['data']['apikey_list']
                        ,list_len =list.length
                        ,index_from
                        ,index_to;

                    for(index_to=list_len;index_to>0;index_to--){

                        index_from=parseInt(index_to)-1;

                        page_object.action.admin.action.apikey_content.action.remove.action.rename_index(index_from,index_to);

                    }

                },
                'move_up':function(index){

                    let  list =page_object.action.admin.data['data']['apikey_list']
                        ,list_len =list.length
                        ,index_from
                        ,index_to;

                    for(index_to=index;index_to<list_len;index_to++){

                        index_from=parseInt(index_to)+1;

                        page_object.action.admin.action.apikey_content.action.remove.action.rename_index(index_from,index_to);

                    }

                },
                'rename_index':function(index_from,index_to){

                    if(isset($d('apikey_item_'+index_from))){

                        $d('apikey_item_'+index_from).setAttribute('id','apikey_item_'+index_to);

                        $d('apikey_item_name_'+index_from).setAttribute('id','apikey_item_name_'+index_to);
                        $d('apikey_item_use_'+index_from).setAttribute('id','apikey_item_use_'+index_to);
                        $d('apikey_item_date_create_'+index_from).setAttribute('id','apikey_item_date_create_'+index_to);
                        $d('apikey_item_edit_button_'+index_from).setAttribute('id','apikey_item_edit_button_'+index_to);
                        $d('apikey_item_remove_button_'+index_from).setAttribute('id','apikey_item_remove_button_'+index_to);

                    }

                }
            },
            'remove':{
                'init':function(dialog_index,index){

                    page_object.action.admin.action.apikey_content.action.remove.remove.send(dialog_index,index);

                },
                'send':function(dialog_index,index){

                    var lang_obj=page_object.action.admin.content[page_object.lang];

                    if(isset($d('dialog_submit_remove_'+dialog_index))){

                        $d('dialog_submit_remove_'+dialog_index).setAttribute('class','dialog_submit_disable');

                        $d('dialog_submit_remove_'+dialog_index).innerHTML =lang_obj['wait'];
                        $d('dialog_submit_remove_'+dialog_index).onclick =function(){};

                    }

                    if(isset($d('dialog_submit_cancel_'+dialog_index))){

                        $d('dialog_submit_cancel_'+dialog_index).setAttribute('class','dialog_submit_disable');

                        $d('dialog_submit_cancel_'+dialog_index).onclick=function(){};

                    }

                    let  post =''
                        ,list =page_object.action.admin.data['data']['apikey_list']
                        ,data =list[index];

                    post+='apikey_id='+uniEncode(data['id']);

                    send({
                        'scriptPath':'/api/json/remove_apikey',
                        'postData':post,
                        'onComplete':function(j,worktime){

                            let  dataTemp, data;

                            dataTemp=j.responseText;
                            trace(dataTemp);
                            data=jsonDecode(dataTemp);
                            trace(data);
                            trace_worktime(worktime,data);

                            if(isset(data['error'])){

                                if($d('dialog_submit_remove_'+dialog_index)){

                                    $d('dialog_submit_remove_'+dialog_index).onclick=function(){

                                        page_object.action.admin.action.apikey_content.action.remove.remove.init(dialog_index,index);

                                    };
                                    $d('dialog_submit_remove_'+dialog_index).setAttribute('class','dialog_submit_remove');
                                    $d('dialog_submit_remove_'+dialog_index).innerHTML=lang_obj['remove'];

                                }

                                if($d('dialog_submit_cancel_'+dialog_index)){

                                    $d('dialog_submit_cancel_'+dialog_index).onclick=function(){

                                        page_object.dialog.action.un_show.init(dialog_index,true);

                                    };
                                    $d('dialog_submit_cancel_'+dialog_index).setAttribute('class','dialog_submit_cancel');

                                }

                            }
                            else
                                page_object.action.admin.action.apikey_content.action.remove.remove.prepare(dialog_index,index);

                        }
                    });

                },
                'prepare':function(dialog_index,index){

                    if(isset($d('apikey_item_'+index)))
                        removeElement($d('apikey_item_'+index));

                    page_object.action.admin.data['data']['apikey_list'].splice(index,1);

                    page_object.action.admin.action.apikey_content.action.remove.action.move_up(index);
                    page_object.dialog.action.un_show.init(dialog_index,true);

                    page_object.action.admin.action.apikey_content.action.init();

                }
            }
        },
        'resize':function(){

            if(isset($d('apikey_list'))){

                let  list = $d('apikey_list').getElementsByClassName('apikey_item')
                    ,index;

                for(index in list)
                    if(isObject(list[index])){

                        let  el_list =list[index].getElementsByClassName('apikey_item_col')
                            ,el_index
                            ,el_h =list[index].scrollHeight;

                        for(el_index in el_list)
                            if(isObject(el_list[el_index]))
                                el_list[el_index].style.height=el_h+'px';

                    }

            }

            if(isset($d('admin_menu'))) $s('admin_menu').height=elementSize.height($d('all'))+'px';

        }
    },
    'remove':function(){

        if(isset($d('apikey_content'))) removeElement($d('apikey_content'));

    },
    'resize':function(){

        if(isset($d('apikey_content'))){

        }

    }
};