cl = console.log;

cl(g);
cl('GGGGGGGGGGGGGGGGGGGGG123'); // 'control_zone'
cl(page_object.action.admin.data);
                       /* 'start': function(e){ // page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.start
                            if(!isset($d('zones_video_container'))) return false;
                            let  mouse_position = page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.get_point_position(e)
                                , mouse_x = mouse_position['x']
                                , mouse_y = mouse_position['y'];

                            page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.point_start_x = mouse_x;
                            page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.point_start_y = mouse_y;

                            if(isset($d('zones_video_container'))){
                                $d('zones_video_container').onmousemove = page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.move;
                                $w().onmouseup = page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.up;
                            }
                            return false;
                        },*/




/*
                            let  mouse_position = page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.get_point_position(e)
                                , mouse_x = mouse_position['x']
                                , mouse_y = mouse_position['y'];

                            if(isset($d('zones_video_container'))){
                                $d('zones_video_container').onmousemove = function(){};
                                $d('zones_video_container').onmouseup = function(){};
                            }

                            page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.point_start_x = mouse_x;
                            page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.point_start_y = mouse_y;

                            page_object.action.admin.action.zones_content.action.zone.is_edit = true;
                            // page_object.action.admin.action.zones_content.action.zone.canvas.is_edit = true;

                            page_object.action.admin.action.zones_content.action.zone.controls();
                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.controls();
                            return false;
*/
var test_colour_line = 'green';
var test_colour_point ='blue';
var test_colour_text ='orange'

$('body').on('keydown', function(e){ //cl(page_object.action.admin.action.zones_content.move_mode);
    if(page_object.action.admin.action.zones_content.move_mode){
        if(e.key === 'ArrowLeft') page_object.action.admin.action.zones_content.on_kmove('l');
        if(e.key === 'ArrowUp') page_object.action.admin.action.zones_content.on_kmove('u');
        if(e.key === 'ArrowRight') page_object.action.admin.action.zones_content.on_kmove('r');
        if(e.key === 'ArrowDown') page_object.action.admin.action.zones_content.on_kmove('d');
        return false;
    }
});

page_object.action.admin.action.zones_content = {

    saved: {}, // page_object.action.admin.action.zones_content.active_layer
    savedr: {},
    active_layer : null, //'zone set_active' 'control_zone' 'move' 4
    move_mode: false,

    'point': {
        'radius': {
            'default':2,
            'hover':5,
        }
    },
    'line': {
        'width': {
            'default':1,
            'hover':4,
        }
    },

    'on_kmove': function(dir){ // keyboard move // page_object.action.admin.action.zones_content.action.zone.canvas.point.init; mouse.start        cl(321);
        if(!isset($d('zone_point'))) return false;
        let p = $('.zone_point').css('transform').replace('matrix(', '').replace(')', '').replace(' ', '').split(','); //matrix(1, 0, 0, 1, 294, 200)
        //cl(p);
        //cl(parseInt(p[4]));        cl(p[5]);
        let x = parseInt(p[4]);
        let y = parseInt(p[5]);
        let   point_start_x = x
            , point_start_y = y
            , mouse_x = x
            , mouse_y = y
            , el_w = elementSize.width($d('zones_video_container'))
            , el_h = elementSize.height($d('zones_video_container'));

        if(mouse_x < 0) mouse_x = 0;
        if(mouse_y < 0) mouse_y = 0;
        if(mouse_x > el_w) mouse_x = el_w;
        if(mouse_y > el_h) mouse_y = el_h;
        switch(dir){
            case 'l': { mouse_x-=1; break; }
            case 'r': { mouse_x+=1; break; }
            case 'u': { mouse_y-=1; break; }
            case 'd': { mouse_y+=1; break; }
        }
                    /*        let  el
                                , container_w = elementSize.width($d('zones_video_container'))
                                , container_h = elementSize.height($d('zones_video_container'))
                                , point_x = parseInt(container_w/2)
                                , point_y = parseInt(container_h/2);

                            el = addElement({'tag': 'div', 'id': 'zone_point', 'class': 'zone_point', 'style': 'transform: translate('+ point_x +'px, '+ point_y +'px)'});
*/

        /*page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.point_x = mouse_x;
        page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.point_y = mouse_y;
        page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.point_start_x = mouse_x;
        page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.point_start_y = mouse_y;*/

        $s('zone_point').transform='translate('+mouse_x+'px, '+mouse_y+'px)';

        let  list = page_object.action.admin.action.zones_content.action.zone.canvas.move_list, key
            , current_list = Object.assign({}, list)
            , line_index
            , index
            , point_delta_x = mouse_x-point_start_x
            , point_delta_y = mouse_y-point_start_y;  /*cl('key');  cl('key');  cl(key);*/
        //cl('page_object.action.admin.action.zones_content.active_layer');                                cl(page_object.action.admin.action.zones_content.active_layer);
        for(key in list){  //cl('key');                                    cl('key');                                    cl(key);

            if(page_object.action.admin.action.zones_content.active_layer !== null &&
                page_object.action.admin.action.zones_content.active_layer !== 'control_zone' &&
                key !== page_object.action.admin.action.zones_content.active_layer
            ) continue;

            if(!isset(current_list[key])) current_list[key] = {'layer_list':[]};

            for(line_index in list[key]['layer_list']){

                if(!isset(current_list[key]['layer_list'][line_index])) current_list[key]['layer_list'][line_index] = {'point_list':[]};

                if(isset(page_object.action.admin.action.zones_content.action.zone.canvas.move_list[key]['layer_list'][line_index]['point_intersection'])){
                    current_list[key]['layer_list'][line_index]['point_intersection']['x']+= Math.round(point_delta_x);
                    current_list[key]['layer_list'][line_index]['point_intersection']['y']+= Math.round(point_delta_y);
                }

                for(index in list[key]['layer_list'][line_index]['point_list']){
                    current_list[key]['layer_list'][line_index]['point_list'][index]['x']+= Math.round(point_delta_x);
                    current_list[key]['layer_list'][line_index]['point_list'][index]['y']+= Math.round(point_delta_y);
                }
            }
        }

        page_object.action.admin.action.zones_content.action.zone.canvas.move_list = Object.assign({}, current_list);
        page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw_all();

        /*if(isset($d('zones_video_container'))){
            $d('zones_video_container').onmousemove = function(){};
            $d('zones_video_container').onmouseup = function(){};
        }
        page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.point_start_x = mouse_x;
        page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.point_start_y = mouse_y;
        // page_object.action.admin.action.zones_content.action.zone.canvas.is_edit = true;*/
        page_object.action.admin.action.zones_content.action.zone.is_edit = true;
        page_object.action.admin.action.zones_content.action.zone.controls();
        page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.controls();
    },

    'show': function(){

        page_object.action.admin.data['zones_backup'] = clone_object(page_object.action.admin.data['zones']);

        page_object.action.admin.action.zones_content.action.zone.is_edit = false;
        page_object.action.admin.action.zones_content.action.zone.canvas.is_edit = false;

        page_object.action.admin.action.zones_content.action.zone.canvas.show_center.un_show();

        if(isset($d('zones_content'))) $s('zones_content').opacity = 1;

        setTimeout(page_object.link.preload.un_show, 300);

    },
    'un_show': function(remove){

        if(isset($d('zones_content'))) $s('zones_content').opacity = 0;
        if(isset(remove)) if(remove) setTimeout(page_object.action.admin.action.zones_content.remove, 300);

    },
    'action': {
        'init': function(){

            page_object.action.admin.action.zones_content.action.camera_menu.init();
            page_object.action.admin.action.zones_content.action.zone.init();
            page_object.action.admin.action.zones_content.action.window.init();
            page_object.action.admin.action.zones_content.action.zoom.init();
            page_object.action.admin.action.zones_content.action.zone.canvas.show_center.reset();

        },
        'load': {
            'show': function(){
                if(isset($d('config_work_mask'))){
                    $s('config_work_mask').display ='block';
                    $d('config_work_mask').innerHTML ='<span>Загрузка...</span>';
                }
            },
            'un_show': function(){
                if(isset($d('config_work_mask'))){
                    $s('config_work_mask').display ='none';
                    $d('config_work_mask').innerHTML ='<span>Загрузка...</span>';
                }
            }
        },
        'window': {
            'is_active':false,
            'init': function(){
                $w().onfocus = page_object.action.admin.action.zones_content.action.window.active;//$w().onblur = page_object.action.admin.action.zones_content.action.window.no_active;

                page_object.action.admin.action.zones_content.action.window.video.timer.remove();
                page_object.action.admin.action.zones_content.action.window.video.init();

            },
            'active': function(){

                if(!page_object.action.admin.action.zones_content.action.window.is_active){
                    page_object.action.admin.action.zones_content.action.window.is_active = true;

                    if(isset(page_object.action.admin.action.zones_content.action.window.video.timer.dialog_index))
                        page_object.dialog.action.un_show.init(page_object.action.admin.action.zones_content.action.window.video.timer.dialog_index, true);

                    page_object.action.admin.action.zones_content.action.window.video.timer.init();
                    page_object.action.admin.action.zones_content.action.window.video.show();
                }
            },
            'no_active': function(){

                if(page_object.action.admin.action.zones_content.action.window.is_active){
                    page_object.action.admin.action.zones_content.action.window.is_active = false;
                    page_object.action.admin.action.zones_content.action.window.video.un_show();
                }
            },
            'video': {
                'init': function(){
                    page_object.action.admin.action.zones_content.action.window.video.timer.init();
                },
                'timer': {
                    'timeout': 180000,                    // 'timeout':5000,
                    'timeout_event':null,
                    'dialog_index':null,
                    'init': function(){
                        page_object.action.admin.action.zones_content.action.window.video.timer.reset();
                        page_object.action.admin.action.zones_content.action.window.video.timer.mouse.init();
                    },
                    'mouse': {
                        'init': function(){
                            if(isset($d('all'))) $d('all').onmousemove = page_object.action.admin.action.zones_content.action.window.video.timer.mouse.action;
                        },
                        'action': function(){
                            if(page_object.action.admin.data['action'] === 'admin_zones_item'){
                                if(isset($d('zone_video_iframe'))) page_object.action.admin.action.zones_content.action.window.video.timer.reset();
                            } else $d('all').onmousemove = function(){};
                        }
                    },
                    'remove': function(){

                        if(isset(page_object.action.admin.action.zones_content.action.window.video.timer.timeout_event))
                            page_object.action.admin.action.zones_content.action.window.video.timer.timeout_event = clearTimeout(page_object.action.admin.action.zones_content.action.window.video.timer.timeout_event);

                    },
                    'reset': function(){
                        page_object.action.admin.action.zones_content.action.window.video.timer.remove();
                        page_object.action.admin.action.zones_content.action.window.video.timer.start();

                    },
                    'start': function(){ //cl('page_object');                        cl(page_object);
                        if(loc) //                        cl(location.href);
                            page_object.action.admin.action.zones_content.action.window.video.timer.timeout_event = setTimeout(
                                    page_object.action.admin.action.zones_content.action.window.video.timer.action,
                                    page_object.action.admin.action.zones_content.action.window.video.timer.timeout
                                );
                    },
                    'action': function(){

                        if(isset($d('zone_zoom'))){
                            page_object.action.admin.action.zones_content.action.window.video.timer.reset();
                            return false;
                        }

                        page_object.action.admin.action.zones_content.action.window.video.un_show();

                        if(isset($d('zone_video_container_inner'))){
                            var  inner =''; //dialog_index,
                            if(loc) inner+= '<div class="dialog_row">Поток видео остановлен всвязи с бездействием. Для продолжения работы закройте диалоговое окно. #2</div>'; else
                            inner+= '<div class="dialog_row">Поток видео остановлен всвязи с бездействием. Для продолжения работы закройте диалоговое окно.</div>';

                            if(!loc) page_object.action.admin.action.zones_content.action.window.video.timer.dialog_index = page_object.dialog.init({
                                'title': 'Информация',
                                'inner':inner,
                                'ok': function(){
                                    page_object.action.admin.action.zones_content.action.window.video.timer.recovery();
                                },
                                'on_cancel': function(){
                                    page_object.action.admin.action.zones_content.action.window.video.timer.recovery();
                                }
                            });
                        }
                    },

                    'recovery': function(){
                        page_object.action.admin.action.zones_content.action.window.video.show();
                        page_object.action.admin.action.zones_content.action.window.video.timer.reset();
                        page_object.dialog.action.un_show.init(page_object.action.admin.action.zones_content.action.window.video.timer.dialog_index, true);
                    }
                },
                'show': function(){ //trace('');//trace('WINDOW ACTIVE'); //trace('');

                    if(isset($d('zone_video_container_inner'))){
                        if(!isset($d('zone_video_iframe'))){
                            let  data = page_object.action.admin.data['zones'], camera_data = data['camera_data']
                                , inner ='<iframe id="zone_video_iframe" src="'+camera_data['video_link']+'" width="100%" style="border: none; outline: none; line-height: 0;"></iframe>';

                            $d('zone_video_container_inner').innerHTML = inner;

                            if(!empty(page_object.action.admin.action.zones_content.action.window.video.timer.dialog_index))
                                page_object.dialog.action.un_show.init(page_object.action.admin.action.zones_content.action.window.video.timer.dialog_index, true);
                            page_object.action.admin.action.zones_content.action.window.video.timer.reset();
                        }
                    }
                    if(isset($d('zones_video_canvas_list'))) $s('zones_video_canvas_list').display='block';
                },
                'un_show': function(){ //trace(''); //trace('WINDOW NOT ACTIVE'); //trace('');
                    if(isset($d('zone_video_container_inner'))) $d('zone_video_container_inner').innerHTML='';
                    if(isset($d('zones_video_canvas_list'))) $s('zones_video_canvas_list').display='none';
                }
            },
            'stop': function(){
                $w().onfocus = null; //$w().onblur = null;
                $w().onfocus = function(){}; //$w().onblur = function(){};
                page_object.action.admin.action.zones_content.action.window.video.timer.timeout_event = clearTimeout(page_object.action.admin.action.zones_content.action.window.video.timer.timeout_event);
            },
        },
        'iframe': {
            'check_size': function(h){
                if(isset($d('zone_video_iframe'))) $d('zone_video_iframe').height = h;
                if(isset($d('zone_video_container_inner'))) $d('zone_video_container_inner').height = h;
            }
        },
        'camera_menu': {
            'init': function(){

                let  data = page_object.action.admin.data['zones'], camera_list = data['camera_list'], index;

                for(index in camera_list)
                    if(!camera_list[index]['is_hide'] &&! camera_list[index]['is_disable'])
                        if(isset($d('camera_menu_item_'+index))) $d('camera_menu_item_'+index).onclick = page_object.action.admin.action.zones_content.action.camera_menu.click;

            },
            'click': function(){

                let  data = page_object.action.admin.data['zones'], camera_list = data['camera_list']
                    , index = parseInt(this.id.split('_')[3])
                    , lang_obj = page_object.content[page_object.lang]
                    , link ='/admin/'+page_object.action.admin.data['user']['login']+'/zones/'+camera_list[index]['camera_id'];

                page_object.action.admin.action.zones_content.action.camera_menu.set_active(index);
                setUrl(lang_obj['title']+' | '+lang_obj['loading'], link);
            },

            'set_active': function(i){ //cl('camera set_active'); camera_id

                let  data = page_object.action.admin.data['zones']
                    , camera_list = data['camera_list'], index;

                for(index in camera_list)
                    if(!camera_list[index]['is_hide']){
                        if(camera_list[index]['is_disable']){
                            $d('camera_menu_item_'+index).setAttribute('class', 'camera_menu_item_disable');
                            $d('camera_menu_item_'+index).onclick = function(){};
                        } else if(parseInt(i) === parseInt(index)){
                            $d('camera_menu_item_'+index).setAttribute('class', 'camera_menu_item_active');
                            $d('camera_menu_item_'+index).onclick = function(){};

                        } else {
                            $d('camera_menu_item_'+index).setAttribute('class', 'camera_menu_item');
                            $d('camera_menu_item_'+index).onclick = page_object.action.admin.action.zones_content.action.camera_menu.click;
                        }
                    }
            }
        },
        'zone': { // page_object.action.admin.action.zones_content.action.zone
            'is_edit':false,
            'init': function(){
                let  list, index;
                // page_object.action.admin.action.zones_content.action.zone.is_edit = false;
                // page_object.action.admin.action.zones_content.action.zone.canvas.is_edit = false;

                if(isArray(page_object.action.admin.data['zones']['zone_list'])) page_object.action.admin.data['zones']['zone_list'] = {};

                if(isset($d('zones_menu_line_list'))){
                    list = $d('zones_menu_line_list').getElementsByTagName('div');
                    for(index in list)
                        if(isObject(list[index]))
                            list[index].onclick = page_object.action.admin.action.zones_content.action.zone.choose_type.init;
                }

                if(isset($d('zones_menu_type_list'))){
                    list = $d('zones_menu_type_list').getElementsByTagName('div');
                    for(index in list)
                        if(isObject(list[index]))
                            list[index].onclick = page_object.action.admin.action.zones_content.action.zone.choose_type.init;
                }

                if(isset($d('zones_control_choose'))){
                    $d('zones_control_choose').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.choose.init;
                    $d('zones_control_choose').setAttribute('class', 'zones_control_item_disable');
                }

                if(isset($d('zones_control_center'))){
                    $d('zones_control_center').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.show_center.init;
                    $d('zones_control_center').setAttribute('class', 'zones_control_item');
                }

                if(isset($d('zones_control_draw'))){
                    $d('zones_control_draw').setAttribute('class', 'zones_control_item_disable');
                    $d('zones_control_draw').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.init;
                }

                if(isset($d('zones_control_arrow'))){
                    $d('zones_control_arrow').setAttribute('class', 'zones_control_item_up_disable');
                    $s('zones_control_arrow').display ='none';
                    $d('zones_control_arrow').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.arrow.init;
                }

                if(isset($d('zones_control_combo'))){
                    $d('zones_control_combo').setAttribute('class', 'zones_control_item_combo_disable');
                    $d('zones_control_combo').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.init;
                }

                if(isset($d('zones_control_fix'))){ //$d('zones_control_fix').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.point.init
                    $d('zones_control_fix').setAttribute('class', 'zones_control_item_lock');
                    $d('zones_control_fix').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.point.init;
                }

                if(isset($d('zones_control_remove'))){
                    $d('zones_control_remove').setAttribute('class', 'zones_control_item_disable');
                    $d('zones_control_remove').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.remove.init;
                }

                if(isset($d('zones_control_point'))){ // $d('zones_control_point').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.init
                    $d('zones_control_point').setAttribute('class', 'zones_control_item_disable');
                    $d('zones_control_point').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.init;
                }

                if(isset($d('zones_control_back'))){
                    $d('zones_control_back').setAttribute('class', 'zones_control_item_disable');
                    $d('zones_control_back').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.back;
                }

                if(isset($d('zones_control_front'))){
                    $d('zones_control_front').setAttribute('class', 'zones_control_item_disable');
                    $d('zones_control_front').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.forward;
                }

                if(isset($d('zones_speed_type'))){
                    $d('zones_speed_type').onkeyup = page_object.action.admin.action.zones_content.action.zone.speed.init;
                    $d('zones_speed_type').onchange = page_object.action.admin.action.zones_content.action.zone.speed.init;
                }

                if(isset($d('zones_speed_max_type'))){
                    $d('zones_speed_max_type').onkeyup = page_object.action.admin.action.zones_content.action.zone.speed.init;
                    $d('zones_speed_max_type').onchange = page_object.action.admin.action.zones_content.action.zone.speed.init;
                }

                if(isset($d('zones_traffic_lights'))) $d('zones_traffic_lights').onchange = page_object.action.admin.action.zones_content.action.zone.traffic_lights.init;

                if(isset($d('zones_control_save')) && !page_object.action.admin.action.zones_content.action.zone.is_edit){

                    $d('zones_control_save').setAttribute('class', 'zones_control_item_disable'); //$d('zones_control_save').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.save.init;
                    $('body').on('click', '#zones_control_save', function(){ $('.loc_save_modal').modal(); });
                    $('body').on('click', '.loc_save_save_btn', function(){
                        page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.save.save(); // page_object.dialog.action.un_show.init(dialog_index, true);
                        $('.loc_save_modal').modal('hide');
                    });

                    $('body').on('click', '.loc_save_cancel_btn', function(){
                        $('.loc_save_modal').modal('hide');
                        return;
                        cl(' =============Cancelling save');
                        var key = page_object.action.admin.action.zones_content.action.zone.choose_type.key;
                        cl('key');
                        cl('key');
                        cl(key);

                        var sl = page_object.action.admin.action.zones_content.saved; cl('sl'); cl(sl);
                        var mlist = page_object.action.admin.action.zones_content.action.zone.canvas.move_list; cl('mlist'); cl(mlist);
                        var dlist = page_object.action.admin.data['zones']['zone_list']; cl('dlist '); cl(dlist );
                        var csl = page_object.action.admin.action.zones_content.action.zone.canvas.list; cl('csl'); cl(csl);

                        cl('null KEY'); //Object { x: 1, y: 106 }
                        for(key in mlist) mlist[key] = jQuery.extend(true, {}, page_object.action.admin.action.zones_content.saved[key]);
                        for(key in dlist) dlist[key] = jQuery.extend(true, {}, page_object.action.admin.action.zones_content.saved[key]);

                        page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw_all();
                        if(isset($d('zone_point'))) removeElement($d('zone_point'));
                        if(isset($d('zones_control_fix'))) $d('zones_control_fix').setAttribute('class', 'zones_control_item_lock');
                        cl(page_object.action.admin.action.zones_content.active_layer);
                        if(page_object.action.admin.action.zones_content.active_layer){
                            $d('zones_control_choose').setAttribute('class', 'zones_control_item');
                            $d('zones_control_draw').setAttribute('class', 'zones_control_item');
                        } //if(isset($d('zones_control_fix'))) $d('zones_control_fix').setAttribute('class', 'zones_control_item_lock'); cl(44444444444);
                        $('.loc_save_modal').modal('hide');
                    });
                }

                if(isset($d('zones_save')) && !page_object.action.admin.action.zones_content.action.zone.is_edit){
                    $d('zones_save').setAttribute('class', 'zones_save_disable');
                    $d('zones_save').onclick = page_object.action.admin.action.zones_content.action.zone.save.init;
                }

                if(isset($d('zones_cancel'))&&!page_object.action.admin.action.zones_content.action.zone.is_edit){
                    $d('zones_cancel').setAttribute('class', 'zones_cancel_disable');
                    $d('zones_cancel').onclick = page_object.action.admin.action.zones_content.action.zone.cancel.init;
                }

                if(!is_null(page_object.action.admin.action.zones_content.action.zone.choose_type.key)){
                    cl('SSSSSSSSSSSSSSSSSSSSSS');
                    page_object.action.admin.action.zones_content.action.zone.choose_type.set_active(page_object.action.admin.action.zones_content.action.zone.choose_type.key);
                    page_object.action.admin.action.zones_content.action.zone.controls();
                    page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.controls();
                    page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();
                }

                let arrow_list = [
                        '/Project/Aist/Admin/Template/Images/Rules/arrow_forward.png',
                        '/Project/Aist/Admin/Template/Images/Rules/arrow_left.png',
                        '/Project/Aist/Admin/Template/Images/Rules/arrow_right.png',
                        '/Project/Aist/Admin/Template/Images/Rules/arrow_left_right.png',
                        '/Project/Aist/Admin/Template/Images/Rules/arrow_forward_left.png',
                        '/Project/Aist/Admin/Template/Images/Rules/arrow_forward_right.png',
                        '/Project/Aist/Admin/Template/Images/Rules/arrow_forward_left_right.png'
                ], arrow_index, base_image;

                for(arrow_index in arrow_list){
                    base_image = new Image();
                    base_image.src = arrow_list[arrow_index];
                    base_image.onload = function(){  return true; }                      //trace('Canvas loaded: '+this.src);
                }
            },
            'speed': {
                'init': function(){

                    page_object.action.admin.action.zones_content.action.zone.is_edit = true;

                    switch(this.id){

                        case 'zones_speed_type': {

                            if(isset($d('zones_speed_max_type'))){

                                $d('zones_speed_max_type').setAttribute('min', this.value);

                                if(parseInt(this.value)>parseInt($v('zones_speed_max_type'))) $d('zones_speed_max_type').value=this.value;

                            }

                            break;

                        }

                    }

                    page_object.action.admin.action.zones_content.action.zone.controls();

                }
            },
            'traffic_lights': {
                'init': function(){

                    page_object.action.admin.action.zones_content.action.zone.is_edit = true;

                    page_object.action.admin.action.zones_content.action.zone.controls();

                }
            },
            'choose_type': {
                'key': null,
                'init': function(){

                    var  el_id = this.id
                        , id_list = el_id.split('_')
                        , key = id_list.splice(3).join('_')
                        , data = page_object.action.admin.data['zones'];

                    if(page_object.action.admin.action.zones_content.action.zone.canvas.is_edit){

                        let inner='';

                        if(loc) inner+= '<div class="dialog_row">Сохранить изменения? #1</div>'; else inner+= '<div class="dialog_row">Сохранить изменения?</div>';

                        var dialog_index = page_object.dialog.init({
                            'title': 'Информация',
                            'inner':inner,
                            'save': function(){

                                page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.save.save();

                                page_object.action.admin.action.zones_content.action.zone.choose_type.set_active(key);
                                page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();

                                if(isset($d('zones_control_choose'))) $d('zones_control_choose').setAttribute('class', 'zones_control_item');

                                if(isset($d('zones_control_point'))) $d('zones_control_point').setAttribute('class', 'zones_control_item_disable');

                                if(isset($d('zones_control_fix'))) $d('zones_control_fix').setAttribute('class', 'zones_control_item_lock');

                                if(isset($d('zones_control_remove'))) $d('zones_control_remove').setAttribute('class', 'zones_control_item_disable');

                                if(isset($d('zones_control_arrow'))) $d('zones_control_arrow').setAttribute('class', 'zones_control_item_up_disable');

                                if(isset($d('zones_control_combo'))) $d('zones_control_combo').setAttribute('class', 'zones_control_item_combo_disable');

                                if(isset($d('zones_control_arrow_combo'))) $d('zones_control_arrow_combo').setAttribute('class', 'zones_control_item_disable');

                                if(isset($d('zones_control_done'))){

                                    $d('zones_control_done').setAttribute('id', 'zones_control_draw');
                                    $d('zones_control_draw').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.init;

                                }

                                page_object.dialog.action.un_show.init(dialog_index, true);

                            },
                            'no_save': function(){

                                page_object.action.admin.action.zones_content.action.zone.canvas.init();
                                page_object.action.admin.action.zones_content.action.zone.cancel.cancel();

                                page_object.action.admin.action.zones_content.action.zone.choose_type.set_active(key);
                                page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();


                                if(isset($d('zones_control_choose'))) $d('zones_control_choose').setAttribute('class', 'zones_control_item');

                                if(isset($d('zones_control_point'))) $d('zones_control_point').setAttribute('class', 'zones_control_item_disable');

                                if(isset($d('zones_control_fix'))) $d('zones_control_fix').setAttribute('class', 'zones_control_item_lock');

                                if(isset($d('zones_control_remove'))) $d('zones_control_remove').setAttribute('class', 'zones_control_item_disable');

                                if(isset($d('zones_control_arrow'))) $d('zones_control_arrow').setAttribute('class', 'zones_control_item_up_disable');

                                if(isset($d('zones_control_combo'))) $d('zones_control_combo').setAttribute('class', 'zones_control_item_combo_disable');

                                if(isset($d('zones_control_arrow_combo'))) $d('zones_control_arrow_combo').setAttribute('class', 'zones_control_item_disable');

                                if(isset($d('zones_control_done'))){

                                    $d('zones_control_done').setAttribute('id', 'zones_control_draw');
                                    $d('zones_control_draw').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.init;

                                }

                                page_object.dialog.action.un_show.init(dialog_index, true);

                            },
                            'cancel':true
                        });
                        return true;
                    }
                    cl('RRRRRRRRRRSSSSSSSSSSSSSSSSSSSSSS');

                    var move_mode = page_object.action.admin.action.zones_content.move_mode;
                    cl(move_mode);
                    if(move_mode && key === 'control_zone') return;

                    page_object.action.admin.action.zones_content.action.zone.choose_type.set_active(key);
                    page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw(); //fredraw

                    ///////////////
                    //cl('active_layer'); 'zone set_active'
                    //cl(key);
                    //page_object.action.admin.action.zones_content.active_layer = key;

                    var move_mode = page_object.action.admin.action.zones_content.move_mode;
                    cl('move_mode'); cl(move_mode);
                    /*if(move_mode){
                        var llist = page_object.action.admin.data['zones']['zone_list']; cl('choose_type init');
                        for(kkey in llist) page_object.action.admin.action.zones_content.saved[kkey] = jQuery.extend(true, {}, llist[kkey]);
                    }*/
                    cl('sssaved');
                },

                'set_active': function(key){ // page_object.action.admin.action.zones_content.action.zone.choose_type.set_active
                    // page_object.action.admin.action.zones_content.active_layer
                    cl('zone set_active');
                    cl(key);
                    var move_mode = page_object.action.admin.action.zones_content.move_mode;
                    cl(move_mode);
                    if(move_mode && key === 'control_zone') return;

                    page_object.action.admin.action.zones_content.active_layer = key;

                    var  data = page_object.action.admin.data['zones']
                        , list = data['zone_list']
                        , index
                        , isset_active = false;

                    page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index = null;
                    page_object.action.admin.action.zones_content.action.zone.choose_type.key = key;

                    /// WAS HERE

                    if(isset(list[key]))
                        page_object.action.admin.action.zones_content.action.zone.canvas.list = list[key];
                    else
                        page_object.action.admin.action.zones_content.action.zone.canvas.list = {'layer_list':[]};

                    if(isset($d('zones_menu_line_list'))){
                        list = $d('zones_menu_line_list').getElementsByTagName('div');
                        for(index in list)
                            if(isObject(list[index])){
                                list[index].setAttribute('class', 'zones_menu_item'+(list[index].getAttribute('id') === 'zones_menu_item_'+key?'_active': ''));
                                if(list[index].getAttribute('id') === ('zones_menu_item_'+key)) isset_active = true;
                            }
                    }

                    if(isset($d('zones_menu_type_list'))){
                        list = $d('zones_menu_type_list').getElementsByTagName('div');
                        for(index in list)
                            if(isObject(list[index])){
                                list[index].setAttribute('class', 'zones_menu_item'+(list[index].getAttribute('id') === 'zones_menu_item_'+key?'_active': ''));
                                if(list[index].getAttribute('id') === ('zones_menu_item_'+key)) isset_active = true;
                            }
                    }

                    if(isset($d('zone_point'))){

                        if(isset($d('zones_control_choose'))) $d('zones_control_choose').setAttribute('class', 'zones_control_item_disable');

                        if(isset($d('zones_control_draw'))) $d('zones_control_draw').setAttribute('class', 'zones_control_item_disable');

                        if(isset($d('zones_control_arrow'))) $d('zones_control_arrow').setAttribute('class', 'zones_control_item_up_disable');

                        if(isset($d('zones_control_remove'))) $d('zones_control_remove').setAttribute('class', 'zones_control_item_disable');

                        if(isset($d('zones_control_save'))) $d('zones_control_save').setAttribute('class', 'zones_control_item_disable');

                        if(isset($d('zones_control_front'))) $d('zones_control_front').setAttribute('class', 'zones_control_item_disable');

                        if(isset($d('zones_control_back'))) $d('zones_control_back').setAttribute('class', 'zones_control_item_disable');

                    } else {

                        if(isset($d('zones_control_choose'))) $d('zones_control_choose').setAttribute('class', 'zones_control_item'+(isset_active?'': '_disable'));

                        if(isset($d('zones_control_draw'))){

                            switch(key){

                                case 'perspective': {

                                    if(isset(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'])){

                                        if(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'].length >= 2)
                                            $d('zones_control_draw').setAttribute('class', 'zones_control_item_disable');
                                        else
                                            $d('zones_control_draw').setAttribute('class', 'zones_control_item');

                                    } else $d('zones_control_draw').setAttribute('class', 'zones_control_item');

                                    break;
                                }

                                default: {
                                    $d('zones_control_draw').setAttribute('class', 'zones_control_item'+(isset_active?'': '_disable'));
                                    break;
                                }
                            }
                        }
                    }
                }
            },
            'canvas': {
                'is_edit':false,
                'line_index':null,
                'list':[],
                'move_list':[],
                'list_forward':[],
                'init': function(){

                    //cl(page_object.action.admin.action.zones_content.action.zone);
                    cl(page_object.action.admin.action.zones_content.action.zone.canvas);
                    cl(page_object.action.admin.action.zones_content.action.zone.canvas);
                    cl(page_object.action.admin.action.zones_content.action.zone.canvas);
                    cl(page_object.action.admin.action.zones_content.action.zone.canvas);
                    cl(typeof page_object.action.admin.action.zones_content.action.zone.canvas.list);
                    cl(typeof page_object.action.admin.action.zones_content.action.zone.canvas.list);
                    cl(typeof page_object.action.admin.action.zones_content.action.zone.canvas.list);
                    cl(typeof page_object.action.admin.action.zones_content.action.zone.canvas.list);
                    cl(typeof page_object.action.admin.action.zones_content.action.zone.canvas.list);

                    if(typeof page_object.action.admin.action.zones_content.action.zone.canvas.list !== 'undefined')
                        if(!isset(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'])) page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'] = [];

                    page_object.action.admin.action.zones_content.action.zone.canvas.list_forward = [];
                    if(typeof page_object.action.admin.action.zones_content.action.zone.canvas.list !== 'undefined')
                        page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index = page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'].length;

                    let  key = page_object.action.admin.action.zones_content.action.zone.choose_type.key, data = { 'point_list':[] };

                    switch(key){
                        case 'perspective':
                        case 'calibration_points':
                        case 'calibration_line':
                        case 'anchor_points':
                        case 'no_right_turn':
                        case 'stop_line':
                        case 'crosswalk':
                        case 'waffle_marking':
                        case 'zone_control':
                        case 'security_area':
                        case 'no_left_turn':
                        case 'tram_rails': { if(isset($d('zones_control_arrow'))) $d('zones_control_arrow').setAttribute('class', 'zones_control_item_up_disable'); break; }

                        default: {
                            data['direction'] = 'up';
                            if(isset($d('zones_control_arrow'))) $d('zones_control_arrow').setAttribute('class', 'zones_control_item_'+data['direction']); break;
                        }
                    }

                    if(typeof page_object.action.admin.action.zones_content.action.zone.canvas.list !== 'undefined')
                        page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'].push(data);

                    if(isset($d('zones_control_draw'))){
                        $d('zones_control_draw').setAttribute('id', 'zones_control_done');
                        $d('zones_control_done').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done;
                    }
                    if(isset($d('zones_control_fix'))) $d('zones_control_fix').setAttribute('class', 'zones_control_item_lock_disable');
                    if(isset($d('zones_control_remove'))) $d('zones_control_remove').setAttribute('class', 'zones_control_item');
                    page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();
                    page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.controls();
                    page_object.action.admin.action.zones_content.action.zone.canvas.mouse.init();

                },
                'arrow': {
                    'init': function(){

                        let  line_index = page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index;//key = page_object.action.admin.action.zones_content.action.zone.choose_type.key;

                        if(this.getAttribute('class') === 'zones_control_item_up'){
                            this.setAttribute('class', 'zones_control_item_down');
                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['direction'] = 'down';
                        } else {
                            this.setAttribute('class', 'zones_control_item_up');
                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['direction'] = 'up';
                        }

                        page_object.action.admin.action.zones_content.action.zone.canvas.is_edit = true;
                        page_object.action.admin.action.zones_content.action.zone.is_edit = true;

                        page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();
                        page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();
                        page_object.action.admin.action.zones_content.action.zone.controls();
                        page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.controls();

                    }
                },
                'arrow_combo': {
                    'direction': 'up',
                    'rule_key':null,
                    'rule_list':[],
                    'get_rule_key': function(el_id){
                        switch(el_id){
                            case 'arrow_rule_forward': return 'arrow_rule_forward';
                            case 'arrow_rule_left': return 'arrow_rule_left';
                            case 'arrow_rule_right': return 'arrow_rule_right';
                            case 'arrow_rule_forward_left': return 'arrow_rule_forward_left';
                            case 'arrow_rule_forward_right': return 'arrow_rule_forward_right';
                            case 'arrow_rule_left_right': return 'arrow_rule_left_right';
                            case 'arrow_rule_forward_left_right': return 'arrow_rule_forward_left_right';
                            case 'arrow_rule_forward_up': return 'arrow_rule_forward_up';
                            case 'arrow_rule_left_up': return 'arrow_rule_left_up';
                            case 'arrow_rule_right_up': return 'arrow_rule_right_up';
                            case 'arrow_rule_forward_left_up': return 'arrow_rule_forward_left_up';
                            case 'arrow_rule_forward_right_up': return 'arrow_rule_forward_right_up';
                            case 'arrow_rule_left_right_up': return 'arrow_rule_left_right_up';
                            case 'arrow_rule_forward_left_right_up': return 'arrow_rule_forward_left_right_up';
                            case 'arrow_rule_forward_down': return 'arrow_rule_forward_down';
                            case 'arrow_rule_left_down': return 'arrow_rule_left_down';
                            case 'arrow_rule_right_down': return 'arrow_rule_right_down';
                            case 'arrow_rule_forward_left_down': return 'arrow_rule_forward_left_down';
                            case 'arrow_rule_forward_right_down': return 'arrow_rule_forward_right_down';
                            case 'arrow_rule_left_right_down': return 'arrow_rule_left_right_down';
                            case 'arrow_rule_forward_left_right_down': return 'arrow_rule_forward_left_right_down';
                            default: return null;
                        }

                    },
                    'get_rule_key_image': function(el_id){

                        switch(el_id){
                            case 'arrow_rule_forward':
                            case 'arrow_rule_forward_up':
                            case 'arrow_rule_forward_down': return '/Project/Aist/Admin/Template/Images/Rules/arrow_forward.png';
                            case 'arrow_rule_left':
                            case 'arrow_rule_left_up':
                            case 'arrow_rule_left_down': return '/Project/Aist/Admin/Template/Images/Rules/arrow_left.png';
                            case 'arrow_rule_right':
                            case 'arrow_rule_right_up':
                            case 'arrow_rule_right_down': return '/Project/Aist/Admin/Template/Images/Rules/arrow_right.png';
                            case 'arrow_rule_forward_left':
                            case 'arrow_rule_forward_left_up':
                            case 'arrow_rule_forward_left_down': return '/Project/Aist/Admin/Template/Images/Rules/arrow_forward_left.png';
                            case 'arrow_rule_forward_right':
                            case 'arrow_rule_forward_right_up':
                            case 'arrow_rule_forward_right_down': return '/Project/Aist/Admin/Template/Images/Rules/arrow_forward_right.png';
                            case 'arrow_rule_left_right':
                            case 'arrow_rule_left_right_up':
                            case 'arrow_rule_left_right_down': return '/Project/Aist/Admin/Template/Images/Rules/arrow_left_right.png';
                            case 'arrow_rule_forward_left_right':
                            case 'arrow_rule_forward_left_right_up':
                            case 'arrow_rule_forward_left_right_down': return '/Project/Aist/Admin/Template/Images/Rules/arrow_forward_left_right.png';
                            default: return null;
                        }
                    },
                    'isset_rule_in_rule_list': function(rule, rule_list){
                        let index;
                        for(index in rule_list) if(rule_list[index]['rule'] === rule) return true;
                        return false;

                    },
                    'get_rule_key_from_list': function(line_index, list){

                        let  layer_list = page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list']
                            , layer_data = layer_list[line_index]
                            , direction = isset(layer_data['direction'])?layer_data['direction'] :  'up';

                        if(page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.isset_rule_in_rule_list('arrow_forward', list)
                            &&page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.isset_rule_in_rule_list('arrow_left', list)
                            &&page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.isset_rule_in_rule_list('arrow_right', list)
                        )
                            return'arrow_rule_forward_left_right_'+direction;
                        else if(page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.isset_rule_in_rule_list('arrow_forward', list)
                            &&page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.isset_rule_in_rule_list('arrow_left', list)
                        )
                            return'arrow_rule_forward_left_'+direction;
                        else if(page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.isset_rule_in_rule_list('arrow_forward', list)
                            &&page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.isset_rule_in_rule_list('arrow_right', list)
                        )
                            return'arrow_rule_forward_right_'+direction;
                        else if(page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.isset_rule_in_rule_list('arrow_left', list)
                            &&page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.isset_rule_in_rule_list('arrow_right', list)
                        )
                            return'arrow_rule_left_right_'+direction;
                        else if(page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.isset_rule_in_rule_list('arrow_left', list)
                        )
                            return'arrow_rule_left_'+direction;
                        else if(page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.isset_rule_in_rule_list('arrow_forward', list)
                        )
                            return'arrow_rule_forward_'+direction;
                        else if(page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.isset_rule_in_rule_list('arrow_right', list)
                        )
                            return'arrow_rule_right_'+direction;

                        return null;

                    },
                    'get_rule_list': function(rule_key){

                        switch(rule_key){

                            case 'arrow_rule_forward':
                            case 'arrow_rule_forward_up':
                            case 'arrow_rule_forward_down':
                                return [
                                    {
                                        'is_always':true,
                                        'rule': 'arrow_forward'
                                    },
                                    {
                                        'is_always':true,
                                        'rule': 'arrow_back'
                                    }
                                ];
                            case 'arrow_rule_left':
                            case 'arrow_rule_left_up':
                            case 'arrow_rule_left_down':
                                return [
                                    {
                                        'is_always':true,
                                        'rule': 'arrow_left'
                                    },
                                    {
                                        'is_always':true,
                                        'rule': 'arrow_back'
                                    }
                                ];
                            case 'arrow_rule_right':
                            case 'arrow_rule_right_up':
                            case 'arrow_rule_right_down':
                                return [
                                    {
                                        'is_always':true,
                                        'rule': 'arrow_right'
                                    },
                                    {
                                        'is_always':true,
                                        'rule': 'arrow_back'
                                    }
                                ];
                            case 'arrow_rule_forward_left':
                            case 'arrow_rule_forward_left_up':
                            case 'arrow_rule_forward_left_down':
                                return [
                                    {
                                        'is_always':true,
                                        'rule': 'arrow_forward'
                                    },
                                    {
                                        'is_always':true,
                                        'rule': 'arrow_left'
                                    },
                                    {
                                        'is_always':true,
                                        'rule': 'arrow_back'
                                    }
                                ];
                            case 'arrow_rule_forward_right':
                            case 'arrow_rule_forward_right_up':
                            case 'arrow_rule_forward_right_down':
                                return [
                                    {
                                        'is_always':true,
                                        'rule': 'arrow_forward'
                                    },
                                    {
                                        'is_always':true,
                                        'rule': 'arrow_right'
                                    },
                                    {
                                        'is_always':true,
                                        'rule': 'arrow_back'
                                    }
                                ];
                            case 'arrow_rule_left_right':
                            case 'arrow_rule_left_right_up':
                            case 'arrow_rule_left_right_down':
                                return [
                                    {
                                        'is_always':true,
                                        'rule': 'arrow_left'
                                    },
                                    {
                                        'is_always':true,
                                        'rule': 'arrow_right'
                                    },
                                    {
                                        'is_always':true,
                                        'rule': 'arrow_back'
                                    }
                                ];
                            case 'arrow_rule_forward_left_right':
                            case 'arrow_rule_forward_left_right_up':
                            case 'arrow_rule_forward_left_right_down':
                                return [
                                    {
                                        'is_always':true,
                                        'rule': 'arrow_forward'
                                    },
                                    {
                                        'is_always':true,
                                        'rule': 'arrow_left'
                                    },
                                    {
                                        'is_always':true,
                                        'rule': 'arrow_right'
                                    },
                                    {
                                        'is_always':true,
                                        'rule': 'arrow_back'
                                    }
                                ];

                            default:
                                return [];

                        }

                    },
                    'init': function(callback){

                        let  inner =''
                            , list = page_object.action.admin.action.zones_content.action.zone.canvas.list
                            , line_index = page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index
                            , layer_list = list['layer_list']
                            , layer_data = layer_list[line_index];

                        if(layer_data['point_list'].length === 1)
                            return;

                        var  direction = empty(layer_data['direction'])?'up':layer_data['direction']
                            , rules_list = layer_data['rules']
                            , allowed_list = rules_list['allowed_list']
                            , rule_key
                            , rule_list = []
                            , index;

                        if(allowed_list.length>0){

                            rule_key = page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.get_rule_key_from_list(line_index, allowed_list);

                            if(!is_null(rule_key))
                                rule_list = page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.get_rule_list(rule_key);

                        }

                        page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.direction = direction;
                        page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.rule_key = rule_key;
                        page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.rule_list = rule_list;

                        inner+= '<div class="dialog_row">Выберите правило относительно направления движения в данной зоне:</div>';

                        inner+= '<div id="arrow_rule_list" class="dialog_row">';

                            inner+= '<div id="arrow_rule_forward_up" class="arrow_rule_item'+(rule_key === 'arrow_rule_forward_up'?'_active': '')+'">';
                                inner+= '<div class="arrow_rule_item_check"></div>';
                            inner+= '</div>';

                            inner+= '<div id="arrow_rule_right_up" class="arrow_rule_item'+(rule_key === 'arrow_rule_right_up'?'_active': '')+'">';
                                inner+= '<div class="arrow_rule_item_check"></div>';
                            inner+= '</div>';

                            inner+= '<div id="arrow_rule_left_up" class="arrow_rule_item'+(rule_key === 'arrow_rule_left_up'?'_active': '')+'">';
                                inner+= '<div class="arrow_rule_item_check"></div>';
                            inner+= '</div>';

                            inner+= '<div id="arrow_rule_forward_left_up" class="arrow_rule_item'+(rule_key === 'arrow_rule_forward_left_up'?'_active': '')+'">';
                                inner+= '<div class="arrow_rule_item_check"></div>';
                            inner+= '</div>';

                            inner+= '<div id="arrow_rule_forward_right_up" class="arrow_rule_item'+(rule_key === 'arrow_rule_forward_right_up'?'_active': '')+'">';
                                inner+= '<div class="arrow_rule_item_check"></div>';
                            inner+= '</div>';

                            inner+= '<div id="arrow_rule_left_right_up" class="arrow_rule_item'+(rule_key === 'arrow_rule_left_right_up'?'_active': '')+'">';
                                inner+= '<div class="arrow_rule_item_check"></div>';
                            inner+= '</div>';

                            inner+= '<div id="arrow_rule_forward_left_right_up" class="arrow_rule_item'+(rule_key === 'arrow_rule_forward_left_right_up'?'_active': '')+'">';
                                inner+= '<div class="arrow_rule_item_check"></div>';
                            inner+= '</div>';

                            inner+= '<div id="arrow_rule_forward_down" class="arrow_rule_item'+(rule_key === 'arrow_rule_forward_down'?'_active': '')+'">';
                                inner+= '<div class="arrow_rule_item_check"></div>';
                            inner+= '</div>';

                            inner+= '<div id="arrow_rule_right_down" class="arrow_rule_item'+(rule_key === 'arrow_rule_right_down'?'_active': '')+'">';
                                inner+= '<div class="arrow_rule_item_check"></div>';
                            inner+= '</div>';

                            inner+= '<div id="arrow_rule_left_down" class="arrow_rule_item'+(rule_key === 'arrow_rule_left_down'?'_active': '')+'">';
                                inner+= '<div class="arrow_rule_item_check"></div>';
                            inner+= '</div>';

                            inner+= '<div id="arrow_rule_forward_left_down" class="arrow_rule_item'+(rule_key === 'arrow_rule_forward_left_down'?'_active': '')+'">';
                                inner+= '<div class="arrow_rule_item_check"></div>';
                            inner+= '</div>';

                            inner+= '<div id="arrow_rule_forward_right_down" class="arrow_rule_item'+(rule_key === 'arrow_rule_forward_right_down'?'_active': '')+'">';
                                inner+= '<div class="arrow_rule_item_check"></div>';
                            inner+= '</div>';

                            inner+= '<div id="arrow_rule_left_right_down" class="arrow_rule_item'+(rule_key === 'arrow_rule_left_right_down'?'_active': '')+'">';
                                inner+= '<div class="arrow_rule_item_check"></div>';
                            inner+= '</div>';

                            inner+= '<div id="arrow_rule_forward_left_right_down" class="arrow_rule_item'+(rule_key === 'arrow_rule_forward_left_right_down'?'_active': '')+'">';
                                inner+= '<div class="arrow_rule_item_check"></div>';
                            inner+= '</div>';

                        inner+= '</div>';

                        var dialog_index = page_object.dialog.init({
                            'title': 'Правила движения',
                            'w':456,
                            'inner':inner,
                            'save': function(){

                                page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.change.save(dialog_index, callback);

                                page_object.dialog.action.un_show.init(dialog_index, true);

                            },
                            'on_create': function(){

                                page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.change.init();

                            },
                            'cancel':true
                        });

                    },
                    'change': {
                        'init': function(){

                            let  el_list = $d('arrow_rule_list').getElementsByTagName('div')
                                , index;

                            for(index in el_list)
                                if(isObject(el_list[index]))
                                    switch(el_list[index].getAttribute('class')){

                                        case 'arrow_rule_item':
                                        case 'arrow_rule_item_active': {

                                            el_list[index].onclick = page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.change.click;

                                            break;

                                        }

                                    }

                        },
                        'click': function(){

                            let  el_list = $d('arrow_rule_list').getElementsByClassName('arrow_rule_item_active')
                                , el_id_list = this.id.split('_')
                                , direction = el_id_list[el_id_list.length-1]
                                , index;

                            for(index in el_list)
                                if(isObject(el_list[index]))
                                    if(el_list[index].getAttribute('id') !== this.id)
                                        el_list[index].setAttribute('class', 'arrow_rule_item');

                            if(this.getAttribute('class') === 'arrow_rule_item'){

                                this.setAttribute('class', 'arrow_rule_item_active');

                                page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.direction = direction;
                                page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.rule_key = this.id;
                                page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.rule_list = page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.get_rule_list(this.id);;

                            } else {

                                this.setAttribute('class', 'arrow_rule_item');

                                page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.direction = null;
                                page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.rule_key = null;
                                page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.rule_list = [];

                            }

                            page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.change.init();

                        },
                        'save': function(dialog_index, callback){

                            let  line_index = page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index;

                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['direction'] = page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.direction;
                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['rules']['allowed_list'] = page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.rule_list;

                            if(isFunction(callback))
                                callback();

                            page_object.dialog.action.un_show.init(dialog_index, true);

                            page_object.action.admin.action.zones_content.action.zone.canvas.is_edit = true;
                            page_object.action.admin.action.zones_content.action.zone.is_edit = true;

                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();
                            page_object.action.admin.action.zones_content.action.zone.controls();
                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.controls();

                        }
                    }
                },
                'choose': {
                    'line_index':null,
                    'init': function(){

                        if(isset($d('zones_video_canvas_item_0'))){

                            if(isset($d('zones_control_choose')))
                                $d('zones_control_choose').setAttribute('class', 'zones_control_item_active');

                            if(isset($d('zones_control_draw')))
                                $d('zones_control_draw').setAttribute('class', 'zones_control_item_disable');

                            if(isset($d('zones_control_arrow')))
                                $d('zones_control_arrow').setAttribute('class', 'zones_control_item_up_disable');

                            if(isset($d('zones_control_combo')))
                                $d('zones_control_combo').setAttribute('class', 'zones_control_item_combo_disable');

                            if(isset($d('zones_control_fix'))) $d('zones_control_fix').setAttribute('class', 'zones_control_item_lock_disable');

                            if(isset($d('zones_control_remove')))
                                $d('zones_control_remove').setAttribute('class', 'zones_control_item_disable');

                            $d('zones_video_canvas_list').onmousemove = page_object.action.admin.action.zones_content.action.zone.canvas.choose.move.init;
                            $d('zones_video_canvas_list').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.choose.click.init;

                        }

                    },
                    'move': {
                        'init': function(e){

                            if(isset($d('zones_video_canvas_item_0'))){

                                let  line_index_success = page_object.action.admin.action.zones_content.action.zone.canvas.choose.move.get_line_index(e)
                                    , is_success = line_index_success >= 0
                                    , list = page_object.action.admin.action.zones_content.action.zone.canvas.list
                                    , line_index
                                    , index;

                                if(is_success){

                                    for(line_index = 0;line_index<list['layer_list'].length;line_index++)
                                        for(index = 0;index<list['layer_list'][line_index]['point_list'].length;index++)
                                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'][index]['line_width'] = (line_index_success === line_index)?page_object.action.admin.action.zones_content.line.width.hover:page_object.action.admin.action.zones_content.line.width.default;

                                } else {

                                    for(line_index = 0;line_index<list['layer_list'].length;line_index++)
                                        for(index = 0;index<list['layer_list'][line_index]['point_list'].length;index++)
                                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'][index]['line_width'] = page_object.action.admin.action.zones_content.line.width.default;

                                }

                                page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();

                            }

                        },
                        'get_line_index': function(e){

                            if(isset($d('zones_video_canvas_item_0'))){

                                let  coords_data = page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.get(e)
                                    , list = page_object.action.admin.action.zones_content.action.zone.canvas.list
                                    , key = page_object.action.admin.action.zones_content.action.zone.choose_type.key
                                    , line_index
                                    , index
                                    , point_x = coords_data['x']
                                    , point_y = coords_data['y']
                                    , delta = 10
                                    , index_success = -1
                                    , line_index_success = -1
                                    , is_success = false;

                                if(!isset(list['layer_list']))
                                    return false;

                                for(line_index = 0;line_index<list['layer_list'].length;line_index++){

                                    for(index = 0;index<list['layer_list'][line_index]['point_list'].length;index++)
                                        if(list['layer_list'][line_index]['point_list'].length === 1){

                                            var  point_data_1 = list['layer_list'][line_index]['point_list'][index]
                                                , point_x1 = point_data_1['x']
                                                , point_y1 = point_data_1['y']
                                                , left_top_x = point_x1-delta
                                                , left_top_y = point_y1-delta
                                                , right_bottom_x = point_x1+delta
                                                , right_bottom_y = point_y1+delta;

                                            if(point_x >= left_top_x
                                                &&point_y >= left_top_y
                                                &&point_x <= right_bottom_x
                                                &&point_y <= right_bottom_y
                                            ){

                                                is_success = true;
                                                line_index_success = line_index;
                                                index_success = index;

                                                page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'][0]['radius'] = page_object.action.admin.action.zones_content.point.radius.hover;

                                            }
                                            else
                                                page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'][0]['radius'] = page_object.action.admin.action.zones_content.point.radius.default;

                                        } else if(index <= list['layer_list'][line_index]['point_list'].length-1){

                                            switch(key){
                                                case 'control_zone': {
                                                    if(list['layer_list'][line_index]['point_list'].length === 4){
                                                        list['layer_list'][line_index]['point_list'].push(list['layer_list'][line_index]['point_list'][0]);
                                                    }
                                                    break;
                                                }
                                            }

                                            let  index_2 = (index+1 === list['layer_list'][line_index]['point_list'].length)?0:index+1
                                                , point_data_1 = list['layer_list'][line_index]['point_list'][index]
                                                , point_data_2 = list['layer_list'][line_index]['point_list'][index_2]
                                                , point_x1 = point_data_1['x']
                                                , point_y1 = point_data_1['y']
                                                , point_x2 = point_data_2['x']
                                                , point_y2 = point_data_2['y']
                                                , left_bottom = point_y2-point_y1
                                                , right_bottom = point_x2-point_x1
                                                , left_2 = right_bottom*point_y1
                                                , right_2 = left_bottom*point_x1
                                                , y_check_min = (left_bottom*(point_x-delta)-right_2+left_2)/right_bottom
                                                , y_check_max = (left_bottom*(point_x+delta)-right_2+left_2)/right_bottom
                                                , x_check_min = (right_bottom*(point_y-delta)+right_2-left_2)/left_bottom
                                                , x_check_max = (right_bottom*(point_y+delta)+right_2-left_2)/left_bottom
                                                , line_width = page_object.action.admin.action.zones_content.line.width.default;

                                            if((
                                                      y_check_max+delta >= point_y
                                                    &&y_check_min-delta <= point_y
                                                ) || (
                                                      x_check_max+delta >= point_x
                                                    &&x_check_min-delta <= point_x
                                                )
                                            ){

                                                if(point_data_1['x'] >= point_data_2['x']
                                                ){

                                                    if(point_data_1['y'] >= point_data_2['y']){

                                                        if((point_data_1['x']+delta) >= point_x
                                                            &&(point_data_1['y']+delta) >= point_y
                                                            &&(point_data_2['x']-delta) <= point_x
                                                            &&(point_data_2['y']-delta) <= point_y
                                                        ){

                                                            is_success = true;
                                                            line_index_success = line_index;
                                                            index_success = index;
                                                            line_width = page_object.action.admin.action.zones_content.line.width.hover;

                                                            break;

                                                        }
                                                        else
                                                            line_width = page_object.action.admin.action.zones_content.line.width.default;

} else {

                                                        if((point_data_1['x']+delta) >= point_x
                                                            &&(point_data_1['y']-delta) <= point_y
                                                            &&(point_data_2['x']-delta) <= point_x
                                                            &&(point_data_2['y']+delta) >= point_y
                                                        ){

                                                            is_success = true;
                                                            line_index_success = line_index;
                                                            index_success = index;
                                                            line_width = page_object.action.admin.action.zones_content.line.width.hover;

                                                            break;

                                                        } else line_width = page_object.action.admin.action.zones_content.line.width.default;

                                                    }

                                                } else {

                                                    if(point_data_1['y'] >= point_data_2['y']){

                                                        if((point_data_1['x']-delta) <= point_x
                                                            &&(point_data_1['y']+delta) >= point_y
                                                            &&(point_data_2['x']+delta) >= point_x
                                                            &&(point_data_2['y']-delta) <= point_y
                                                        ){

                                                            is_success = true;
                                                            line_index_success = line_index;
                                                            index_success = index;
                                                            line_width = page_object.action.admin.action.zones_content.line.width.hover;

                                                            break;

                                                        } else line_width = page_object.action.admin.action.zones_content.line.width.default;

                                                    } else {

                                                        if((point_data_1['x']-delta) <= point_x
                                                            &&(point_data_1['y']-delta) <= point_y
                                                            &&(point_data_2['x']+delta) >= point_x
                                                            &&(point_data_2['y']+delta) >= point_y
                                                        ){

                                                            is_success = true;
                                                            line_index_success = line_index;
                                                            index_success = index;
                                                            line_width = page_object.action.admin.action.zones_content.line.width.hover;

                                                            break;

                                                        } else line_width = page_object.action.admin.action.zones_content.line.width.default;
                                                    }

                                                }

                                                page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'][index_2]['line_width'] = line_width;

                                                break;

                                            } else page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'][index_2]['line_width'] = line_width;
                                        }

                                    if(is_success) break;
                                }
                                return line_index_success;
                            }
                            return -1;
                        }
                    },
                    'click': {
                        'init': function(e){

                            let  line_index_success = page_object.action.admin.action.zones_content.action.zone.canvas.choose.move.get_line_index(e)
                                , key = page_object.action.admin.action.zones_content.action.zone.choose_type.key
                                , list = page_object.action.admin.action.zones_content.action.zone.canvas.list
                                , is_success = line_index_success >= 0
                                , line_index
                                , index;

                            if(is_success){

                                page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index = line_index_success;

                                switch(key){

                                    case 'lane':
                                    case 'route_vehicles':
                                    case 'roadside':
                                    case 'no_right_turn':
                                    case 'no_left_turn':
                                    case 'no_direct_traffic':
                                    case 'tram_rails': {

                                        if(!isset(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index_success]['rules'])){

                                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index_success]['rules'] = {
                                                'prohibited_list':[],
                                                'allowed_list':[]
                                            };

                                        }

                                        break;

                                    }

                                }

                                for(line_index = 0;line_index<list['layer_list'].length;line_index++)
                                    for(index = 0;index<list['layer_list'][line_index]['point_list'].length;index++){

                                        if(isset(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'][index]['line_width']))
                                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'][index]['line_width'] = page_object.action.admin.action.zones_content.line.width.default;

                                        if(isset(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'][index]['radius']))
                                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'][index]['radius'] = page_object.action.admin.action.zones_content.point.radius.default;

                                    }

                                page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();

                                if(isset($d('zones_video_canvas_list'))){

                                    $d('zones_video_canvas_list').onmousemove = function(){};
                                    $d('zones_video_canvas_list').onclick = function(){};

                                }

                                if(isset($d('zones_control_choose'))) $d('zones_control_choose').setAttribute('class', 'zones_control_item_disable');

                                if(isset($d('zones_control_draw'))){

                                    $d('zones_control_draw').setAttribute('class', 'zones_control_item');
                                    $d('zones_control_draw').setAttribute('id', 'zones_control_done');

                                    $d('zones_control_done').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done;

                                }

                                switch(key){

                                    case 'no_parking':
                                    case 'control_zone':
                                    case 'crosswalk':
                                    case 'waffle_marking':
                                    case 'security_area':
                                    case 'anchor_points':
                                    case 'no_stop': {

                                        if(isset($d('zones_control_combo')))
                                            $d('zones_control_combo').setAttribute('class', 'zones_control_item_combo_disable');

                                        break;

                                    }

                                    default: {

                                        if(isset($d('zones_control_combo')))
                                            $d('zones_control_combo').setAttribute('class', 'zones_control_item_combo');

                                        break;

                                    }

                                }

                                if(isset($d('zones_control_fix'))) $d('zones_control_fix').setAttribute('class', 'zones_control_item_lock_disable');

                                if(isset($d('zones_control_arrow'))){

                                    switch(key){

                                        case 'perspective':
                                        case 'calibration_points':
                                        case 'calibration_line':
                                        case 'stop_line': {

                                            if(isset($d('zones_control_arrow'))){

                                                $d('zones_control_arrow').setAttribute('class', 'zones_control_item_up_disable');

                                            }

                                            break;

                                        }

                                        default: {

                                            if(isset($d('zones_control_arrow')))
                                                $d('zones_control_arrow').setAttribute('class', 'zones_control_item_'+list['layer_list'][line_index_success]['direction']);

                                            break;

                                        }

                                    }

                                }

                                if(isset($d('zones_control_arrow_combo'))){

                                    switch(key){

                                        case 'perspective':
                                        case 'calibration_points':
                                        case 'calibration_line':
                                        case 'stop_line': {

                                            if(isset($d('zones_control_arrow_combo'))){

                                                $d('zones_control_arrow_combo').setAttribute('class', 'zones_control_item_disable');

                                            }

                                            break;

                                        }

                                        default: {

                                            if(isset($d('zones_control_arrow')))
                                                $d('zones_control_arrow').setAttribute('class', 'zones_control_item');

                                            break;

                                        }

                                    }

                                }

                                if(isset($d('zones_control_remove'))) $d('zones_control_remove').setAttribute('class', 'zones_control_item');

                                if(isset($d('zones_control_point'))) $d('zones_control_point').setAttribute('class', 'zones_control_item');

                            }

                        }
                    }
                },
                'choose_point': { //  $d('zones_control_point').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.init
                    'line_index':null,
                    'point_index':null,
                    'init': function(){ cl('choose_point'); cl(555555555555);

                        trace('choose point rindex: ');
                        trace(page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index);

                        if(isset($d('zones_video_canvas_item_0'))){

                            if(isset($d('zones_control_front')))
                                $s('zones_control_front').display='none';

                            if(isset($d('zones_control_back')))
                                $s('zones_control_back').display='none';

                            if(isset($d('zones_control_point')))
                                $d('zones_control_point').setAttribute('class', 'zones_control_item_active');

                            if(isset($d('zones_control_choose')))
                                $d('zones_control_choose').setAttribute('class', 'zones_control_item_disable');

                            if(isset($d('zones_control_draw')))
                                $d('zones_control_draw').setAttribute('class', 'zones_control_item_disable');

                            if(isset($d('zones_control_arrow')))
                                $d('zones_control_arrow').setAttribute('class', 'zones_control_item_up_disable');

                            if(isset($d('zones_control_combo')))
                                $d('zones_control_combo').setAttribute('class', 'zones_control_item_combo_disable');

                            if(isset($d('zones_control_fix'))) $d('zones_control_fix').setAttribute('class', 'zones_control_item_lock_disable');

                            if(isset($d('zones_control_remove')))
                                $d('zones_control_remove').setAttribute('class', 'zones_control_item_disable');

                            page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.line_index = page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index;
                            page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.point_index = null;

                            $d('zones_video_canvas_list').onmousemove = page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.move.init;
                            $d('zones_video_canvas_list').ondrag = page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.move.init;
                            $d('zones_video_canvas_list').onmousedown = page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.onmousedown.init;
                            $d('zones_video_canvas_list').onmouseup = page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.onmouseup.init;
                        }
                    },

                    'move': {
                        'init': function(e){
                            if(isset($d('zones_video_canvas_item_0'))){

                                trace('line index: ');
                                trace(page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.line_index);
                                trace(page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.point_index);

                                if(!is_null(page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.point_index)){

                                    let  point_index = page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.point_index
                                        , line_index = page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.line_index
                                        , coords_data = page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.get(e)
                                        , point_x = coords_data['x']
                                        , point_y = coords_data['y'];

                                    if(isset(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index])){

                                        if(isset(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'][point_index])){

                                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'][point_index]['x'] = Math.round(point_x);
                                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'][point_index]['y'] = Math.round(point_y);

                                            if(point_index === 0
                                                &&(
                                                      page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].length >= 4 || page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].length === 3
                                                )
                                            ){

                                                let last_index = page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].length-1;

                                                page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'][last_index]['x'] = Math.round(point_x);
                                                page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'][last_index]['y'] = Math.round(point_y);

                                            }

                                        }

                                    }

                                }

                                page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.move.get_line_index(e);
                                page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();
                            }
                        },
                        'get_line_index': function(e){

                            if(isset($d('zones_video_canvas_item_0'))){

                                let  coords_data = page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.get(e)
                                    , list = page_object.action.admin.action.zones_content.action.zone.canvas.list
                                    , key = page_object.action.admin.action.zones_content.action.zone.choose_type.key
                                    // , line_index_current = page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index
                                    , line_index = page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index
                                    , index
                                    , point_x = coords_data['x']
                                    , point_y = coords_data['y']
                                    , delta = 10
                                    , index_success = -1
                                    , line_index_success = -1
                                    , is_success = false;

                                if(!isset(list['layer_list'])) return false;

                                // for(line_index = 0;line_index<list['layer_list'].length;line_index++){

                                for(index = 0;index<list['layer_list'][line_index]['point_list'].length;index++){

                                    var  point_data_1 = list['layer_list'][line_index]['point_list'][index]
                                        , point_x1 = point_data_1['x']
                                        , point_y1 = point_data_1['y']
                                        , left_top_x = point_x1-delta
                                        , left_top_y = point_y1-delta
                                        , right_bottom_x = point_x1+delta
                                        , right_bottom_y = point_y1+delta;

                                    if(point_x >= left_top_x
                                        &&point_y >= left_top_y
                                        &&point_x <= right_bottom_x
                                        &&point_y <= right_bottom_y
                                    ){

                                        is_success = true;
                                        line_index_success = line_index;
                                        index_success = index;

                                        page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'][index]['radius'] = page_object.action.admin.action.zones_content.point.radius.hover;

                                    }
                                    else
                                        page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'][index]['radius'] = page_object.action.admin.action.zones_content.point.radius.default;

                                    if(is_success)
                                        break;

                                }

                                // }

                                return {
                                    'line_index':line_index_success,
                                    'point_index':index_success,
                                };

                            }

                            return -1;

                        }
                    },
                    'onmouseup': {
                        'init': function(){

                            let  list = page_object.action.admin.action.zones_content.action.zone.canvas.list
                                , point_index
                                , index;

                            page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.point_index = null;
                            // page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.line_index = null;

                            for(point_index = 0;point_index<list['layer_list'].length;point_index++)
                                for(index = 0;index<list['layer_list'][point_index]['point_list'].length;index++){

                                    if(isset(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][point_index]['point_list'][index]['radius']))
                                        page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][point_index]['point_list'][index]['radius'] = page_object.action.admin.action.zones_content.point.radius.default;

                                }

                            page_object.action.admin.action.zones_content.action.zone.is_edit = true;
                            page_object.action.admin.action.zones_content.action.zone.canvas.is_edit = true;

                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();
                            page_object.action.admin.action.zones_content.action.zone.controls();
                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.controls();

                        },
                    },
                    'onmousedown': {
                        'init': function(e){

                            let  choose_data = page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.move.get_line_index(e)
                                , line_index = page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index
                                , point_index_success = choose_data['point_index']
                                , line_index_success = choose_data['line_index']
                                , key = page_object.action.admin.action.zones_content.action.zone.choose_type.key
                                , is_success = point_index_success >= 0;

                            if(is_success&&line_index_success === line_index){

                                page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.point_index = point_index_success;
                                // page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.line_index = line_index_success;

                                trace(page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.point_index);

                                switch(key){
                                    case 'lane':
                                    case 'route_vehicles':
                                    case 'roadside':
                                    case 'no_right_turn':
                                    case 'no_left_turn':
                                    case 'no_direct_traffic':
                                    case 'tram_rails': {

                                        if(!isset(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index_success]['rules'])){

                                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index_success]['rules'] = {
                                                'prohibited_list':[],
                                                'allowed_list':[]
                                            };

                                        }
                                        break;
                                    }

                                }

                                page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();

                                if(isset($d('zones_control_choose'))) $d('zones_control_choose').setAttribute('class', 'zones_control_item_disable');

                                if(isset($d('zones_control_draw'))){
                                    $d('zones_control_draw').setAttribute('class', 'zones_control_item');
                                    $d('zones_control_draw').setAttribute('id', 'zones_control_done');
                                    $d('zones_control_done').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done;
                                }

                                if(isset($d('zones_control_arrow_combo'))){
                                    switch(key){
                                        case 'perspective':
                                        case 'calibration_points':
                                        case 'calibration_line':
                                        case 'stop_line': {

                                            if(isset($d('zones_control_arrow_combo'))){
                                                $d('zones_control_arrow_combo').setAttribute('class', 'zones_control_item_disable');
                                            }
                                            break;
                                        }

                                        default: {
                                            if(isset($d('zones_control_arrow'))) $d('zones_control_arrow').setAttribute('class', 'zones_control_item');
                                            break;
                                        }
                                    }
                                }

                                if(isset($d('zones_control_remove'))) $d('zones_control_remove').setAttribute('class', 'zones_control_item');
                            }
                        }
                    }
                },

                'point': { // $d('zones_control_fix').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.point.init
                    'init': function(){

                        cl('point init'); // console.trace(); //cl('ssaved');
                        if(page_object.action.admin.action.zones_content.active_layer === 'control_zone') return;
                        cl(page_object.action.admin.action.zones_content.active_layer);

                        var move_mode = page_object.action.admin.action.zones_content.move_mode;
                        if(isset($d('zones_video_container')) && isset($d('zones_control_fix')))
                            if($d('zones_control_fix').getAttribute('class') === 'zones_control_item_lock') move_mode = true; else move_mode = false;
                        //cl(move_mode);
                        if(move_mode) page_object.action.admin.action.zones_content.move_mode = true; else page_object.action.admin.action.zones_content.move_mode = false;
                        //cl(page_object.action.admin.action.zones_content.move_mode);

                        if(move_mode){ // move_mode

                            $d('zones_control_fix').setAttribute('class', 'zones_control_item_un_lock');

                            if(isset($d('zones_control_choose'))) $d('zones_control_choose').setAttribute('class', 'zones_control_item_disable');
                            if(isset($d('zones_control_draw'))) $d('zones_control_draw').setAttribute('class', 'zones_control_item_disable');
                            if(isset($d('zones_control_arrow'))) $d('zones_control_arrow').setAttribute('class', 'zones_control_item_up_disable');
                            if(isset($d('zones_control_combo'))) $d('zones_control_combo').setAttribute('class', 'zones_control_item_combo_disable');
                            if(isset($d('zones_control_remove'))) $d('zones_control_remove').setAttribute('class', 'zones_control_item_disable');

                            if(isset($d('zone_point'))) return;

                            let  el
                                , container_w = elementSize.width($d('zones_video_container'))
                                , container_h = elementSize.height($d('zones_video_container'))
                                , point_x = parseInt(container_w/2)
                                , point_y = parseInt(container_h/2);

                            el = addElement({'tag': 'div', 'id': 'zone_point', 'class': 'zone_point', 'style': 'transform: translate('+ point_x +'px, '+ point_y +'px)'});

                            $d('zones_video_container').appendChild(el);
                            $d('zones_video_container').onmousedown = page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.start;
                            page_object.action.admin.action.zones_content.action.zone.canvas.move_list = Object.assign({}, page_object.action.admin.data['zones']['zone_list']);
                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw_all();

                            ///////////////
                            // if(!page_object.action.admin.action.zones_content.active_layer){
                                //cl(page_object.action.admin.action.zones_content.active_layer);
                                var llist = page_object.action.admin.data['zones']['zone_list'];
                                //page_object.action.admin.action.zones_content.action.zone.save.zone_list.encode_coords(page_object.action.admin.data['zones']['zone_list']);
                                /*page_object.action.admin.action.zones_content.saved = page_object.action.admin.action.zones_content.action.zone.save.zone_list.encode_coords(page_object.action.admin.action.zones_content.saved);
                                for(kkey in llist){
                                    page_object.action.admin.action.zones_content.saved[kkey] = jQuery.extend(true, {}, llist[kkey]);
                                }*/
                                //Object.assign({}, list);
                                //page_object.action.admin.action.zones_content.saved = page_object.action.admin.action.zones_content.action.zone.save.zone_list.decode_coords(llist);
                                //page_object.action.admin.action.zones_content.saved = Object.assign({}, llist);

                                for(kkey in llist) page_object.action.admin.action.zones_content.saved[kkey] = jQuery.extend(true, {}, llist[kkey]);
                            //}
                            ///////////////

                            // page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.start

                        } else {
                            //cl($d('zone_point'));
                            //cl(page_object.action.admin.action.zones_content.action.zone.canvas.move_list); return;
                            //console.trace();
                                        //cl(page_object.action.admin.action.zones_content.saved);
                                        //cl(page_object.action.admin.action.zones_content.action.zone.canvas.move_list);
                                        //return;
                            if(isset($d('zone_point'))) page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.save.init();
                        }
                    },

                    'mouse': {
                        'point_start_x':null,
                        'point_start_y':null,
                        'point_x':null,
                        'point_y':null,
                        'get_point_position': function(e){

                            let  mouse_position = mouse.getPosition(e)
                                , mouse_position_x = mouse_position['x']
                                , mouse_position_y = mouse_position['y']
                                , el_position = getElementPosition($d('zones_video_container'))
                                , el_position_x = el_position['left']
                                , el_position_y = el_position['top']
                                , mouse_x = mouse_position_x-el_position_x
                                , mouse_y = mouse_position_y-el_position_y;

                            return {
                                'x':mouse_x,
                                'y':mouse_y
                            };

                        },

                        'start': function(e){ cl('mouse.start'); // page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.start
                            if(!isset($d('zones_video_container'))) return false;
                            let  mouse_position = page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.get_point_position(e)
                                , mouse_x = mouse_position['x']
                                , mouse_y = mouse_position['y'];

                            page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.point_start_x = mouse_x;
                            page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.point_start_y = mouse_y;

                            if(isset($d('zones_video_container'))){
                                $d('zones_video_container').onmousemove = page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.move;
                                $w().onmouseup = page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.up;
                            }
                            return false;
                        },

                        'move': function(e){ //cl('fmove');  // page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.move   //cl(page_object.action.admin.action.zones_content.saved.lane.layer_list[0].point_list[0]);

                            if(!isset($d('zone_point'))) return false;

                            let  mouse_position = page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.get_point_position(e)
                                , point_start_x = page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.point_start_x
                                , point_start_y = page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.point_start_y
                                , mouse_x = mouse_position['x']
                                , mouse_y = mouse_position['y']
                                , el_w = elementSize.width($d('zones_video_container'))
                                , el_h = elementSize.height($d('zones_video_container'));

                            if(mouse_x < 0) mouse_x = 0;
                            if(mouse_y < 0) mouse_y = 0;
                            if(mouse_x > el_w) mouse_x = el_w;
                            if(mouse_y > el_h) mouse_y = el_h;

                            page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.point_x = mouse_x;
                            page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.point_y = mouse_y;
                            page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.point_start_x = mouse_x;
                            page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.point_start_y = mouse_y;

                            $s('zone_point').transform='translate('+mouse_x+'px, '+mouse_y+'px)';

                            let  list = page_object.action.admin.action.zones_content.action.zone.canvas.move_list
                                , key
                                , current_list = Object.assign({}, list)
                                , line_index
                                , index
                                , point_delta_x = mouse_x-point_start_x
                                , point_delta_y = mouse_y-point_start_y;


                            /*cl('key');  cl('key');  cl(key);*/
                            //cl('page_object.action.admin.action.zones_content.active_layer');                                cl(page_object.action.admin.action.zones_content.active_layer);
                            for(key in list){  //cl('key');                                    cl('key');                                    cl(key);

                                if(page_object.action.admin.action.zones_content.active_layer !== null &&
                                    page_object.action.admin.action.zones_content.active_layer !== 'control_zone' &&
                                    key !== page_object.action.admin.action.zones_content.active_layer
                                ) continue;

                                if(!isset(current_list[key])) current_list[key] = {'layer_list':[]};

                                for(line_index in list[key]['layer_list']){

                                    if(!isset(current_list[key]['layer_list'][line_index])) current_list[key]['layer_list'][line_index] = {'point_list':[]};

                                    if(isset(page_object.action.admin.action.zones_content.action.zone.canvas.move_list[key]['layer_list'][line_index]['point_intersection'])){
                                        current_list[key]['layer_list'][line_index]['point_intersection']['x']+= Math.round(point_delta_x);
                                        current_list[key]['layer_list'][line_index]['point_intersection']['y']+= Math.round(point_delta_y);
                                        // current_list[key]['layer_list'][line_index]['point_intersection'] = {
                                        //     'x':list[key]['layer_list'][line_index]['point_intersection']['x']+point_delta_x,
                                        //     'y':list[key]['layer_list'][line_index]['point_intersection']['y']+point_delta_y
                                        // };
                                    }

                                    for(index in list[key]['layer_list'][line_index]['point_list']){
                                        current_list[key]['layer_list'][line_index]['point_list'][index]['x']+= Math.round(point_delta_x);
                                        current_list[key]['layer_list'][line_index]['point_list'][index]['y']+= Math.round(point_delta_y);
                                        // current_list[key]['layer_list'][line_index]['point_list'][index] = {
                                        //     'x':list[key]['layer_list'][line_index]['point_list'][index]['x']+point_delta_x,
                                        //     'y':list[key]['layer_list'][line_index]['point_list'][index]['y']+point_delta_y
                                        // };
                                    }
                                }
                            }

                            page_object.action.admin.action.zones_content.action.zone.canvas.move_list = Object.assign({}, current_list);
                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw_all();

                            return false;
                        },

                        'up': function(e){ // page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.up

                            let  mouse_position = page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.get_point_position(e)
                                , mouse_x = mouse_position['x']
                                , mouse_y = mouse_position['y'];

                            if(isset($d('zones_video_container'))){
                                $d('zones_video_container').onmousemove = function(){};
                                $d('zones_video_container').onmouseup = function(){};
                            }

                            page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.point_start_x = mouse_x;
                            page_object.action.admin.action.zones_content.action.zone.canvas.point.mouse.point_start_y = mouse_y;

                            page_object.action.admin.action.zones_content.action.zone.is_edit = true;
                            // page_object.action.admin.action.zones_content.action.zone.canvas.is_edit = true;

                            page_object.action.admin.action.zones_content.action.zone.controls();
                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.controls();
                            return false;
                        },
                    }
                },
                'remove': {
                    'init': function(){

                        let inner='';
                        inner+= '<div class="dialog_row">Удалить выделенную зону контроля или элемент разметки?</div>';

                        var dialog_index = page_object.dialog.init({
                            'title': 'Информация',
                            'inner':inner,
                            'remove': function(){
                                page_object.action.admin.action.zones_content.action.zone.canvas.remove.drop();
                                page_object.dialog.action.un_show.init(dialog_index, true);
                            },
                            'cancel':true
                        });

                    },
                    'drop': function(){

                        let  line_index = page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index
                            , key = page_object.action.admin.action.zones_content.action.zone.choose_type.key;

                        page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'].splice(line_index, 1);

                        page_object.action.admin.action.zones_content.action.zone.is_edit = true;
                        page_object.action.admin.action.zones_content.action.zone.canvas.is_edit = true;
                        page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index = null;
                        page_object.action.admin.action.zones_content.action.zone.canvas.list_forward = [];

                        if(isset($d('zones_control_choose'))){
                            if(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'].length>0)
                                $d('zones_control_choose').setAttribute('class', 'zones_control_item');
                            else
                                $d('zones_control_choose').setAttribute('class', 'zones_control_item_disable');
                        }

                        if(isset($d('zones_control_done'))){

                            $d('zones_control_done').setAttribute('id', 'zones_control_draw');

                            switch(key){
                                case 'perspective': {
                                    if(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'].length >= 2)
                                        $d('zones_control_draw').setAttribute('class', 'zones_control_item_disable');
                                    else {
                                        delete page_object.action.admin.action.zones_content.action.zone.canvas.list['point_intersection'];
                                        $d('zones_control_draw').setAttribute('class', 'zones_control_item');
                                    }
                                    break;
                                }

                                default: {
                                    $d('zones_control_draw').setAttribute('class', 'zones_control_item');
                                    break;
                                }
                            }
                            $d('zones_control_draw').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.init;
                        }

                        if(isset($d('zones_control_fix'))) $d('zones_control_fix').setAttribute('class', 'zones_control_item_lock');

                        if(isset($d('zones_control_remove'))) $d('zones_control_remove').setAttribute('class', 'zones_control_item_disable');

                        if(isset($d('zones_control_back'))) $d('zones_control_back').setAttribute('class', 'zones_control_item_disable');

                        if(isset($d('zones_control_front'))) $d('zones_control_front').setAttribute('class', 'zones_control_item_disable');

                        if(isset($d('zones_control_save'))) $d('zones_control_save').setAttribute('class', 'zones_control_item'+(page_object.action.admin.action.zones_content.action.zone.canvas.is_edit?'': '_disable'));

                        if(isset($d('zones_control_arrow'))) $d('zones_control_arrow').setAttribute('class', 'zones_control_item_up_disable');

                        if(isset($d('zones_control_combo'))) $d('zones_control_combo').setAttribute('class', 'zones_control_item_combo_disable');

                        page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();
                        page_object.action.admin.action.zones_content.action.zone.controls();
                        page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.controls();

                    }
                },
                'create': {
                    'init': function(){

                        page_object.action.admin.action.zones_content.action.zone.canvas.is_edit = false;
                        page_object.action.admin.action.zones_content.action.zone.canvas.list = [];
                        page_object.action.admin.action.zones_content.action.zone.canvas.list_forward = [];

                        page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.controls();
                        page_object.action.admin.action.zones_content.action.zone.canvas.create.add();
                    },

                    'add': function(){ cl('create add');
                        var inner='';
                        inner+= '<canvas id="zones_video_canvas_item_0" class="zones_video_canvas_item" width="590" height="493"></canvas>';
                        inner+= '<div id="zones_video_center" class="zones_video_center"'+(page_object.action.admin.action.zones_content.action.zone.canvas.show_center.is_show?' style="display: block;"': '')+'></div>';
                        inner+= '<div id="zones_video_h_line" class="zones_video_h_line"'+(page_object.action.admin.action.zones_content.action.zone.canvas.show_center.is_show?' style="display: block;"': '')+'></div>';
                        inner+= '<div id="zones_video_v_line" class="zones_video_v_line"'+(page_object.action.admin.action.zones_content.action.zone.canvas.show_center.is_show?' style="display: block;"': '')+'></div>';

                        if(isset($d('zones_video_canvas_list'))) $d('zones_video_canvas_list').innerHTML = inner;
                        page_object.action.admin.action.zones_content.action.zone.save.zone_list.decode_coords(page_object.action.admin.data['zones']['zone_list']);
                    }
                },
                'mouse': {
                    'init': function(){
                        if(isset($d('zones_video_canvas_list'))){
                            $d('zones_video_canvas_list').onmousemove = page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.live;
                            $d('zones_video_canvas_list').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.add;
                            $d('zones_video_canvas_list').oncontextmenu = page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.add;
                        }
                    },
                    'coords': {
                        'get': function(e){

                            if(isset($d('zones_video_canvas_list'))){

                                e = window.event || e;

                                let  el_pos = getElementPosition($d('zones_video_canvas_list'))
                                    , mouse_coords = mouse.getPosition(e)
                                    , point_x = Math.round(mouse_coords['x']-el_pos['left'])
                                    , point_y = Math.round(mouse_coords['y']-el_pos['top']);

                                return {
                                    'x':point_x,
                                    'y':point_y,
                                    'line_width':page_object.action.admin.action.zones_content.line.width.default
                                };
                            }
                        },
                        'live': function(e){

                            if(!isset($d('zones_video_canvas_item_0'))) return

                            let  coords_data = page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.get(e)
                                , line_index = page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index
                                , list = page_object.action.admin.action.zones_content.action.zone.canvas.list;

                            if(isset(list['layer_list'][line_index])){

                                let  coords_last_data = (list['layer_list'][line_index]['point_list'].length === 0) ? null : list['layer_list'][line_index]['point_list'][list['layer_list'][line_index]['point_list'].length-1]
                                    , point_last_x
                                    , point_last_y
                                    , point_x = coords_data['x']
                                    , point_y = coords_data['y'];

                                page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();

                                let  canvas = document.getElementById('zones_video_canvas_item_0')
                                    , canvas_object
                                    , key = page_object.action.admin.action.zones_content.action.zone.choose_type.key;

                                if(canvas.getContext){

                                    canvas_object = canvas.getContext('2d');

                                    if(!empty(coords_last_data)){

                                        point_last_x = coords_last_data['x'];
                                        point_last_y = coords_last_data['y'];

                                        switch(key){

                                            case 'control_zone': {

                                                canvas_object.beginPath();

                                                canvas_object.moveTo(point_last_x, point_last_y);
                                                canvas_object.lineTo(point_last_x, point_y);
                                                canvas_object.lineTo(point_x, point_y);

                                                canvas_object.moveTo(point_last_x, point_last_y);
                                                canvas_object.lineTo(point_x, point_last_y);
                                                canvas_object.lineTo(point_x, point_y);
                                                canvas_object.strokeStyle='green';
                                                canvas_object.stroke();
                                                canvas_object.restore();
                                                canvas_object.save();

                                                canvas_object.beginPath();

                                                canvas_object.moveTo(point_x, point_y);
                                                canvas_object.arc(point_x, point_y, page_object.action.admin.action.zones_content.point.radius.default, 2*Math.PI, false);
                                                canvas_object.fillStyle='green';
                                                canvas_object.fill();
                                                canvas_object.lineWidth = page_object.action.admin.action.zones_content.line.width.default;
                                                canvas_object.strokeStyle='green';
                                                canvas_object.stroke();
                                                canvas_object.restore();
                                                canvas_object.save();

                                                break;

                                            }

                                            default: {

                                                canvas_object.beginPath();

                                                canvas_object.moveTo(point_last_x, point_last_y);
                                                canvas_object.lineTo(point_x, point_y);

                                                canvas_object.moveTo(point_x, point_y);
                                                canvas_object.arc(point_x, point_y, page_object.action.admin.action.zones_content.point.radius.default, 2*Math.PI, false);
                                                canvas_object.fillStyle='green';
                                                canvas_object.fill();
                                                canvas_object.lineWidth = page_object.action.admin.action.zones_content.line.width.default;
                                                canvas_object.strokeStyle='green';
                                                canvas_object.stroke();
                                                canvas_object.restore();
                                                canvas_object.save();

                                                break;

                                            }
                                        }
                                    }
                                }
                            }
                        },

                        'redraw': function(){ cl('fredrawf'); // page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();

                            if(!isset($d('zones_video_canvas_item_0'))) page_object.action.admin.action.zones_content.action.zone.canvas.create.add();  //cl(page_object.action.admin.action.zones_content.action.zone.canvas.list); return;
                            let  list = page_object.action.admin.action.zones_content.action.zone.canvas.list
                                , line_index = page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index
                                , index;

                            let canvas = document.getElementById('zones_video_canvas_item_0'), canvas_object;

                            if(canvas.getContext){
                                canvas_object = canvas.getContext('2d');
                                canvas_object.clearRect(0, 0, canvas.width, canvas.height);
                            }

                            if(is_null(line_index)){
                                if(typeof list !== 'undefined')
                                    for(line_index in list['layer_list'])
                                        for(index in list['layer_list'][line_index]['point_list'])
                                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.draw(line_index, index);
                            } else {

                                let layer_index;
                                for(layer_index in list['layer_list'])
                                    for(index in list['layer_list'][layer_index]['point_list'])
                                        page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.draw(layer_index, index);
                            }
                        },

                        'redraw_all': function(){ cl('redrawa'); //cl(page_object.action.admin.action.zones_content.move_mode);

                            //cl(!isset($d('zones_video_canvas_item_0')));
                            if(!isset($d('zones_video_canvas_item_0'))) page_object.action.admin.action.zones_content.action.zone.canvas.create.add();

                            //cl(page_object.action.admin.action.zones_content.action.zone.canvas.move_list); //cl(page_object.action.admin.action.zones_content.action.zone.canvas);

                            let  list = page_object.action.admin.action.zones_content.action.zone.canvas.move_list
                                , key = page_object.action.admin.action.zones_content.action.zone.choose_type.key
                                , line_index
                                , index;

                            let  canvas = document.getElementById('zones_video_canvas_item_0')
                                , canvas_object;

                            if(canvas.getContext){
                                canvas_object = canvas.getContext('2d');
                                canvas_object.clearRect(0, 0, canvas.width, canvas.height);
                            }

                            //cl('rakey'); cl(key); cl('list'); cl(list);

                            if(empty(key)){
                                for(key in list){
                                    page_object.action.admin.action.zones_content.action.zone.canvas.list = list[key]; //if(isset(list[key]['layer_list'])) cl(list[key]['layer_list']);
                                    if(isset(list[key]['layer_list']))
                                        for(line_index in list[key]['layer_list'])
                                            for(index in list[key]['layer_list'][line_index]['point_list'])
                                                page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.draw(line_index, index);

                                }

                            } else {

                                page_object.action.admin.action.zones_content.action.zone.canvas.list = list[key];

                                cl(list[key]);
                                cl(list[key]);
                                cl(list[key]);
                                cl(list[key]);
                                //if(isset(list[key]['layer_list'])) cl(list[key]['layer_list']);
                                if(typeof list[key] === 'undefined'){
                                    //page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw_all();
                                } else
                                    if(isset(list[key]['layer_list']))
                                        for(line_index in list[key]['layer_list'])
                                            for(index in list[key]['layer_list'][line_index]['point_list'])
                                                page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.draw(line_index, index);

                            }
                        },

                        'image_onload': function(base_image, point_x, point_y, direction){

                            let  canvas = document.getElementById('zones_video_canvas_item_0')
                                , canvas_object = canvas.getContext('2d')
                                , degree = Math.PI;

                            switch(direction){

                                case 'up': {

                                    degree/= 180;

                                    break;

                                }

                            }

                            //trace('>>>>>>>>>>>>');
                            //trace(point_x+' '+point_y);
                            //trace(base_image);
                            canvas_object.beginPath();
                            canvas_object.save();
                            canvas_object.translate(point_x, point_y);
                            canvas_object.rotate(degree);
                            canvas_object.drawImage(base_image, -15, -15, 30, 30);
                            canvas_object.stroke();
                            canvas_object.restore();
                            canvas_object.save();

                        },

                        'draw' : function(line_index, index){  //cl(fdraw);                            return;
                            if(!isset($d('zones_video_canvas_item_0'))) return;

                            var  line_list = page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list']
                                , current_line_index = page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index
                                , line_data = line_list[line_index]
                                , list = line_data['point_list']
                                , coords_data = list[index]
                                , coords_last_data = index === 0?null:list[index-1]
                                , key = page_object.action.admin.action.zones_content.action.zone.choose_type.key
                                , point_last_x
                                , point_last_y
                                , line_width = coords_data['line_width']
                                , radius = isset(coords_data['radius'])?coords_data['radius'] : page_object.action.admin.action.zones_content.point.radius.default
                                , colour_line ='red'
                                , colour_point ='red'
                                , colour_text ='red'
                                , colour_arrow ='white'
                                , point_x = coords_data['x']
                                , point_y = coords_data['y']
                                , canvas = document.getElementById('zones_video_canvas_item_0')
                                , canvas_object;
                            cl(g.zone_test);
                            cl(g);
                            if(g.zones_test){
                                colour_line = test_colour_line;
                                colour_point = test_colour_point;
                                colour_text = test_colour_text;
                            }

                            if(!is_null(current_line_index)){
                                if(parseInt(current_line_index) !== parseInt(line_index)){
                                    colour_line ='#000000';
                                    colour_point ='#000000';
                                    colour_text ='#000000';
                                    colour_arrow = null;
                                }
                            }

                            if(canvas.getContext){

                                canvas_object = canvas.getContext('2d');

                                canvas_object.beginPath();

                                if(empty(coords_last_data)){

                                    canvas_object.moveTo(point_x, point_y);
                                    canvas_object.arc(point_x, point_y, radius, 2*Math.PI, false);
                                    canvas_object.fillStyle = colour_point;
                                    canvas_object.fill();
                                    canvas_object.lineWidth = line_width;
                                    canvas_object.strokeStyle = colour_point;
                                    canvas_object.stroke();
                                    canvas_object.restore();
                                    canvas_object.save();

                                    if(isset(line_data['distance'])){

                                        if(parseInt(index) === list.length-1){

                                            let  coords_first_data = list[0]
                                                , point_first_x = coords_first_data['x']
                                                , point_first_y = coords_first_data['y']
                                                , x = point_first_x+10
                                                , y = point_first_y
                                                , delta_y = 7
                                                , delta_x = 0;

                                            canvas_object.save();

                                            canvas_object.font ='10px Arial';
                                            canvas_object.textAlign ='left';
                                            canvas_object.fillStyle = colour_text;

                                            canvas_object.fillText((line_data['distance']+' мм'), (x+delta_x), (y+delta_y));

                                            canvas_object.restore();

                                        }

                                    }

                                } else {

                                    point_last_x = coords_last_data['x'];
                                    point_last_y = coords_last_data['y'];

                                    canvas_object.lineWidth = line_width;
                                    canvas_object.strokeStyle = colour_line;

                                    canvas_object.moveTo(point_last_x, point_last_y);
                                    canvas_object.lineTo(point_x, point_y);

                                    canvas_object.moveTo(point_x, point_y);
                                    canvas_object.arc(point_x, point_y, radius, 2*Math.PI, false);
                                    canvas_object.fillStyle = colour_line;
                                    canvas_object.fill();
                                    canvas_object.stroke();
                                    canvas_object.restore();
                                    canvas_object.save();

                                    switch(key){
                                        case 'control_zone': {
                                            if(parseInt(index) === list.length-1
                                                &&list.length === 4
                                            ){

                                                let  coords_first_data = list[0]
                                                    , point_first_x = coords_first_data['x']
                                                    , point_first_y = coords_first_data['y'];

                                                canvas_object.moveTo(point_x, point_y);
                                                canvas_object.lineTo(point_first_x, point_first_y);
                                                canvas_object.stroke();
                                                canvas_object.restore();
                                                canvas_object.save();

                                            }
                                            break;
                                        }
                                    }   //trace('line_data: ');                  //trace(line_data);

                                    if(isset(line_data['distance'])){
                                        if(parseInt(index) === list.length-1){
                                            let  coords_first_data = list[0]
                                                , point_first_x = coords_first_data['x']
                                                , point_first_y = coords_first_data['y']
                                                , x = (point_first_x+point_last_x)/2
                                                , y = (point_first_y+point_last_y)/2
                                                , delta_y = -10
                                                , delta_x = 0;

                                            canvas_object.save();
                                            canvas_object.font ='10px Arial';
                                            canvas_object.textAlign ='center';
                                            canvas_object.fillStyle = colour_text;
                                            canvas_object.fillText((line_data['distance']+' мм'), (x+delta_x+25), (y+delta_y+10));
                                            canvas_object.restore();
                                        }
                                    } else if(isset(line_data['direction'])){

                                        if(parseInt(index) === list.length-1
                                            &&list.length>4
                                        ){

                                            let  x_sum = 0
                                                , y_sum = 0
                                                , point_index
                                                , rule_list = isset(line_data['rules'])?line_data['rules'] :  {}
                                                , rule_allowed_list = isset(rule_list['allowed_list'])?rule_list['allowed_list'] : []
                                                , rule_key = page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.get_rule_key_from_list(line_index, rule_allowed_list)
                                                , rule_image = page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.get_rule_key_image(rule_key);

                                            var  point_x
                                                , point_y
                                                , base_image;

                                            for(point_index = 0;point_index<list.length-1;point_index++){
                                                x_sum+= list[point_index]['x'];
                                                y_sum+= list[point_index]['y'];
                                            }

                                            point_x = parseInt(x_sum/(list.length-1));
                                            point_y = parseInt(y_sum/(list.length-1));

                                            if(!is_null(colour_arrow)){
                                                switch(line_data['direction']){
                                                    case 'down':
                                                    case 'up': {
                                                        // let func = new Function("page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.image_onload("+point_x+", "+point_y+");");

                                                        base_image = new Image();
                                                        base_image.x = point_x;
                                                        base_image.y = point_y;
                                                        base_image.src = rule_image;
                                                        base_image.onload = function(){
                                                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.image_onload(this, point_x, point_y, line_data['direction']);
                                                        };
                                                        page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.image_onload(base_image, point_x, point_y, line_data['direction']);
                                                        break;
                                                    }
                                                }
                                            }

                                            if(isset(line_data['lane'])){
                                                canvas_object.save();
                                                canvas_object.font = (line_width === page_object.action.admin.action.zones_content.line.width.default?'': 'bold ')+'10px Arial';
                                                canvas_object.textAlign ='center';
                                                canvas_object.fillStyle = colour_text;
                                                canvas_object.fillText('#'+line_data['lane'], (point_x+30), (point_y+8));
                                                canvas_object.restore();
                                            } else if(isset(line_data['time'])){
                                                canvas_object.save();
                                                canvas_object.font = (line_width === page_object.action.admin.action.zones_content.line.width.default?'': 'bold ')+'10px Arial';
                                                canvas_object.textAlign ='center';
                                                canvas_object.fillStyle = colour_text;
                                                canvas_object.fillText(line_data['time']+' сек.', (point_x-15), (point_y+8));
                                                canvas_object.restore();
                                            }
                                        }
                                    }
                                }
                            }
                        },
                        'add': function(e){

                            let  coords_data = page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.get(e)
                                , key = page_object.action.admin.action.zones_content.action.zone.choose_type.key
                                , point_x = coords_data['x']
                                , point_y = coords_data['y'];

                            var line_index = page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index;

                            page_object.action.admin.action.zones_content.action.zone.canvas.is_edit = true;
                            page_object.action.admin.action.zones_content.action.zone.is_edit = true;
                            page_object.action.admin.action.zones_content.action.zone.canvas.list_forward = [];

                            switch(e.which){

                                case 1: {

                                    if(!isset(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]))
                                        page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index] = {
                                            'point_list':[]
                                        };

                                    switch(key){

                                        case 'control_zone': {

                                            if(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].length === 0){

                                                page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].push({
                                                    'x':point_x,
                                                    'y':point_y
                                                });

                                            } else {

                                                let  list = page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list']
                                                    , last_point_data = list[list.length-1]
                                                    , last_point_x = last_point_data['x']
                                                    , last_point_y = last_point_data['y'];

                                                page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].push({
                                                    'x':point_x,
                                                    'y':last_point_y
                                                });

                                                page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].push({
                                                    'x':point_x,
                                                    'y':point_y
                                                });

                                                page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].push({
                                                    'x':last_point_x,
                                                    'y':point_y
                                                });

                                            }

                                            break;

                                        }

                                        default: {

                                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].push({
                                                'x':point_x,
                                                'y':point_y
                                            });

                                            break;

                                        }

                                    }

                                    switch(key){

                                        case 'perspective':
                                        case 'stop_line': {

                                            if(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].length >= 2)
                                                page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();

                                            break;

                                        }

                                        case 'anchor_points': {

                                            if(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].length >= 1)
                                                page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();

                                            break;

                                        }

                                        case 'calibration_points': {

                                            if(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].length >= 1){

                                                var  inner = '', dialog_index, title ='Добавление калибровочной точки';

                                                if(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'].length === 1){

                                                    inner+= '<div class="dialog_row">';
                                                    inner+= 'Добавить нулевую калибровочную точки для рассчета скорости движения АТС?';
                                                    inner+= '</div>';

                                                    inner+= '<div class="dialog_row">';
                                                    inner+= 'Расстояния до следующих калибровочных точек будут указываться относительно данной калибровочной точки.';
                                                    inner+= '</div>';

                                                    dialog_index = page_object.dialog.init({
                                                        'title':title,
                                                        'inner':inner,
                                                        'add': function(){

                                                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['distance'] = 0;

                                                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();
                                                            page_object.dialog.action.un_show.init(dialog_index, true);

                                                        },
                                                        'on_cancel': function(){

                                                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'] = [];

                                                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();
                                                            page_object.dialog.action.un_show.init(dialog_index, true);

                                                        }
                                                    });

                                                } else {

                                                    inner+= '<div class="dialog_row">Для добавления следующей калибровочной токчи, задайте расстояние до нулевой калибровочной токчи</div>';
                                                    inner+= '<div class="dialog_row">';
                                                        inner+= '<div class="dialog_row_label_x2" style="width: 200px;">';
                                                            inner+= '<span>Расстояние, мм</span>';
                                                        inner+= '</div>';
                                                        inner+= '<div class="dialog_row_input" style="width: 100px;">';
                                                            inner+= '<input type="number" min="0" max="100" id="dialog_line_distance" class="dialog_row_input_text" value="0">';
                                                        inner+= '</div>';
                                                    inner+= '</div>';

                                                    dialog_index = page_object.dialog.init({
                                                        'title':title,
                                                        'inner':inner,
                                                        'add': function(){

                                                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['distance'] = parseInt($v('dialog_line_distance'));

                                                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();
                                                            page_object.dialog.action.un_show.init(dialog_index, true);

                                                        },
                                                        'on_cancel': function(){

                                                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'] = [];

                                                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();
                                                            page_object.dialog.action.un_show.init(dialog_index, true);

                                                        }
                                                    });

                                                }

                                            }

                                            break;

                                        }

                                        // case 'calibration_points':
                                        case 'calibration_line': {

                                            if(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].length >= 2){

                                                var  inner=''
                                                    , dialog_index
                                                    , title ='Добавление калибровочной линии';

                                                if(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'].length === 1){

                                                    inner+= '<div class="dialog_row">';
                                                    inner+= 'Добавить нулевую калибровочную линию для рассчета скорости движения АТС?';
                                                    inner+= '</div>';

                                                    inner+= '<div class="dialog_row">';
                                                    inner+= 'Расстояния до следующих калибровочных линий будут указываться относительно данной калибровочной линии.';
                                                    inner+= '</div>';

                                                    dialog_index = page_object.dialog.init({
                                                        'title':title,
                                                        'inner':inner,
                                                        'add': function(){

                                                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['distance'] = 0;

                                                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();
                                                            page_object.dialog.action.un_show.init(dialog_index, true);

                                                        },
                                                        'on_cancel': function(){

                                                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'] = [];

                                                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();
                                                            page_object.dialog.action.un_show.init(dialog_index, true);

                                                        }
                                                    });

                                    } else {

                                                    inner+= '<div class="dialog_row">Для добавления следующей калибровочной линии, задайте расстояние до нулевой калибровочной линии</div>';
                                                    inner+= '<div class="dialog_row">';
                                                        inner+= '<div class="dialog_row_label_x2" style="width: 200px;">';
                                                            inner+= '<span>Расстояние, мм</span>';
                                                        inner+= '</div>';
                                                        inner+= '<div class="dialog_row_input" style="width: 100px;">';
                                                            inner+= '<input type="number" min="0" max="100" id="dialog_line_distance" class="dialog_row_input_text" value="0">';
                                                        inner+= '</div>';
                                                    inner+= '</div>';

                                                    dialog_index = page_object.dialog.init({
                                                        'title':title,
                                                        'inner':inner,
                                                        'add': function(){

                                                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['distance'] = parseInt($v('dialog_line_distance'));

                                                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();
                                                            page_object.dialog.action.un_show.init(dialog_index, true);

                                                        },
                                                        'on_cancel': function(){

                                                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'] = [];

                                                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();
                                                            page_object.dialog.action.un_show.init(dialog_index, true);

                                                        }
                                                    });

                                                }

                                            }

                                            break;

                                        }

                                        case 'lane': {

                                            if(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].length >= 4){

                                                var  inner=''
                                                    , dialog_index
                                                    , title ='Добавление номера полосы движения';

                                                inner+= '<div class="dialog_row">Для добавления полосы движения, задайте её порядковый номер в соответствии с ГОСТ.</div>';
                                                inner+= '<div class="dialog_row">';
                                                    inner+= '<div class="dialog_row_label_x2" style="width: 200px;">';
                                                        inner+= '<span>Номер полосы движения: </span>';
                                                    inner+= '</div>';
                                                    inner+= '<div class="dialog_row_input" style="width: 100px;">';
                                                        inner+= '<input type="number" min="1" max="10" id="dialog_line_number" class="dialog_row_input_text" value="1">';
                                                    inner+= '</div>';
                                                inner+= '</div>';

                                                dialog_index = page_object.dialog.init({
                                                    'title':title,
                                                    'w':500,
                                                    'inner':inner,
                                                    'add': function(){

                                                        page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['lane'] = parseInt($v('dialog_line_number'));
                                                        page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['rules'] = {
                                                            'prohibited_list':[],
                                                            'allowed_list':page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.get_rule_list("arrow_rule_forward_up")
                                                        };

                                                        // page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();
                                                        page_object.dialog.action.un_show.init(dialog_index, true);

                                                        setTimeout(function(){

                                                            page_object.action.admin.action.zones_content.action.zone.canvas.arrow_combo.init(function(){
                                                                page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();
                                                            });

                                                        }, 340);

                                                    },
                                                    'on_cancel': function(){

                                                        page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'] = [];
                                                        page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['rules'] = {
                                                            'prohibited_list':[],
                                                            'allowed_list':[]
                                                        };

                                                        page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();
                                                        page_object.dialog.action.un_show.init(dialog_index, true);

                                                    }
                                                });

                                            }

                                            break;

                                        }

                                        case 'no_parking': {

                                            if(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].length >= 4){

                                                var  inner=''
                                                    , dialog_index
                                                    , title ='Добавление зоны без остановки';

                                                inner+= '<div class="dialog_row">Для добавления зоны без остановки необходимо ввести максимальное время нахождения ТС в данной зоне без движения</div>';
                                                inner+= '<div class="dialog_row">';
                                                    inner+= '<div class="dialog_row_label_x2" style="width: 200px;">';
                                                        inner+= '<span>Время, сек: </span>';
                                                    inner+= '</div>';
                                                    inner+= '<div class="dialog_row_input" style="width: 100px;">';
                                                        inner+= '<input type="number" min="1" max="10" id="dialog_no_parking_time" class="dialog_row_input_text" value="1">';
                                                    inner+= '</div>';
                                                inner+= '</div>';

                                                dialog_index = page_object.dialog.init({
                                                    'title':title,
                                                    'w':500,
                                                    'inner':inner,
                                                    'add': function(){

                                                        page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['time'] = parseInt($v('dialog_no_parking_time'));

                                                        page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();
                                                        page_object.dialog.action.un_show.init(dialog_index, true);

                                                    },
                                                    'on_cancel': function(){

                                                        page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'] = [];

                                                        page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();
                                                        page_object.dialog.action.un_show.init(dialog_index, true);

                                                    }
                                                });

                                            }

                                            break;

                                        }

                                        case 'no_stop': {

                                            if(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].length >= 4){

                                                var  inner=''
                                                    , dialog_index
                                                    , title ='Добавление зоны без стоянки';

                                                inner+= '<div class="dialog_row">Для добавления зоны без стоянки необходимо ввести максимальное время нахождения ТС в данной зоне без движения</div>';
                                                inner+= '<div class="dialog_row">';
                                                    inner+= '<div class="dialog_row_label_x2" style="width: 200px;">';
                                                        inner+= '<span>Время, сек: </span>';
                                                    inner+= '</div>';
                                                    inner+= '<div class="dialog_row_input" style="width: 100px;">';
                                                        inner+= '<input type="number" min="1" max="10" id="dialog_no_parking_time" class="dialog_row_input_text" value="1">';
                                                    inner+= '</div>';
                                                inner+= '</div>';

                                                dialog_index = page_object.dialog.init({
                                                    'title':title,
                                                    'w':500,
                                                    'inner':inner,
                                                    'add': function(){

                                                        page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['time'] = parseInt($v('dialog_no_parking_time'));

                                                        page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();
                                                        page_object.dialog.action.un_show.init(dialog_index, true);

                                                    },
                                                    'on_cancel': function(){

                                                        page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'] = [];

                                                        page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();
                                                        page_object.dialog.action.un_show.init(dialog_index, true);

                                                    }
                                                });

                                            }

                                            break;

                                        }

                                        case 'control_zone': {

                                            if(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].length >= 4)
                                                page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();

                                            break;

                                        }

                                        // case 'no_stop': {
                                        //
                                        //     if(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].length >= 4)
                                        //         page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();
                                        //
                                        //     break;
                                        //
                                        // }

                                        default: {

                                            if(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].length >= 4)
                                                page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();

                                            break;

                                        }

                                    }

                                    break;

                                }

                                case 3: {

                                    page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.done();

                                    break;

                                }

                            }

                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();
                            page_object.action.admin.action.zones_content.action.zone.controls();
                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.controls();

                            e.preventDefault();
                            //e.returnValue=false; //'add': function(e){
                            return false;
                        },

                        'back': function(){

                            let line_index = page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index;

                            if(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].length>0){

                                page_object.action.admin.action.zones_content.action.zone.canvas.is_edit = true;
                                page_object.action.admin.action.zones_content.action.zone.is_edit = true;

                                page_object.action.admin.action.zones_content.action.zone.canvas.list_forward.push(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].pop());

                                page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();
                                page_object.action.admin.action.zones_content.action.zone.controls();
                                page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.controls();

                            }

                        },
                        'forward': function(){ //page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.forward;

                            let line_index = page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index;

                            if(page_object.action.admin.action.zones_content.action.zone.canvas.list_forward.length>0){

                                page_object.action.admin.action.zones_content.action.zone.canvas.is_edit = true;
                                page_object.action.admin.action.zones_content.action.zone.is_edit = true;

                                page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].push(page_object.action.admin.action.zones_content.action.zone.canvas.list_forward.pop());

                                page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();
                                page_object.action.admin.action.zones_content.action.zone.controls();
                                page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.controls();

                            }

                        },
                        'controls': function(){

                            let line_index = page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index;

                            if(is_null(line_index)){
                                if(isset($d('zones_control_front'))) $d('zones_control_front').setAttribute('class', 'zones_control_item_disable');

                                if(isset($d('zones_control_back'))) $d('zones_control_back').setAttribute('class', 'zones_control_item_disable');

                            } else if(is_null(page_object.action.admin.action.zones_content.action.zone.canvas.choose_point.point_index)){

                                if(isset($d('zones_control_front'))) $d('zones_control_front').setAttribute('class', 'zones_control_item'+(page_object.action.admin.action.zones_content.action.zone.canvas.list_forward.length === 0?'_disable': ''));
                                if(isset($d('zones_control_back'))) $d('zones_control_back').setAttribute('class', 'zones_control_item'+(page_object.action.admin.action.zones_content.action.zone.canvas.list.length === 0?'_disable': ''));
                            }

                            if(isset($d('zones_control_save'))) $d('zones_control_save').setAttribute('class', 'zones_control_item'+(page_object.action.admin.action.zones_content.action.zone.canvas.is_edit?'': '_disable'));
                        },
                        'done': function(){

                            let  list = page_object.action.admin.action.zones_content.action.zone.canvas.list
                                , key = page_object.action.admin.action.zones_content.action.zone.choose_type.key
                                , line_index = page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index
                                , coords_last_data
                                , point_last_x
                                , point_last_y;

                            switch(key){

                                case 'perspective': {

                                    if(list['layer_list'].length >= 2){

                                        if(list['layer_list'][line_index]['point_list'].length>0){

                                            let  point_list_1 = page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][0]['point_list']
                                                , point_list_2 = page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][1]['point_list']
                                                , a = point_list_1[0]
                                                , b = point_list_1[1]
                                                , c = point_list_2[0]
                                                , d = point_list_2[1]
                                                , a_x = a['x']
                                                , a_y = a['y']
                                                , b_x = b['x']
                                                , b_y = b['y']
                                                , c_x = c['x']
                                                , c_y = c['y']
                                                , d_x = d['x']
                                                , d_y = d['y']
                                                , t_x = -((a_x*b_y-b_x*a_y)*(d_x-c_x)-(c_x*d_y-d_x*c_y)*(b_x-a_x))/((a_y-b_y)*(d_x-c_x)-(c_y-d_y)*(b_x-a_x))
                                                , t_y = ((c_y-d_y)*(-t_x)-(c_x*d_y-d_x*c_y))/(d_x-c_x);

                                            page_object.action.admin.action.zones_content.action.zone.canvas.list['point_intersection'] = {
                                                'x':t_x,
                                                'y':t_y
                                            };

                                        }
                                        else
                                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'].splice(line_index, 1);

                                    }

                                    break;

                                }

                                default: {

                                    if(list['layer_list'][line_index]['point_list'].length >= 1){

                                        coords_last_data = list['layer_list'][line_index]['point_list'][0];

                                        point_last_x = coords_last_data['x'];
                                        point_last_y = coords_last_data['y'];

                                        let  coords_end_data = list['layer_list'][line_index]['point_list'][list['layer_list'][line_index]['point_list'].length-1]
                                            , point_end_x = coords_end_data['x']
                                            , point_end_y = coords_end_data['y'];

                                        if(point_end_x !== point_last_x
                                            &&point_end_y !== point_last_y
                                        )
                                            page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'][line_index]['point_list'].push({
                                                'x':point_last_x,
                                                'y':point_last_y
                                            });

                                        switch(key){

                                            case 'lane': {

                                                break;

                                            }

                                        }

                                    }
                                    else
                                        page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'].splice(line_index, 1);

                                    break;

                                }

                            }

                            if(isset($d('zones_control_front')))
                                $s('zones_control_front').display='inline-block';

                            if(isset($d('zones_control_back')))
                                $s('zones_control_back').display='inline-block';

                            if(isset($d('zones_control_done'))){

                                $d('zones_control_done').setAttribute('id', 'zones_control_draw');

                                switch(key){

                                    case 'stop_line':
                                    case 'perspective': {

                                        if(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'].length >= 2)
                                            $d('zones_control_draw').setAttribute('class', 'zones_control_item_disable');
                                        else
                                            $d('zones_control_draw').setAttribute('class', 'zones_control_item');

                                        break;

                                    }

                                    default: {

                                        $d('zones_control_draw').setAttribute('class', 'zones_control_item');

                                        break;

                                    }

                                }

                                $d('zones_control_draw').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.init;

                            }

                            if(isset($d('zones_control_choose')))
                                $d('zones_control_choose').setAttribute('class', 'zones_control_item');

                            if(isset($d('zones_control_point')))
                                $d('zones_control_point').setAttribute('class', 'zones_control_item_disable');

                            if(isset($d('zones_control_fix'))) $d('zones_control_fix').setAttribute('class', 'zones_control_item_lock');

                            if(isset($d('zones_control_remove')))
                                $d('zones_control_remove').setAttribute('class', 'zones_control_item_disable');

                            if(isset($d('zones_control_arrow')))
                                $d('zones_control_arrow').setAttribute('class', 'zones_control_item_up_disable');

                            if(isset($d('zones_control_combo')))
                                $d('zones_control_combo').setAttribute('class', 'zones_control_item_combo_disable');

                            if(isset($d('zones_control_arrow_combo')))
                                $d('zones_control_arrow_combo').setAttribute('class', 'zones_control_item_disable');

                            if(isset($d('zones_video_canvas_list'))){

                                $d('zones_video_canvas_list').onmousemove = function(){};
                                $d('zones_video_canvas_list').onclick = function(){};
                                $d('zones_video_canvas_list').oncontextmenu = function(){};

                            }

                            page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index = null;

                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();
                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.controls();

                        },
                        'cancel': function(){

                        },
                        'save': {

                            'save': function(){

                                if(isset($d('zone_point'))) removeElement($d('zone_point'));

                                if(!is_null(page_object.action.admin.action.zones_content.action.zone.choose_type.key)){

                                    let key = page_object.action.admin.action.zones_content.action.zone.choose_type.key;

                                    if(!isset(page_object.action.admin.data['zones']['zone_list'][key]))
                                        page_object.action.admin.data['zones']['zone_list'][key] = {
                                            'layer_list':[]
                                        };

                                    if(!isset(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list']))
                                        page_object.action.admin.action.zones_content.action.zone.canvas.list = {
                                            'layer_list':[]
                                        };

                                    if(!isset(page_object.action.admin.data['zones']['zone_list'][key]['layer_list']))
                                        page_object.action.admin.data['zones']['zone_list'][key]['layer_list'] = [];

                                    page_object.action.admin.data['zones']['zone_list'][key]['layer_list'] = Object.assign([], page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list']);

                                    if(isset($d('zones_control_done'))){

                                        $d('zones_control_done').setAttribute('id', 'zones_control_draw');

                                        switch(key){

                                            // case 'anchor_points': {
                                            //
                                            //     if(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'].length >= 1)
                                            //         $d('zones_control_draw').setAttribute('class', 'zones_control_item_disable');
                                            //     else
                                            //         $d('zones_control_draw').setAttribute('class', 'zones_control_item');
                                            //
                                            //     break;
                                            //
                                            // }

                                            case 'perspective': {
                                                if(page_object.action.admin.action.zones_content.action.zone.canvas.list['layer_list'].length >= 2)
                                                    $d('zones_control_draw').setAttribute('class', 'zones_control_item_disable');
                                                else
                                                    $d('zones_control_draw').setAttribute('class', 'zones_control_item');
                                                break;
                                            }

                                            default: {
                                                $d('zones_control_draw').setAttribute('class', 'zones_control_item');
                                                break;
                                            }
                                        }
                                        $d('zones_control_draw').onclick = page_object.action.admin.action.zones_content.action.zone.canvas.init;
                                    }

                                    if(isset($d('zones_control_arrow')))
                                        $d('zones_control_arrow').setAttribute('class', 'zones_control_item_disable');

                                    if(isset($d('zones_control_point')))
                                        $d('zones_control_point').setAttribute('class', 'zones_control_item_disable');

                                    if(isset($d('zones_control_choose')))
                                        $d('zones_control_choose').setAttribute('class', 'zones_control_item');

                                    if(isset($d('zones_control_fix'))) $d('zones_control_fix').setAttribute('class', 'zones_control_item_lock');

                                    if(isset($d('zones_control_remove')))
                                        $d('zones_control_remove').setAttribute('class', 'zones_control_item_disable');

                                    if(isset($d('zones_control_save')))
                                        $d('zones_control_save').setAttribute('class', 'zones_control_item_disable');

                                    if(isset($d('zones_control_arrow')))
                                        $d('zones_control_arrow').setAttribute('class', 'zones_control_item_up_disable');

                                    if(isset($d('zones_control_combo')))
                                        $d('zones_control_combo').setAttribute('class', 'zones_control_item_combo_disable');

                                    if(isset($d('zones_video_canvas_list'))){
                                        $d('zones_video_canvas_list').onmousemove = function(){};
                                        $d('zones_video_canvas_list').onclick = function(){};
                                        $d('zones_video_canvas_list').oncontextmenu = function(){};
                                    }

                                    page_object.action.admin.data['zones_backup'] = clone_object(page_object.action.admin.data['zones']);

                                    page_object.action.admin.action.zones_content.action.zone.is_edit = true;
                                    page_object.action.admin.action.zones_content.action.zone.canvas.is_edit = false;
                                    page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index = null;

                                    page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();
                                    page_object.action.admin.action.zones_content.action.zone.controls();
                                    page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.controls();

                                } else {

                                    if(isset($d('zone_point'))){

                                        page_object.action.admin.data['zones']['zone_list'] = Object.assign({}, page_object.action.admin.action.zones_content.action.zone.canvas.move_list);

                                        if($d('zones_control_fix').getAttribute('class') === 'zones_control_item_un_lock') $d('zones_control_fix').setAttribute('class', 'zones_control_item_lock');

                                        if(isset($d('zones_video_container'))) $d('zones_video_container').onmousedown = function(){};

                                        page_object.action.admin.data['zones_backup'] = clone_object(page_object.action.admin.data['zones']);

                                        page_object.action.admin.action.zones_content.action.zone.canvas.move_list = {};
                                        page_object.action.admin.action.zones_content.action.zone.choose_type.key = null;
                                        page_object.action.admin.action.zones_content.action.zone.canvas.is_edit = false;
                                        page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index = null;

                                        page_object.action.admin.action.zones_content.action.zone.choose_type.set_active(null);
                                        page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw_all();
                                    }
                                }
                            }
                        },
                    } //'save': function(){
                },
                'show_center': {
                    'is_show':false,
                    'init': function(){

                        if(page_object.action.admin.action.zones_content.action.zone.canvas.show_center.is_show)
                            page_object.action.admin.action.zones_content.action.zone.canvas.show_center.un_show();
                        else
                            page_object.action.admin.action.zones_content.action.zone.canvas.show_center.show();

                    },
                    'show': function(){
                        if(isset($d('zones_video_center'))){
                            $s('zones_video_center').display='block';
                            $s('zones_video_h_line').display='block';
                            $s('zones_video_v_line').display='block';
                            page_object.action.admin.action.zones_content.action.zone.canvas.show_center.is_show = true;
                        }
                    },
                    'un_show': function(){

                        if(isset($d('zones_video_center'))){
                            $s('zones_video_center').display='none';
                            $s('zones_video_h_line').display='none';
                            $s('zones_video_v_line').display='none';
                            page_object.action.admin.action.zones_content.action.zone.canvas.show_center.is_show = false;
                        }

                    },
                    'reset': function(){

                        if(isset($d('zones_video_center'))){

                            $s('zones_video_center').display = page_object.action.admin.action.zones_content.action.zone.canvas.show_center.is_show?'block': 'none';
                            $s('zones_video_h_line').display = page_object.action.admin.action.zones_content.action.zone.canvas.show_center.is_show?'block': 'none';
                            $s('zones_video_v_line').display = page_object.action.admin.action.zones_content.action.zone.canvas.show_center.is_show?'block': 'none';

                        }

                    },
                },
            },
            'save': {
                'init': function(){

                    let inner='';
                    if(loc) inner+= '<div class="dialog_row">Сохранить изменения?</div>'; else inner+= '<div class="dialog_row">Сохранить изменения? #3</div>';

                    var dialog_index = page_object.dialog.init({
                        'title': 'Информация',
                        'inner':inner,
                        'save': function(){

                            page_object.action.admin.action.zones_content.action.zone.save.save(dialog_index);

                        },
                        'cancel':true
                    });

                },
                'zone_list': {
                    'encode_coords': function(list){

                        let  data = page_object.action.admin.data
                            , zone_data = data['zones']
                            , camera_data = zone_data['camera_data']
                            , camera_width = camera_data['camera_width']
                            , camera_height = camera_data['camera_height']
                            , container_width = elementSize.width($d('zones_video_canvas_list'))
                            , container_height = elementSize.height($d('zones_video_canvas_list'))
                            , camera_width_perc = camera_width/container_width
                            , camera_height_perc = camera_height/container_height
                            , key
                            , layer_index
                            , point_index
                            , zone_list = Object.assign({}, list);

                        for(key in zone_list){

                            if(isset(zone_list[key]['layer_list']))
                                for(layer_index in zone_list[key]['layer_list']){

                                    if(isset(zone_list[key]['layer_list'][layer_index]['point_list']))
                                        for(point_index in zone_list[key]['layer_list'][layer_index]['point_list']){

                                            zone_list[key]['layer_list'][layer_index]['point_list'][point_index] = Object.assign({}, zone_list[key]['layer_list'][layer_index]['point_list'][point_index]);

                                            zone_list[key]['layer_list'][layer_index]['point_list'][point_index]['x']*= camera_width_perc;
                                            zone_list[key]['layer_list'][layer_index]['point_list'][point_index]['y']*= camera_height_perc;

                                            zone_list[key]['layer_list'][layer_index]['point_list'][point_index]['x'] = Math.round(zone_list[key]['layer_list'][layer_index]['point_list'][point_index]['x']);
                                            zone_list[key]['layer_list'][layer_index]['point_list'][point_index]['y'] = Math.round(zone_list[key]['layer_list'][layer_index]['point_list'][point_index]['y']);

                                        }
                                }
                        }
                        return zone_list;
                    },
                    'decode_coords': function(list){

                        let  data = page_object.action.admin.data
                            , zone_data = data['zones']
                            , camera_data = zone_data['camera_data']
                            , camera_width = camera_data['camera_width']
                            , camera_height = camera_data['camera_height']
                            , container_width = elementSize.width($d('zones_video_canvas_list'))
                            , container_height = elementSize.height($d('zones_video_canvas_list'))
                            , camera_width_perc = container_width/camera_width
                            , camera_height_perc = container_height/camera_height
                            , key
                            , layer_index
                            , point_index
                            , zone_list = Object.assign({}, list);

                        for(key in zone_list){

                            if(isset(zone_list[key]['layer_list']))
                                for(layer_index in zone_list[key]['layer_list']){
                                    if(isset(zone_list[key]['layer_list'][layer_index]['point_list']))
                                        for(point_index in zone_list[key]['layer_list'][layer_index]['point_list']){

                                            zone_list[key]['layer_list'][layer_index]['point_list'][point_index] = Object.assign({}, zone_list[key]['layer_list'][layer_index]['point_list'][point_index]);

                                            zone_list[key]['layer_list'][layer_index]['point_list'][point_index]['x']*= camera_width_perc;
                                            zone_list[key]['layer_list'][layer_index]['point_list'][point_index]['y']*= camera_height_perc;

                                            zone_list[key]['layer_list'][layer_index]['point_list'][point_index]['x'] = Math.round(zone_list[key]['layer_list'][layer_index]['point_list'][point_index]['x']);
                                            zone_list[key]['layer_list'][layer_index]['point_list'][point_index]['y'] = Math.round(zone_list[key]['layer_list'][layer_index]['point_list'][point_index]['y']);
                                        }
                                }
                        }
                        return zone_list;
                    }
                },
                'save': function(dialog_index){

                    page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.save.save();
                    page_object.action.admin.action.zones_content.action.zone.save.send(dialog_index);

                },

                'send': function(dialog_index){ cl('SEND'); // SEND1

                    //cl("page_object.action.admin.data['zones']['zone_list']"); cl(page_object.action.admin.data['zones']['zone_list']);

                    var  post='',
                        data = page_object.action.admin.data,
                        zone_list = page_object.action.admin.action.zones_content.action.zone.save.zone_list.encode_coords(page_object.action.admin.data['zones']['zone_list']);

                    var cz = zone_list.control_zone.layer_list; // cl('cz'); cl('cz'); cl(cz); cl(cz);
                    //cz[1].point_list[0].x = -10;                    cz[1].point_list[0].y = 5000;
                    $.each(cz, function(){                        //cl(321);                        cl(this);
                        var pl = this.point_list;
                        $.each(pl, function(){ //return;
                            if(this.x < 0) this.x = 0;
                            if(this.x > 2440) this.x = 2440;
                            if(this.y < 0) this.y = 0;
                            if(this.y > 2040) this.y = 2040; // cl(321);cl(this);
                        });
                    })

                    page_object.link.preload.show(); // page_object.action.admin.action.zones_content.action.load.show();

                    post+= 'camera_id='+uniEncode(page_object.link.link_list[3]);

                    if(!empty($v('zones_speed_type'))) post+= '&speed_max='+uniEncode($v('zones_speed_type'));
                    if(!empty($v('zones_speed_max_type'))) post+= '&speed_max_border='+uniEncode($v('zones_speed_max_type'));
                    if(!empty($v('zones_traffic_lights'))) post+= '&light_id='+uniEncode($v('zones_traffic_lights'));
                    post+= '&zone_list='+uniEncode(jsonEncode(zone_list));
                    // page_object.action.admin.action.zones_content.action.zone.save.zone_list.decode_coords(page_object.action.admin.data['zones']['zone_list']);

                    send({
                        'scriptPath': '/api/json/save_zone_list', // SAAAVVVEEE!!!
                        'postData':post,
                        'onComplete': function(j, worktime){

                            page_object.action.admin.action.zones_content.move_mode = false;

                            var  dataTemp, data;
                            dataTemp = j.responseText;  //trace(dataTemp);
                            data = jsonDecode(dataTemp); //trace(data); trace_worktime(worktime, data);
                            cl(data);
                            cl(data.zone_list);
                            var zl = jsonDecode(data.zone_list);
                            cl(zl);
                            page_object.dialog.action.un_show.init(dialog_index, true);
                            cl('page_object.action.admin.create.zones');
                            cl('page_object.action.admin.create.zones');
                            cl('page_object.action.admin.create.zones');
                            cl(page_object.action.admin.data);
                            cl(page_object.action.admin.data.zones.zone_list.control_zone.layer_list);
                            page_object.action.admin.data.zones.zone_list.control_zone.layer_list = zl;

                            if(isset(data['error'])) page_object.action.admin.action.zones_content.action.error.init(data);
                            if(isset(data['er'])) er(data['er'], 150000);

                            if(isset($d('zone_point'))) removeElement($d('zone_point'));
                            if(isset($d('zones_control_fix'))) $d('zones_control_fix').setAttribute('class', 'zones_control_item_lock');
                            if(isset($d('zones_control_draw'))) $d('zones_control_draw').setAttribute('class', 'zones_control_item_disable');
                            if(isset($d('zones_control_choose'))) $d('zones_control_choose').setAttribute('class', 'zones_control_item_disable');
                            if(isset($d('zones_control_combo'))) $d('zones_control_combo').setAttribute('class', 'zones_control_item_combo_disable');
                            if(isset($d('zones_video_canvas_item_0'))) removeElement($d('zones_video_canvas_item_0'));
                            page_object.action.admin.data['zones_backup'] = clone_object(page_object.action.admin.data['zones']);

                            page_object.action.admin.action.zones_content.action.zone.is_edit = false;
                            page_object.action.admin.action.zones_content.action.zone.canvas.is_edit = false;
                            page_object.action.admin.action.zones_content.action.zone.choose_type.key = null;
                            page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index = null;

                            page_object.action.admin.action.zones_content.action.zone.choose_type.set_active(null);
                            page_object.action.admin.action.zones_content.action.zone.controls();
                            page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.controls();
                            page_object.link.preload.un_show();   // page_object.action.admin.action.zones_content.action.load.un_show();
                            //location.reload();
                        }
                    });

                }
            },
            'cancel': {
                'init': function(){

                    let inner='';
                    if(loc) inner+= '<div class="dialog_row">Отменить изменения? #3</div>'; else inner+= '<div class="dialog_row">Отменить изменения? #3</div>';

                    var dialog_index = page_object.dialog.init({
                        'title': 'Информация',
                        'inner':inner,
                        'ok': function(){

                            page_object.action.admin.action.zones_content.action.zone.cancel.cancel();

                            page_object.dialog.action.un_show.init(dialog_index, true);

                        },
                        'cancel':true
                    });

                },
                'cancel': function(){                    // page_object.action.admin.data['zones'] = clone_object(page_object.action.admin.data['zones_backup']);

                    page_object.action.admin.data['zones']['zone_list'] = clone_object(page_object.action.admin.data['zones_backup']['zone_list']);
                    // page_object.action.admin.data['zones']['zone_list'] = page_object.action.admin.action.zones_content.action.zone.save.zone_list.decode_coords(page_object.action.admin.data['zones_backup']['zone_list']);

                    page_object.action.admin.action.zones_content.action.zone.is_edit = false;
                    page_object.action.admin.action.zones_content.action.zone.canvas.is_edit = false;
                    page_object.action.admin.action.zones_content.action.zone.canvas.list = [];
                    page_object.action.admin.action.zones_content.action.zone.choose_type.key = null;
                    page_object.action.admin.action.zones_content.action.zone.canvas.choose.line_index = null;

                    if(isset($d('zone_point'))) removeElement($d('zone_point'));

                    if(isset($d('zones_control_fix'))) $d('zones_control_fix').setAttribute('class', 'zones_control_item_lock');

                    page_object.action.admin.action.zones_content.action.zone.choose_type.set_active(null);
                    page_object.action.admin.action.zones_content.action.zone.controls();
                    page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.controls();
                    page_object.action.admin.action.zones_content.action.zone.canvas.mouse.coords.redraw();
                }
            },
            'controls': function(){ // page_object.action.admin.action.zones_content.action.zone.controls
                if(page_object.action.admin.action.zones_content.action.zone.is_edit){
                    if(isset($d('zones_save'))) $d('zones_save').setAttribute('class', 'zones_save');
                    if(isset($d('zones_cancel'))) $d('zones_cancel').setAttribute('class', 'zones_cancel');
                } else {
                    if(isset($d('zones_save'))) $d('zones_save').setAttribute('class', 'zones_save_disable');
                    if(isset($d('zones_cancel'))) $d('zones_cancel').setAttribute('class', 'zones_cancel_disable');
                }
            }
        },
        'zoom': {
            'image_link':null,
            'init': function(){
                if(isset($d("zones_control_zoom"))) $d('zones_control_zoom').onclick = page_object.action.admin.action.zones_content.action.zoom.get_screen;
            },

            'get_screen': function(){

                if(isset($d('zones_content'))) $s('zones_content').opacity = 0;

                page_object.action.admin.action.zones_content.action.window.stop();
                page_object.link.preload.show();

                send({
                    'scriptPath': '/api/json/get_camera_screen_link',
                    'postData': 'camera_id='+uniEncode(page_object.link.link_list[3]),
                    'onComplete': function(j, worktime){
                        var  dataTemp, data;
                        dataTemp = j.responseText;                        //trace(dataTemp);
                        data = jsonDecode(dataTemp);                        //trace(data);
                        trace_worktime(worktime, data);
                        if(!isset(data['error'])){
                            page_object.action.admin.action.zones_content.action.zoom.image_link = data['data']['screen_link'];
                            page_object.action.admin.action.zones_content.action.zoom.show();
                        } else page_object.link.preload.un_show();
                    }
                });

            },
            'reset_screen': function(){

                page_object.link.preload.show();

                send({
                    'scriptPath': '/api/json/get_camera_screen_link',
                    'postData': 'camera_id='+uniEncode(page_object.link.link_list[3]),
                    'onComplete': function(j, worktime){

                        var  dataTemp
                            , data;

                        dataTemp = j.responseText;
                        //trace(dataTemp);
                        data = jsonDecode(dataTemp);
                        //trace(data);
                        trace_worktime(worktime, data);

                        if(!isset(data['error'])){

                            page_object.action.admin.action.zones_content.action.zoom.image_link = data['data']['screen_link'];

                            if(isset($d('zone_video_container_inner')))
                                $s('zone_video_container_inner').opacity = 0;

                            setTimeout(function(){

                                $d('zone_video_iframe').src = page_object.action.admin.action.zones_content.action.zoom.image_link;
                                $d('zone_video_iframe').onload = function(){

                                    if(isset($d('zone_video_container_inner')))
                                        $s('zone_video_container_inner').opacity = 1;

                                    page_object.link.preload.un_show();

                                };

                            }, 300);

                        }
                        else
                            page_object.link.preload.un_show();

                    }
                });

            },
            'show': function(){

                page_object.action.admin.action.zones_content.action.zone.save.zone_list.encode_coords(page_object.action.admin.data['zones']['zone_list']);

                if(isset($d('zone_row'))) $d('zone_row').innerHTML='';

                page_object.action.admin.action.zones_content.action.zoom.create();
                page_object.action.admin.action.zones_content.action.zoom.load_image();
            },

            'create': function(){

                let  inner=''
                    , el;

                inner+= '<div id="zones_zoom_row_left" class="zones_zoom_row_left">';

                    inner+= page_object.action.admin.create.zones.create.get_left_menu();
                    inner+= page_object.action.admin.create.zones.create.get_right_menu();

                inner+= '</div>';

                inner+= '<div id="zones_row_center" class="zones_zoom_row_center">';

                    inner+= '<div class="zones_row_center_controls">';

                        inner+= '<div id="zones_row_center_controls_left" class="zones_row_center_controls_left">';

                            inner+= page_object.action.admin.create.zones.create.get_left_controls();

                        inner+= '</div>';

                        inner+= '<div id="zones_row_center_controls_right" class="zones_row_center_controls_right">';

                            inner+= page_object.action.admin.create.zones.create.get_right_controls(true);

                        inner+= '</div>';

                    inner+= '</div>';

                    inner+= '<div id="zones_video_container" class="zones_row_center_video">';

                        inner+= page_object.action.admin.create.zones.create.get_video_container(false, page_object.action.admin.action.zones_content.action.zoom.image_link);

                    inner+= '</div>';

                inner+= '</div>';

                el = addElement({
                    'tag': 'div',
                    'id': 'zone_zoom',
                    'class': 'zone_zoom',
                    'style': 'opacity: 0',
                    'inner':inner
                });

                $d('all').appendChild(el);

                page_object.action.admin.action.zones_content.action.zone.canvas.show_center.reset();

            },
            'load_image': function(){

                if(isset($d('zone_video_iframe')))
                    $d('zone_video_iframe').onload = page_object.action.admin.action.zones_content.action.zoom.prepare_size;

            },
            'prepare_size': function(){

                let  img_w = elementSize.width($d('zone_video_iframe'))
                    , img_h = elementSize.height($d('zone_video_iframe'));

                if(isset($d('zones_control_zoom_revert')))
                    $d('zones_control_zoom_revert').onclick = page_object.action.admin.action.zones_content.action.zoom_revert.init;

                if(isset($d("zones_control_reset_image")))
                    $d('zones_control_reset_image').onclick = page_object.action.admin.action.zones_content.action.zoom.reset_screen;

                if(isset($d('zones_video_canvas_list'))){

                    $s('zones_video_canvas_list').width = img_w+'px';
                    $s('zones_video_canvas_list').height = img_h+'px';

                    var inner='';

                    inner+= '<canvas id="zones_video_canvas_item_0" class="zones_video_canvas_item" width="'+img_w+'" height="'+img_h+'"></canvas>';
                    inner+= '<div id="zones_video_center" class="zones_video_center"'+(page_object.action.admin.action.zones_content.action.zone.canvas.show_center.is_show?' style="display: block;"': '')+'></div>';
                    inner+= '<div id="zones_video_h_line" class="zones_video_h_line"'+(page_object.action.admin.action.zones_content.action.zone.canvas.show_center.is_show?' style="display: block;"': '')+'></div>';
                    inner+= '<div id="zones_video_v_line" class="zones_video_v_line"'+(page_object.action.admin.action.zones_content.action.zone.canvas.show_center.is_show?' style="display: block;"': '')+'></div>';

                    $d('zones_video_canvas_list').innerHTML = inner;

                }

                if(isset($d('zone_zoom')))
                    $s('zone_zoom').opacity = 1;

                page_object.action.admin.action.zones_content.action.zone.init();
                page_object.link.preload.un_show();

            },
        },
        'zoom_revert': {
            'init': function(){

                if(isset($d('zone_zoom')))
                    $s('zone_zoom').opacity = 0;

                setTimeout(function(){

                    removeElement($d('zone_zoom'));

                    setTimeout(function(){

                        let  inner=''
                            , el;

                        inner+= '<div id="zones_row_left" class="zones_row_left">';

                            inner+= page_object.action.admin.create.zones.create.get_left_menu();

                        inner+= '</div>';

                        inner+= '<div id="zones_row_center" class="zones_row_center">';

                            inner+= '<div class="zones_row_center_controls">';

                                inner+= '<div id="zones_row_center_controls_left" class="zones_row_center_controls_left">';

                                    inner+= page_object.action.admin.create.zones.create.get_left_controls();

                                inner+= '</div>';

                                inner+= '<div id="zones_row_center_controls_right" class="zones_row_center_controls_right">';

                                    inner+= page_object.action.admin.create.zones.create.get_right_controls();

                                inner+= '</div>';

                            inner+= '</div>';

                            inner+= '<div id="zones_video_container" class="zones_row_center_video">';

                                inner+= page_object.action.admin.create.zones.create.get_video_container(true, page_object.action.admin.data['zones']['camera_data']['video_link']);

                            inner+= '</div>';

                        inner+= '</div>';

                        inner+= '<div id="zones_row_right" class="zones_row_right">';

                            inner+= page_object.action.admin.create.zones.create.get_right_menu();

                        inner+= '</div>';

                        $d('zone_row').innerHTML = inner;

                        if(isset($d('zones_content'))) $s('zones_content').opacity = 1;

                        setTimeout(function(){

                            // page_object.action.admin.data['zones']['zone_list'] = page_object.action.admin.action.zones_content.action.zone.save.zone_list.decode_coords(page_object.action.admin.data['zones']['zone_list']);

                            page_object.action.admin.action.zones_content.action.init();
                            page_object.action.admin.action.zones_content.action.zone.canvas.show_center.reset();

                        }, 40);

                    }, 40);

                }, 340);

            },
        },
    },
    'remove': function(){
        if(isset($d('zones_content'))) removeElement($d('zones_content'));
    },
    'resize': function(){
        if(isset($d('zones_content'))){
        }
    }
};