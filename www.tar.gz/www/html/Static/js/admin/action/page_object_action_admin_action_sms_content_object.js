page_object.action.admin.action.sms_content={
    'show':function(){

        if(isset($d('sms_content'))) $s('sms_content').opacity=1;

        setTimeout(page_object.link.preload.un_show,300);

    },
    'un_show':function(remove){

        if(isset($d('sms_content'))) $s('sms_content').opacity=0;

        if(isset(remove))
            if(remove)
                setTimeout(page_object.action.admin.action.sms_content.remove,300);

    },
    'action':{
        'action_type':null,
        'init':function(){

            page_object.action.admin.action.sms_content.action.info.init();
            page_object.action.admin.action.sms_content.action.add.init();
            page_object.action.admin.action.sms_content.action.add_ussd.init();
            page_object.action.admin.action.sms_content.action.update.init();

            page_object.action.admin.action.sms_content.action.resize();

        },
        'info':{
            'init':function(){

                if(page_object.action.admin.data['data']['list'].length === 0)
                    page_object.action.admin.action.sms_content.action.info.show();
                else
                    page_object.action.admin.action.sms_content.action.info.un_show();

            },
            'show':function(){

                if(isset($d('sms_info')))
                    $d('sms_info').setAttribute('class','sms_info');

            },
            'un_show':function(){

                if(isset($d('sms_info')))
                    $d('sms_info').setAttribute('class','sms_info_hide');

            },
        },
        'add':{
            'index':null,
            'init':function(){

                if(isset($d('sms_add')))
                    $d('sms_add').onclick=page_object.action.admin.action.sms_content.action.add.box.init;

            },
            'box':{
                'dialog_index':null,
                'init':function(){

                    let  inner=''
                        ,data =page_object.action.admin.data['data']
                        ,key_list =data['key_list']
                        ,index;

                    page_object.action.admin.action.sms_content.action.action_type='add';

                    inner+='<div class="dialog_row">';
                        inner+='<div class="dialog_row_label" style="width: 240px;">';
                            inner+='<span>Телефон</span>';
                        inner+='</div>';
                        inner+='<div class="dialog_row_input" style="width: 360px;">';
                            inner+='<input type="text" id="dialog_phone_input_text" class="dialog_row_input_text" placeholder="+79998887766" value="" />';
                        inner+='</div>';
                    inner+='</div>';

                    inner+='<div class="dialog_row">';
                        inner+='<div class="dialog_row_label" style="width: 240px;">';
                            inner+='<span>Текст сообщения</span>';
                        inner+='</div>';
                        inner+='<div class="dialog_row_input" style="width: 360px;">';
                            inner+='<textarea id="dialog_content_input_text" class="dialog_row_textarea"></textarea>';
                        inner+='</div>';
                    inner+='</div>';

                    page_object.action.admin.action.sms_content.action.add.box.dialog_index=page_object.dialog.init({
                        'title':'Отправка SMS сообщения',
                        'inner':inner,
                        'w':600,
                        'send':function(){

                            page_object.action.admin.action.sms_content.action.add.save.init();

                        },
                        'cancel':true,
                        'on_create':function(dialog_index){

                        }
                    });

                }
            },
            'save':{
                'init':function(){

                    let is_error=false;

                    if(empty($v('dialog_phone_input_text'))){

                        is_error=true;

                        $s('dialog_phone_input_text').border='1px solid #ff0000';

                    }

                    if(empty($v('dialog_content_input_text'))){

                        is_error=true;

                        $s('dialog_content_input_text').border='1px solid #ff0000';

                    }

                    if(!is_error)
                        page_object.action.admin.action.sms_content.action.add.save.send();

                },
                'error':function(data){

                    page_object.action.admin.action.sms_content.action.edit.test_connection.error();

                },
                'send':function(){

                    var  index
                        ,data =page_object.action.admin.data['data']
                        ,post ='';

                    page_object.link.preload.show();

                    post+='&phone='+uniEncode($v('dialog_phone_input_text'));
                    post+='&content='+uniEncode($v('dialog_content_input_text'));

                    send({
                        'scriptPath':'/api/json/add_sms',
                        'postData':post,
                        'onComplete':function(j,worktime){

                            var  dataTemp, data;

                            dataTemp=j.responseText;
                            trace(dataTemp);
                            data=jsonDecode(dataTemp);
                            trace(data);
                            trace_worktime(worktime,data);

                            if(isset(data['error'])){

                                page_object.action.admin.action.sms_content.action.edit.save.error(data);
                                page_object.link.preload.un_show();

                            }
                            else{

                                page_object.action.admin.data['data']['list'].unshift(data['data']);

                                page_object.action.admin.action.sms_content.action.add.save.prepare();

                            }

                        }
                    });

                },
                'prepare':function(){

                    var  inner =page_object.action.admin.create.sms.create.get_sms_row(0)
                        ,el =addElement({
                            'tag':'div',
                            'id':'sms_item_'+page_object.action.admin.data['data']['list'][0]['id'],
                            'class':'sms_item',
                            'inner':inner
                        });

                    if(isset($d('sms_list')))
                        $d('sms_list').prepend(el);

                    $d('sms_table_block').setAttribute('class','sms_table_block');

                    page_object.action.admin.action.sms_content.action.init();

                    page_object.dialog.action.un_show.init(page_object.action.admin.action.sms_content.action.add.box.dialog_index,true);
                    page_object.link.preload.un_show();

                }
            },
        },
        'add_ussd':{
            'index':null,
            'init':function(){

                if(isset($d('sms_ussd_add')))
                    $d('sms_ussd_add').onclick=page_object.action.admin.action.sms_content.action.add_ussd.box.init;

            },
            'box':{
                'dialog_index':null,
                'init':function(){

                    let  inner=''
                        ,data =page_object.action.admin.data['data']
                        ,key_list =data['key_list']
                        ,index;

                    page_object.action.admin.action.sms_content.action.action_type='add_ussd';

                    inner+='<div class="dialog_row">';
                        inner+='<div class="dialog_row_label" style="width: 240px;">';
                            inner+='<span>USSD команда</span>';
                        inner+='</div>';
                        inner+='<div class="dialog_row_input" style="width: 360px;">';
                            inner+='<input type="text" id="dialog_phone_input_text" class="dialog_row_input_text" placeholder="#100#" value="" />';
                        inner+='</div>';
                    inner+='</div>';

                    page_object.action.admin.action.sms_content.action.add_ussd.box.dialog_index=page_object.dialog.init({
                        'title':'Отправка USSD команды',
                        'inner':inner,
                        'w':600,
                        'send':function(){

                            page_object.action.admin.action.sms_content.action.add_ussd.save.init();

                        },
                        'cancel':true,
                        'on_create':function(dialog_index){

                        }
                    });

                }
            },
            'save':{
                'init':function(){

                    let is_error=false;

                    if(empty($v('dialog_phone_input_text'))){

                        is_error=true;

                        $s('dialog_phone_input_text').border='1px solid #ff0000';

                    }

                    if(!is_error)
                        page_object.action.admin.action.sms_content.action.add_ussd.save.send();

                },
                'error':function(data){

                    page_object.action.admin.action.sms_content.action.edit.test_connection.error();

                },
                'send':function(){

                    var  index
                        ,data =page_object.action.admin.data['data']
                        ,post ='';

                    page_object.link.preload.show();

                    post+='&phone='+uniEncode($v('dialog_phone_input_text'));

                    send({
                        'scriptPath':'/api/json/add_sms',
                        'postData':post,
                        'onComplete':function(j,worktime){

                            var  dataTemp, data;

                            dataTemp=j.responseText;
                            trace(dataTemp);
                            data=jsonDecode(dataTemp);
                            trace(data);
                            trace_worktime(worktime,data);

                            if(isset(data['error'])){

                                page_object.action.admin.action.sms_content.action.edit.save.error(data);
                                page_object.link.preload.un_show();

                            }
                            else{

                                page_object.action.admin.data['data']['list'].unshift(data['data']);

                                page_object.action.admin.action.sms_content.action.add_ussd.save.prepare();

                            }

                        }
                    });

                },
                'prepare':function(){

                    var  inner =page_object.action.admin.create.sms.create.get_sms_row(0)
                        ,el =addElement({
                            'tag':'div',
                            'id':'sms_item_'+page_object.action.admin.data['data']['list'][0]['id'],
                            'class':'sms_item',
                            'inner':inner
                        });

                    if(isset($d('sms_list')))
                        $d('sms_list').prepend(el);

                    $d('sms_table_block').setAttribute('class','sms_table_block');

                    page_object.action.admin.action.sms_content.action.init();

                    page_object.dialog.action.un_show.init(page_object.action.admin.action.sms_content.action.add_ussd.box.dialog_index,true);
                    page_object.link.preload.un_show();

                }
            },
        },
        'get_list_index':function(sms_id){

            var  index
                ,list=page_object.action.admin.data['data']['list'];

            for(index in list){

                console.log(sms_id+' === ' +list[index]['id']);

                if(sms_id === list[index]['id']) return index;

            }

            return null;

        },
        'update':{
            'timeout':3000,
            'timeout_event':null,
            'init':function(){

                page_object.action.admin.action.sms_content.action.update.restart();

            },
            'reset':function(){

                if(!empty(page_object.action.admin.action.sms_content.action.update.timeout_event))
                    clearTimeout(page_object.action.admin.action.sms_content.action.update.timeout_event);

            },
            'restart':function(){

                page_object.action.admin.action.sms_content.action.update.reset();

                page_object.action.admin.action.sms_content.action.update.timeout_event=setTimeout(page_object.action.admin.action.sms_content.action.update.send,page_object.action.admin.action.sms_content.action.update.timeout);

            },
            'send':function(){

                var  post =''
                    ,timestamp =page_object.action.admin.data['data']['timestamp'];

                if(page_object.action.admin.data['data']['list'].length>0)
                    timestamp=page_object.action.admin.data['data']['list'][0]['date_create'];

                post+='timestamp='+timestamp;

                send({
                    'scriptPath':'/api/json/get_update_sms_list',
                    'postData':post,
                    'onComplete':function(j,worktime){

                        var  dataTemp
                            ,data;

                        dataTemp=j.responseText;
                        trace(dataTemp);
                        data=jsonDecode(dataTemp);
                        trace(data);
                        trace_worktime(worktime,data);

                        if(isset(data['error'])){

                            page_object.link.preload.un_show();

                        }
                        else{

                            let  index, list_index, list=data['data']['list'];

                            page_object.action.admin.data['data']['timestamp'] = data['data']['timestamp'];

                            for(index in list)
                                if(isset($d('sms_item_'+list[index]['id']))){

                                    list_index=page_object.action.admin.action.sms_content.action.get_list_index(list[index]['id']);

                                    page_object.action.admin.data['data']['list'][list_index] = list[index];

                                    $d('sms_item_'+list[index]['id']).innerHTML=page_object.action.admin.create.sms.create.get_sms_row(list_index);

                                }
                                else{

                                    page_object.action.admin.data['data']['list'].unshift(list[index]);

                                    let  inner =page_object.action.admin.create.sms.create.get_sms_row(0)
                                        ,el =addElement({
                                            'tag':'div',
                                            'id':'sms_item_'+list[index]['id'],
                                            'class':'sms_item',
                                            'inner':inner
                                        });

                                    if(isset($d('sms_list')))
                                        $d('sms_list').prepend(el);

                                    $d('sms_table_block').setAttribute('class','sms_table_block');

                                }

                                page_object.action.admin.action.sms_content.action.init();

                        }

                        page_object.action.admin.action.sms_content.action.update.restart();

                    }
                });

            },
            'prepare':function(){},
        },
        'resize':function(){

            if(isset($d('sms_list'))){

                let  list = $d('sms_list').getElementsByClassName('sms_item')
                    ,index;

                for(index in list)
                    if(isObject(list[index])){

                        let  el_list =list[index].getElementsByClassName('sms_item_col')
                            ,el_index
                            ,el_h =list[index].scrollHeight;

                        for(el_index in el_list)
                            if(isObject(el_list[el_index]))
                                el_list[el_index].style.height=el_h+'px';

                    }

            }

            if(isset($d('admin_menu'))) $s('admin_menu').height=elementSize.height($d('all'))+'px';

        }
    },
    'remove':function(){

        if(isset($d('sms_content'))) removeElement($d('sms_content'));

    },
    'resize':function(){

        if(isset($d('sms_content'))){

        }

    }
};