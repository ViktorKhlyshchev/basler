cl = console.log;

page_object.action.admin.action.config_content={
    'show':function(){

        if(isset($d('config_content'))) $s('config_content').opacity=1;

        page_object.action.admin.action.config_content.action.check_video_container.init();

        setTimeout(page_object.link.preload.un_show,300);

    },
    'un_show':function(remove){

        if(isset($d('config_content'))) $s('config_content').opacity=0;

        if(isset(remove))
            if(remove)
                setTimeout(page_object.action.admin.action.config_content.remove,300);

    },
    'action':{
        'init':function(){

            page_object.action.admin.action.config_content.action.camera_menu.init();
            page_object.action.admin.action.config_content.action.camera_work_mode.init();
            page_object.action.admin.action.config_content.action.camera_const.init();
            page_object.action.admin.action.config_content.action.camera_config.init();
            page_object.action.admin.action.config_content.action.light_config.init();
            page_object.action.admin.action.config_content.action.ir_config.init();
            page_object.action.admin.action.config_content.action.gen_config.init();
            page_object.action.admin.action.config_content.action.heater_config.init();
            page_object.action.admin.action.config_content.action.cooler_config.init();
            page_object.action.admin.action.config_content.action.glass_heater_config.init();
            page_object.action.admin.action.config_content.action.brush_config.init();
            page_object.action.admin.action.config_content.action.screen.init();
            page_object.action.admin.action.config_content.action.buttons.init();
            page_object.action.admin.action.config_content.action.timer.init();
            page_object.action.admin.action.config_content.action.window.init();

        },
        'buttons':{
            'data':null,
            'is_edit':false,
            'init':function(){

                page_object.action.admin.action.config_content.action.buttons.reset();
                page_object.action.admin.action.config_content.action.buttons.set_action();

            },
            'set_edit':function(){

                switch(this.id){

                    case 'config_gen_period':{

                        if(isset($d('config_gen_cam_delay'))){

                            $d('config_gen_cam_delay').setAttribute('max',this.value);

                            if(parseInt(this.value)<parseInt($v('config_gen_cam_delay'))
                                &&parseInt(this.value)!==0
                            )
                                $d('config_gen_cam_delay').value=this.value;

                        }

                        if(isset($d('config_gen_light_delay'))){

                            $d('config_gen_light_delay').setAttribute('max',this.value);

                            if(parseInt(this.value)<parseInt($v('config_gen_light_delay'))
                                &&parseInt(this.value)!==0
                            )
                                $d('config_gen_light_delay').value=this.value;

                        }

                        break;

                    }

                }

                if(!page_object.action.admin.action.config_content.action.buttons.is_edit){

                    let data=page_object.action.admin.data['config']['camera_data'];

                    page_object.action.admin.action.config_content.action.buttons.data={};

                    page_object.action.admin.action.config_content.action.buttons.data['camera_work_mode'] =data['camera_work_mode'];
                    page_object.action.admin.action.config_content.action.buttons.data['install_height'] =data['install_height'];
                    page_object.action.admin.action.config_content.action.buttons.data['focus_max'] =data['focus_max'];
                    page_object.action.admin.action.config_content.action.buttons.data['iris_max'] =data['iris_max'];
                    page_object.action.admin.action.config_content.action.buttons.data['zoom_max'] =data['zoom_max'];
                    page_object.action.admin.action.config_content.action.buttons.data['iris'] =data['iris'];
                    page_object.action.admin.action.config_content.action.buttons.data['focus'] =data['focus'];
                    page_object.action.admin.action.config_content.action.buttons.data['bright'] =data['bright'];
                    page_object.action.admin.action.config_content.action.buttons.data['zoom'] =data['zoom'];
                    page_object.action.admin.action.config_content.action.buttons.data['exposure_time'] =data['exposure_time'];
                    page_object.action.admin.action.config_content.action.buttons.data['gain'] =data['gain'];
                    page_object.action.admin.action.config_content.action.buttons.data['digital_shift'] =data['digital_shift'];
                    page_object.action.admin.action.config_content.action.buttons.data['gamma'] =data['gamma'];
                    page_object.action.admin.action.config_content.action.buttons.data['black_level'] =data['black_level'];
                    page_object.action.admin.action.config_content.action.buttons.data['gen_mode'] =data['gen_mode'];
                    page_object.action.admin.action.config_content.action.buttons.data['gen_period'] =data['gen_period'];
                    page_object.action.admin.action.config_content.action.buttons.data['gen_cam_delay'] =data['gen_cam_delay'];
                    page_object.action.admin.action.config_content.action.buttons.data['gen_light_delay'] =data['gen_light_delay'];
                    page_object.action.admin.action.config_content.action.buttons.data['gen_light_time'] =data['gen_light_time'];
                    page_object.action.admin.action.config_content.action.buttons.data['ir_power'] =data['ir_power'];
                    page_object.action.admin.action.config_content.action.buttons.data['ir_mode'] =data['ir_mode'];
                    page_object.action.admin.action.config_content.action.buttons.data['ir_min'] =data['ir_min'];
                    page_object.action.admin.action.config_content.action.buttons.data['ir_max'] =data['ir_max'];
                    page_object.action.admin.action.config_content.action.buttons.data['heater_mode'] =data['heater_mode'];
                    page_object.action.admin.action.config_content.action.buttons.data['heater_min'] =data['heater_min'];
                    page_object.action.admin.action.config_content.action.buttons.data['heater_max'] =data['heater_max'];
                    page_object.action.admin.action.config_content.action.buttons.data['cooler_mode'] =data['cooler_mode'];
                    page_object.action.admin.action.config_content.action.buttons.data['cooler_min'] =data['cooler_min'];
                    page_object.action.admin.action.config_content.action.buttons.data['cooler_max'] =data['cooler_max'];
                    page_object.action.admin.action.config_content.action.buttons.data['glass_heater_mode'] =data['glass_heater_mode'];
                    page_object.action.admin.action.config_content.action.buttons.data['brush_mode'] =data['brush_mode'];
                    page_object.action.admin.action.config_content.action.buttons.data['target_light_day'] =data['target_light_day'];
                    page_object.action.admin.action.config_content.action.buttons.data['target_light_night'] =data['target_light_night'];

                }

                page_object.action.admin.action.config_content.action.buttons.is_edit=true;

                page_object.action.admin.action.config_content.action.buttons.set_action();

            },
            'set_action':function(){

                if(isset($d('config_cancel'))){

                    if(page_object.action.admin.action.config_content.action.buttons.is_edit){

                        $d('config_cancel').setAttribute('class','config_cancel');

                        $d('config_cancel').onclick=page_object.action.admin.action.config_content.action.cancel.init;

                    }
                    else{

                        $d('config_cancel').setAttribute('class','config_cancel_disable');

                        $d('config_cancel').onclick=function(){};

                    }

                }

                if(isset($d('config_save'))){

                    if(page_object.action.admin.action.config_content.action.buttons.is_edit){

                        $d('config_save').setAttribute('class','config_save');

                        $d('config_save').onclick=page_object.action.admin.action.config_content.action.save.init;

                    }
                    else{

                        $d('config_save').setAttribute('class','config_save_disable');

                        $d('config_save').onclick=function(){};

                    }

                }

                if(isset($d('config_save_test'))){

                    $d('config_save_test').setAttribute('class','config_save');

                    $d('config_save_test').onclick=page_object.action.admin.action.config_content.action.save.init;

                }

                if(isset($d('config_update'))){

                    $d('config_update').setAttribute('class','config_update_disable');

                    $d('config_update').onclick=function(){};

                }

            },
            'reset':function(){

                page_object.action.admin.action.config_content.action.buttons.data =null;
                page_object.action.admin.action.config_content.action.buttons.is_edit =false;

            }
        },
        'window':{
            'is_active':false,
            'init':function(){

                $w().onfocus =page_object.action.admin.action.config_content.action.window.active;
                $w().onblur =page_object.action.admin.action.config_content.action.window.no_active;

                page_object.action.admin.action.zones_content.action.window.video.timer.remove();
                page_object.action.admin.action.config_content.action.window.video.init();

            },
            'active':function(){

                if(!page_object.action.admin.action.config_content.action.window.is_active){

                    page_object.action.admin.action.config_content.action.window.is_active=true;

                    if(isset(page_object.action.admin.action.config_content.action.window.video.timer.dialog_index))
                        page_object.dialog.action.un_show.init(page_object.action.admin.action.config_content.action.window.video.timer.dialog_index,true);

                    page_object.action.admin.action.config_content.action.window.video.timer.init();
                    page_object.action.admin.action.config_content.action.window.video.show();

                }

            },
            'no_active':function(){

                if(page_object.action.admin.action.config_content.action.window.is_active){

                    page_object.action.admin.action.config_content.action.window.is_active=false;

                    page_object.action.admin.action.config_content.action.window.video.un_show();

                }

            },
            'video':{
                'init':function(){

                    page_object.action.admin.action.config_content.action.window.video.timer.init();

                },
                'timer':{
                    'timeout':180000,
                    // 'timeout':5000,
                    'timeout_event':null,
                    'dialog_index':null,
                    'init':function(){

                        page_object.action.admin.action.config_content.action.window.video.timer.reset();
                        page_object.action.admin.action.config_content.action.window.video.timer.mouse.init();

                    },
                    'mouse':{
                        'init':function(){

                            if(isset($d('all')))
                                $d('all').onmousemove=page_object.action.admin.action.config_content.action.window.video.timer.mouse.action;

                        },
                        'action':function(){

                            if(page_object.action.admin.data['action'] === 'admin_config_item'){

                                if(isset($d('config_video_iframe')))
                                    page_object.action.admin.action.config_content.action.window.video.timer.reset();

                            }
                            else
                                $d('all').onmousemove=function(){};

                        }
                    },
                    'remove':function(){

                        if(isset(page_object.action.admin.action.config_content.action.window.video.timer.timeout_event))
                            clearTimeout(page_object.action.admin.action.config_content.action.window.video.timer.timeout_event);

                    },
                    'reset':function(){

                        page_object.action.admin.action.config_content.action.window.video.timer.remove();
                        page_object.action.admin.action.config_content.action.window.video.timer.start();

                    },
                    'start':function(){

                        page_object.action.admin.action.config_content.action.window.video.timer.timeout_event=setTimeout(page_object.action.admin.action.config_content.action.window.video.timer.action,page_object.action.admin.action.config_content.action.window.video.timer.timeout);

                    },
                    'action':function(){

                        page_object.action.admin.action.config_content.action.window.video.un_show();

                        if(isset($d('config_video_container'))){

                            var inner='';

                            inner+='<div class="dialog_row">Поток видео остановлен всвязи с бездействием. Для продолжения работы закройте диалоговое окно. #1</div>';

                            page_object.action.admin.action.config_content.action.window.video.timer.dialog_index=page_object.dialog.init({
                                'title':'Информация',
                                'inner':inner,
                                'ok':function(){

                                    page_object.action.admin.action.config_content.action.window.video.timer.recovery();

                                },
                                'on_cancel':function(){

                                    page_object.action.admin.action.config_content.action.window.video.timer.recovery();

                                }
                            });

                        }

                    },
                    'recovery':function(){

                        page_object.action.admin.action.config_content.action.window.video.show();
                        page_object.action.admin.action.config_content.action.window.video.timer.reset();
                        page_object.dialog.action.un_show.init(page_object.action.admin.action.config_content.action.window.video.timer.dialog_index,true);

                    }
                },
                'show':function(){

                    trace('WINDOW ACTIVE');

                    if(isset($d('config_video_container'))){

                        if(!isset($d('config_video_iframe'))){

                            let  data =page_object.action.admin.data['config'], camera_data =data['camera_data'], inner ='<iframe id="config_video_iframe" src="'+camera_data['video_link']+'" width="100%" style="border: none; outline: none; line-height: 0;"></iframe>';

                            $d('config_video_container').innerHTML=inner;

                            if(!empty(page_object.action.admin.action.config_content.action.window.video.timer.dialog_index))
                                page_object.dialog.action.un_show.init(page_object.action.admin.action.config_content.action.window.video.timer.dialog_index,true);

                            page_object.action.admin.action.zones_content.action.window.video.timer.reset();

                        }

                    }

                },
                'un_show':function(){

                    trace('WINDOW NOT ACTIVE');

                    if(isset($d('config_video_container')))
                        $d('config_video_container').innerHTML='';

                }
            }
        },
        'error':{
            'init':function(data){

                if(isset($d('config_work_mask'))){

                    $s('config_work_mask').display ='block';
                    $d('config_work_mask').innerHTML ='<span style="color: #ff0000;">Ошибка получения данных</span>'

                }

            }
        },
        'load':{
            'show':function(){

                if(isset($d('config_work_mask'))){

                    $s('config_work_mask').display ='block';
                    $d('config_work_mask').innerHTML ='<span>Загрузка...</span>';

                }

            },
            'un_show':function(){

                if(isset($d('config_work_mask'))){

                    $s('config_work_mask').display ='none';
                    $d('config_work_mask').innerHTML ='<span>Загрузка...</span>';

                }

            }
        },
        'update':{
            'init':function(){

                alert('coming soon');

            }
        },
        'save':{
            'init':function(){

                let inner='';

                switch(this.id){

                    case 'config_save':{

                        inner+='<div class="dialog_row">Применить параметры?</div>';

                        var dialog_index=page_object.dialog.init({
                            'title':'Информация',
                            'inner':inner,
                            'ok':function(){

                                page_object.action.admin.action.config_content.action.save.send(false);

                                page_object.dialog.action.un_show.init(dialog_index,true);

                            },
                            'cancel':true
                        });

                        break;

                    }

                    case 'config_update':{

                        inner+='<div class="dialog_row">Сохранить изменения?</div>';

                        var dialog_index=page_object.dialog.init({
                            'title':'Информация',
                            'inner':inner,
                            'ok':function(){

                                page_object.action.admin.action.config_content.action.save.send(true);

                                page_object.dialog.action.un_show.init(dialog_index,true);

                            },
                            'cancel':true
                        });

                        break;

                    }

                    case 'config_save_test':{

                        page_object.action.admin.action.config_content.action.save.send_test();

                        break;

                    }

                }

            },
            'send':function(is_save){

                page_object.action.admin.action.config_content.action.timer.is_stop=true;

                page_object.action.admin.action.config_content.action.timer.reset();

                let  post=''
                    ,sec =parseInt($v('config_back_to_auto'))
                    ,time_type =parseInt($v('config_back_to_auto_type'))
                    ,brush_mode =-1
                    ,ir_mode =-1
                    ,heater_mode =-1
                    ,cooler_mode =-1
                    ,glass_heater_mode =-1
                    ,gen_mode =-1;

                page_object.action.admin.action.config_content.action.load.show();

                switch(time_type){

                    case 2:{

                        sec=sec*60;

                        break;

                    }

                    case 3:{

                        sec=sec*60*60;

                        break;

                    }

                }

                if($d('config_ir_auto').getAttribute('class') === 'switch_item_active')
                    ir_mode=0;
                else if($d('config_ir_hand').getAttribute('class') === 'switch_item_active')
                    ir_mode=1;
                else if($d('config_ir_off').getAttribute('class') === 'switch_item_active')
                    ir_mode=2;

                if($d('config_gen_auto').getAttribute('class') === 'switch_item_active')
                    gen_mode=0;
                // else if($d('config_gen_hand').getAttribute('class') === 'switch_item_active')
                //     gen_mode=1;
                else if($d('config_gen_off').getAttribute('class') === 'switch_item_active')
                    gen_mode=2;
                else
                    gen_mode=-1;

                if($d('config_heater_auto').getAttribute('class') === 'switch_item_active')
                    heater_mode=0;
                else if($d('config_heater_hand').getAttribute('class') === 'switch_item_active')
                    heater_mode=1;
                else if($d('config_heater_off').getAttribute('class') === 'switch_item_active')
                    heater_mode=2;

                if($d('config_cooler_auto').getAttribute('class') === 'switch_item_active')
                    cooler_mode=0;
                else if($d('config_cooler_hand').getAttribute('class') === 'switch_item_active')
                    cooler_mode=1;
                else if($d('config_cooler_off').getAttribute('class') === 'switch_item_active')
                    cooler_mode=2;

                if($d('config_glass_heater_auto').getAttribute('class') === 'switch_item_active')
                    glass_heater_mode=0;
                else if($d('config_glass_heater_hand').getAttribute('class') === 'switch_item_active')
                    glass_heater_mode=1;

                if($d('config_brush_auto').getAttribute('class') === 'switch_item_active')
                    brush_mode=0;
                else if($d('config_brush_on').getAttribute('class') === 'switch_item_active')
                    brush_mode=1;
                else
                    brush_mode=2;

                post+='&is_save='+(is_save?1:0);
                post+='&camera_id='+uniEncode(page_object.link.link_list[3]);
                post+='&name='+uniEncode(page_object.action.admin.data['config']['camera_data']['name']);

                post+='&focus='+uniEncode(empty($v('config_focus'))?0:$v('config_focus'));
                post+='&iris='+uniEncode(empty($v('config_iris'))?0:$v('config_iris'));
                post+='&bright='+uniEncode(empty($v('config_bright'))?0:$v('config_bright'));

                post+='&exposure_time='+uniEncode(empty($v('config_exposure'))?0:$v('config_exposure'));
                post+='&exposure_time_max='+uniEncode(empty($v('config_exposure_time_max'))?0:$v('config_exposure_time_max'));

                post+='&gain='+uniEncode(empty($v('config_gain'))?0:$v('config_gain'));
                post+='&gain_max='+uniEncode(empty($v('config_gain_max'))?0:$v('config_gain_max'));
                post+='&digital_shift='+uniEncode(empty($v('config_digital_shift'))?0:$v('config_digital_shift'));
                post+='&gamma='+uniEncode(empty($v('config_gamma'))?0:$v('config_gamma'));
                post+='&gamma_min='+uniEncode(empty($v('config_gamma_min'))?0:$v('config_gamma_min'));
                post+='&black_level='+uniEncode(empty($v('config_black_level'))?0:$v('config_black_level'));

                post+='&target_light_day='+uniEncode(empty($v('config_target_light_day'))?0:$v('config_target_light_day'));
                post+='&target_light_night='+uniEncode(empty($v('config_target_light_night'))?0:$v('config_target_light_night'));

                post+='&ir_mode='+uniEncode(ir_mode);
                post+='&ir_min='+uniEncode(empty($v('config_ir_min'))?0:$v('config_ir_min'));
                post+='&ir_max='+uniEncode(empty($v('config_ir_max'))?0:$v('config_ir_max'));
                post+='&light_sensor='+uniEncode(empty($v('config_light_sensor'))?0:$v('config_light_sensor'));

                post+='&gen_mode='+uniEncode(gen_mode);
                post+='&gen_period='+uniEncode(empty($v('config_gen_period'))?0:$v('config_gen_period'));
                post+='&gen_cam_delay='+uniEncode(empty($v('config_gen_cam_delay'))?0:$v('config_gen_cam_delay'));
                post+='&gen_light_delay='+uniEncode(empty($v('config_gen_light_delay'))?0:$v('config_gen_light_delay'));
                post+='&gen_light_time='+uniEncode(empty($v('config_gen_light_time'))?0:$v('config_gen_light_time'));

                post+='&heater_mode='+uniEncode(heater_mode);
                post+='&heater_min='+uniEncode(empty($v('config_heater_min'))?0:$v('config_heater_min'));
                post+='&heater_max='+uniEncode(empty($v('config_heater_max'))?0:$v('config_heater_max'));

                post+='&cooler_mode='+uniEncode(cooler_mode);
                post+='&cooler_min='+uniEncode(empty($v('config_cooler_min'))?0:$v('config_cooler_min'));
                post+='&cooler_max='+uniEncode(empty($v('config_cooler_max'))?0:$v('config_cooler_max'));

                post+='&glass_heater_mode='+uniEncode(glass_heater_mode);

                post+='&brush_mode='+uniEncode(brush_mode);
                post+='&back_to_auto='+uniEncode(sec);

                send({
                    'scriptPath':'/api/json/set_camera_config_data',
                    'postData':post,
                    'onComplete':function(j,worktime){

                        var  dataTemp
                            ,data;

                        dataTemp=j.responseText;
                        trace(dataTemp);
                        data=jsonDecode(dataTemp);
                        trace(data);
                        trace_worktime(worktime,data);

                        if(isset(data['error'])){

                            page_object.action.admin.action.config_content.action.error.init(data);

                        }
                        else{

                            page_object.action.admin.data['config']['camera_data']['iris'] =data['data']['iris'];
                            page_object.action.admin.data['config']['camera_data']['focus'] =data['data']['focus'];

                            page_object.action.admin.data['config']['camera_data']['exposure_time'] =data['data']['exposure_time'];
                            page_object.action.admin.data['config']['camera_data']['exposure_time_max'] =data['data']['exposure_time_max'];

                            page_object.action.admin.data['config']['camera_data']['gain'] =data['data']['gain'];
                            page_object.action.admin.data['config']['camera_data']['gain_max'] =data['data']['gain_max'];
                            page_object.action.admin.data['config']['camera_data']['digital_shift'] =data['data']['digital_shift'];
                            page_object.action.admin.data['config']['camera_data']['gamma'] =data['data']['gamma'];
                            page_object.action.admin.data['config']['camera_data']['gamma_min'] =data['data']['gamma_min'];
                            page_object.action.admin.data['config']['camera_data']['black_level'] =data['data']['black_level'];

                            page_object.action.admin.data['config']['camera_data']['ir_mode'] =data['data']['ir_mode'];
                            page_object.action.admin.data['config']['camera_data']['ir_min'] =data['data']['ir_min'];
                            page_object.action.admin.data['config']['camera_data']['ir_max'] =data['data']['ir_max'];
                            page_object.action.admin.data['config']['camera_data']['ir_power'] =data['data']['ir_power'];

                            page_object.action.admin.data['config']['camera_data']['gen_mode'] =data['data']['gen_mode'];
                            page_object.action.admin.data['config']['camera_data']['gen_period'] =data['data']['gen_period'];
                            page_object.action.admin.data['config']['camera_data']['gen_cam_delay'] =data['data']['gen_cam_delay'];
                            page_object.action.admin.data['config']['camera_data']['gen_light_delay'] =data['data']['gen_light_delay'];
                            page_object.action.admin.data['config']['camera_data']['gen_light_time'] =data['data']['gen_light_time'];

                            page_object.action.admin.data['config']['camera_data']['heater_mode'] =data['data']['heater_mode'];
                            page_object.action.admin.data['config']['camera_data']['heater_min'] =data['data']['heater_min'];
                            page_object.action.admin.data['config']['camera_data']['heater_max'] =data['data']['heater_max'];

                            page_object.action.admin.data['config']['camera_data']['cooler_mode'] =data['data']['cooler_mode'];
                            page_object.action.admin.data['config']['camera_data']['cooler_min'] =data['data']['cooler_min'];
                            page_object.action.admin.data['config']['camera_data']['cooler_max'] =data['data']['cooler_max'];

                            page_object.action.admin.data['config']['camera_data']['glass_heater_mode'] =data['data']['glass_heater_mode'];

                            page_object.action.admin.data['config']['camera_data']['brush_mode'] =data['data']['brush_mode'];

                            page_object.action.admin.action.config_content.action.timer.prepare();


                        }

                        page_object.action.admin.action.config_content.action.buttons.reset();
                        page_object.action.admin.action.config_content.action.buttons.set_action();

                        if(isset($d('config_update'))){

                            if(is_save){

                                $d('config_update').setAttribute('class','config_update_disable');

                                $d('config_update').onclick=function(){};

                            }
                            else{

                                $d('config_update').setAttribute('class','config_update');

                                $d('config_update').onclick=page_object.action.admin.action.config_content.action.save.init;

                            }

                        }

                        page_object.action.admin.action.config_content.action.timer.is_stop=false;
                        page_object.action.admin.action.config_content.action.timer.init();

                        page_object.action.admin.action.config_content.action.load.un_show();

                    }
                });

            },
            'send_test':function(){

                let  post='';

                page_object.action.admin.action.config_content.action.timer.is_stop=true;

                page_object.action.admin.action.config_content.action.timer.reset();
                page_object.action.admin.action.config_content.action.load.show();

                post+='&camera_id='+uniEncode(page_object.link.link_list[3]);
                post+='&focus='+uniEncode(empty($v('config_focus'))?0:$v('config_focus'));
                post+='&iris='+uniEncode(empty($v('config_iris'))?0:$v('config_iris'));

                post+='&exposure_time='+uniEncode(empty($v('config_exposure'))?0:$v('config_exposure'));
                post+='&exposure_time_max='+uniEncode(empty($v('config_exposure_time_max'))?0:$v('config_exposure_time_max'));

                post+='&gain='+uniEncode(empty($v('config_gain'))?0:$v('config_gain'));
                post+='&gain_max='+uniEncode(empty($v('config_gain_max'))?0:$v('config_gain_max'));
                post+='&digital_shift='+uniEncode(empty($v('config_digital_shift'))?0:$v('config_digital_shift'));
                post+='&gamma='+uniEncode(empty($v('config_gamma'))?0:$v('config_gamma'));
                post+='&gamma_min='+uniEncode(empty($v('config_gamma_min'))?0:$v('config_gamma_min'));
                post+='&black_level='+uniEncode(empty($v('config_black_level'))?0:$v('config_black_level'));

                post+='&target_light_day='+uniEncode(empty($v('config_target_light_day'))?0:$v('config_target_light_day'));
                post+='&target_light_night='+uniEncode(empty($v('config_target_light_night'))?0:$v('config_target_light_night'));

                send({
                    'scriptPath':'/api/json/set_camera_test_config_data',
                    'postData':post,
                    'onComplete':function(j,worktime){

                        var  dataTemp
                            ,data;

                        dataTemp=j.responseText;
                        trace(dataTemp);
                        data=jsonDecode(dataTemp);
                        trace(data);
                        trace_worktime(worktime,data);

                        if(isset(data['error'])){

                            page_object.action.admin.action.config_content.action.error.init(data);

                        }
                        else{

                            page_object.action.admin.data['config']['camera_data']['iris'] =data['data']['iris'];
                            page_object.action.admin.data['config']['camera_data']['focus'] =data['data']['focus'];

                            page_object.action.admin.data['config']['camera_data']['exposure_time'] =data['data']['exposure_time'];

                            page_object.action.admin.data['config']['camera_data']['gain'] =data['data']['gain'];
                            page_object.action.admin.data['config']['camera_data']['digital_shift'] =data['data']['digital_shift'];
                            page_object.action.admin.data['config']['camera_data']['gamma'] =data['data']['gamma'];
                            page_object.action.admin.data['config']['camera_data']['black_level'] =data['data']['black_level'];

                            page_object.action.admin.action.config_content.action.timer.prepare();

                        }

                        page_object.action.admin.action.config_content.action.buttons.is_edit =true;
                        page_object.action.admin.action.config_content.action.timer.is_stop =false;

                        page_object.action.admin.action.config_content.action.buttons.set_action();
                        page_object.action.admin.action.config_content.action.timer.init();

                        page_object.action.admin.action.config_content.action.load.un_show();

                    }
                });

            }
        },
        'cancel':{
            'init':function(){

                let inner='';

                inner+='<div class="dialog_row">Отменить изменения?</div>';

                var dialog_index=page_object.dialog.init({
                    'title':'Информация',
                    'inner':inner,
                    'ok':function(){

                        page_object.action.admin.action.config_content.action.cancel.prepare();

                        page_object.dialog.action.un_show.init(dialog_index,true);

                    },
                    'cancel':true
                });

            },
            'prepare':function(){

                let data=clone_object(page_object.action.admin.action.config_content.action.buttons.data);

                trace('CANCEL >>>>');
                trace(data);

                page_object.action.admin.data['config']['camera_data']['iris'] =data['iris'];
                page_object.action.admin.data['config']['camera_data']['iris_max'] =data['iris_max'];

                page_object.action.admin.data['config']['camera_data']['focus'] =data['focus'];
                page_object.action.admin.data['config']['camera_data']['focus_max'] =data['focus_max'];

                page_object.action.admin.data['config']['camera_data']['exposure_time'] =data['exposure_time'];
                page_object.action.admin.data['config']['camera_data']['exposure_time_max'] =data['exposure_time_max'];

                page_object.action.admin.data['config']['camera_data']['gain'] =data['gain'];
                page_object.action.admin.data['config']['camera_data']['gain_max'] =data['gain_max'];
                page_object.action.admin.data['config']['camera_data']['digital_shift'] =data['digital_shift'];
                page_object.action.admin.data['config']['camera_data']['gamma'] =data['gamma'];
                page_object.action.admin.data['config']['camera_data']['gamma_min'] =data['gamma_min'];
                page_object.action.admin.data['config']['camera_data']['black_level'] =data['black_level'];

                page_object.action.admin.data['config']['camera_data']['ir_mode'] =data['ir_mode'];
                page_object.action.admin.data['config']['camera_data']['ir_min'] =data['ir_min'];
                page_object.action.admin.data['config']['camera_data']['ir_max'] =data['ir_max'];

                page_object.action.admin.data['config']['camera_data']['gen_mode'] =data['gen_mode'];
                page_object.action.admin.data['config']['camera_data']['gen_period'] =data['gen_period'];
                page_object.action.admin.data['config']['camera_data']['gen_cam_delay'] =data['gen_cam_delay'];
                page_object.action.admin.data['config']['camera_data']['gen_light_delay'] =data['gen_light_delay'];
                page_object.action.admin.data['config']['camera_data']['gen_light_time'] =data['gen_light_time'];

                page_object.action.admin.data['config']['camera_data']['light_sensor'] =data['light_sensor'];

                page_object.action.admin.data['config']['camera_data']['heater_mode'] =data['heater_mode'];
                page_object.action.admin.data['config']['camera_data']['heater_min'] =data['heater_min'];
                page_object.action.admin.data['config']['camera_data']['heater_max'] =data['heater_max'];

                page_object.action.admin.data['config']['camera_data']['cooler_mode'] =data['cooler_mode'];
                page_object.action.admin.data['config']['camera_data']['cooler_min'] =data['cooler_min'];
                page_object.action.admin.data['config']['camera_data']['cooler_max'] =data['cooler_max'];

                page_object.action.admin.data['config']['camera_data']['glass_heater_mode'] =data['glass_heater_mode'];

                page_object.action.admin.data['config']['camera_data']['brush_mode'] =data['brush_mode'];

                page_object.action.admin.data['config']['camera_data']['current_light'] =data['current_light'];
                page_object.action.admin.data['config']['camera_data']['target_light_day'] =data['target_light_day'];
                page_object.action.admin.data['config']['camera_data']['target_light_night'] =data['target_light_night'];

                data=page_object.action.admin.data['config']['camera_data'];

                if(isset($d('config_install_height')))
                    $d('config_install_height').value=stripSlashes(data['install_height']);

                if(isset($d('config_focus')))
                    $d('config_focus').value=stripSlashes(data['focus']);

                if(isset($d('config_iris')))
                    $d('config_iris').value=stripSlashes(data['iris']);

                if(isset($d('config_exposure')))
                    $d('config_exposure').value=stripSlashes(data['exposure_time']);

                if(isset($d('config_exposure_time_max')))
                    $d('config_exposure_time_max').value=stripSlashes(data['exposure_time_max']);

                if(isset($d('config_gain')))
                    $d('config_gain').value=stripSlashes(data['gain']);

                if(isset($d('config_gain_max')))
                    $d('config_gain_max').value=stripSlashes(data['gain_max']);

                if(isset($d('config_digital_shift')))
                    $d('config_digital_shift').value=stripSlashes(data['digital_shift']);

                if(isset($d('config_gamma')))
                    $d('config_gamma').value=stripSlashes(data['gamma']);

                if(isset($d('config_gamma_min')))
                    $d('config_gamma_min').value=stripSlashes(data['gamma_min']);

                if(isset($d('config_black_level')))
                    $d('config_black_level').value=stripSlashes(data['black_level']);


                if(isset($d('config_ir_min')))
                    $d('config_ir_min').value=stripSlashes(data['ir_min']);

                if(isset($d('config_ir_max')))
                    $d('config_ir_max').value=stripSlashes(data['ir_max']);

                if(isset($d('config_light_sensor')))
                    $d('config_light_sensor').value=stripSlashes(data['light_sensor']);


                if(isset($d('config_gen_period')))
                    $d('config_gen_period').value=stripSlashes(data['gen_period']);

                if(isset($d('config_gen_cam_delay')))
                    $d('config_gen_cam_delay').value=stripSlashes(data['gen_cam_delay']);

                if(isset($d('config_gen_light_delay')))
                    $d('config_gen_light_delay').value=stripSlashes(data['gen_light_delay']);

                if(isset($d('config_gen_light_time')))
                    $d('config_gen_light_time').value=stripSlashes(data['gen_light_time']);


                if(isset($d('config_heater_min')))
                    $d('config_heater_min').value=stripSlashes(data['heater_min']);

                if(isset($d('config_heater_max')))
                    $d('config_heater_max').value=stripSlashes(data['heater_max']);


                if(isset($d('config_cooler_min')))
                    $d('config_cooler_min').value=stripSlashes(data['cooler_min']);

                if(isset($d('config_cooler_max')))
                    $d('config_cooler_max').value=stripSlashes(data['cooler_max']);

                if(isset($d('config_current_light')))
                    $d('config_current_light').value=stripSlashes(data['current_light']);

                if(isset($d('config_target_light_day')))
                    $d('config_target_light_day').value=stripSlashes(data['target_light_day']);

                if(isset($d('config_target_light_night')))
                    $d('config_target_light_night').value=stripSlashes(data['target_light_night']);


                if(isset($d('config_back_to_auto')))
                    $d('config_back_to_auto').value=300;

                if(isset($d('config_back_to_auto_type')))
                    $d('config_back_to_auto_type').value=1;

                page_object.action.admin.action.config_content.action.buttons.reset();
                page_object.action.admin.action.config_content.action.buttons.set_action();

                page_object.action.admin.action.config_content.action.timer.prepare();

            }
        },
        'iframe':{
            'check_size':function(h){

                if(isset($d('config_video_iframe'))){

                    $d('config_video_iframe').height=h;

                }

            }
        },
        'timer':{
            'timeout':3000,
            'timeout_event':null,
            'is_stop':false,
            'init':function(){

                if(page_object.action.admin.data['config']['camera_data']['camera_work_mode'] === 0 || page_object.action.admin.data['config']['camera_data']['camera_work_mode'] === 1
                )
                    page_object.action.admin.action.config_content.action.timer.start();

            },
            'reset':function(){

                if(isset(page_object.action.admin.action.config_content.action.timer.timeout_event))
                    clearTimeout(page_object.action.admin.action.config_content.action.timer.timeout_event);

            },
            'start':function(){

                page_object.action.admin.action.config_content.action.timer.reset();

                page_object.action.admin.action.config_content.action.timer.timeout_event=setTimeout(page_object.action.admin.action.config_content.action.timer.send,page_object.action.admin.action.config_content.action.timer.timeout);

            },
            'send':function(){

                page_object.action.admin.action.config_content.action.timer.reset();

                if(page_object.action.admin.action.config_content.action.timer.is_stop)
                    return true;

                if(isset(page_object.action.admin.data['config']))
                    if(page_object.action.admin.data['config']['camera_data']['camera_work_mode'] === 0 || page_object.action.admin.data['config']['camera_data']['camera_work_mode'] === 1
                    ){

                        send({
                            'scriptPath':'/api/json/get_camera_config_data',
                            'postData':'camera_id='+uniEncode(page_object.link.link_list[3]),
                            'onComplete':function(j,worktime){

                                var  dataTemp
                                    ,data;

                                dataTemp=j.responseText;
                                trace(dataTemp);
                                data=jsonDecode(dataTemp);
                                trace(data);
                                trace_worktime(worktime,data);

                                if(isset(data['error'])){

                                    page_object.action.admin.action.config_content.action.error.init(data);

                                }
                                else{

                                    trace('CAMERA WORK MODE: '+data['data']['camera_work_mode']);

                                    if(data['data']['camera_work_mode'] === 0){

                                        page_object.action.admin.data['config']['camera_data']['camera_work_mode'] =data['data']['camera_work_mode'];

                                        page_object.action.admin.data['config']['camera_data']['iris'] =data['data']['iris'];
                                        page_object.action.admin.data['config']['camera_data']['iris_max'] =data['data']['iris_max'];

                                        page_object.action.admin.data['config']['camera_data']['focus'] =data['data']['focus'];
                                        page_object.action.admin.data['config']['camera_data']['focus_max'] =data['data']['focus_max'];

                                        page_object.action.admin.data['config']['camera_data']['bright'] =data['data']['bright'];

                                        page_object.action.admin.data['config']['camera_data']['ir_mode'] =data['data']['ir_mode'];
                                        page_object.action.admin.data['config']['camera_data']['ir_min'] =data['data']['ir_min'];
                                        page_object.action.admin.data['config']['camera_data']['ir_max'] =data['data']['ir_max'];
                                        page_object.action.admin.data['config']['camera_data']['ir_power'] =data['data']['ir_power'];

                                        page_object.action.admin.data['config']['camera_data']['gen_mode'] =data['data']['gen_mode'];
                                        page_object.action.admin.data['config']['camera_data']['gen_period'] =data['data']['gen_period'];
                                        page_object.action.admin.data['config']['camera_data']['gen_cam_delay'] =data['data']['gen_cam_delay'];
                                        page_object.action.admin.data['config']['camera_data']['gen_light_delay'] =data['data']['gen_light_delay'];
                                        page_object.action.admin.data['config']['camera_data']['gen_light_time'] =data['data']['gen_light_time'];

                                        page_object.action.admin.data['config']['camera_data']['light_sensor'] =data['data']['light_sensor'];

                                        page_object.action.admin.data['config']['camera_data']['heater_mode'] =data['data']['heater_mode'];
                                        page_object.action.admin.data['config']['camera_data']['heater_min'] =data['data']['heater_min'];
                                        page_object.action.admin.data['config']['camera_data']['heater_max'] =data['data']['heater_max'];

                                        page_object.action.admin.data['config']['camera_data']['cooler_mode'] =data['data']['cooler_mode'];
                                        page_object.action.admin.data['config']['camera_data']['cooler_min'] =data['data']['cooler_min'];
                                        page_object.action.admin.data['config']['camera_data']['cooler_max'] =data['data']['cooler_max'];

                                        page_object.action.admin.data['config']['camera_data']['glass_heater_mode'] =data['data']['glass_heater_mode'];

                                        page_object.action.admin.data['config']['camera_data']['brush_mode'] =data['data']['brush_mode'];

                                        page_object.action.admin.data['config']['camera_data']['gain'] =data['data']['gain'];
                                        page_object.action.admin.data['config']['camera_data']['gain_max'] =data['data']['gain_max'];
                                        page_object.action.admin.data['config']['camera_data']['gamma'] =data['data']['gamma'];
                                        page_object.action.admin.data['config']['camera_data']['gamma_min'] =data['data']['gamma_min'];
                                        page_object.action.admin.data['config']['camera_data']['exposure_time'] =data['data']['exposure_time'];
                                        page_object.action.admin.data['config']['camera_data']['exposure_time_max'] =data['data']['exposure_time_max'];

                                        page_object.action.admin.data['config']['camera_data']['current_light'] =data['data']['current_light'];
                                        page_object.action.admin.data['config']['camera_data']['target_light_day'] =data['data']['target_light_day'];
                                        page_object.action.admin.data['config']['camera_data']['target_light_night'] =data['data']['target_light_night'];

                                        page_object.action.admin.action.config_content.action.timer.prepare();

                                    }
                                    else if(data['data']['camera_work_mode'] === 1){

                                        if(page_object.action.admin.data['config']['camera_data']['camera_work_mode'] === 0){

                                            page_object.action.admin.data['config']['camera_data']['camera_work_mode'] =data['data']['camera_work_mode'];

                                            page_object.action.admin.data['config']['camera_data']['iris'] =data['data']['iris'];
                                            page_object.action.admin.data['config']['camera_data']['iris_max'] =data['data']['iris_max'];

                                            page_object.action.admin.data['config']['camera_data']['focus'] =data['data']['focus'];
                                            page_object.action.admin.data['config']['camera_data']['focus_max'] =data['data']['focus_max'];

                                            page_object.action.admin.data['config']['camera_data']['bright'] =data['data']['bright'];

                                            page_object.action.admin.data['config']['camera_data']['ir_mode'] =data['data']['ir_mode'];
                                            page_object.action.admin.data['config']['camera_data']['ir_min'] =data['data']['ir_min'];
                                            page_object.action.admin.data['config']['camera_data']['ir_max'] =data['data']['ir_max'];
                                            page_object.action.admin.data['config']['camera_data']['ir_power'] =data['data']['ir_power'];

                                            page_object.action.admin.data['config']['camera_data']['gen_mode'] =data['data']['gen_mode'];
                                            page_object.action.admin.data['config']['camera_data']['gen_period'] =data['data']['gen_period'];
                                            page_object.action.admin.data['config']['camera_data']['gen_cam_delay'] =data['data']['gen_cam_delay'];
                                            page_object.action.admin.data['config']['camera_data']['gen_light_delay'] =data['data']['gen_light_delay'];
                                            page_object.action.admin.data['config']['camera_data']['gen_light_time'] =data['data']['gen_light_time'];

                                            page_object.action.admin.data['config']['camera_data']['light_sensor'] =data['data']['light_sensor'];

                                            page_object.action.admin.data['config']['camera_data']['heater_mode'] =data['data']['heater_mode'];
                                            page_object.action.admin.data['config']['camera_data']['heater_min'] =data['data']['heater_min'];
                                            page_object.action.admin.data['config']['camera_data']['heater_max'] =data['data']['heater_max'];

                                            page_object.action.admin.data['config']['camera_data']['cooler_mode'] =data['data']['cooler_mode'];
                                            page_object.action.admin.data['config']['camera_data']['cooler_min'] =data['data']['cooler_min'];
                                            page_object.action.admin.data['config']['camera_data']['cooler_max'] =data['data']['cooler_max'];

                                            page_object.action.admin.data['config']['camera_data']['glass_heater_mode'] =data['data']['glass_heater_mode'];

                                            page_object.action.admin.data['config']['camera_data']['brush_mode'] =data['data']['brush_mode'];

                                            page_object.action.admin.data['config']['camera_data']['gain'] =data['data']['gain'];
                                            page_object.action.admin.data['config']['camera_data']['gain_max'] =data['data']['gain_max'];
                                            page_object.action.admin.data['config']['camera_data']['gamma'] =data['data']['gamma'];
                                            page_object.action.admin.data['config']['camera_data']['gamma_min'] =data['data']['gamma_min'];
                                            page_object.action.admin.data['config']['camera_data']['exposure_time'] =data['data']['exposure_time'];
                                            page_object.action.admin.data['config']['camera_data']['exposure_time_max'] =data['data']['exposure_time_max'];

                                            page_object.action.admin.data['config']['camera_data']['current_light'] =data['data']['current_light'];
                                            page_object.action.admin.data['config']['camera_data']['target_light_day'] =data['data']['target_light_day'];
                                            page_object.action.admin.data['config']['camera_data']['target_light_night'] =data['data']['target_light_night'];

                                            page_object.action.admin.action.config_content.action.timer.prepare();

                                        }
                                        else{

                                            page_object.action.admin.data['config']['camera_data']['light_sensor'] =data['data']['light_sensor'];

                                            page_object.action.admin.data['config']['camera_data']['current_light'] =data['data']['current_light'];
                                            page_object.action.admin.data['config']['camera_data']['target_light_day'] =data['data']['target_light_day'];
                                            page_object.action.admin.data['config']['camera_data']['target_light_night'] =data['data']['target_light_night'];

                                            page_object.action.admin.action.config_content.action.timer.prepare();

                                        }

                                    }

                                    page_object.action.admin.data['config']['camera_data']['camera_work_mode'] = data['data']['camera_work_mode'];

                                }

                                page_object.action.admin.action.config_content.action.check_video_container.check();

                                if(page_object.action.admin.data['config']['camera_data']['camera_work_mode'] === 0 || page_object.action.admin.data['config']['camera_data']['camera_work_mode'] === 1
                                ){

                                    page_object.action.admin.action.config_content.action.timer.start();

                                }

                            }
                        });

                    }

            },
            'prepare':function(){

                let data=page_object.action.admin.data['config']['camera_data'];

                if(page_object.action.admin.data['config']['camera_data']['camera_work_mode'] === 0){

                    page_object.action.admin.data['config']['camera_data']['light_sensor'] =data['light_sensor'];

                    page_object.action.admin.data['config']['camera_data']['gain'] =data['gain'];
                    page_object.action.admin.data['config']['camera_data']['gain_max'] =data['gain_max'];
                    page_object.action.admin.data['config']['camera_data']['gamma'] =data['gamma'];
                    page_object.action.admin.data['config']['camera_data']['gamma_min'] =data['gamma_min'];
                    page_object.action.admin.data['config']['camera_data']['exposure_time'] =data['exposure_time'];
                    page_object.action.admin.data['config']['camera_data']['exposure_time_max'] =data['exposure_time_max'];

                    page_object.action.admin.data['config']['camera_data']['current_light'] =data['current_light'];
                    page_object.action.admin.data['config']['camera_data']['target_light_day'] =data['target_light_day'];
                    page_object.action.admin.data['config']['camera_data']['target_light_night'] =data['target_light_night'];

                    if(isset($d('config_focus')))
                        $d('config_focus').value=stripSlashes(data['focus']);

                    if(isset($d('config_iris')))
                        $d('config_iris').value=stripSlashes(data['iris']);

                    if(isset($d('config_bright')))
                        $d('config_bright').value=stripSlashes(data['bright']);

                    if(isset($d('config_exposure')))
                        $d('config_exposure').value=stripSlashes(data['exposure_time']);

                    if(isset($d('config_gain')))
                        $d('config_gain').value=stripSlashes(data['gain']);

                    if(isset($d('config_gain_max')))
                        $d('config_gain_max').value=stripSlashes(data['gain_max']);

                    if(isset($d('config_light_sensor')))
                        $d('config_light_sensor').value=stripSlashes(data['light_sensor']);

                    if(isset($d('config_digital_shift')))
                        $d('config_digital_shift').value=stripSlashes(data['digital_shift']);

                    if(isset($d('config_gamma')))
                        $d('config_gamma').value=stripSlashes(data['gamma']);

                    if(isset($d('config_current_light')))
                        $d('config_current_light').value=stripSlashes(data['current_light']);

                    if(isset($d('config_black_level')))
                        $d('config_black_level').value=stripSlashes(data['black_level']);

                    page_object.action.admin.action.config_content.action.camera_config.un_show();
                    page_object.action.admin.action.config_content.action.light_config.un_show();
                    page_object.action.admin.action.config_content.action.ir_config.un_show();
                    page_object.action.admin.action.config_content.action.gen_config.un_show();
                    page_object.action.admin.action.config_content.action.heater_config.un_show();
                    page_object.action.admin.action.config_content.action.cooler_config.un_show();
                    page_object.action.admin.action.config_content.action.glass_heater_config.un_show();
                    page_object.action.admin.action.config_content.action.brush_config.un_show();
                    page_object.action.admin.action.config_content.action.timer_config.un_show();

                }
                else{

                    if(isset($d('config_light_sensor')))
                        $d('config_light_sensor').value=stripSlashes(data['light_sensor']);

                    if(isset($d('config_digital_shift')))
                        $d('config_digital_shift').value=stripSlashes(data['digital_shift']);

                    if(isset($d('config_current_light')))
                        $d('config_current_light').value=stripSlashes(data['current_light']);

                    if(isset($d('config_black_level')))
                        $d('config_black_level').value=stripSlashes(data['black_level']);

                    page_object.action.admin.action.config_content.action.camera_config.show();
                    page_object.action.admin.action.config_content.action.light_config.show();
                    page_object.action.admin.action.config_content.action.ir_config.show();
                    page_object.action.admin.action.config_content.action.gen_config.show();
                    page_object.action.admin.action.config_content.action.heater_config.show();
                    page_object.action.admin.action.config_content.action.cooler_config.show();
                    page_object.action.admin.action.config_content.action.glass_heater_config.show();
                    page_object.action.admin.action.config_content.action.brush_config.show();
                    page_object.action.admin.action.config_content.action.timer_config.show();

                }

                page_object.action.admin.action.config_content.action.camera_work_mode.set_action();
                page_object.action.admin.action.config_content.action.light_config.set_action();
                page_object.action.admin.action.config_content.action.ir_config.set_action();
                page_object.action.admin.action.config_content.action.gen_config.set_action();
                page_object.action.admin.action.config_content.action.heater_config.set_action();
                page_object.action.admin.action.config_content.action.cooler_config.set_action();
                page_object.action.admin.action.config_content.action.glass_heater_config.set_action();
                page_object.action.admin.action.config_content.action.brush_config.set_action();

            }
        },
        'camera_menu':{
            'init':function(){

                let  data =page_object.action.admin.data['config']
                    ,camera_list =data['camera_list']
                    ,index;

                for(index in camera_list)
                    if(!camera_list[index]['is_hide'] &&!camera_list[index]['is_disable']
                    )
                        if(isset($d('camera_menu_item_'+index)))
                            $d('camera_menu_item_'+index).onclick=page_object.action.admin.action.config_content.action.camera_menu.click;

            },
            'click':function(){

                let  data =page_object.action.admin.data['config']
                    ,camera_list =data['camera_list']
                    ,index =parseInt(this.id.split('_')[3])
                    ,lang_obj =page_object.content[page_object.lang]
                    ,link ='/admin/'+page_object.action.admin.data['user']['login']+'/config/'+camera_list[index]['camera_id'];

                page_object.action.admin.action.config_content.action.camera_menu.set_active(index);

                setUrl(lang_obj['title']+' | '+lang_obj['loading'],link);

            },
            'set_active':function(i){

                let  data =page_object.action.admin.data['config']
                    ,camera_list =data['camera_list']
                    ,index;

                for(index in camera_list)
                    if(!camera_list[index]['is_hide']){

                        if(camera_list[index]['is_disable']){

                            $d('camera_menu_item_'+index).setAttribute('class','camera_menu_item_disable');
                            $d('camera_menu_item_'+index).onclick=function(){};

                        }
                        else if(parseInt(i) === parseInt(index)){

                            $d('camera_menu_item_'+index).setAttribute('class','camera_menu_item_active');
                            $d('camera_menu_item_'+index).onclick=function(){};

                        }
                        else{

                            $d('camera_menu_item_'+index).setAttribute('class','camera_menu_item');
                            $d('camera_menu_item_'+index).onclick=page_object.action.admin.action.config_content.action.camera_menu.click;

                        }

                    }



            }
        },
        'screen':{
            'init':function(){

                if(isset($d('config_video_shot')))
                    $d('config_video_shot').onclick=page_object.action.admin.action.config_content.action.screen.send;

            },
            'send':function(){

                if(isset($d('config_video_shot'))){

                    $d('config_video_shot').setAttribute('class','config_video_shot_disable');

                    $d('config_video_shot').onclick =function(){};
                    $d('config_video_shot').innerHTML ='<span>Создаем изображение...</span>';

                    send({
                        'scriptPath':'/api/json/get_camera_screen_link',
                        'postData':'camera_id='+uniEncode(page_object.link.link_list[3]),
                        'onComplete':function(j,worktime){

                            var  dataTemp, data;

                            dataTemp=j.responseText;//                            trace(dataTemp);
                            data=jsonDecode(dataTemp);  //trace(data);                            trace_worktime(worktime,data);                        cl(data);
                            cl(data);
                            cl(data.data.error_list);
                            let link = data['data']['screen_link'];//  cl(link);                        // cl(/admin\/root\/config\/null/.test(link));
                            if(isset(data['error_list']) || !link || /admin\/root\/config\/null/.test(link)){                                //cl(data['error_list']);
                                cl(data['error_list']);
                                er(data.data.error_list + `<br/>Проверьте камеру и питон`, 5000);
                                if(isset($d('config_video_shot'))){
                                    $d('config_video_shot').innerHTML= `<span style="color: #ff0000;">Ошибка:` + data.data.error_list +`<br/>Проверьте камеру и питон</span>`;
                                    setTimeout(function(){
                                        $d('config_video_shot').setAttribute('class','config_video_shot');
                                        $d('config_video_shot').onclick =page_object.action.admin.action.config_content.action.screen.send;
                                        $d('config_video_shot').innerHTML ='<span>Сделать снимок с камеры</span>';

                                    }, 15000);
                                }

                            } else {

                                if(isset($d('camera_screen'))) removeElement($d('camera_screen'));

                                let  link = data['data']['screen_link'], el;

                                el = addElement({
                                    'tag':'a',
                                    'id':'camera_screen',
                                    'href': link,
                                    'style':'display: none;',
                                    'target':'_blank',
                                });

                                $d('all').appendChild(el);
                                $d('camera_screen').click();

                                if(isset($d('config_video_shot'))){

                                    $d('config_video_shot').setAttribute('class','config_video_shot');

                                    $d('config_video_shot').onclick = page_object.action.admin.action.config_content.action.screen.send;
                                    $d('config_video_shot').innerHTML ='<span>Сделать снимок с камеры</span>';

                                }

                            }

                        }
                    });

                }

            }
        },
        'camera_const':{
            'init':function(){

                if(isset($d('config_install_height'))){

                    $d('config_install_height').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_install_height').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                if(isset($d('config_iris_max'))){

                    $d('config_iris_max').onchange =page_object.action.admin.action.config_content.action.camera_const.change_number_max;
                    $d('config_iris_max').onkeyup =page_object.action.admin.action.config_content.action.camera_const.change_number_max;

                }

                if(isset($d('config_focus_max'))){

                    $d('config_focus_max').onchange =page_object.action.admin.action.config_content.action.camera_const.change_number_max;
                    $d('config_focus_max').onkeyup =page_object.action.admin.action.config_content.action.camera_const.change_number_max;

                }

            },
            'change_number_max':function(){

                let key=this.id.split('_')[1];

                if(isNumber(this.value))
                    if(isset($d('config_'+key))){

                        $d('config_'+key).setAttribute('max',parseInt(this.value));

                        if(parseInt(this.value)<parseInt($v('config_'+key)))
                            $d('config_'+key).value=parseInt(this.value);

                    }

                page_object.action.admin.action.config_content.action.buttons.set_edit();

            }
        },
        'camera_work_mode':{
            'init':function(){

                page_object.action.admin.action.config_content.action.camera_work_mode.set_action();

            },
            'camera_off':{
                'show':function(){

                    if(isset($d('config_work_mask'))){

                        $s('config_work_mask').display ='block';
                        $d('config_work_mask').innerHTML ='<span>Камера отключена</span>';

                    }

                },
                'un_show':function(){

                    if(isset($d('config_work_mask'))){

                        $s('config_work_mask').display ='none';
                        $d('config_work_mask').innerHTML ='<span>Камера отключена</span>';

                    }

                }
            },
            'click':{
                'init':function(){

                    let key=this.id.split('_')[2];

                    switch(key){

                        case 'auto':{

                            trace('>>>>>>> send camera work mode');

                            page_object.action.admin.action.config_content.action.camera_work_mode.click.send(0);

                            break;

                        }

                        case 'hand':{

                            page_object.action.admin.action.config_content.action.camera_work_mode.click.send(1);

                            break;

                        }

                    }

                },
                'send':function(camera_work_mode){

                    let  post =''
                        ,sec =parseInt($v('config_back_to_auto'))
                        ,time_type =parseInt($v('config_back_to_auto_type'));

                    switch(time_type){

                        case 2:{

                            sec=sec*60;

                            break;

                        }

                        case 3:{

                            sec=sec*60*60;

                            break;

                        }

                    }

                    post+='camera_id='+uniEncode(page_object.link.link_list[3]);
                    post+='&camera_work_mode='+uniEncode(camera_work_mode);
                    post+='&back_to_auto='+uniEncode(sec);

                    send({
                        'scriptPath':'/api/json/set_camera_work_mode',
                        'postData':post,
                        'onComplete':function(j,worktime){

                            var  dataTemp, data;

                            dataTemp=j.responseText;
                            trace(dataTemp);
                            data=jsonDecode(dataTemp);
                            trace(data);
                            trace_worktime(worktime,data);

                            if(isset(data['error'])){

                                page_object.action.admin.action.config_content.action.error.init(data);

                            }
                            else{

                                page_object.action.admin.action.config_content.action.buttons.set_edit();

                                page_object.action.admin.data['config']['camera_data']['camera_work_mode'] = data['data']['camera_work_mode'];

                                if(page_object.action.admin.data['config']['camera_data']['camera_work_mode'] === 0){

                                    page_object.action.admin.data['config']['camera_data']['iris'] =data['data']['iris'];
                                    page_object.action.admin.data['config']['camera_data']['iris_max'] =data['data']['iris_max'];

                                    page_object.action.admin.data['config']['camera_data']['focus'] =data['data']['focus'];
                                    page_object.action.admin.data['config']['camera_data']['focus_max'] =data['data']['focus_max'];

                                    page_object.action.admin.data['config']['camera_data']['zoom'] =data['data']['zoom'];
                                    page_object.action.admin.data['config']['camera_data']['zoom_max'] =data['data']['zoom_max'];

                                    page_object.action.admin.data['config']['camera_data']['bright'] =data['data']['bright'];

                                    page_object.action.admin.data['config']['camera_data']['ir_mode'] =data['data']['ir_mode'];
                                    page_object.action.admin.data['config']['camera_data']['ir_min'] =data['data']['ir_min'];
                                    page_object.action.admin.data['config']['camera_data']['ir_max'] =data['data']['ir_max'];
                                    page_object.action.admin.data['config']['camera_data']['ir_power'] =data['data']['ir_power'];

                                    page_object.action.admin.data['config']['camera_data']['gen_mode'] =data['data']['gen_mode'];
                                    page_object.action.admin.data['config']['camera_data']['gen_period'] =data['data']['gen_period'];
                                    page_object.action.admin.data['config']['camera_data']['gen_cam_delay'] =data['data']['gen_cam_delay'];
                                    page_object.action.admin.data['config']['camera_data']['gen_light_delay'] =data['data']['gen_light_delay'];
                                    page_object.action.admin.data['config']['camera_data']['gen_light_time'] =data['data']['gen_light_time'];

                                    page_object.action.admin.data['config']['camera_data']['light_sensor'] =data['data']['light_sensor'];

                                    page_object.action.admin.data['config']['camera_data']['heater_mode'] =data['data']['heater_mode'];
                                    page_object.action.admin.data['config']['camera_data']['heater_min'] =data['data']['heater_min'];
                                    page_object.action.admin.data['config']['camera_data']['heater_max'] =data['data']['heater_max'];

                                    page_object.action.admin.data['config']['camera_data']['cooler_mode'] =data['data']['cooler_mode'];
                                    page_object.action.admin.data['config']['camera_data']['cooler_min'] =data['data']['cooler_min'];
                                    page_object.action.admin.data['config']['camera_data']['cooler_max'] =data['data']['cooler_max'];

                                    page_object.action.admin.data['config']['camera_data']['glass_heater_mode'] =data['data']['glass_heater_mode'];

                                    page_object.action.admin.data['config']['camera_data']['brush_mode'] =data['data']['brush_mode'];

                                    page_object.action.admin.action.config_content.action.timer.init();

                                }

                                page_object.action.admin.action.config_content.action.timer.prepare();

                            }

                        }
                    });

                }
            },
            'set_button':function(){

                let  camera_work_mode =page_object.action.admin.data['config']['camera_data']['camera_work_mode']
                    ,list = $d('config_work_type').getElementsByTagName('div')
                    ,index;

                for(index in list)
                    if(isObject(list[index])){

                        list[index].setAttribute('class','switch_item');

                        list[index].onclick=page_object.action.admin.action.config_content.action.camera_work_mode.click.init;

                    }

                switch(camera_work_mode){

                    case 0:{

                        if(isset($d('config_work_auto'))){

                            $d('config_work_auto').setAttribute('class','switch_item_active');

                            $d('config_work_auto').onclick=function(){};

                        }

                        break;

                    }

                    case 1:{

                        if(isset($d('config_work_hand'))){

                            $d('config_work_hand').setAttribute('class','switch_item_active');

                            $d('config_work_hand').onclick=function(){};

                        }

                        break;

                    }

                }

            },
            'set_action':function(){

                let camera_data=page_object.action.admin.data['config']['camera_data'];

                switch(camera_data['camera_work_mode']){

                    case 0:{

                        page_object.action.admin.action.config_content.action.camera_work_mode.camera_off.un_show();
                        page_object.action.admin.action.config_content.action.camera_work_mode.set_button();

                        break;

                    }

                    case 1:{

                        page_object.action.admin.action.config_content.action.camera_work_mode.camera_off.un_show();
                        page_object.action.admin.action.config_content.action.camera_work_mode.set_button();

                        break;

                    }

                    case 2:{

                        page_object.action.admin.action.config_content.action.camera_work_mode.camera_off.show();
                        page_object.action.admin.action.config_content.action.camera_work_mode.set_button();

                        break;

                    }

                }

            }
        },
        'camera_config':{
            'init':function(){

                if(isset($d('config_focus'))){

                    $d('config_focus').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_focus').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                if(isset($d('config_iris'))){

                    $d('config_iris').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_iris').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                if(isset($d('config_bright'))){

                    $d('config_bright').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_bright').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                if(isset($d('config_exposure'))){

                    $d('config_exposure').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_exposure').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                if(isset($d('config_exposure_time_max'))){

                    $d('config_exposure_time_max').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_exposure_time_max').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                if(isset($d('config_gain'))){

                    $d('config_gain').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_gain').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                if(isset($d('config_gain_max'))){

                    $d('config_gain_max').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_gain_max').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                if(isset($d('config_digital_shift'))){

                    $d('config_digital_shift').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_digital_shift').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                if(isset($d('config_gamma'))){

                    $d('config_gamma').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_gamma').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                if(isset($d('config_gamma_min'))){

                    $d('config_gamma_min').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_gamma_min').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                if(isset($d('config_black_level'))){

                    $d('config_black_level').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_black_level').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

            },
            'show':function(){

                if(isset($d('config_camera_block')))
                    $d('config_camera_block').setAttribute('class','config_row_item')

            },
            'un_show':function(){

                if(isset($d('config_camera_block')))
                    $d('config_camera_block').setAttribute('class','config_row_item_disable')

            }
        },
        'light_config':{
            'init':function(){

                if(isset($d('config_target_light_day'))){

                    $d('config_target_light_day').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_target_light_day').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                if(isset($d('config_target_light_night'))){

                    $d('config_target_light_night').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_target_light_night').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                if(page_object.action.admin.data['config']['camera_data']['camera_work_mode'] === 0)
                    page_object.action.admin.action.config_content.action.light_config.un_show();

            },
            'set_action':function(){

            },
            'show':function(){

                if(isset($d('config_light_block')))
                    $d('config_light_block').setAttribute('class','config_row_item')

            },
            'un_show':function(){

                if(isset($d('config_light_block')))
                    $d('config_light_block').setAttribute('class','config_row_item_disable');

            }
        },
        'ir_config':{
            'init':function(){

                if(isset($d('config_ir_min'))){

                    $d('config_ir_min').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_ir_min').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                if(isset($d('config_ir_max'))){

                    $d('config_ir_max').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_ir_max').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                if(isset($d('config_back_to_auto_type')))
                    $d('config_back_to_auto_type').onchange=page_object.action.admin.action.config_content.action.buttons.set_edit;

                page_object.action.admin.action.config_content.action.ir_config.set_action();

            },
            'click':{
                'init':function(){

                    let key=this.id.split('_')[2];

                    switch(key){

                        case 'auto':{

                            page_object.action.admin.action.config_content.action.buttons.set_edit();

                            page_object.action.admin.data['config']['camera_data']['ir_mode'] = 0;

                            page_object.action.admin.action.config_content.action.ir_config.set_action();

                            break;

                        }

                        case 'hand':{

                            page_object.action.admin.action.config_content.action.buttons.set_edit();

                            page_object.action.admin.data['config']['camera_data']['ir_mode'] = 1;

                            page_object.action.admin.action.config_content.action.ir_config.set_action();

                            break;

                        }

                        case 'off':{

                            page_object.action.admin.action.config_content.action.buttons.set_edit();

                            page_object.action.admin.data['config']['camera_data']['ir_mode'] = 2;

                            page_object.action.admin.action.config_content.action.ir_config.set_action();

                            break;

                        }

                    }

                }
            },
            'set_button':function(){

                let  ir_mode =page_object.action.admin.data['config']['camera_data']['ir_mode']
                    ,list = $d('config_ir').getElementsByTagName('div')
                    ,index;

                for(index in list)
                    if(isObject(list[index])){

                        list[index].setAttribute('class','switch_item');

                        list[index].onclick=page_object.action.admin.action.config_content.action.ir_config.click.init;

                    }

                switch(ir_mode){

                    case 0:{

                        if(isset($d('config_ir_auto'))){

                            $d('config_ir_auto').setAttribute('class','switch_item_active');

                            $d('config_ir_auto').onclick=function(){};

                        }

                        break;

                    }

                    case 1:{

                        if(isset($d('config_ir_hand'))){

                            $d('config_ir_hand').setAttribute('class','switch_item_active');

                            $d('config_ir_hand').onclick=function(){};

                        }

                        break;

                    }

                    case 2:{

                        if(isset($d('config_ir_off'))){

                            $d('config_ir_off').setAttribute('class','switch_item_active');

                            $d('config_ir_off').onclick=function(){};

                        }

                        break;

                    }

                }

            },
            'set_action':function(){

                let camera_data=page_object.action.admin.data['config']['camera_data'];

                switch(camera_data['ir_mode']){

                    case -1:{

                        page_object.action.admin.action.config_content.action.ir_config.ir_power_block.un_show();
                        page_object.action.admin.action.config_content.action.ir_config.set_button();

                        break;

                    }

                    case 0:{

                        page_object.action.admin.action.config_content.action.ir_config.ir_power_block.show();
                        page_object.action.admin.action.config_content.action.ir_config.set_button();

                        break;

                    }

                    case 1:{

                        page_object.action.admin.action.config_content.action.ir_config.ir_power_block.un_show();
                        page_object.action.admin.action.config_content.action.ir_config.set_button();

                        break;

                    }

                    case 2:{

                        page_object.action.admin.action.config_content.action.ir_config.ir_power_block.un_show();
                        page_object.action.admin.action.config_content.action.ir_config.set_button();

                        break;

                    }

                }

            },
            'ir_power_block':{
                'show':function(){

                    if(isset($d('ir_min')))
                        $d('ir_min').setAttribute('class','config_row_item_container');

                    if(isset($d('ir_max')))
                        $d('ir_max').setAttribute('class','config_row_item_container');

                    if(isset($d('light_sensor')))
                        $d('light_sensor').setAttribute('class','config_row_item_container');

                },
                'un_show':function(){

                    if(isset($d('ir_min')))
                        $d('ir_min').setAttribute('class','config_row_item_container_disable');

                    if(isset($d('ir_max')))
                        $d('ir_max').setAttribute('class','config_row_item_container_disable');

                    if(isset($d('light_sensor')))
                        $d('light_sensor').setAttribute('class','config_row_item_container_disable');

                }
            },
            'show':function(){

                if(isset($d('config_ir_block')))
                    $d('config_ir_block').setAttribute('class','config_row_item')

            },
            'un_show':function(){

                if(isset($d('config_ir_block')))
                    $d('config_ir_block').setAttribute('class','config_row_item_disable');

                if(page_object.action.admin.data['config']['camera_data']['camera_work_mode'] === 0)
                    page_object.action.admin.action.config_content.action.ir_config.ir_power_block.show();

            }
        },
        'cooler_config':{
            'init':function(){

                if(isset($d('config_cooler_min'))){

                    $d('config_cooler_min').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_cooler_min').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                if(isset($d('config_cooler_max'))){

                    $d('config_cooler_max').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_cooler_max').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                page_object.action.admin.action.config_content.action.cooler_config.set_action();

            },
            'click':{
                'init':function(){

                    let key=this.id.split('_')[2];

                    switch(key){

                        case 'auto':{

                            page_object.action.admin.action.config_content.action.buttons.set_edit();

                            page_object.action.admin.data['config']['camera_data']['cooler_mode'] = 0;

                            page_object.action.admin.action.config_content.action.cooler_config.set_action();

                            break;

                        }

                        case 'hand':{

                            page_object.action.admin.action.config_content.action.buttons.set_edit();

                            page_object.action.admin.data['config']['camera_data']['cooler_mode'] = 1;

                            page_object.action.admin.action.config_content.action.cooler_config.set_action();

                            break;

                        }

                        case 'off':{

                            page_object.action.admin.action.config_content.action.buttons.set_edit();

                            page_object.action.admin.data['config']['camera_data']['cooler_mode'] = 2;

                            page_object.action.admin.action.config_content.action.cooler_config.set_action();

                            break;

                        }

                    }

                }
            },
            'set_button':function(){

                let  cooler_mode =page_object.action.admin.data['config']['camera_data']['cooler_mode']
                    ,list = $d('config_cooler').getElementsByTagName('div')
                    ,index;

                for(index in list)
                    if(isObject(list[index])){

                        list[index].setAttribute('class','switch_item');

                        list[index].onclick=page_object.action.admin.action.config_content.action.cooler_config.click.init;

                    }

                switch(cooler_mode){

                    case 0:{

                        if(isset($d('config_cooler_auto'))){

                            $d('config_cooler_auto').setAttribute('class','switch_item_active');

                            $d('config_cooler_auto').onclick=function(){};

                        }

                        break;

                    }

                    case 1:{

                        if(isset($d('config_cooler_hand'))){

                            $d('config_cooler_hand').setAttribute('class','switch_item_active');

                            $d('config_cooler_hand').onclick=function(){};

                        }

                        break;

                    }

                    case 2:{

                        if(isset($d('config_cooler_off'))){

                            $d('config_cooler_off').setAttribute('class','switch_item_active');

                            $d('config_cooler_off').onclick=function(){};

                        }

                        break;

                    }

                }

            },
            'set_action':function(){

                let camera_data=page_object.action.admin.data['config']['camera_data'];

                switch(camera_data['cooler_mode']){

                    case -1:{

                        page_object.action.admin.action.config_content.action.cooler_config.cooler_power_block.un_show();
                        page_object.action.admin.action.config_content.action.cooler_config.set_button();

                        break;

                    }

                    case 0:{

                        page_object.action.admin.action.config_content.action.cooler_config.cooler_power_block.show();
                        page_object.action.admin.action.config_content.action.cooler_config.set_button();

                        break;

                    }

                    case 1:{

                        page_object.action.admin.action.config_content.action.cooler_config.cooler_power_block.un_show();
                        page_object.action.admin.action.config_content.action.cooler_config.set_button();

                        break;

                    }

                    case 2:{

                        page_object.action.admin.action.config_content.action.cooler_config.cooler_power_block.un_show();
                        page_object.action.admin.action.config_content.action.cooler_config.set_button();

                        break;

                    }

                }

            },
            'cooler_power_block':{
                'show':function(){

                    if(isset($d('cooler_min_block')))
                        $d('cooler_min_block').setAttribute('class','config_row_item_container');

                    if(isset($d('cooler_max_block')))
                        $d('cooler_max_block').setAttribute('class','config_row_item_container');

                },
                'un_show':function(){

                    if(isset($d('cooler_min_block')))
                        $d('cooler_min_block').setAttribute('class','config_row_item_container_disable');

                    if(isset($d('cooler_max_block')))
                        $d('cooler_max_block').setAttribute('class','config_row_item_container_disable');

                }
            },
            'show':function(){

                if(isset($d('config_cooler_block')))
                    $d('config_cooler_block').setAttribute('class','config_row_item')

            },
            'un_show':function(){

                if(isset($d('config_cooler_block')))
                    $d('config_cooler_block').setAttribute('class','config_row_item_disable');

                if(page_object.action.admin.data['config']['camera_data']['camera_work_mode'] === 0)
                    page_object.action.admin.action.config_content.action.cooler_config.cooler_power_block.show();

            }
        },
        'heater_config':{
            'init':function(){

                if(isset($d('config_heater_min'))){

                    $d('config_heater_min').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_heater_min').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                if(isset($d('config_heater_max'))){

                    $d('config_heater_max').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_heater_max').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                page_object.action.admin.action.config_content.action.heater_config.set_action();

            },
            'click':{
                'init':function(){

                    let key=this.id.split('_')[2];

                    switch(key){

                        case 'auto':{

                            page_object.action.admin.action.config_content.action.buttons.set_edit();

                            page_object.action.admin.data['config']['camera_data']['heater_mode'] = 0;

                            page_object.action.admin.action.config_content.action.heater_config.set_action();

                            break;

                        }

                        case 'hand':{

                            page_object.action.admin.action.config_content.action.buttons.set_edit();

                            page_object.action.admin.data['config']['camera_data']['heater_mode'] = 1;

                            page_object.action.admin.action.config_content.action.heater_config.set_action();

                            break;

                        }

                        case 'off':{

                            page_object.action.admin.action.config_content.action.buttons.set_edit();

                            page_object.action.admin.data['config']['camera_data']['heater_mode'] = 2;

                            page_object.action.admin.action.config_content.action.heater_config.set_action();

                            break;

                        }

                    }

                }
            },
            'set_button':function(){

                let  heater_mode =page_object.action.admin.data['config']['camera_data']['heater_mode']
                    ,list = $d('config_heater').getElementsByTagName('div')
                    ,index;

                for(index in list)
                    if(isObject(list[index])){

                        list[index].setAttribute('class','switch_item');

                        list[index].onclick=page_object.action.admin.action.config_content.action.heater_config.click.init;

                    }

                switch(heater_mode){

                    case 0:{

                        if(isset($d('config_heater_auto'))){

                            $d('config_heater_auto').setAttribute('class','switch_item_active');

                            $d('config_heater_auto').onclick=function(){};

                        }

                        break;

                    }

                    case 1:{

                        if(isset($d('config_heater_hand'))){

                            $d('config_heater_hand').setAttribute('class','switch_item_active');

                            $d('config_heater_hand').onclick=function(){};

                        }

                        break;

                    }

                    case 2:{

                        if(isset($d('config_heater_off'))){

                            $d('config_heater_off').setAttribute('class','switch_item_active');

                            $d('config_heater_off').onclick=function(){};

                        }

                        break;

                    }

                }

            },
            'set_action':function(){

                let camera_data=page_object.action.admin.data['config']['camera_data'];

                switch(camera_data['heater_mode']){

                    case -1:{

                        page_object.action.admin.action.config_content.action.heater_config.heater_power_block.un_show();
                        page_object.action.admin.action.config_content.action.heater_config.set_button();

                        break;

                    }

                    case 0:{

                        page_object.action.admin.action.config_content.action.heater_config.heater_power_block.show();
                        page_object.action.admin.action.config_content.action.heater_config.set_button();

                        break;

                    }

                    case 1:{

                        page_object.action.admin.action.config_content.action.heater_config.heater_power_block.un_show();
                        page_object.action.admin.action.config_content.action.heater_config.set_button();

                        break;

                    }

                    case 2:{

                        page_object.action.admin.action.config_content.action.heater_config.heater_power_block.un_show();
                        page_object.action.admin.action.config_content.action.heater_config.set_button();

                        break;

                    }

                }

            },
            'heater_power_block':{
                'show':function(){

                    if(isset($d('heater_min_block')))
                        $d('heater_min_block').setAttribute('class','config_row_item_container');

                    if(isset($d('heater_max_block')))
                        $d('heater_max_block').setAttribute('class','config_row_item_container');

                },
                'un_show':function(){

                    if(isset($d('heater_min_block')))
                        $d('heater_min_block').setAttribute('class','config_row_item_container_disable');

                    if(isset($d('heater_max_block')))
                        $d('heater_max_block').setAttribute('class','config_row_item_container_disable');

                }
            },
            'show':function(){

                if(isset($d('config_heater_block')))
                    $d('config_heater_block').setAttribute('class','config_row_item')

            },
            'un_show':function(){

                if(isset($d('config_heater_block')))
                    $d('config_heater_block').setAttribute('class','config_row_item_disable');

                if(page_object.action.admin.data['config']['camera_data']['camera_work_mode'] === 0)
                    page_object.action.admin.action.config_content.action.heater_config.heater_power_block.show();

            }
        },
        'gen_config':{
            'init':function(){

                if(isset($d('config_gen_period'))){

                    $d('config_gen_period').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_gen_period').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                if(isset($d('config_gen_cam_delay'))){

                    $d('config_gen_cam_delay').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_gen_cam_delay').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                if(isset($d('config_gen_light_delay'))){

                    $d('config_gen_light_delay').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_gen_light_delay').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                if(isset($d('config_gen_light_time'))){

                    $d('config_gen_light_time').onchange =page_object.action.admin.action.config_content.action.buttons.set_edit;
                    $d('config_gen_light_time').onkeyup =page_object.action.admin.action.config_content.action.buttons.set_edit;

                }

                page_object.action.admin.action.config_content.action.gen_config.set_action();

            },
            'click':{
                'init':function(){

                    let key=this.id.split('_')[2];

                    switch(key){

                        case 'auto':{

                            page_object.action.admin.action.config_content.action.buttons.set_edit();

                            page_object.action.admin.data['config']['camera_data']['gen_mode'] = 0;

                            page_object.action.admin.action.config_content.action.gen_config.set_action();

                            break;

                        }

                        case 'hand':{

                            page_object.action.admin.action.config_content.action.buttons.set_edit();

                            page_object.action.admin.data['config']['camera_data']['gen_mode'] = 1;

                            page_object.action.admin.action.config_content.action.gen_config.set_action();

                            break;

                        }

                        case 'off':{

                            page_object.action.admin.action.config_content.action.buttons.set_edit();

                            page_object.action.admin.data['config']['camera_data']['gen_mode'] = 2;

                            page_object.action.admin.action.config_content.action.gen_config.set_action();

                            break;

                        }

                    }

                }
            },
            'set_button':function(){

                let  gen_mode =page_object.action.admin.data['config']['camera_data']['gen_mode']
                    ,list = $d('config_gen').getElementsByTagName('div')
                    ,index;

                for(index in list)
                    if(isObject(list[index])){

                        list[index].setAttribute('class','switch_item');

                        list[index].onclick=page_object.action.admin.action.config_content.action.gen_config.click.init;

                    }

                switch(gen_mode){

                    case 0:{

                        if(isset($d('config_gen_auto'))){

                            $d('config_gen_auto').setAttribute('class','switch_item_active');

                            $d('config_gen_auto').onclick=function(){};

                        }

                        break;

                    }

                    // case 1:{
                    //
                    //     if(isset($d('config_gen_hand'))){
                    //
                    //         $d('config_gen_hand').setAttribute('class','switch_item_active');
                    //
                    //         $d('config_gen_hand').onclick=function(){};
                    //
                    //     }
                    //
                    //     break;
                    //
                    // }

                    case 2:{

                        if(isset($d('config_gen_off'))){

                            $d('config_gen_off').setAttribute('class','switch_item_active');

                            $d('config_gen_off').onclick=function(){};

                        }

                        break;

                    }

                }

            },
            'set_action':function(){

                let camera_data=page_object.action.admin.data['config']['camera_data'];

                switch(camera_data['gen_mode']){

                    case -1:{

                        page_object.action.admin.action.config_content.action.gen_config.gen_power_block.un_show();
                        page_object.action.admin.action.config_content.action.gen_config.set_button();

                        break;

                    }

                    case 0:{

                        page_object.action.admin.action.config_content.action.gen_config.gen_power_block.show();
                        page_object.action.admin.action.config_content.action.gen_config.set_button();

                        break;

                    }

                    case 1:{

                        page_object.action.admin.action.config_content.action.gen_config.gen_power_block.un_show();
                        page_object.action.admin.action.config_content.action.gen_config.set_button();

                        break;

                    }

                    case 2:{

                        page_object.action.admin.action.config_content.action.gen_config.gen_power_block.un_show();
                        page_object.action.admin.action.config_content.action.gen_config.set_button();

                        break;

                    }

                }

            },
            'gen_power_block':{
                'show':function(){

                    if(isset($d('gen_period_block')))
                        $d('gen_period_block').setAttribute('class','config_row_item_container');

                    if(isset($d('gen_cam_delay_block')))
                        $d('gen_cam_delay_block').setAttribute('class','config_row_item_container');

                    if(isset($d('gen_light_delay_block')))
                        $d('gen_light_delay_block').setAttribute('class','config_row_item_container');

                    if(isset($d('gen_light_time_block')))
                        $d('gen_light_time_block').setAttribute('class','config_row_item_container');

                },
                'un_show':function(){

                    if(isset($d('gen_period_block')))
                        $d('gen_period_block').setAttribute('class','config_row_item_container_disable');

                    if(isset($d('gen_cam_delay_block')))
                        $d('gen_cam_delay_block').setAttribute('class','config_row_item_container_disable');

                    if(isset($d('gen_light_delay_block')))
                        $d('gen_light_delay_block').setAttribute('class','config_row_item_container_disable');

                    if(isset($d('gen_light_time_block')))
                        $d('gen_light_time_block').setAttribute('class','config_row_item_container_disable');

                }
            },
            'show':function(){

                if(isset($d('config_gen_block')))
                    $d('config_gen_block').setAttribute('class','config_row_item')

            },
            'un_show':function(){

                if(isset($d('config_gen_block')))
                    $d('config_gen_block').setAttribute('class','config_row_item_disable');

                if(page_object.action.admin.data['config']['camera_data']['camera_work_mode'] === 0)
                    page_object.action.admin.action.config_content.action.gen_config.gen_power_block.show();

            }
        },
        'glass_heater_config':{
            'init':function(){

                page_object.action.admin.action.config_content.action.glass_heater_config.set_action();

            },
            'click':{
                'init':function(){

                    let key=this.id.split('_')[3];

                    trace(this.id);
                    trace(key);

                    switch(key){

                        case 'auto':{

                            page_object.action.admin.action.config_content.action.buttons.set_edit();

                            page_object.action.admin.data['config']['camera_data']['glass_heater_mode'] = 0;

                            page_object.action.admin.action.config_content.action.glass_heater_config.set_action();

                            break;

                        }

                        case 'hand':{

                            page_object.action.admin.action.config_content.action.buttons.set_edit();

                            page_object.action.admin.data['config']['camera_data']['glass_heater_mode'] = 1;

                            page_object.action.admin.action.config_content.action.glass_heater_config.set_action();

                            break;

                        }

                        case 'off':{

                            page_object.action.admin.action.config_content.action.buttons.set_edit();

                            page_object.action.admin.data['config']['camera_data']['glass_heater_mode'] = 2;

                            page_object.action.admin.action.config_content.action.glass_heater_config.set_action();

                            break;

                        }

                    }

                }
            },
            'set_button':function(){

                let  glass_heater_mode =page_object.action.admin.data['config']['camera_data']['glass_heater_mode']
                    ,list = $d('config_glass_heater').getElementsByTagName('div')
                    ,index;

                for(index in list)
                    if(isObject(list[index])){

                        list[index].setAttribute('class','switch_item');

                        list[index].onclick=page_object.action.admin.action.config_content.action.glass_heater_config.click.init;

                    }

                switch(glass_heater_mode){

                    case 0:{

                        if(isset($d('config_glass_heater_auto'))){

                            $d('config_glass_heater_auto').setAttribute('class','switch_item_active');

                            $d('config_glass_heater_auto').onclick=function(){};

                        }

                        break;

                    }

                    case 1:{

                        if(isset($d('config_glass_heater_hand'))){

                            $d('config_glass_heater_hand').setAttribute('class','switch_item_active');

                            $d('config_glass_heater_hand').onclick=function(){};

                        }

                        break;

                    }

                    case 2:{

                        if(isset($d('config_glass_heater_off'))){

                            $d('config_glass_heater_off').setAttribute('class','switch_item_active');

                            $d('config_glass_heater_off').onclick=function(){};

                        }

                        break;

                    }

                }

            },
            'set_action':function(){

                let camera_data=page_object.action.admin.data['config']['camera_data'];

                switch(camera_data['glass_heater_mode']){

                    case -1:{

                        page_object.action.admin.action.config_content.action.glass_heater_config.glass_heater_power_block.un_show();
                        page_object.action.admin.action.config_content.action.glass_heater_config.set_button();

                        break;

                    }

                    case 0:{

                        page_object.action.admin.action.config_content.action.glass_heater_config.glass_heater_power_block.show();
                        page_object.action.admin.action.config_content.action.glass_heater_config.set_button();

                        break;

                    }

                    case 1:{

                        page_object.action.admin.action.config_content.action.glass_heater_config.glass_heater_power_block.un_show();
                        page_object.action.admin.action.config_content.action.glass_heater_config.set_button();

                        break;

                    }

                    case 2:{

                        page_object.action.admin.action.config_content.action.glass_heater_config.glass_heater_power_block.un_show();
                        page_object.action.admin.action.config_content.action.glass_heater_config.set_button();

                        break;

                    }

                }

            },
            'glass_heater_power_block':{
                'show':function(){

                    // if(isset($d('glass_heater_period_block')))
                    //     $d('glass_heater_period_block').setAttribute('class','config_row_item_container');
                    //
                    // if(isset($d('glass_heater_cam_delay_block')))
                    //     $d('glass_heater_cam_delay_block').setAttribute('class','config_row_item_container');
                    //
                    // if(isset($d('glass_heater_light_delay_block')))
                    //     $d('glass_heater_light_delay_block').setAttribute('class','config_row_item_container');
                    //
                    // if(isset($d('glass_heater_light_time_block')))
                    //     $d('glass_heater_light_time_block').setAttribute('class','config_row_item_container');

                },
                'un_show':function(){

                    // if(isset($d('glass_heater_period_block')))
                    //     $d('glass_heater_period_block').setAttribute('class','config_row_item_container_disable');
                    //
                    // if(isset($d('glass_heater_cam_delay_block')))
                    //     $d('glass_heater_cam_delay_block').setAttribute('class','config_row_item_container_disable');
                    //
                    // if(isset($d('glass_heater_light_delay_block')))
                    //     $d('glass_heater_light_delay_block').setAttribute('class','config_row_item_container_disable');
                    //
                    // if(isset($d('glass_heater_light_time_block')))
                    //     $d('glass_heater_light_time_block').setAttribute('class','config_row_item_container_disable');

                }
            },
            'show':function(){

                if(isset($d('config_glass_heater_block')))
                    $d('config_glass_heater_block').setAttribute('class','config_row_item');

            },
            'un_show':function(){

                if(isset($d('config_glass_heater_block')))
                    $d('config_glass_heater_block').setAttribute('class','config_row_item_disable');

                if(page_object.action.admin.data['config']['camera_data']['camera_work_mode'] === 0)
                    page_object.action.admin.action.config_content.action.glass_heater_config.glass_heater_power_block.show();

            }
        },
        'brush_config':{
            'init':function(){

                page_object.action.admin.action.config_content.action.brush_config.set_action();

            },
            'click':{
                'init':function(){

                    let key=this.id.split('_')[2];

                    switch(key){

                        case 'auto':{

                            page_object.action.admin.action.config_content.action.buttons.set_edit();

                            page_object.action.admin.data['config']['camera_data']['brush_mode'] = 0;

                            page_object.action.admin.action.config_content.action.brush_config.set_action();

                            break;

                        }

                        case 'on':{

                            page_object.action.admin.action.config_content.action.buttons.set_edit();

                            page_object.action.admin.data['config']['camera_data']['brush_mode'] = 1;

                            page_object.action.admin.action.config_content.action.brush_config.set_action();

                            break;

                        }

                        case 'off':{

                            page_object.action.admin.action.config_content.action.buttons.set_edit();

                            page_object.action.admin.data['config']['camera_data']['brush_mode'] = 2;

                            page_object.action.admin.action.config_content.action.brush_config.set_action();

                            break;

                        }

                    }

                }
            },
            'set_button':function(){

                let  brush_mode =page_object.action.admin.data['config']['camera_data']['brush_mode']
                    ,list = $d('config_brush').getElementsByTagName('div')
                    ,index;

                for(index in list)
                    if(isObject(list[index])){

                        list[index].setAttribute('class','switch_item');

                        list[index].onclick=page_object.action.admin.action.config_content.action.brush_config.click.init;

                    }

                switch(brush_mode){

                    case 0:{

                        if(isset($d('config_brush_auto'))){

                            $d('config_brush_auto').setAttribute('class','switch_item_active');

                            $d('config_brush_auto').onclick=function(){};

                        }

                        break;

                    }

                    case 1:{

                        if(isset($d('config_brush_on'))){

                            $d('config_brush_on').setAttribute('class','switch_item_active');

                            $d('config_brush_on').onclick=function(){};

                        }

                        break;

                    }

                    case 2:{

                        if(isset($d('config_brush_off'))){

                            $d('config_brush_off').setAttribute('class','switch_item_active');

                            $d('config_brush_off').onclick=function(){};

                        }

                        break;

                    }

                }

            },
            'set_action':function(){

                let camera_data=page_object.action.admin.data['config']['camera_data'];

                switch(camera_data['brush_mode']){

                    case 0:{

                        page_object.action.admin.action.config_content.action.brush_config.set_button();

                        break;

                    }

                    case 1:{

                        page_object.action.admin.action.config_content.action.brush_config.set_button();

                        break;

                    }

                    case 2:{

                        page_object.action.admin.action.config_content.action.brush_config.set_button();

                        break;

                    }

                }

            },
            'show':function(){

                if(isset($d('config_brush_block')))
                    $d('config_brush_block').setAttribute('class','config_row_item')

            },
            'un_show':function(){

                if(isset($d('config_brush_block')))
                    $d('config_brush_block').setAttribute('class','config_row_item_disable');

            }
        },
        'timer_config':{
            'init':function(){

            },
            'show':function(){

                if(isset($d('config_timer_block')))
                    $d('config_timer_block').setAttribute('class','config_row_col')

            },
            'un_show':function(){

                if(isset($d('config_timer_block')))
                    $d('config_timer_block').setAttribute('class','config_row_col_disable')

            }
        },
        'check_video_container':{
            'init':function(){

                setTimeout(page_object.action.admin.action.config_content.action.check_video_container.check,1000);

            },
            'check':function(){

                if(isset($d('config_video_container'))){

                    if(isset($d('config_work_mask'))){

                        let v_h=elementSize.height($d('config_video_container'));

                        if(v_h<50){

                            if(page_object.action.admin.data['config']['camera_data']['camera_work_mode']!==2){

                                page_object.action.admin.data['config']['camera_data']['camera_work_mode'] = 0;

                                page_object.action.admin.action.config_content.action.camera_work_mode.camera_off.un_show();

                            }

                        }

                    }

                }

            }
        }
    },
    'remove':function(){

        if(isset($d('config_content'))) removeElement($d('config_content'));

    },
    'resize':function(){

        if(isset($d('config_content'))){

        }

    }
};