cl = console.log;

page_object.action.admin.section_change_workflow = {
    'admin':{
        'init':function(){

            page_object.action.admin.create.header.init();
            if(isset($d('header_profile_menu_block'))) page_object.action.admin.action.header_profile_menu_block.un_show(true);
            if(isset($d('config_content'))) page_object.action.admin.action.config_content.un_show(true);
            if(isset($d('zones_content'))) page_object.action.admin.action.zones_content.un_show(true);
            if(isset($d('key_content'))) page_object.action.admin.action.key_content.un_show(true);
            if(isset($d('apikey_content'))) page_object.action.admin.action.apikey_content.un_show(true);
            if(isset($d('tcp_content'))) page_object.action.admin.action.tcp_content.un_show(true);
            if(isset($d('sms_content'))) page_object.action.admin.action.sms_content.un_show(true);
            if(isset($d('users_content'))) page_object.action.admin.action.users.un_show(true);
            if(isset($d('settings'))) page_object.action.admin.action.settings.un_show(true);
        }
    },
    'admin_config':{
        'init':function(){
            page_object.action.admin.create.header.init();
            if(isset($d('header_profile_menu_block'))) page_object.action.admin.action.header_profile_menu_block.un_show(true);
            if(isset($d('config_content'))) page_object.action.admin.action.config_content.un_show(true);
            if(isset($d('zones_content'))) page_object.action.admin.action.zones_content.un_show(true);
            if(isset($d('key_content'))) page_object.action.admin.action.key_content.un_show(true);
            if(isset($d('apikey_content'))) page_object.action.admin.action.apikey_content.un_show(true);
            if(isset($d('tcp_content'))) page_object.action.admin.action.tcp_content.un_show(true);
            if(isset($d('sms_content'))) page_object.action.admin.action.sms_content.un_show(true);
            if(isset($d('users_content'))) page_object.action.admin.action.users.un_show(true);
            if(isset($d('settings'))) page_object.action.admin.action.settings.un_show(true);
            setTimeout(page_object.action.admin.create.admin_menu.init, 300);
            setTimeout(page_object.action.admin.create.config.init, 300);

        }
    },
    'admin_tcp':{
        'init':function(){
            page_object.action.admin.create.header.init();
            if(isset($d('header_profile_menu_block'))) page_object.action.admin.action.header_profile_menu_block.un_show(true);
            if(isset($d('config_content'))) page_object.action.admin.action.config_content.un_show(true);
            if(isset($d('zones_content'))) page_object.action.admin.action.zones_content.un_show(true);
            if(isset($d('key_content'))) page_object.action.admin.action.key_content.un_show(true);
            if(isset($d('apikey_content'))) page_object.action.admin.action.apikey_content.un_show(true);
            if(isset($d('tcp_content'))) page_object.action.admin.action.tcp_content.un_show(true);
            if(isset($d('sms_content'))) page_object.action.admin.action.sms_content.un_show(true);
            if(isset($d('users_content'))) page_object.action.admin.action.users.un_show(true);
            if(isset($d('settings'))) page_object.action.admin.action.settings.un_show(true);
            setTimeout(page_object.action.admin.create.admin_menu.init, 300);
            setTimeout(page_object.action.admin.create.tcp.init, 300);

        }
    },
    'admin_tcp_item':{
        'init':function(){
            page_object.action.admin.create.header.init();
            if(isset($d('header_profile_menu_block'))) page_object.action.admin.action.header_profile_menu_block.un_show(true);
            if(isset($d('config_content'))) page_object.action.admin.action.config_content.un_show(true);
            if(isset($d('zones_content'))) page_object.action.admin.action.zones_content.un_show(true);
            if(isset($d('key_content'))) page_object.action.admin.action.key_content.un_show(true);
            if(isset($d('apikey_content'))) page_object.action.admin.action.apikey_content.un_show(true);
            if(isset($d('tcp_content'))) page_object.action.admin.action.tcp_content.un_show(true);
            if(isset($d('sms_content'))) page_object.action.admin.action.sms_content.un_show(true);
            if(isset($d('users_content'))) page_object.action.admin.action.users.un_show(true);
            if(isset($d('settings'))) page_object.action.admin.action.settings.un_show(true);
            setTimeout(page_object.action.admin.create.admin_menu.init, 300);
            setTimeout(page_object.action.admin.create.tcp.init, 300);

        }
    },
    'admin_zones':{
        'init':function(){
            page_object.action.admin.create.header.init();
            if(isset($d('header_profile_menu_block'))) page_object.action.admin.action.header_profile_menu_block.un_show(true);

            if(isset($d('config_content'))) page_object.action.admin.action.config_content.un_show(true);
            if(isset($d('zones_content'))) page_object.action.admin.action.zones_content.un_show(true);
            if(isset($d('key_content'))) page_object.action.admin.action.key_content.un_show(true);
            if(isset($d('apikey_content'))) page_object.action.admin.action.apikey_content.un_show(true);
            if(isset($d('tcp_content'))) page_object.action.admin.action.tcp_content.un_show(true);
            if(isset($d('sms_content'))) page_object.action.admin.action.sms_content.un_show(true);
            if(isset($d('users_content'))) page_object.action.admin.action.users.un_show(true);
            if(isset($d('settings'))) page_object.action.admin.action.settings.un_show(true);
            setTimeout(page_object.action.admin.create.admin_menu.init,300);
            setTimeout(page_object.action.admin.create.zones.init,300);

        }
    },
    'admin_zones_item':{
        'init':function(){
            page_object.action.admin.create.header.init();
            if(isset($d('header_profile_menu_block'))) page_object.action.admin.action.header_profile_menu_block.un_show(true);

            if(isset($d('config_content'))) page_object.action.admin.action.config_content.un_show(true);
            if(isset($d('zones_content'))) page_object.action.admin.action.zones_content.un_show(true);
            if(isset($d('key_content'))) page_object.action.admin.action.key_content.un_show(true);
            if(isset($d('apikey_content'))) page_object.action.admin.action.apikey_content.un_show(true);
            if(isset($d('tcp_content'))) page_object.action.admin.action.tcp_content.un_show(true);
            if(isset($d('sms_content'))) page_object.action.admin.action.sms_content.un_show(true);
            if(isset($d('users_content'))) page_object.action.admin.action.users.un_show(true);
            if(isset($d('settings'))) page_object.action.admin.action.settings.un_show(true);
            setTimeout(page_object.action.admin.create.admin_menu.init, 300);
            setTimeout(page_object.action.admin.create.zones.init, 300);
        }
    },
    'admin_key':{
        'init':function(){
            page_object.action.admin.create.header.init();
            if(isset($d('header_profile_menu_block'))) page_object.action.admin.action.header_profile_menu_block.un_show(true);

            if(isset($d('config_content'))) page_object.action.admin.action.config_content.un_show(true);
            if(isset($d('zones_content'))) page_object.action.admin.action.zones_content.un_show(true);
            if(isset($d('key_content'))) page_object.action.admin.action.key_content.un_show(true);
            if(isset($d('apikey_content'))) page_object.action.admin.action.apikey_content.un_show(true);
            if(isset($d('tcp_content'))) page_object.action.admin.action.tcp_content.un_show(true);
            if(isset($d('sms_content'))) page_object.action.admin.action.sms_content.un_show(true);
            if(isset($d('users_content'))) page_object.action.admin.action.users.un_show(true);
            if(isset($d('settings'))) page_object.action.admin.action.settings.un_show(true);
            setTimeout(page_object.action.admin.create.admin_menu.init, 300);
            setTimeout(page_object.action.admin.create.key.init, 300);
        }
    },
    'admin_apikey':{
        'init':function(){
            page_object.action.admin.create.header.init();
            if(isset($d('header_profile_menu_block'))) page_object.action.admin.action.header_profile_menu_block.un_show(true);

            if(isset($d('config_content'))) page_object.action.admin.action.config_content.un_show(true);
            if(isset($d('zones_content'))) page_object.action.admin.action.zones_content.un_show(true);
            if(isset($d('key_content'))) page_object.action.admin.action.key_content.un_show(true);
            if(isset($d('apikey_content'))) page_object.action.admin.action.apikey_content.un_show(true);
            if(isset($d('tcp_content'))) page_object.action.admin.action.tcp_content.un_show(true);
            if(isset($d('sms_content'))) page_object.action.admin.action.sms_content.un_show(true);
            if(isset($d('users_content'))) page_object.action.admin.action.users.un_show(true);
            if(isset($d('settings'))) page_object.action.admin.action.settings.un_show(true);
            setTimeout(page_object.action.admin.create.admin_menu.init, 300);
            setTimeout(page_object.action.admin.create.apikey.init, 300);
        }
    },
    'admin_sms':{
        'init':function(){
            page_object.action.admin.create.header.init();
            if(isset($d('header_profile_menu_block'))) page_object.action.admin.action.header_profile_menu_block.un_show(true);

            if(isset($d('config_content'))) page_object.action.admin.action.config_content.un_show(true);
            if(isset($d('zones_content'))) page_object.action.admin.action.zones_content.un_show(true);
            if(isset($d('key_content'))) page_object.action.admin.action.key_content.un_show(true);
            if(isset($d('apikey_content'))) page_object.action.admin.action.apikey_content.un_show(true);
            if(isset($d('tcp_content'))) page_object.action.admin.action.tcp_content.un_show(true);
            if(isset($d('sms_content'))) page_object.action.admin.action.sms_content.un_show(true);
            if(isset($d('users_content'))) page_object.action.admin.action.users.un_show(true);
            if(isset($d('settings'))) page_object.action.admin.action.settings.un_show(true);
            setTimeout(page_object.action.admin.create.admin_menu.init, 300);
            setTimeout(page_object.action.admin.create.sms.init, 300);

        }
    },
    'admin_config_item':{
        'init':function(){
            page_object.action.admin.create.header.init();
            if(isset($d('header_profile_menu_block'))) page_object.action.admin.action.header_profile_menu_block.un_show(true);

            if(isset($d('config_content'))) page_object.action.admin.action.config_content.un_show(true);
            if(isset($d('zones_content'))) page_object.action.admin.action.zones_content.un_show(true);
            if(isset($d('key_content'))) page_object.action.admin.action.key_content.un_show(true);
            if(isset($d('apikey_content'))) page_object.action.admin.action.apikey_content.un_show(true);
            if(isset($d('tcp_content'))) page_object.action.admin.action.tcp_content.un_show(true);
            if(isset($d('sms_content'))) page_object.action.admin.action.sms_content.un_show(true);
            if(isset($d('users_content'))) page_object.action.admin.action.users.un_show(true);
            if(isset($d('settings'))) page_object.action.admin.action.settings.un_show(true);
            setTimeout(page_object.action.admin.create.admin_menu.init, 300);
            setTimeout(page_object.action.admin.create.config.init, 300);

        }
    },
    'admin_radar':{
        'init':function(){
            page_object.action.admin.create.header.init();
            if(isset($d('header_profile_menu_block'))) page_object.action.admin.action.header_profile_menu_block.un_show(true);

            if(isset($d('config_content'))) page_object.action.admin.action.config_content.un_show(true);
            if(isset($d('zones_content'))) page_object.action.admin.action.zones_content.un_show(true);
            if(isset($d('key_content'))) page_object.action.admin.action.key_content.un_show(true);
            if(isset($d('apikey_content'))) page_object.action.admin.action.apikey_content.un_show(true);
            if(isset($d('tcp_content'))) page_object.action.admin.action.tcp_content.un_show(true);
            if(isset($d('sms_content'))) page_object.action.admin.action.sms_content.un_show(true);
            if(isset($d('users_content'))) page_object.action.admin.action.users.un_show(true);
            if(isset($d('settings'))) page_object.action.admin.action.settings.un_show(true);

            if(isset($d('admin_menu'))) page_object.action.admin.action.admin_menu.un_show(true);
            setTimeout(page_object.action.admin.create.radar.init, 300);

        }
    },
    'admin_users':{
        'init':function(){
            page_object.action.admin.create.header.init();
            if(isset($d('header_profile_menu_block'))) page_object.action.admin.action.header_profile_menu_block.un_show(true);

            if(isset($d('config_content'))) page_object.action.admin.action.config_content.un_show(true);
            if(isset($d('zones_content'))) page_object.action.admin.action.zones_content.un_show(true);
            if(isset($d('key_content'))) page_object.action.admin.action.key_content.un_show(true);
            if(isset($d('apikey_content'))) page_object.action.admin.action.apikey_content.un_show(true);
            if(isset($d('tcp_content'))) page_object.action.admin.action.tcp_content.un_show(true);
            if(isset($d('sms_content'))) page_object.action.admin.action.sms_content.un_show(true);
            if(isset($d('users_content'))) page_object.action.admin.action.users.un_show(true);
            if(isset($d('settings'))) page_object.action.admin.action.settings.un_show(true);

            if(isset($d('admin_menu'))) page_object.action.admin.action.admin_menu.un_show(true);

            page_object.action.admin.create.users.init();

        }
    },
    'admin_settings':{
        'init':function(){

            page_object.action.admin.create.header.init();
            if(isset($d('header_profile_menu_block'))) page_object.action.admin.action.header_profile_menu_block.un_show(true);

            if(isset($d('config_content'))) page_object.action.admin.action.config_content.un_show(true);
            if(isset($d('zones_content'))) page_object.action.admin.action.zones_content.un_show(true);
            if(isset($d('key_content'))) page_object.action.admin.action.key_content.un_show(true);
            if(isset($d('apikey_content'))) page_object.action.admin.action.apikey_content.un_show(true);
            if(isset($d('tcp_content'))) page_object.action.admin.action.tcp_content.un_show(true);
            if(isset($d('sms_content'))) page_object.action.admin.action.sms_content.un_show(true);
            if(isset($d('users_content'))) page_object.action.admin.action.users.un_show(true);
            if(isset($d('settings'))) page_object.action.admin.action.settings.un_show(true);

            if(isset($d('admin_menu'))) page_object.action.admin.action.admin_menu.un_show(true);

            page_object.action.admin.create.settings.init();

        }
    },
    'admin_logout':{
        'init':function(){

            page_object.action.admin.action.header.un_show(true);
            page_object.action.admin.action.admin_menu.un_show(true);
            page_object.action.admin.action.key_content.un_show(true);
            page_object.action.admin.action.apikey_content.un_show(true);
            page_object.action.admin.action.config_content.un_show(true);
            page_object.action.admin.action.tcp_content.un_show(true);
            page_object.action.admin.action.zones_content.un_show(true);
            page_object.action.admin.action.users.un_show(true);
            page_object.action.admin.action.settings.un_show(true);
            page_object.action.admin.action.radar_content.un_show(true);
            page_object.action.admin.action.header_profile_menu_block.un_show(true);

            page_object.action.admin.data={};

            setTimeout(page_object.action.admin.section_change_workflow.admin_logout.redirect, 300);
        },
        'redirect':function(){

            let  lang_obj =page_object.content[page_object.lang]
                , link ='/';

            setUrl(lang_obj['title']+' | '+lang_obj['loading'], link);
            if(OS.isMobile) document.location.reload();
        }
    }
};
