
var is_work =false;
var timer_func =function(index,drop_list){

    if(typeof drop_list[index]!='undefined'){

        if(is_work){

            var el=document.getElementsByClassName('box_layout');

            if(typeof el[0]!='undefined'){

                console.log('isset_msgbox');

                var el_button=document.getElementsByClassName('flat_button');

                if(typeof el_button[0]!='undefined'){

                    console.log('isset_msgbox_button');

                    el_button[0].click();

                    console.log('click_msgbox_button');

                    setTimeout(function(){

                        is_work=false;

                        console.log('next_item: '+(index+1));

                        timer_func((index+1),drop_list);

                    },3000);

                }
                else{

                    //is_work=false;

                    setTimeout(function(){

                        console.log('reset_item: '+index);

                        timer_func(index,drop_list);

                    },1000);

                }

            }
            else{

                //is_work=false;

                setTimeout(function(){

                    console.log('reset_item: '+index);

                    timer_func(index,drop_list);

                },1000);

            }

        }
        else{

            is_work=true;

            console.log('click_button_drop: '+index);

            drop_list[index].click();

            setTimeout(function(){

                console.log('reset_item: '+index);

                timer_func(index,drop_list);

            },3000);

        }

    }

};
var func_drop=function(){

    var  list=document.getElementsByClassName('wk_likes_likers_rows')
        ,i
        ,drop_list = [];

    for(i=0;i<list.length;i++)
        if(typeof list[i] === 'object'){

            var list_a=list[i].getElementsByTagName('a')
                ,i1;

            for(i1=0;i1<list_a.length;i1++)
                if(typeof list_a[i1] === 'object'){

                    var href=list_a[i1].getAttribute('href')+'';

                    if(typeof href!='undefined'&&href!=null){

                        //console.log(href.substr(1));

                        var id=href.substr(1);
                        //console.log(id);
                        //

                        var img=list_a[i1].getElementsByTagName('img');

                        if(typeof img[0]!='undefined')
                            if(img[0].getAttribute('src')=='/images/deactivated_100.png' || img[0].getAttribute('src')=='/images/camera_100.png'){

                                var drop=list_a[i1].getElementsByClassName('wk_likes_bl_wrap');

                                if(typeof drop[0]!='undefined'){

                                    drop_list.push(drop[0]);
                                    //drop[0].click();

                                }

                            }

                    }

                }

        }

    console.log(drop_list);
    console.log(drop_list.length);

    timer_func(0,drop_list);

};

