$(function(){ //'use strict';

var isset = function(e){ return typeof e == 'undefined' ? false : true;},
    cl = console.log,
    req = null,
endvar;

$('body').on('click', '#authn_keep_button', function(){ //cl($('#authn_keep'));
    if($('#authn_keep').hasClass('authn_keep_active')){
        $('#authn_keep').attr('class', 'authn_keep');
    } else {
        $('#authn_keep').attr('class', 'authn_keep_active');
    }
});

$('body').on('click', '.auth_btn', function(){ // authn_block      //cl(classes);        //if(migrated) return;
    var $this = $(this); $this.blur();
    if(req) return; else req = true;
    var vals = $this.parent().parent().find('input, select, textarea').serializeArray();//cl(vals);
    var data = { data: vals, action: 'login' };

    $('.auth_btn').html('<i class=\'fa fa-circle-o-notch fa-spin\'></i>');
    var suc = function(resp){
        $('.auth_btn').html('Войти');
        req = false;
        if(isset(resp) && resp.error === false){ // cl(resp);
            var lhref = location.href+'';
            if(/authn/.test(lhref)) location.href = '/'; else location.reload(); // cl(lhref);//            location.href = '/';
            return;
        }
        er(resp.error);
    };
    var err = function(xhr, ajaxOptions, thrownError){ req = false; $('.auth_btn').html('Войти'); er('Неизвестная ошибка получения данных #1');}
    $.ajax({ url: '/authn', type: 'post', dataType: 'json', data: data, success: suc, error: err }); //  url: '/http://aist.loc/authn',
});

});