var test = {
    "perspective": {
        "line_list": [
            {
                'type':'line',
                "point_list": [
                    {
                        "x": 205,
                        "y": 57,
                        "line_width": 1
                    },
                    {
                        "x": 147,
                        "y": 407,
                        "line_width": 1
                    },
                    {"x": 411, "y": 405, "line_width": 1}, {"x": 391, "y": 228, "line_width": 1}, {
                        "x": 205,
                        "y": 57,
                        "line_width": 1
                    }
                ]
            },
            {
                "point_list": [
                    {
                        "x": 89,
                        "y": 110,
                        "line_width": 1
                    },
                    {
                        "x": 278,
                        "y": 374,
                        "line_width": 1
                    },
                    {
                        "x": 411,
                        "y": 227,
                        "line_width": 1
                    },
                    {"x": 302, "y": 92, "line_width": 1}, {"x": 89, "y": 110, "line_width": 1}]
            }]
    },
    "calibration_line": {
        "line_list": [{
            "point_list": [{"x": 67, "y": 431}, {"x": 495, "y": 426}, {
                "x": 67,
                "y": 431
            }]
        }, {"point_list": [{"x": 78, "y": 330}, {"x": 505, "y": 328}, {"x": 78, "y": 330}]}, {
            "point_list": [{
                "x": 87,
                "y": 244
            }, {"x": 505, "y": 243}, {"x": 87, "y": 244}]
        }]
    }
}