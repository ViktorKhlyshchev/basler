//function(e){ return typeof e == 'undefined' ? false : true;},
function isset (e){ return typeof e == 'undefined' || e === null /*typeof e == 'undefined'*/ ? false : true;}
cl = console.log;

function urldecode(str){
    return decodeURIComponent((str + '').replace(/\+/g, '%20'));
}

function showNotify(type, title, message, delay){ cl(arguments);
    if(typeof delay === 'undefined') delay = 1000;
    if(!message) message = '';
    if(!title) title = '';
    //var class_name = type === 'ok' ? 'notify_suc' : 'notify_fail';

    switch (type){
        case 'ok':
            var class_name = 'notify_suc';
            var icon_class_name = 'glyphicon glyphicon-ok-circle';
            var color = '#82d184';
        break;
        case 'er':
            var class_name = 'notify_fail';
            var icon_class_name = 'glyphicon glyphicon-remove-circle';
            var color = '#f09695';
        break;
        case 'i':
            var class_name = 'notify_info';
            var icon_class_name = 'glyphicon glyphicon-info-sign';
            var color = '#31708f';
        break;
        default:
            var class_name = 'notify_info';
            var icon_class_name = 'glyphicon glyphicon-info-sign';
            var color = '#31708f';
        break;
    }

    var template = ''+
        '<div data-notify=container class="col-xs-3 col-sm-3 col-md-2 alert alert-{0} '+ class_name +'" role="alert">' +
            '<div class=row>'+
                '<div class=col-xs-2><span style="color:'+ color +';font-size: 3rem;" class="'+ icon_class_name +'"></span></div>' +
                '<div class=col-xs-10>' +
                '<div class="notify-title">{1}</div>' +
                '<div class=notify-message>{2}</div></div>' +
        '</div>';
    //var placement = { from: 'bottom', align:'left' };
    var placement = { from: 'top', align:'center' };

    var not = $.notify(
        { title: title, message: message },{
            placement: placement, type: 'minimalist', delay: delay, icon_type: 'image', template: template,
            offset: { y: 300 },
            animate: {
                enter: 'animated fadeInDown',
                exit: 'animated fadeOutUp'
            },
        }
    );
    $('div.'+ class_name).css('z-index', 9999).on('click', function(){
        not.close();
    });
}

function er(mes, del = 2000){ showNotify('er', null, mes, del); }
function ok(mes, del = 2000){ showNotify('ok', null, mes, del); }

function set_cookied(cname, cvalue, exdays){
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function get_cookie(cname){
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++){
        var c = ca[i];
        while (c.charAt(0) == ' '){
            c = c.substring(1);
        }
        if(c.indexOf(name) == 0){
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function unique_id(){
    return (Date.now().toString(36) + Math.random().toString(36).substr(2, 5)).toLowerCase();
}