var parse_DOM={
    'init':function(){

        //var brand_list=document.getElementById('menu');
        var brand_list=document.getElementsByClassName('content-block');

        var name_list = [];

        for(var i=0;i<brand_list.length;i++){

            var a_list=brand_list[i].getElementsByTagName('a');

            for(var i1=0;i1<a_list.length;i1++){

//                name_list.push(a_list[i1].title);
                name_list.push(a_list[i1].childNodes[0].nodeValue);

            }

        }

        console.log(name_list);

        var values='';

        for(var i=0;i<name_list.length;i++)
            if(typeof (name_list[i])=='string'){

            //values+=name_list[i]+",";
            //values+=name_list[i]+",";
            values+=name_list[i]+",\n";

        }

        console.log(values);

    }
};

parse_DOM.init();