$(function(){
    winSize.checkBrowserSize.options(resize_object.init);
    page_object.link.init();
});