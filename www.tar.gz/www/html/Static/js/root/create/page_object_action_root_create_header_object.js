page_object.action.root.create.header={
    'init':function(){

        if((
                   isset($d('header'))
                &&!isset($d('header_profile'))
                &&!isset($d('header_login'))
                &&!OS.isMobile
            ) || (
                   isset($d('header'))
                &&!isset($d('header_profile'))
                &&!isset($d('header_login'))
                &&!isset($d('menu_close'))
                &&OS.isMobile
            )
        ){

            page_object.action.root.action.header.un_show(true);

            setTimeout(page_object.action.root.create.header.create.init,300);

        }
        else
            setTimeout(page_object.action.root.create.header.create.init,40);

    },
    'position':{
        'header_menu':function(){

            page_object.action.root.position.header_menu.w=Math.ceil(winSize.winWidth*.63);

        },
        'header':function(){

            page_object.action.root.position.header.w =winSize.winWidth;
            page_object.action.root.position.header.x =0;
            page_object.action.root.position.header.y =-page_object.action.root.position.header.h;

        },
        'header_profile':function(){

            if(isset($d('header_profile'))){

                page_object.action.root.position.header_profile.o =0;
                page_object.action.root.position.header_profile.w =elementSize.width($d('header_profile'));
                page_object.action.root.position.header_profile.x =winSize.winWidth-page_object.action.root.position.header_profile.m.r-page_object.action.root.position.header_profile.w;

                $s('header_profile').opacity =page_object.action.root.position.header_profile.o;
                $s('header_profile').height =page_object.action.root.position.header_profile.h+'px';

            }

        }
    },
    'create':{
        'init':function(){

            if(isset($d('header'))){

                page_object.action.root.create.header.show();
                page_object.action.root.create.header.set_action();

                return true;

            }

            page_object.action.root.create.header.position.header();
            page_object.action.root.create.header.position.header_menu();
            page_object.action.root.create.header.create.header();
            page_object.action.root.create.header.create.footer();
            page_object.action.root.create.header.set_action();
            page_object.action.root.create.header.show();

            return true;

        },
        'header':function(){

            if(isset($d('header')))
                return false;

            let  el
                ,inner='';

            inner+='<div id="logo"></div>';
            inner+='<div id="header_login" class="header_login">Войти</div>';

            el=addElement({
                'tag':'div',
                'id':'header',
                'inner':inner
            });

            $d('all').appendChild(el);

        },
        'footer':function(){

            let  el;

            el=addElement({
                'tag':'div',
                'id':'footer',
                'inner':'© 2019 АИСТ-КОНТРОЛЬ',
                'style':'opacity: 0'
            });

            $d('all').appendChild(el);

        }
    },
    'set_action':function(){

        if(isset($d('logo'))) $d('logo').onclick=page_object.action.root.action.header.logo.click;

        if(isset($d('header_login'))) $d('header_login').onclick=page_object.action.root.action.header.auth.click;

        if(isset($d('menu_close'))) $d('menu_close').onclick=page_object.action.root.action.header.menu.un_show;

    },
    'show':function(){

        setTimeout(page_object.action.root.action.header.show,40);

    }
};
