page_object.action.root.create.root_content={
    'init':function(){

        page_object.action.root.create.root_content.position.init();
        page_object.action.root.create.root_content.create.init();
        page_object.action.root.create.root_content.set_action();
        page_object.action.root.create.root_content.show();

    },
    'position':{
        'init':function(){}
    },
    'create':{
        'init':function(){

            page_object.action.root.create.root_content.create.root_content.init();

        },
        'root_content':{
            'init':function(){

                let  action=page_object.action.root.data['action'];

                switch(action){

                    case 'auth':
                    case 'reg':
                    case 'confirm_email':
                    case 'root':{

                        page_object.action.root.create.root_content.create.root_content.default();

                        break;

                    }

                }

            },
            'default':function(){}
        },
    },
    'set_action':function(){

        if(isset($d('settings_close_button'))) $d('settings_close_button').onclick=page_object.action.root.action.header.logo.click;

        page_object.action.root.action.root_content.action.init();

    },
    'show':function(){

        setTimeout(page_object.action.root.action.root_content.show,40);

    }
};
