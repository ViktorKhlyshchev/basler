page_object.action.root={
    'data':{},
    'script_list':{
        'core':{
            'localization':'/Static/js/root/localization.js',
            'elements_positions':'/Static/js/root/elements_positions.js',
            'section_change_workflow':'/Static/js/root/section_change_workflow.js'
        },
        'ui_elements_creation':{
            'header':'/Static/js/root/create/page_object_action_root_create_header_object.js',
            'root_content':'/Static/js/root/create/page_object_action_root_create_root_content_object.js',
            'reg':'/Static/js/reg/init.js',
            'auth':'/Static/js/auth/init.js',
        },
        'ui_elements_manipulation':{
            'header':'/Static/js/root/action/page_object_action_root_action_header_object.js',
            'root_content':'/Static/js/root/action/page_object_action_root_action_root_content_object.js',
        },
        'system':{
            'exif':'/Static/js/system/exif.js'
        },
        'recaptcha':{}
    },
    'style_list':[
        '/Static/css/root.css',
        '/Static/css/dialog_block.css'
    ],
    'section_change_workflow':{},
    'page_action':null,
    'back_page_action':null,
    'content':{},
    'position':{},
    'init':function(data){

        if(OS.isMobile) page_object.action.root.style_list.push('/show/css/system/root_mobile.css');

        var temp={
            'script_list':config.updateScriptsList(page_object.action.root.script_list,'Root'),
            'style_list':config.updateScriptsList(page_object.action.root.style_list,'Root'),
            'init_list':[
                function(){

                    if(typeof config !== 'undefined' && $.isFunction(config.updateSectionChangeWorkflow)){
                        page_object.action.root.section_change_workflow = config.updateSectionChangeWorkflow(page_object.action.root.section_change_workflow);
                    }

                    page_object.action.root.run(data);
                }
            ]
        };

        page_object.require.init(temp);

    },
    'run':function(data){

        if(page_object.link.link_list[(page_object.link.link_list.length-1)]!==page_object.link.back_link_list[(page_object.link.back_link_list.length-1)] || page_object.link.link_list[(page_object.link.link_list.length-2)]!==page_object.link.back_link_list[(page_object.link.back_link_list.length-2)] || page_object.link.link_list[(page_object.link.link_list.length-3)]!==page_object.link.back_link_list[(page_object.link.back_link_list.length-3)]
        ){

            page_object.action.root.data =data;
            page_object.action.root.back_page_action =page_object.action.root.page_action;
            page_object.action.root.page_action =data['action'];

            //if(isset($d('dialog_block'))) page_object.dialog.action.un_show.init(dialog_index,true);

            if(isset(page_object.action.root.section_change_workflow[data['action']])){

                page_object.action.root.section_change_workflow[data['action']].init();

                setTimeout(page_object.action.root.action.all.resize,1200);

            }
            else
                trace(' == > TRIG ACTION IS NOT EXISTS');

        }
        else
            trace(' == > ACTION ALREADY ACTIVE');

    },
    'prepend_localization_content':function(data){
        page_object.action.root.content = $.extendext(true, 'concat', data, page_object.action.root.content);
    },
    'append_localization_content':function(data){
        page_object.action.root.content = $.extendext(true, 'concat', page_object.action.root.content, data);
    },
    'prepend_element_positions_settings':function(data){
        page_object.action.root.position = $.extendext(true, 'concat', data, page_object.action.root.position);
    },
    'append_element_positions_settings':function(data){
        page_object.action.root.position = $.extendext(true, 'concat', page_object.action.root.position, data);
    },
    'create':{},
    'action':{
        'all':{
            'resize':function(){}
        }
    }
};