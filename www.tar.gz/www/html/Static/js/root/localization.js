page_object.action.root.content={
    'ru':{
        'wait':'Подождите',
    },
    'en':{}
};