cl = console.log;

$(function(){ //'use strict';

var isset = function(e){ return typeof e == 'undefined' ? false : true;},
    cl = console.log,
    req = null,
    cval = null,
endvar;

$('body').on('click', '.edit_coords_save_btn', function(){
    if(req) return; else req = true;
    var $this = $(this); $this.blur();
    var vals = $('.edit_coords_modal').find('input, select, textarea').serializeArray();//cl(vals);
    var data = { action: 'save_coords_and_set_xavier_work_mode', data: vals }
    var suc = function(resp){
        req = false;
        if(isset(resp) && resp.error === false){
            ok('Значения сохранены');
            $('#header_power_submit').attr('class', 'header_submit_button_disable');
            $('.edit_coords_modal').modal('hide');
            return;
        }
        if(isset(resp) && resp.error !== false){
            if(Array.isArray(resp.error)) resp.error = resp.error.join('<br>');
            er(resp.error, 7000);// er(resp.error); 'Не удалось отправить файл'
            return;
        }
        er('Неизвестная ошибка обновления данных #2');
    };
    var err = function(xhr, ajaxOptions, thrownError){ req = false; er('Неизвестная ошибка обновления данных #1'); }
    $.ajax({ type: 'post', dataType: 'json', url: '/admin/work_mode', data: data, success: suc, error: err });
});

$('body').on('click', '.edit_coords_cancel_btn', function(){ $('.edit_coords_modal').modal('hide'); });

});

page_object.action.admin.action.header = { // Project/Aist/Admin/Template/Js/Admin/Action/page_object_action_admin_action_header_object.js
    'show':function(){
        if(isset($d('header'))){
            page_object.action.admin.position.header.o=1;
            page_object.action.admin.position.header.y=0;
            $s('header').opacity =page_object.action.admin.position.header.o;
            $s('header').transform ='translate('+page_object.action.admin.position.header.x+'px,'+page_object.action.admin.position.header.y+'px)'
            page_object.action.admin.action.header.controls.init();
        }
        if(isset($d('footer'))) $s('footer').opacity=1;
    },
    'un_show':function(remove){
        if(isset($d('header'))){
            page_object.action.admin.position.header.o=0;
            page_object.action.admin.position.header.y=-page_object.action.admin.position.header.h;
            $s('header').opacity =page_object.action.admin.position.header.o;
            $s('header').transform ='translate('+page_object.action.admin.position.header.x+'px,'+page_object.action.admin.position.header.y+'px)'
        }
        if(isset($d('footer'))) $s('footer').opacity=0;
        if(isset(remove))
            if(remove)
                setTimeout(page_object.action.admin.action.header.remove,300);
    },
    'logo':{
        'click':function(){
            let  lang_obj =page_object.content[page_object.lang], link ='/admin/dashboard';
            setUrl(lang_obj['title']+' | '+lang_obj['loading'],link);
        }
    },
    'controls':{
        'init':function(){
            if(isset($d('device_power_select'))) $d('device_power_select').onchange=page_object.action.admin.action.header.controls.change;
        },
        'change':function(){
            if(isset($d('header_power_submit'))){
                $d('header_power_submit').setAttribute('class','header_submit_button');
                $d('header_power_submit').onclick=page_object.action.admin.action.header.controls.click.init
            }
        },
        'click':{
            'init':function(){
                let post = 'work_mode='+uniEncode($v('device_power_select'));
                send({
                    'scriptPath': '/api/json/set_xavier_work_mode',
                    'postData': post,
                    'onComplete':function(j, worktime){
                        var resp, data;
                        resp = jsonDecode(j.responseText); // trace(data); trace_worktime(worktime,data);
                        data = resp;

                        if(!resp.data.coords){ $('.edit_coords_modal').modal(); return; }

                        if(typeof resp.error !== 'undefined' && resp.error !== false){ cl(resp.error);
                            if(Array.isArray(resp.error)) resp.error = resp.error.join('<br>');
                            er(resp.error, 10000);// er(resp.error); 'Не удалось отправить файл'
                            return;
                        }
                        ok('Режим установлен');
                    }
                });
            },
            'off':function(){
                page_object.dialog.init({
                    'title':'Функционал не доступен',
                    'inner':'<div class="dialog_row">Попробуйте позже</div>',
                    'cancel': true
                });
            }
        }
    },
    'remove':function(){
        if(isset($d('header'))) removeElement($d('header'));
        if(isset($d('footer'))) removeElement($d('footer'));
    },
    'resize':function(){ }
};