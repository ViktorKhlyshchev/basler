$(function(){ //'use strict'; //connection_refresh

var isset = function(e){ return typeof e == 'undefined' ? false : true;},
    req = false,
    rid = 0,
    loaded = false,
endvar; // SLidEUP = collpase    // SLidEDOWN = open

cl = console.log; //cl();return; //if($('#connect_header'))
var timezone;
var autorefresh_ival;

function autorefresh($el){
    if(page_object.action.admin.page_action_loaded !== 'connect') clearInterval(autorefresh_ival); //cl(location);
    var $this = $($el);
    $this.find('.de_last_send').removeClass('flash_text');
    var data = { action: 'refresh_connection_date', id: $this.data('id') }
    var suc = function(res){ cl(res);
        req = false;
        if(isset(res) && res.error === false){ //            cl(res);
            $this.find('.de_last_send').addClass('flash_text').html(stripSlashes(empty(res.data)?'-':get_date_time(get_timestamp(res.data)-new Date().getTimezoneOffset()*60,timezone)));
            return;
        } //er('Неизвестная ошибка обновления данных #2');
    };
    var err = function(xhr, ajaxOptions, thrownError){ req = false; } //er('Неизвестная ошибка обновления данных #1');
    $.ajax({ type: 'post', dataType: 'json', url: location.href, data: data, success: suc, error: err });
}

function mocallback(){ //cl('mocallback'); //mutationrecords connection.js
    if(!$('#connect_header').length) return; cl('connection.js loaded');//cl('page_object.action.admin.page_action');
    cl('page_object.action.admin.page_action_loaded');
    cl(page_object.action.admin.page_action_loaded);
    if(page_object.action.admin.page_action_loaded !== 'connect') return; //cl(page_object.action.admin.data);
    if(page_object.action.admin.need_reloadjq){
        page_object.action.admin.need_reloadjq = false;
        loaded = false;
    }
    if(loaded) return; loaded = true; cl('connection.js');
    timezone = page_object.action.admin.data.data.timezone;

    $('.de_last_send_info').on('click', function(){ //  connection_refresh
        var $this = $(this);
        var data = { action: 'refresh_connection_date', id: $this.data('id') }
        var suc = function(res){
            req = false;
            if(isset(res) && res.error === false){ //                cl(res);
                $this.find('.date_last_send').html(stripSlashes(empty(res.data)?'-':get_date_time(get_timestamp(res.data)-new Date().getTimezoneOffset()*60,timezone)));
                return;
            }
            er('Неизвестная ошибка обновления данных #2');
        };
        var err = function(xhr, ajaxOptions, thrownError){ req = false; er('Неизвестная ошибка обновления данных #1');}
        $.ajax({ type: 'post', dataType: 'json', data: data, success: suc, error: err });
    });

    $.each($('.connect_item'), function(){
        cl($(this).data('ip'));
        if($(this).data('ip') === '192.168.2.180'){ //cl($(this));
            autorefresh_ival = setInterval(autorefresh, 5000, this);
            /*$(this).find('.de_last_send').on("animationend", function(){
                $(this).removeClass('flash_text');
            });*/
        }
        /*$.each($(this).children(), function(){
            cl(this);
        });*/
    });
}

cl(rp);
cl(erp);
if(erp !== 'connect') return;
return;

/*
pages.connect = {
    get_page: function(){

        var $this = $($el);
        $this.find('.de_last_send').removeClass('flash_text');
        var data = { action: 'refresh_connection_date', id: $this.data('id') }
        var suc = function(res){
            req = false;
            if(isset(res) && res.errors === false){ //cl(res);
                $this.find('.de_last_send').addClass('flash_text').html(stripSlashes(empty(res.data)?'-':get_date_time(get_timestamp(res.data)-new Date().getTimezoneOffset()*60,timezone)));
                return;
            } //er('Неизвестная ошибка обновления данных #2');
        };
        var err = function(xhr, ajaxOptions, thrownError){ req = false; } //er('Неизвестная ошибка обновления данных #1');
        $.ajax({ type: 'post', dataType: 'json', url: location.href, data: data, success: suc, error: err });
    }
}*/


var mo = new MutationObserver(mocallback);
var options = {'childList': true};
mo.observe($('#all')[0], options);

});