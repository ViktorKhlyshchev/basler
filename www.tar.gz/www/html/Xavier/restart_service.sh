#!/bin/bash

sudo systemctl restart aist