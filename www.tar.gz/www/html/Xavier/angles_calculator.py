#!/usr/bin/env python3
from math import sin
from math import cos
import math
import sys
import json
from scipy.optimize import minimize

METHOD_LIST = ['Nelder-Mead', 'Powell', 'CG', 'BFGS', 'L-BFGS-B', 'TNC', 'COBYLA']
KEY_LIST = ['nelder_mead', 'powell', 'cg', 'bfgs', 'l_bfgs_b', 'tnc', 'cobyla']
TOL_LIST = [1e-5, 1e-5, 1e-2, 1e-1, 1e-6, 1e-6, 1e-6]


def basic_values(xi, yi, zm, zs, _f, _alpha, _omega, _hi):
    a1 = cos(_alpha) * cos(_hi) - sin(_alpha) * sin(_omega) * sin(_hi)
    a2 = -cos(_alpha) * sin(_hi) - sin(_alpha) * sin(_omega) * cos(_hi)
    a3 = - sin(_alpha) * cos(_omega)
    b1 = cos(_omega) * sin(_hi)
    b2 = cos(_omega) * cos(_hi)
    b3 = - sin(_omega)
    c1 = sin(_alpha) * cos(_hi) + cos(_alpha) * sin(_omega) * sin(_hi)
    c2 = -sin(_alpha) * sin(_hi) + cos(_alpha) * sin(_omega) * cos(_hi)
    c3 = cos(_alpha) * cos(_omega)

    x = (zm - zs) * (a1 * xi + a2 * yi - a3 * _f) / (c1 * xi + c2 * yi - c3 * _f)
    y = (zm - zs) * (b1 * xi + b2 * yi - b3 * _f) / (c1 * xi + c2 * yi - c3 * _f)

    return x, y


def get_angles(_install_height, _center_dst_x, _delta_y):
    _alpha_angle = 90 - math.degrees(math.atan(_install_height/math.sqrt(_center_dst_x**2+_delta_y**2)))  # 81.159
    _omega_angle = math.degrees(-math.atan(_delta_y/_center_dst_x))  # -2.8167
    _hi_angle = 0.0
    _alpha = math.radians(_alpha_angle)
    _omega = math.radians(_omega_angle)
    _hi = math.radians(_hi_angle)
    return _alpha, _omega, _hi


def fun(angles):
    _alpha = angles[0]
    _omega = angles[1]
    _hi = angles[2]
    _f = 0

    for k in range(len(control_points_dst)):
        x, y = basic_values(x_arr_pic_dist[k], y_arr_pic_dist[k], 0, install_height, f, _alpha, _omega, _hi)
        _f += (x - control_points_dst[k]) ** 2
    return _f


def get_fixed_angles(_st, _method, _tol):
    res = minimize(fun, _st, method=_method, tol=_tol)
    # print('ANGLES IN DEGREES ({})'.format(_method), math.degrees(res.x[0]), math.degrees(res.x[1]),
    # math.degrees(res.x[2]))
    return math.degrees(res.x[0]), math.degrees(res.x[1]), math.degrees(res.x[2])


def send_error(_error):
    result = {'success': False, 'error': {'list': []}}
    result['error']['list'].append(_error)
    _result = json.dumps(result)
    print(_result)


def send_result(_angles):
    result = {'success': True, 'data': {}, 'error': {'list': []}}
    result['data'].update({'alpha_angle': _angles[0]})
    result['data'].update({'omega_angle': _angles[1]})
    result['data'].update({'hi_angle': _angles[2]})
    _result = json.dumps(result)
    print(_result)


if __name__ == '__main__':
    # example = {
    #     'method': 'nelder_mead',
    #     'install_height': 7504,
    #     'center_dst_y': 6191,
    #     'center_dst_x': 48190,
    #     'camera_y': 3820,
    #     'control_point_dst_x': 32687,
    #     'plate_height': 400,
    #     'calibration_point_list': [
    #         {
    #             'x': 1738,
    #             'y': 1817,
    #             'distance': 0,
    #         },
    #         {
    #             'x': 1676,
    #             'y': 1702,
    #             'distance': 2000,
    #         },
    #         {
    #             'x': 1603,
    #             'y': 1583,
    #             'distance': 4000,
    #         },
    #         {
    #             'x': 1548,
    #             'y': 1480,
    #             'distance': 6000,
    #         },
    #         {
    #             'x': 1502,
    #             'y': 1383,
    #             'distance': 8000,
    #         },
    #         {
    #             'x': 1465,
    #             'y': 1294,
    #             'distance': 10000,
    #         },
    #         {
    #             'x': 1433,
    #             'y': 1221,
    #             'distance': 12000,
    #         },
    #         {
    #             'x': 1401,
    #             'y': 1151,
    #             'distance': 14000,
    #         },
    #         {
    #             'x': 1380,
    #             'y': 1086,
    #             'distance': 16000,
    #         },
    #     ],
    # }

    # json_raw = json.dumps(example)
    # print(json_raw)

    # Проверка на наличие json и его чтение
    try:
        if len(sys.argv) > 1:
            data = sys.argv[1]
            json_s = json.loads(data)
        else:
            send_error("Missed input parameter - json string")
            sys.exit()
    except Exception as ex:
        send_error("Can't read json. {}".format(ex))
        sys.exit()

    # Чтение параметров
    try:
        # Проверка на наличие метода в списке
        if json_s['method'] in KEY_LIST:
            idx = KEY_LIST.index(json_s['method'])
        else:
            send_error("No such method {}! Possible methods: {}".format(json_s['method'], ', '.join(KEY_LIST)))
            sys.exit()

        install_height = json_s['install_height'] / 1000  # Высота установки |zs|
        center_dst_y = json_s['center_dst_y'] / 1000  # Расстояние от края дороги до центра кадра
        center_dst_x = json_s['center_dst_x'] / 1000  # Расстояние от столба до центра кадра
        camera_y = json_s['camera_y'] / 1000  # Смещение камеры относительно края дороги
        control_point_dst_x = json_s['control_point_dst_x'] / 1000  # Расстояние от столба до первой контрольной точки
        # plate_height = json_s['plate_height'] / 1000  # Высота ГРЗ |zm|
        f = 35 / 1000  # Фокусное расстояние, метров

        # Получение контрольных точек
        control_points = []
        control_points_dst = []
        for point in json_s['calibration_point_list']:
            control_points.append((point['x'], point['y']))
            control_points_dst.append(control_point_dst_x + (point['distance'] / 1000))
    except Exception as ex:
        send_error("Can't read parameter! {}".format(ex))
        sys.exit()

    # Расчет углов
    try:
        alpha, omega, hi = get_angles(install_height, center_dst_x, center_dst_y - camera_y)
        st = [alpha, omega, hi]
        # print(st)

        # Получение расстояния на матрице
        x_arr_pic_dist = []  # Расстояние на матрице до контрольных точек, в метрах
        y_arr_pic_dist = []  # Расстояние на матрице до контрольных точек, в метрах
        for i, p in enumerate(control_points):
            x_arr_pic_dist.append(7.1 * (2040.0 / 2.0 - p[1]) / 2040.0 / 1000.0)
            y_arr_pic_dist.append(8.4 * (2440.0 / 2.0 - p[0]) / 2440.0 / 1000.0)

        # Получение скорректированных углов
        alpha_fixed, omega_fixed, hi_fixed = get_fixed_angles(st, METHOD_LIST[idx], TOL_LIST[idx])
        send_result([round(alpha_fixed, 5), round(omega_fixed, 5), round(hi_fixed, 5)])
    except Exception as ex:
        send_error("Can't calculate angles! {}".format(ex))
        sys.exit()
