<?

$rr = shell_exec('/var/www/html/Xavier/restart_service.sh');
print_r($rr);