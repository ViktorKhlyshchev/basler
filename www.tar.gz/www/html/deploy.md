For duplo needs php7.2-curl and php7.2-xml:

sudo apt install php7.2-curl php7.2-xml

sudo mv /root/.ssh /root/.sshb
sudo cp -a ~/.ssh /root

sudo chown -R www-data:www-data /mnt/data/Temp
sudo chown -R www-data:www-data /mnt/data/Resource

===

sudo service postgresql status

===

pg_ctlcluster 10 main restart

===

cp /var/www/html/tools/services/aist_front.service /lib/systemd/system/aist_front.service && cp /var/www/html/tools/services/aist_rtsws.service /lib/systemd/system/aist_rtsws.service && cp /var/www/html/tools/services/aist_upload.service /lib/systemd/system/aist_upload.service && systemctl daemon-reload

===

