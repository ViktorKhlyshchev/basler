#!/bin/bash

# cda && git reset --hard && sh pull.sh

#git pull && sudo -u www-data /usr/bin/php7.2 -f /var/www/html/migrations/0/index.php && sudo -u www-data /usr/bin/php7.2 -f /var/www/html/tools/deploy/index.php && sudo -u www-data /usr/bin/php7.2 -f /var/www/html/migrations/0/index.php && systemctl restart aist_upload && systemctl restart aist_remove && systemctl restart aist_front && systemctl restart aist_rtsws && cd tools/servicesctl && gcc ssetuid.c -o ssetuid && sudo chown root:root ssetuid && sudo chmod +s ssetuid && sudo chmod 6775 ssetuid && cd /var/www/html/tools/autoupdate && gcc autoupdate.c -o autoupdate && sudo chown root:root autoupdate && sudo chmod +s autoupdate && sudo chmod 6775 autoupdate

RD=/var/www/html # echo $RD > 000.txt

systemctl stop aist_upload && systemctl stop aist_remove && systemctl stop aist_front && systemctl stop aist_rtsws

git pull

./setperms.sh

sudo -u www-data /usr/bin/php7.2 -f $RD/migrations.php
sudo -u www-data /usr/bin/php7.2 -f $RD/deploy.php
sudo -u www-data /usr/bin/php7.2 -f $RD/migrations.php
sudo -u www-data /usr/bin/php7.2 -f $RD/deploy.php

systemctl stop aist_upload_avg_speed && systemctl disable aist_upload_avg_speed

systemctl start aist_upload && systemctl start aist_remove && systemctl start aist_front && systemctl start aist_rtsws

# cd $RD/tools/autoupdate && /usr/bin/gcc autoupdate.c -o autoupdate && sudo chown root:root autoupdate && sudo chmod 6775 autoupdate && sudo chmod +s autoupdate # 6775
#cd /var/www/html/tools/servicesctl

# UNCOMMENT WHEN ALL HAVE MIG FROM SHELL APPLYING git pull && sudo -u www-data /usr/bin/php7.2 -f /var/www/html/index.php page=admin/migration action=apply && systemctl restart aist_upload && systemctl restart aist_remove

# sudo -u www-data /usr/bin/php7.2 -f $PWD/Project/tools/deploy/index.php

# cd /var/www/html/tools/autoupdate && gcc autoupdate.c -o autoupdate && sudo chown root:root autoupdate && sudo chmod +s autoupdate && sudo chmod 6775 autoupdate