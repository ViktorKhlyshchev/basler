1. If need "is send to all?" feature - need on crearting box set IDs to where must be sended!
1 track 2 servs
1 serv send - is_send++
check if allsend - allsend = 1

2. If sending in work, but if work too long? Need create thread that checks for that kind of records and nulling them

