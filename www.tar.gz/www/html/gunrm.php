<?php # git status untracked new files and dirs remove

# gs --short
# git status --short | php gunrm.php

# print_r(getopt());
#pred($argv);
/*$r = fopen("php://stdin", "r"); print_r(333);print_r($r);*/

define('fromain', true); # Define that request goes from main page - index.php
define('DR', __DIR__); #$_SERVER['DOCUMENT_ROOT']
if(php_sapi_name() === 'cli') define('cli', true); else define('cli', false);

require __DIR__ .'/Core/Module/Debug/debug.php';

$cmd = 'git status --short';
$o = shell_exec($cmd);
#pred($o);
$lines = explode("\n", $o);
foreach($lines as $line){ #pre($line); continue;
    if(strpos($line, '?') !== 0) continue;#pre($line);continue;
    $fn = explode('?? ', $line); #pred($fn);
    $ff = array_shift($fn); #pred($ff);
    $fn = implode('?? ', $fn);
    $files[] = $fn;
}

/*
$files = [];
while(false !== ($line = fgets(STDIN))){
    if(strpos($line, '?') === 0){ # print_r($line);    print_r(321);
        $fn = explode('?? ', $line);
        $ff = array_shift($fn); # print_r($fn);
        $fn = implode('?? ', $fn);
        $files[] = $fn;
    }
}*/

#pred($files);
$o = null;
foreach($files as $fn){
    $cmd = 'rm -rf '. __DIR__ .'/'. $fn;
    pre($cmd);
    if(isset($argv[1]) && $argv[1] === '-y') $o = shell_exec($cmd);
    pre($o);
}