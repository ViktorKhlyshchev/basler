<?php

namespace Core\Module\Ftp;

class FtpValidation {

    public static function is_valid_protocol(string $ftp_protocol = null){
        if(empty($ftp_protocol)) return false;
        if(array_search($ftp_protocol,FtpConfig::$ftp_protocol_list) !== false) return true;
        return false;
    }
}
