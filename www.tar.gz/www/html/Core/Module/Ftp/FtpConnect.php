<?php

namespace Core\Module\Ftp;

class FtpConnect {

    public static function get_connect(string $ftp_protocol = null, string $ip_address = null, string $ip_port = null){
        switch($ftp_protocol){
            case 'ftp': return self::get_ftp_connect($ip_address, $ip_port);
            case 'sftp': return self::get_sftp_connect($ip_address, $ip_port);
            default: {
                $connect_list['errors'][] = '$ftp_protocol not in switch!';
                return false;
            }
        }
    }

    public static function get_ftp_connect(string $ip_address = null, string $ip_port = null){ #vd(func_get_args()); #pred(func_get_args());

        #$old_error_handler = set_error_handler("myErrorHandler");
        $r = @ftp_connect($ip_address, $ip_port, 1); #pred($r);
        /*try {
            $r = @ftp_connect($ip_address, (int)$ip_port, 1);
        } catch(\Exception $e){
            pred($e);
        }*/
        #if(!$r) return error_get_last(); #        pred($r);
        return $r;
    }

    public static function get_sftp_connect(string $ip_address = null, string $ip_port = null){
        return @ssh2_connect($ip_address, $ip_port);
    }

    public static function close_connect(string $ftp_protocol = null, $connection_object = null){
        if(empty($connection_object)) return true;
        switch($ftp_protocol){
            case 'ftp': return self::close_ftp_connect($connection_object);
            case 'sftp': return self::close_sftp_connect($connection_object);
            default: return false;
        }
    }

    public static function close_ftp_connect($connect_object = null){
        if(empty($connect_object)) return true;
        return @ftp_close($connect_object);
    }

    public static function close_sftp_connect($connect_object = null){
        if(empty($connect_object)) return true;
        return @fclose($connect_object);
    }

    public static function get_auth(string $ftp_protocol = null, $connection_object = null, string $login = null, string $password = null){
        switch($ftp_protocol){
            case 'ftp': return self::get_ftp_auth($connection_object, $login, $password);
            case 'sftp': return self::get_sftp_auth($connection_object, $login, $password);
            default: return false;
        }
    }

    public static function get_ftp_auth($connection_object = null, string $login = null, string $password = null){
        if(empty($connection_object) || empty($login) || empty($password)
        ) return false;
        $r = @ftp_login($connection_object, $login, $password);
        if($r) return $connection_object;
    }

    public static function get_sftp_auth($connection_object = null, string $login = null, string $password = null){
        if(empty($connection_object) || empty($login) || empty($password)
        ) return false;
        if(!@ssh2_auth_password($connection_object, $login, $password)) return false;
        return @ssh2_sftp($connection_object);
    }
}
