<?php

namespace Core\Module\Ftp;

class FtpConfig {
    public static $ftp_protocol_list = [ 'ftp', 'sftp'];
}
