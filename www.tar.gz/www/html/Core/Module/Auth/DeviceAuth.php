<?php

namespace Core\Module\Auth;

class DeviceAuth{

}