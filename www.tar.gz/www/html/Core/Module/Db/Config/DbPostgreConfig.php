<?php

namespace Core\Module\Db\Config;

use Core\Module\Db\Config\PostgreSQL\DbPostgreLocalConfig;
use Core\Module\Db\Config\PostgreSQL\DbPostgreLocalConf;
use Core\Module\Db\Config\PostgreSQL\DbPostgreServerConfig;
use Core\Module\Db\Config\PostgreSQL\DbPostgreServerConf;
use Core\Module\Exception\PhpException;


class DbPostgreConfig {

    private static function get_postgre_hecner_config(){
        if(class_exists(DbPostgreServerConf::class)) $data = DbPostgreServerConf::$access_data_list; else $data = DbPostgreServerConfig::$access_data_list;
        return $data;
    }

    public static function get_list(){
        if(cli) return self::get_postgre_hecner_config();
        if(\Config::$is_query_debug) pre(debug_backtrace());
        $data = DbPostgreLocalConf::$access_data_list;
    }

    public static function get_config(string $db_name = null){
        $list = self::get_list();
        if(isset($list[$db_name])) return $list[$db_name];
        $error = array('title' => 'System problem',
            'info' => 'DB name is not exist in access data list'
        );
        throw new PhpException($error);
    }
}