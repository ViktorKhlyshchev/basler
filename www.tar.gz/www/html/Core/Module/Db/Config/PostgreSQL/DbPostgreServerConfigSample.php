<?php

namespace Core\Module\Db\Config\PostgreSQL;

class DbPostgreServerConfig { # Rename it to DbPostgreServerConfig

    /**
     * @var array
     */
    public static $access_data_list= [
        'project' => [
            'type' => 'postgresql',
            'host' => '127.0.0.1',
            'login' => 'login',
            'password' => 'pass',
            'name' => 'name'
        ]
    ];
}