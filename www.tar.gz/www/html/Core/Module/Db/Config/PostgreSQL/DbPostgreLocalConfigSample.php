<?php

namespace Core\Module\Db\Config\PostgreSQL;

class DbPostgreLocalConfig { # Rename it to DbPostgreLocalConfig

    /**
     * @var array
     */
    public static $access_data_list = [
        'aist' => [
            'type' => 'postgresql',
            'host' => 'localhost',
            'login' => 'postgres',
            'password' => 'postgres',
            'name' => 'aist6'
        ]
    ];

}