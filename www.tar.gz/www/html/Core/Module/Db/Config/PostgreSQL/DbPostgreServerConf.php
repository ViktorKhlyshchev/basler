<?php

namespace Core\Module\Db\Config\PostgreSQL;

class DbPostgreServerConfig{

    /**
     * @var array
     */
    public  static $access_data_list=array(
        'aist'=>array(
            'type'                      =>'postgresql',
            'host'                      =>'127.0.0.1',
            'login'                     =>'aist',
            'password'                  =>'Berlin1945',
            'name'                      =>'aist'
        )
    );

}