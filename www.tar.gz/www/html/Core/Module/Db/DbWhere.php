<?php

namespace Core\Module\Db;

use Core\Modules\Data;
use Core\Module\Exception\DbQueryParametersException;

trait DbWhere {

    public static function get_where_from_key(string $key = null, array $data = [], string $name = null){ # pred($key);        #get_where
        return self::get_where($data, $name);
    }

    public static function transorm(&$value, &$column){ # pred($key);        #get_where
        if(isset($value['transform'])){
            switch($value['transform']){
                case 'lower': { $column = 'LOWER('. $column .')'; break; }
            }
        }
    }

    public static function get_where(array $data = [], string $name = null){ # if(self::$show_qurey) pre(func_get_args()); # _from_key string $key = null,
        $key = 'where';
        #if($key === 'where'){
            if(empty($data['where'])){ $error = ['title' => 'DB query parameters error', 'info' => 'Where is empty #1', 'data' => $data]; throw new DbQueryParametersException($error); }
            if(!is_array($data['where'])){ $error = ['title' => 'DB query parameters error', 'info' => 'Query parameters of WHERE is not array', 'data' => $data]; throw new DbQueryParametersException($error); }
        #}
        #if($key != 'where' && $key != 'having'){ $error = ['title' => 'DB query parameters error', 'info' => 'Key is not valid', 'data' => ['key' => $key, 'data' => $data]]; pre($error); throw new DbQueryParametersException($error); }
        if(empty($data[$key])){ $error = ['title' => 'DB query parameters error', 'info' => 'Where is empty #2', 'data' => $data]; pre($error); throw new DbQueryParametersException($error); }
        if(!is_array($data[$key])){ $error = ['title' => 'DB query parameters error', 'info' => 'Query parameters of '.$key.' is not array', 'data' => $data]; pre($error); throw new DbQueryParametersException($error); }

        #if(self::$show_qurey) pre($data[$key]);
        if(Data::is_associative_array($data[$key], $name)) return self::get_associative_array($data, $name); else return self::get_array($data, $name);
    }

    public static function get_associative_array(array &$data = [], string $name = null){ # if(self::$show_qurey) pre(func_get_args()); # _from_key string $key = null,

        $key = 'where';
        $where = '';
        $value_list = [];
        $name = self::get_db_name($name);
        $column_quote = self::get_quote_column($name);

        foreach($data[$key] as $column => $value){

            if(isset($value['column'])) $column = $value['column']; #pre($column); pred($value);
            $column = $column_quote . $column . $column_quote;
            self::transorm($value, $column);

            if(is_null($value)){
                $where .= empty($where) ? '' : (' AND ');
                $where .= $column .' IS NULL';
                continue;
            }

            if(Data::is_associative_array($value)){ #pre($value);# pre($value); pred($data[$key]);
                #pre(self::$nextkw);
                if(self::$nextkwaa) $where .= self::$nextkwaa; else {
                    $union = empty($value['union']) ? 'AND' : strtoupper($value['union']); # pre($value); pre($union); # $unionn = empty($value['unionn']);
                }
                if(empty($value['method'])){ #pre($value['method']);
                    if(empty($value['function'])){ #pred($value);
                        $value['method'] = '=';
                        if(!empty($value['column_join'])){
                            $where .= (empty($where) ? '' : (' '.$union.' '));
                            $where .= $column .' '.strtoupper($value['method']).' ';
                            $where .= empty($value['table_join']) ? '' :( $column_quote.$value['table_join'].$column_quote.'.');
                            $where .= $column_quote . $value['column_join'] . $column_quote;
                        } elseif(!empty($value['function'])){
                            $where .= (empty($where) ? '' : (' '.$union.' ')). $column .'" '.strtoupper($value['method']).' '.$value['function'];
                        } elseif(isset($value['where'])){
                            #pre($union);                                    pre($where);
                            #if($union === 'OR' && !$where) $where = '1=1'; #pre($where); pre($union); pred($value);
                            if($union === 'OR' && !$where) self::$nextkwaa = 'OR'; #pre($where); pre($union); pred($value);
                            #pre(self::$nextkwaa);
                            list($where_add, $value_add_list) = self::get_where($value, $name);
                            $where .= (empty($where) ? '' : (' '.$union.' ')) .'('. $where_add .')';
                            $value_list = array_merge($value_list,$value_add_list);
                        } else { # pred($value);
                            if(is_null($value['value'])){
                                $where .= (empty($where) ? '' : (' '.$union.' ')). $column .' IS'. ($value['method'] === '!=' || $value['method'] === '<>' ? ' NOT' : '') .' null';
                            } else { # else if(is_null($value['value'])) $where .= (empty($where) ? '' : (' '.$union.' ')). $column .' IS'.($value['method'] === '!=' || $value['method'] === '<>'?' NOT':'').' null';
                                $where .= (empty($where) ? '' : (' '.$union.' ')). $column .' '. $value['method'].' ?';
                                $value_list[] = $value['value'];
                            }
                        }
                    } else { #if(!isset($value['value'])){ pre($value); pred(debug_backtrace()); }
                        $where .= (empty($where) ? '' : (' '.$union.' ')). $column .' '. $value['function'];
                    } # pre($value);
                    continue;
                }

                if(Data::is_array($value['value'])) if($value['method'] === '!=' || $value['method'] === '<>') $value['method'] = 'not in'; #pre($value['method']);

                switch($value['method']){
                    case 'in':
                    case 'not in':
                    case 'any': { # pred($value);
                        if(isset($value['value'])){
                            if(is_array($value['value'])){
                                if(count($value['value']) === 0) return [];
                                $vals = implode(', ', array_fill(0, count($value['value']),'?')); #pred($vals); foreach($value['value'] as $v) $v = "'". htmlentities($v, ENT_QUOTES) ."'";
                                $where .=  (empty($where) ? '' : (' '.$union.' ')). $column .' '. strtoupper($value['method']) .'('. $vals .')';
                                $value_list = array_merge($value_list, $value['value']);
                            } else {
                                $where .= (empty($where) ? '' : (' '. $union .' ')) . $column .' = ?';
                                $value_list[] = $value['value'];
                            }
                        }
                        break;
                    }
                    case 'between': {
                        if(!is_array($value['column'])){ $error = ['title' => 'DB query parameters exception', 'info' => 'Value is not valid', 'data' => ['column' => $value['column'], 'method' => $value['method'], 'value' => $value['value']]]; throw new DbQueryParametersException($error);
                        }
                        if(count($value['column']) != 2){
                            $error = array('title' => 'DB query parameters exception',
                                'info' => 'Value list length is not valid',
                                'data' => array('column' => $value['column'],
                                    'method' => $value['method'],
                                    'value' => $value['value']
                                )
                            );
                            throw new DbQueryParametersException($error);
                        }
                        $where .= (empty($where) ? '' : (' '.$union.' ')).' ? BETWEEN ';
                        $where .= (empty($value['table_join']) ? '':($column_quote.$value['table_join'].$column_quote.'.')).$column_quote.$value['column'][0].$column_quote;
                        $where .= ' AND '.(empty($value['table_join']) ? '':($column_quote.$value['table_join'].$column_quote.'.')).$column_quote.$value['column'][1].$column_quote;
                        $value_list[] = $value['value'];
                        break;
                    }
                    case '=':
                    case '!=':
                    case '<':
                    case '>':
                    case '<=':
                    case '>=':
                    case '>>=':
                    case '<>': {
                        if(!empty($value['column_join']))
                            $where .= (empty($where) ? '' : (' '.$union.' ')). $column .' '.strtoupper($value['method']).' '.(empty($value['table_join']) ? '':($column_quote.$value['table_join'].$column_quote.'.')).$column_quote.$value['column_join'].$column_quote;
                        else if(!empty($value['function']))
                            $where .= (empty($where) ? '' : (' '.$union.' ')). $column .'" '.strtoupper($value['method']).' '.$value['function'];
                        else if(is_null($value['value']))
                            $where .= (empty($where) ? '' : (' '.$union.' ')). $column .' IS'.($value['method'] === '!=' || $value['method'] === '<>'?' NOT':'').' null';
                        else {
                            $where .= (empty($where) ? '' : (' '.$union.' ')). $column .' '.$value['method'].' ?';
                            $value_list[] = $value['value'];
                        }
                        break;
                    }
                    case 'like%': {
                        if(isset($value['value'])){
                            $where .= (empty($where) ? '' : (' '.$union.' ')). $column .' LIKE ?';
                            $value_list[] = $value['value'].'%';
                        }
                        break;
                    }
                    case 'nlike':
                    case 'not like': {
                        if(isset($value['value'])){
                            $where .= (empty($where) ? '' : (' '.$union.' ')). $column .' NOT LIKE ?';
                            $value_list[] = $value['value'];
                        }
                        break;
                    }
                    case 'like':
                    case 'unlike': {
                        if(isset($value['value'])){
                            $where .= (empty($where) ? '' : (' '.$union.' ')). $column .' '.strtoupper($value['method']).' ?';
                            $value_list[] ='%'.$value['value'].'%'; #pred($value_list);
                        }
                        break;
                    }
                    default: {
                        $error = ['title' => 'DB query parameters error', 'info' => 'Query parameters in where list have unknown method', 'row' => $value, 'data' => $data]; throw new DbQueryParametersException($error);
                        break;
                    }
                }
                continue;
            } # pre($value);

            if(self::$nextkwaa){ $kw = ' '. self::$nextkwaa .' '; self::$nextkwaa = false; } else $kw = ' AND '; # self::$nextkwaa = false; #$kw = self::$nextkwaa ? ' '. self::$nextkwaa .' ': ' AND ';  self::$nextkwaa = false;
            if(Data::is_array($value)){
                #if(self::$nextkwaa) $where .= self::$nextkwaa;
                $where .= (empty($where) ? '' : ($kw)). $column .' IN ('.implode(', ',array_fill(0,count($value),'?')).')';
                $value_list =array_merge($value_list,$value);
            } else {
                $where .= (empty($where) ? '' : ($kw)). $column .' = ?';
                $value_list[] = $value;
            }
        }
        return [$where, $value_list];
    }

    public static function get_array(array &$data = [], string $name = null){ # if(self::$show_qurey) pre(func_get_args()); # _from_key string $key = null,

        $key = 'where';
        $where = '';
        $value_list = [];
        $name = self::get_db_name($name);
        $column_quote = self::get_quote_column($name); #if(self::$show_qurey) pre($data[$key]);

        foreach($data[$key] as $row){
            if(!Data::is_array($row)) continue;

            #if(self::$nextkwa) $where .= self::$nextkwa; else {
                $union = empty($row['union']) ? 'AND' : strtoupper($row['union']); # pre($value); pre($union); # $unionn = empty($value['unionn']);
            #}
            if(isset($row['where'])){
                list($where_add,$value_add_list) = self::get_where($row, $name); # $where .= (empty($where) ? '' : (' '.$union.' (')).$where_add.(empty($where) ? '':')');
                $where .= (empty($where) ? '' : (' '.$union.' ')) .'('. $where_add .')';
                $value_list =array_merge($value_list,$value_add_list);
            }
            else if(!empty($row['column'])){
                if(empty($row['method'])){
                    if(isset($row['value']))
                        $method=Data::is_array($row['value']) ? (count($row['value']) > 0?'in':'='):'=';
                    else
                        $method='=';
                }
                else
                    $method=strtolower($row['method']);
                if(!is_array($row['column']))
                    $column=self::get_column_name($row,false,$name);
                else
                    $column= $row['column'];
                switch($method){
                    case 'in':
                    case 'not in':
                    case 'any': { # pred(123);
                        if(isset($row['value'])){
                            if(is_array($row['value'])){
                                if(count($row['value']) === 0) return [];
                                else if(count($row['value']) === 1)
                                    $where .= (empty($where) ? '' : (' '.$union.' ')). $column .' = ?';
                                else
                                    $where .= (empty($where) ? '' : (' '.$union.' ')). $column .' '.strtoupper($method).'('.implode(', ', array_fill(0,count($row['value']),'?')).')';
                                $value_list = array_merge($value_list,$row['value']);
                            }
                            else {
                                $where .= (empty($where) ? '' : (' '.$union.' ')). $column .' = ?';
                                $value_list[] = $row['value'];
                            }
                        }
                        break;
                    }
                    case 'between': {
                        if(!is_array($row['column'])){
                            $error = array('title' => 'DB query parameters exception',
                                'info' => 'Value is not valid',
                                'data' => array('column' => $row['column'],
                                    'method' => $method,
                                    'value' => $row['value']
                                )
                            );
                            throw new DbQueryParametersException($error);
                        }
                        if(count($row['column']) != 2){  $error = ['title' => 'DB query parameters exception', 'info' => 'Value list length is not valid', 'data' => ['column' => $row['column'], 'method' => $method, 'value' => $row['value']]]; throw new DbQueryParametersException($error); }
                        $where .= (empty($where) ? '' : (' '.$union.' ')).' ? BETWEEN ';
                        $where .= (empty($row['table_join']) ? '':($column_quote.$row['table_join'].$column_quote.'.')).$column_quote.$row['column'][0].$column_quote;
                        $where .= ' AND '.(empty($row['table_join']) ? '':($column_quote.$row['table_join'].$column_quote.'.')).$column_quote.$row['column'][1].$column_quote;
                        $value_list[] = $row['value'];
                        break;
                    }
                    case '=':
                    case '!=':
                    case '<':
                    case '>':
                    case '<=':
                    case '>=':
                    case '>>=':
                    case '<>': {
                        if(!empty($row['column_join'])){
                            $where .= (empty($where) ? '' : (' '.$union.' ')). $column .' '.strtoupper($method).' '.(empty($row['table_join']) ? '':($column_quote.$row['table_join'].$column_quote.'.')).$column_quote.$row['column_join'].$column_quote;
                        } elseif(!empty($row['function']))
                            $where .= (empty($where) ? '' : (' '.$union.' ')). $column .'" '.strtoupper($method).' '.$row['function'];
                        else if(is_null($row['value']))
                            $where .= (empty($where) ? '' : (' '.$union.' ')). $column .' IS'.($method=='!=' || $method=='<>'?' NOT':'').' null';
                        else {
                            /*if(self::$show_qurey){
                                pre($row);
                                pre(self::$nextkwa);
                                pre($where);
                            }*/
                            #if(self::$nextkwa){ $where = ' '. self::$nextkwa .' '; self::$nextkwa = false; }
                            #$where .= (empty($where) ? '' : (' '.$union.' ')). $column .' '.$method.' ?';
                            #if(!$where) self::$nextkwa = $union;
                            #if(self::$show_qurey){ pre($row); pre($union); pre(self::$nextkwa); }
                            if($union === 'OR' && !$where){
                                self::$nextkwa = 'OR';
                                $kw = '';
                            } else {
                                if(self::$nextkwa){ $kw = ' '. self::$nextkwa .' '; self::$nextkwa = false; } else $kw = ' AND ';
                            }
                            if(self::$show_qurey) pre($kw);
                            #if(self::$show_qurey) $where .= (empty($where) ? '' : (' '. $kw .'D ')). $column .' '.$method.' ?'; else
                            $where .= (empty($where) ? '' : ($kw)). $column .' '.$method.' ?';
                            #$where .= (empty($where) ? '' : (' '. $union.' ')). $column .' '.$method.' ?';
                            $value_list[] = $row['value'];
                        } # if(self::$nextkwa){ $kw = ' '. self::$nextkwa .' '; self::$nextkwa = false; } else $kw = ' AND ';
                        break;
                    }
                    case 'like':
                    case 'unlike': {
                        if(isset($row['value'])){
                            $where .= (empty($where) ? '' : (' '.$union.' ')). $column .' '.strtoupper($method).' ?';
                            $value_list[] ='%'.$row['value'].'%';
                        }
                        break;
                    }
                    default: {
                        $error = array('title' => 'DB query parameters error',
                            'info' => 'Query parameters in where list have unknown method',
                            'row' => $row,
                            'data' => $data
                        );
                        throw new DbQueryParametersException($error);
                        break;
                    }
                }
            } elseif(!empty($row['function'])){
                $where .= (empty($where) ? '' : (' '.$union.' ')).$row['function'];
            }
        }

        return [$where, $value_list];
    } # /*if(strpos($where, 'date_live') === false && strpos($where, 'user_id') === false && strpos($where, 'type') === false && strpos($where, 'hash') === false){ pre($where); pred($value_list); }*/
}