<?php

namespace Core\Module\Db;

use Core\Modules\Data;
use Core\Module\Exception\DbQueryParametersException;

trait DbInner {

    public static function isset_select_parameters(array $data = []){
        if(empty($data['select'])){
            $error = array('title' => 'DB query parameters error',
                'info' => 'DB query have not SELECT parameter',
                'data' => $data
            );
            throw new DbQueryParametersException($error);
        }
        if(count($data['select']) === 0){
            $error = array('title' => 'DB query parameters error',
                'info' => 'SELECT have not parameteres',
                'data' => $data
            );
            throw new DbQueryParametersException($error);
        }
    }

    public static function isset_set_parameters(array $data = []){
        if(empty($data['set'])){
            $error = array('title' => 'DB query parameters error',
                'info' => 'DB query have not SET parameter',
                'data' => $data
            );
            throw new DbQueryParametersException($error);
        }
        if(count($data['set']) === 0){
            $error = array('title' => 'DB query parameters error',
                'info' => 'SET have not parameteres',
                'data' => $data
            );
            throw new DbQueryParametersException($error);
        }
    }

    public static function isset_table_parameters(array $data = []){
        if(empty($data['table'])){
            $error = array('title' => 'DB query parameters error',
                'info' => 'DB query have not TABLE parameter',
                'data' => $data
            );
            if(\Config::$is_query_debug) pre(debug_backtrace());
            throw new DbQueryParametersException($error);
        }
        if(Data::is_array($data['table']))
            if(count($data['table']) === 0){
                $error = array('title' => 'DB query parameters error',
                    'info' => 'TABLE have not parameteres',
                    'data' => $data
                );
                throw new DbQueryParametersException($error);
            }
        return true;
    }

    public static function isset_values_parameters(array $data = []){
        if(empty($data['values'])){
            $error = array('title' => 'DB query parameters error',
                'info' => 'DB query have not VALUES parameter',
                'data' => $data
            );
            throw new DbQueryParametersException($error);
        }
        if(count($data['values']) === 0){
            $error = array('title' => 'DB query parameters error',
                'info' => 'VALUES have not parameteres',
                'data' => $data
            );
            throw new DbQueryParametersException($error);
        }
    }

    public static function isset_join_parameters(array $data = []){
        if(empty($data['join'])){
            $error = array('title' => 'DB query parameters error',
                'info' => 'DB query have not JOIN parameter',
                'data' => $data
            );
            throw new DbQueryParametersException($error);
        }
        if(count($data['join']) === 0){
            $error = array('title' => 'DB query parameters error',
                'info' => 'JOIN have not parameteres',
                'data' => $data
            );
            throw new DbQueryParametersException($error);
        }
    }

    public static function isset_where_parameters(array $data = []){
        if(empty($data['where'])){
            $error = array('title' => 'DB query parameters error',
                'info' => 'DB query have not WHERE parameter',
                'data' => $data
            );
            throw new DbQueryParametersException($error);
        }
        if(count($data['where']) === 0){
            $error = array('title' => 'DB query parameters error',
                'info' => 'WHERE have not parameteres',
                'data' => $data
            );
            throw new DbQueryParametersException($error);
        }
    }

    public static function isset_group_parameters(array $data = []){
        if(empty($data['group'])){
            $error = array('title' => 'DB query parameters error',
                'info' => 'DB query have not GROUP parameter',
                'data' => $data
            );
            throw new DbQueryParametersException($error);
        }
        if(count($data['group']) === 0){
            $error = array('title' => 'DB query parameters error',
                'info' => 'GROUP have not parameters',
                'data' => $data
            );
            throw new DbQueryParametersException($error);
        }
    }

    public static function isset_order_parameters(array $data = []){
        if(empty($data['order'])){
            $error = array('title' => 'DB query parameters error',
                'info' => 'DB query have not ORDER parameter',
                'data' => $data
            );
            throw new DbQueryParametersException($error);
        }
        if(count($data['order']) === 0){
            $error = array('title' => 'DB query parameters error',
                'info' => 'ORDER have not parameteres',
                'data' => $data
            );
            throw new DbQueryParametersException($error);
        }
    }

    public static function isset_limit_parameters(array $data = []){
        if(empty($data['limit'])){
            $error = array('title' => 'DB query parameters error',
                'info' => 'DB query have not limit parameter',
                'data' => $data
            );
            throw new DbQueryParametersException($error);
        }
        else if(!is_numeric($data['limit'])){
            if(is_array($data['limit'])){
                if(count($data['limit'])!=2){
                    $error = array('title' => 'DB query parameters error',
                        'info' => 'LIMIT must have 2 parameters in array',
                        'data' => $data
                    );
                    throw new DbQueryParametersException($error);
                }
            }
        }
    }

    public static function get_table_name_full(array $data = [],string $name = null){
        if(empty($data['table'])){
            $error = ['title' => 'DB query parameters error', 'info' => 'Query parameters of TABLE is empty', 'data' => $data];
            throw new DbQueryParametersException($error);
        }
        $name = self::get_db_name($name);
        $quote = self::get_quote_column($name);
        if(is_string($data['table'])) return $quote.$data['table'].$quote;
        if(!is_array($data['table'])){
            $error = ['title' => 'DB query parameters error', 'info' => 'Query parameters of TABLE is not array', 'data' => $data];
            throw new DbQueryParametersException($error);
        }
        if(empty($data['table']['name'])){
            $error = ['title' => 'DB query parameters error', 'info' => 'Query parameters of TABLE in array is empty', 'data' => $data];
            throw new DbQueryParametersException($error);
        }
        $table = $quote.$data['table']['name'] . $quote;
        if(!empty($data['table']['rename'])) $table .= ' AS '.$quote.$data['table']['rename'] . $quote;
        return $table;
    }

    public static function get_validation_value_list(string $table_default,array $list = []){
        return true;
//        foreach($list as $row)
//            if(isset($row['value'])){
//
//                $table = empty($row['table']) ? $table_default:self::get_table_name($row['table']);
//
//                if(!DbValidationValue::init($table,$row['column'],$row['value'])){
//
//                    $error = array(
//                        'title' => 'DB query parameters error',
//                        'info' => 'Query parameter of value list is not valid',
//                        'data' => array(
//                            'table' => $table,
//                            'row' => array(
//                                'table' => $table,
//                                'column' => $row['column'],
//                                'value' => $row['value']
//                            ),
//                            'list' => $list
//                        )
//                    );
//
//                    throw new DbValidationValueException($error);
//
//                }
//
//            }
//
//        return true;
    }
}