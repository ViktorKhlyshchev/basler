<?php

namespace Core\Module\Db;

use Core\Module\Exception\ParametersException;
use Core\Module\Exception\SystemException;

class DbValidationValue {

    private static $table;
    private static $column;
    private static $value;

    private static function get_class_name_from_table_name(){
        $table_list = mb_split('_', self::$table);
        $result = '';
        foreach($table_list as $row) if(!empty($row)) $result.= ucfirst($row);
            pred(debug_backtrace());
        $file_path = 'Core/Module/Db/DbValueType/DbTable'.$result.'Value.php';
        if(file_exists($file_path)) return __NAMESPACE__.'\DbValueType\DbTable'. $result .'Value';
        else {
            $file_path = 'Core/Project/Db/DbValueType/DbTable'. $result .'Value.php';
            if(file_exists($file_path)) return '\Project\Aist\All\Module\Db\DbValueType\DbTable'. $result .'Value';

            $error = ['title' => 'Parameters problem', 'info' => 'DB validation class is not exists, fp:_'. $file_path, 'data' => ['table' => self::$table, 'column' => self::$column, 'value' => self::$value]];
            throw new ParametersException($error);
        }
    }

    private static function is_valid(){
        $class_name = self::get_class_name_from_table_name();
        try {
            return $class_name::init(self::$column, self::$value);
        }
        catch(\Exception $error){
            throw new SystemException($error);
        }
    }

    public static function init(string $table = null, string $column = null, $value = null){
        return true;
        if(empty($column)) return false;
        self::$table = empty($table) ? null : $table;
        self::$column = $column; self::$value = $value;
        return self::is_valid();
    }
}