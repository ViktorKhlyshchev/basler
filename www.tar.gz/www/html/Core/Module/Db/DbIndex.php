<?php

namespace Core\Module\Db;

use Core\Module\Exception\ParametersException;

class DbIndex {

    public static function cidr_index(string $table = null, string $column = null){
        $error_info_list = [];
        if(empty($table)) $error_info_list[] = 'Table is empty';
        if(empty($column)) $error_info_list[] = 'Column is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem', 'info' => $error_info_list);
            throw new ParametersException($error);
        }
        $q='CREATE INDEX "'.$table.'_'.$column.'_idx" ON "'.$table.'" USING gist (inet("'.$column.'") inet_ops)';
        return Db::exec($q);
    }

    public static function drop_index(string $table = null, string $column = null, string $name = null){
        $error_info_list = [];
        if(empty($table)) $error_info_list[] = 'Table is empty';
        if(empty($column)) $error_info_list[] = 'Column is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem', 'info' => $error_info_list);
            throw new ParametersException($error);
        }
        $q='DROP INDEX "'.$table.'_'.$column.'_idx"';
        return Db::exec($q,$name);
    }
}