<?php

namespace Core\Module\Db;

use Core\Modules\Data;
use Core\Module\Exception\ParametersException;

trait DbModel {

    public static function isset_row_id(int $id = null, string $table = null, int $type = null, array $where_list = [], string $name = null){
        $error_info_list = []; #if($table !== '_user'){ #pre(func_get_args());        #pre(debug_backtrace());}
        if(empty($id)) $error_info_list[] = 'ID is empty';
        if(empty($table)) $error_info_list[] = 'Table name is empty';
        if(count($error_info_list) > 0){
            $error = ['title' => 'Parameters problem', 'info' => $error_info_list, 'data' => ['id' => $id, 'table' => $table, 'name' => $name]];
            throw new ParametersException($error);
        }
        $where_temp_list = [['column' => 'id', 'value' => $id]];
        $where_list = array_merge($where_temp_list, $where_list);
        if(!is_null($type)) $where_list[] = ['column' => 'type', 'value' => $type];
        $q = ['select' => [['function' => 'COUNT(*)', 'rename' => 'len']], 'table' => $table, 'where' => $where_list, 'limit' => 1];
        $r = Db::select($q,$name); #if($table !== '_user'){#pre(func_get_args());       #pre(debug_backtrace());}
        if(count($r) === 0) return false; #if($table !== '_user'){ #pre($q); #pre(empty($r[0]['len']));#pre(func_get_args());       #pre(debug_backtrace()); }
        return !empty($r[0]['len']);
    }

    public static function isset_row_id_list(array $id_list = [],string $table = null, int $type = null, array $where_list = [],string $name = null){
        $error_info_list = [];
        if(count($id_list) === 0) $error_info_list[] = 'ID list is empty';
        if(empty($table)) $error_info_list[] = 'Table name is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );
            throw new ParametersException($error);
        }
        $list = [];
        foreach($id_list as $id)
            if(!empty($id)) $list[$id] = $id;
        $id_list=array_keys($list);
        $where_temp_list = array(
             array('column' => 'id',
                'value' => $id_list
            )
        );
        $where_list=array_merge($where_temp_list,$where_list);
        if(!is_null($type)) $where_list[] = array('column' => 'type',
                'value' => $type
            );
        $q = array('select' => array(
                 array('function' => 'COUNT(*)',
                    'rename' => 'len'
                )
            ),
            'table' => $table,
            'where' => $where_list,
            'limit' => 1
        );
        $r = Db::select($q,$name);
        if(count($r) === 0) return false;
        return count($id_list)== $r[0]['len'];
    }

    public static function delby_id(int $id = null, string $table = null, int $type = null, array $where_list = [],string $name = null){
        call_user_func_array(self::pseudo_delete_from_id, func_get_args());
    }

    public static function pseudo_delete_from_id(int $id = null, string $table = null, int $type = null, array $where = [],string $name = null){
        $error_info_list = []; #pred(func_get_args());
        if(empty($id)) $error_info_list[] = 'ID is empty';
        if(empty($table)) $error_info_list[] = 'Table name is empty';
        if(count($error_info_list)){
            $error = array('title' => 'Parameters problem', 'info' => $error_info_list, 'data' => array('id' => $id, 'table' => $table,'name' => $name));
            throw new ParametersException($error);
        }
        $update_set_list = array('date_update' => 'NOW()', 'date_remove' => 'NOW()', 'type' => 1);
        $where_temp_list = [];
        if(Data::is_associative_array($where)) $where_temp_list['id'] = $id;
        else if(Data::is_array($where)) $where_temp_list[] = array('column' => 'id', 'value' => $id);
        else { $error = array('title' => 'System error', 'info' => 'Where list is not array'); throw new PhpException($error); }
        $where = array_merge($where_temp_list, $where);
        if(!is_null($type)){
            if(Data::is_associative_array($where)) $where['type'] = $type;
            else if(Data::is_array($where)) $where[] = array('column' => 'type', 'value' => $type);
            else { $error = array('title' => 'System error', 'info' => 'Where list is not array'); throw new PhpException($error); }
        }
        $q = ['table' => $table, 'set' => $update_set_list, 'where' => $where];
        return Db::update($q,$name);
    }

    public static function delby_where(int $id = null, string $table = null, int $type = null, array $where = [], string $name = null){
        call_user_func_array('self::pseudo_delete_from_where_list', func_get_args());
    }

    public static function pseudo_delete_from_where_list(string $table = null, int $type = null, array $where = [], string $name = null){ # FAKEEE!!!
        if(empty($table)) { $error = ['title' => 'Parameters problem', 'info' => ['Table name is empty'], 'data' => ['table' => $table, 'name' => $name]]; throw new ParametersException($error); }
        $update_set_list = ['date_update' => 'NOW()', 'date_remove' => 'NOW()', 'type' => 1];
        if(!is_null($type)){
            if(Data::is_associative_array($where)) $where['type'] = $type;
            else if(Data::is_array($where)) $where[] = ['column' => 'type', 'value' => $type];
            else { $error = ['title' => 'System error', 'info' => 'Where list is not array']; throw new PhpException($error); }
        }
        $q = ['table' => $table, 'set' => $update_set_list, 'where' => $where];
        return Db::update($q, $name);
    }

    public static function pseudo_delete_from_id_list(array $id_list = [], string $table = null, int $type = null, array $where = [],string $name = null){

        $error_info_list = [];
        if(!count($id_list)) $error_info_list[] = 'ID list is empty';
        if(empty($table)) $error_info_list[] = 'Table name is empty';
        if(count($error_info_list)){ $error = array('title' => 'Parameters problem', 'info' => $error_info_list); throw new ParametersException($error); }
        $where_temp_list = [];
        $update_set_list = array('date_update' => 'NOW()', 'date_remove' => 'NOW()', 'type' => 1);
        if(Data::is_associative_array($where)) $where_temp_list['id'] = $id_list;
        else if(Data::is_array($where)) $where_temp_list[] = array('column' => 'id', 'value' => $id_list);
        else { $error = array('title' => 'System error', 'info' => 'Where list is not array');
            throw new PhpException($error);
        }
        $where = array_merge($where_temp_list,$where);
        if(!is_null($type)){
            if(Data::is_associative_array($where)) $where['type'] = $type;
            else if(Data::is_array($where)) $where[] = array('column' => 'type', 'value' => $type);
            else { $error = array('title' => 'System error', 'info' => 'Where list is not array'); throw new PhpException($error); }
        }
        $q = array('table' => $table, 'set' => $update_set_list, 'where' => $where);
        return Db::update($q,$name);
    }

    public static function get_row_len(string $table = null, int $type = null, array $where = [],string $name = null){
        $error_info_list = [];
        if(empty($table)) $error_info_list[] = 'Table name is empty'; # if(count($where) === 0)  $error_info_list[] = 'Where list is empty';
        if(count($error_info_list)){ $error = ['title' => 'Parameters problem', 'info' => $error_info_list]; throw new ParametersException($error); }
        $where_temp = [];
        $where = array_merge($where_temp, $where);
        if(!is_null($type)){
            if(Data::is_associative_array($where)){
                #if(!isset($where['type'])) $where['type'] = $type;
            } else if(Data::is_array($where)) $where[] = ['column' => 'type','value' => $type];
        }
        #$q = ['select' => [['function' => 'COUNT(*)', 'rename' => 'len']], 'table' => $table, 'where' => $where]; pred($q);
        $q = ['select' => [['function' => 'COUNT(id)', 'rename' => 'len']], 'table' => $table, 'where' => $where]; #pre($q);
        $r = Db::select($q, $name); #pre($r);
        if(isset($r['error'])) return $r;
        if(!count($r)) return 0;
        return $r[0]['len'];
    }

    public static function get_row_len_id(string $table = null, array $where_list = [], string $name = null){
        $error_info_list = [];
        if(empty($table)) $error_info_list[] = 'Table name is empty'; # if(count($where_list) === 0)   $error_info_list[] = 'Where list is empty';
        if(count($error_info_list) > 0){
            $error = ['title' => 'Parameters problem', 'info' => $error_info_list];
            throw new ParametersException($error);
        }
        $where_temp_list = [];
        $where_list =array_merge($where_temp_list, $where_list);
        $q = ['select' => [['function' => 'COUNT(id)', 'rename' => 'len']], 'table' => $table, 'where' => $where_list];
        $r = Db::select($q, $name);
        if(!$r) return 0; # if(count($r) === 0) return 0;
        return $r[0]['len'];
    }

    public static function get_row_id(string $table = null, int $type = null, array $where_list = [], string $name = null){
        $error_info_list = [];
        if(empty($table)) $error_info_list[] = 'Table name is empty';
        if(count($where_list) === 0) $error_info_list[] = 'Where list is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('table' => $table,
                    'name' => $name
                )
            );
            throw new ParametersException($error);
        }
        $where_temp_list = [];
        $where_list =array_merge($where_temp_list,$where_list);
        if(!is_null($type)){
            if(Data::is_associative_array($where_list)){
                if(!isset($where_list['type']))
                    $where_list['type'] = $type;
            }
            else if(Data::is_array($where_list)) $where_list[] = array('column' => 'type',
                    'value' => $type
                );
        }
        $q = array('select' => array('id'),
            'table' => $table,
            'where' => $where_list,
            'limit' => 1
        );
        $r = Db::select($q,$name);
        if(count($r) === 0) return null;
        return $r[0]['id'];
    }

    public static function get_row_id_list(string $table = null, int $type = null, array $where_list = [],string $name = null){
        $error_info_list = [];
        if(empty($table)) $error_info_list[] = 'Table name is empty';
        if(count($where_list) === 0) $error_info_list[] = 'Where list is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('table' => $table,
                    'name' => $name
                )
            );
            throw new ParametersException($error);
        }
        $where_temp_list = [];
        $where_list =array_merge($where_temp_list,$where_list);
        if(!is_null($type)){
            if(Data::is_associative_array($where_list)){
                if(!isset($where_list['type']))
                    $where_list['type'] = $type;
            }
            else if(Data::is_array($where_list)) $where_list[] = array('column' => 'type',
                    'value' => $type
                );
            else {
                $error = array('title' => 'System error',
                    'info' => 'Where list is not array'
                );
                throw new PhpException($error);
            }
        }
        $q = array('select' => array('id'),
            'table' => $table,
            'where' => $where_list
        );
        $r = Db::select($q,$name);
        if(count($r) === 0) return [];
        $list = [];
        foreach($r as $row) $list[] = $row['id'];
        return $list;
    }

    public static function get_data_from_id(int $id = null, string $table = null, array $column_list = [],int $type = null, array $where_list = [],string $name = null){
        $error_info_list = [];
        if(empty($id)) $error_info_list[] = 'ID is empty';
        if(empty($table)) $error_info_list[] = 'Table name is empty';
        if(count($column_list) === 0) $error_info_list[] = 'Column name list is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('id' => $id,
                    'table' => $table,
                    'column_list' => $column_list,
                    'name' => $name
                )
            );
            throw new ParametersException($error);
        }
        $select_list = [];
        $where_temp_list = [];
        if(Data::is_associative_array($where_list)) $where_temp_list['id'] = $id;
        else if(Data::is_array($where_list)) $where_temp_list[] = array('column' => 'id',
                'value' => $id
            );
        else {
            $error = array('title' => PhpException::$title,
                'info' => 'Where list is not array'
            );
            throw new PhpException($error);
        }
        $where_list=array_merge($where_temp_list,$where_list);
        if(!is_null($type)){
            if(Data::is_associative_array($where_list)){
                if(!isset($where_list['type']))
                    $where_list['type'] = $type;
            }
            else if(Data::is_array($where_list)) $where_list[] = array('column' => 'type',
                    'value' => $type
                );
            else {
                $error = array('title' => 'System error',
                    'info' => 'Where list is not array'
                );
                throw new PhpException($error);
            }
        }
        foreach($column_list as $column_name) $select_list[] = $column_name;
        $q = ['select' => $select_list, 'table' => $table, 'where' => $where_list, 'limit' => 1];
        $r = Db::select($q,$name);
        if(count($r) === 0) return null;
        return $r[0];
    }

    public static function get_data_from_id_list(array $id_list = [],string $table = null, array $column_list = [],int $type = null, array $where_list = [],string $name = null){
        $error_info_list = [];
        if(count($id_list) === 0) $error_info_list[] = 'ID list is empty';
        if(empty($table)) $error_info_list[] = 'Table name is empty';
        if(count($column_list) === 0) $error_info_list[] = 'Column name list is empty';
        if(count($error_info_list)){ $error = ['title' => 'Parameters problem', 'info' => $error_info_list, 'data' => ['id_list' => $id_list, 'table' => $table, 'column_list' => $column_list, 'name' => $name]]; throw new ParametersException($error); }
        $select_list = [['column' => 'id']];
        $where_temp_list = [['column' => 'id', 'method' => 'IN', 'value' => $id_list]];
        $where_list = array_merge($where_temp_list,$where_list);
        if(!is_null($type)){
            if(Data::is_associative_array($where_list)){
                if(!isset($where_list['type'])) $where_list['type'] = $type;
            }
            else if(Data::is_array($where_list)) $where_list[] = array('column' => 'type',                    'value' => $type                );
            else {                $error = array('title' => 'System error',                    'info' => 'Where list is not array'                );                throw new PhpException($error);            }
        }
        foreach($column_list as $column_name) $select_list[$column_name] = ['column' => $column_name];
        foreach($column_list as $column_name) $select_list[$column_name] = ['column' => $column_name];
        $q = ['select' => $select_list, 'table' => $table, 'where' => $where_list, 'limit' => count($id_list)];
        $r = Db::select($q,$name);
        return $r;
    }

    public static function update_date_update_from_id(int $id = null, string $table = null, int $type = null, string $name = null){
        $error_info_list = [];
        if(empty($id)) $error_info_list[] = 'ID is empty';
        if(empty($table)) $error_info_list[] = 'Table name is empty';
        if(count($error_info_list) > 0){
            $error = ['title' => ParametersException::$title, 'info' => $error_info_list];
            throw new ParametersException($error);
        }
        $q = ['table' => $table,
            'set' => ['date_update' => 'NOW()'],
            'where' => ['id' => $id], 'limit' => 1];
        if(is_null($type)) $q['where']['type'] = 0;
        return Db::update($q,$name);
    }

    public static function update_data_from_id(int $id = null, string $table = null, array $set_list = [],int $type = null, array $where_list = [],string $name = null){
        $error_info_list = [];
        if(empty($id)) $error_info_list[] = 'ID is empty';
        if(empty($table)) $error_info_list[] = 'Table name is empty';
        if(count($set_list) === 0) $error_info_list[] = 'Set list is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('id' => $id,
                    'table' => $table,
                    'column_list' => $set_list,
                    'name' => $name
                )
            );
            throw new ParametersException($error);
        }
        $update_set_list = [];
        if(Data::is_associative_array($where_list)) $where_temp_list['id'] = $id;
        else if(Data::is_array($where_list)) $where_temp_list[] = array('column' => 'id',
                'value' => $id
            );
        else {
            $error = array('title' => 'System error',
                'info' => 'Where list is not array'
            );
            throw new PhpException($error);
        }
        $where_list=array_merge($where_temp_list,$where_list);
        if(!is_null($type)){
            if(Data::is_associative_array($where_list)) $where_list['type'] = $type;
            else if(Data::is_array($where_list)) $where_list[] = array('column' => 'type',
                    'value' => $type
                );
            else {
                $error = array('title' => 'System error',
                    'info' => 'Where list is not array'
                );
                throw new PhpException($error);
            }
        }
        foreach($set_list as $column_name => $value)
            $update_set_list[$column_name] = array('column' => $column_name,
                'value' => $value
            );
        $q = array('table' => $table,
            'set' => array_values($update_set_list),
            'where' => $where_list,
            'limit' => 1
        );
        return Db::update($q,$name);
    }

    public static function update_data_from_where_list(string $table = null, array $set_list = [],int $type = null, array $where_list = [],string $name = null){
        $error_info_list = [];
        if(empty($table)) $error_info_list[] = 'Table name is empty';
        if(count($set_list) === 0) $error_info_list[] = 'Set list is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('table' => $table,
                    'column_list' => $set_list,
                    'name' => $name
                )
            );
            throw new ParametersException($error);
        }
        $update_set_list = [];
        if(!is_null($type)){
            if(Data::is_associative_array($where_list)) $where_list['type'] = $type;
            else if(Data::is_array($where_list)) $where_list[] = array('column' => 'type',
                    'value' => $type
                );
            else {
                $error = array('title' => 'System error',
                    'info' => 'Where list is not array'
                );
                throw new PhpException($error);
            }
        }
        foreach($set_list as $column_name => $value)
            $update_set_list[$column_name] = array('column' => $column_name,
                'value' => $value
            );
        $q = array('table' => $table,
            'set' => $update_set_list,
            'where' => $where_list
        );
        return Db::update($q,$name);
    }

    public static function update_data_from_id_list(array $id_list = [],string $table = null, array $set_list = [],int $type = null, array $where_list = [],string $name = null){
        $error_info_list = [];
        if(count($id_list) === 0) $error_info_list[] = 'ID list is empty';
        if(empty($table)) $error_info_list[] = 'Table name is empty';
        if(count($set_list) === 0) $error_info_list[] = 'Set list is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('id_list' => $id_list,
                    'table' => $table,
                    'column_list' => $set_list,
                    'name' => $name
                )
            );
            throw new ParametersException($error);
        }
        $update_set_list = [];
        $where_temp_list = [];
        if(Data::is_associative_array($where_list)) $where_temp_list['id'] = $id_list;
        else if(Data::is_array($where_list)) $where_temp_list[] = array('column' => 'id',
                'value' => $id_list
            );
        else {
            $error = array('title' => 'System error',
                'info' => 'Where list is not array'
            );
            throw new PhpException($error);
        }
        $where_list=array_merge($where_temp_list,$where_list);
        if(!is_null($type)){
            if(Data::is_associative_array($where_list)) $where_list['type'] = $type;
            else if(Data::is_array($where_list)) $where_list[] = array('column' => 'type',
                    'value' => $type
                );
            else {
                $error = array('title' => 'System error',
                    'info' => 'Where list is not array'
                );
                throw new PhpException($error);
            }
        }
        foreach($set_list as $column_name => $value)
            $update_set_list[$column_name] = array('column' => $column_name,
                'value' => $value
            );
        $q = array('table' => $table,
            'set' => $update_set_list,
            'where' => $where_list,
            'limit' => 1
        );
        return Db::update($q,$name);
    }
}