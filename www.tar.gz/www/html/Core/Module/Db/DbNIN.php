<?php

namespace Core\Module\Db;

trait DbNIN {

    public static function get_having(array $data = [], string $name = null){
        if(empty($data['having'])){ $error = ['title' => 'DB query parameters error', 'info' => 'Having is empty', 'data' => $data]; throw new DbQueryParametersException($error); }
        if(!is_array($data['having'])){ $error = ['title' => 'DB query parameters error', 'info' => 'Query parameters of having is not array', 'data' => $data]; throw new DbQueryParametersException($error); }
        return self::get_where_from_key('having', $data, $name);
    }
}