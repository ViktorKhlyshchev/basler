<?php

namespace Core\Module\Db;

use Core\Modules\Data;
use Core\Module\Db\Connect\DbPostgreConnect;
use Core\Module\Exception\DbPdoException;
use Core\Module\Exception\DbParametersException;
use Core\Module\Exception\DbQueryParametersException;
use Core\Module\Exception\DbValidationValueException;
use Core\Module\Exception\ParametersException;
use Core\Modules\Log;

class Db {

    use DbWhere;
    use DbInner;
    use DbInfrequent;
    use DbModel;
    use DbNIN;

    public static $db_connect_list = [];
    public static $db_port_default_list = ['pgsql' => 5432, 'mysql' => 3306];
    public static $db_name_default;
    public static $db_host_default;
    public static $db_login_default;
    public static $db_password_default;
    public static $db_port_default;
    public static $db_type;
    public static $limit_default =10;
    public static $query_last;
    public static $value_last;
    public static $last_error;
    public static $show_qurey = false;
    public static $nextkwaa = false;
    public static $nextkwa = false;

    public static function init(){
        DbPostgreConnect::init();
    }

    public static function is_empty_query(string $query = null){
        if(empty($query)){ $error = ['title' => 'DB parameters problem', 'info' => 'Query is empty']; throw new DbParametersException($error); }
        return false;
    }

    public static function q(string $query = null, string $name = null){
        self::is_empty_query($query);
        $name = self::get_db_name($name);
        try { return self::$db_connect_list[$name]['connect']->query($query); }
        catch(\PDOException $error){
            $data = ['title' => 'PDO Exception', 'info' => 'PDO cannot make query', 'data' => ['db_name' => $name, 'query' => $query, 'error' => $error]];
            Log::erlog($data); if(hand){ pre($data); pred($error); pred('critERRR!'); } # pre($data); pred($error); #if(loc){ pre($data); pred($error); }
            throw new DbPdoException($error, $data);
        }
    }

    public static function get_query(string $query = null, string $name = null){
        self::is_empty_query($query);
        $name = self::get_db_name($name);
        try {
            return self::$db_connect_list[$name]['connect']->query($query);
        }
        catch(\PDOException $error){
            $data = ['title' => 'PDO Exception', 'info' => 'PDO cannot make query', 'data' => ['db_name' => $name, 'query' => $query]];
            throw new DbPdoException($error,$data);
        }
    }

    public static function get_results(string $query = null, string $name = null){
        self::is_empty_query($query);
        $name = self::get_db_name($name);
        $result = self::q($query, $name);
        try { return $result->fetchAll(\PDO::FETCH_ASSOC); }
        catch(\PDOException $error){ $data = ['title' => 'PDO Exception', 'data' => ['db_name' => $name, 'query' => $query]]; throw new DbPdoException($error, $data); }
    }

    public static function get_result(string $query = null, string $name = null){
        $result = self::q($query, $name); # pre($result);        pred($result->fetch(\PDO::FETCH_ASSOC));
        try { return $result->fetch(\PDO::FETCH_ASSOC); }
        catch(\PDOException $error){ $data = ['title' => 'DB bad query in get_result', 'db_name' => $name, 'query' => $query]; pre($error); pre($data); throw new DbPdoException($error, $data); }
    }

    public static function res(string $query = null, string $name = null){
        return self::q($query, $name);
    }

    public static function fetch(object $pdo = null){
        while($r = $pdo->fetch(\PDO::FETCH_ASSOC)) return $r;
    }

    public static function get_insert_id(string $name = null){
        if(self::is_mysql($name)){
            $query = 'SELECT LAST_INSERT_id() as `ID`';
            return self::prepare('select',$query,[],false,$name);
        } else if(self::is_postgresql($name)){
            try { return self::$db_connect_list[$name]['connect']->lastInsertId(); }
            catch(\PDOException $error){ $data = ['title' => 'PDO Exception', 'info' => 'Problem with last insert ID', 'data' => ['db_name' => $name]]; throw new DbPdoException($error, $data); }
        }
        return false;
    }

    public static function get_quote_string(string $query = null, string $name = null){
        self::is_empty_query($query);
        $name = self::get_db_name($name);
        try { return self::$db_connect_list[$name]['connect']->quote($query); }
        catch(\PDOException $error){ $data = ['title' => 'PDO Exception', 'info' => 'PDO cannot make quote string', 'data' => ['db_name' => $name]]; throw new DbPdoException($error, $data); }
    }

    public static function get_parameters_type($value){
        if(is_null($value)) return \PDO::PARAM_NULL;
        if(is_string($value))
            switch($value){
                case 'null':
                case 'null':
                    return \PDO::PARAM_NULL;
            }
        $type = gettype($value);
        switch($type){
            case 'boolean': {
                return \PDO::PARAM_BOOL;
                break;
            }
            case 'integer': {
                return \PDO::PARAM_INT;
                break;
            }
            case 'function':
            case 'string': {
                return \PDO::PARAM_STR;
                break;
            }
            default: {
                return \PDO::PARAM_STR;
                break;
            }
        }
    }

    public static function get_quote_column(string $name = null){
        $name = self::get_db_name($name);
        $db_type = self::get_db_type($name);
        switch($db_type){
            case 'mysql': return'`';
            case 'pgsql': return'"';
            default: {
                $error = array('title' => 'Parameters problem',
                    'info' => 'DB type is not exists in connect list #2',
                    'data' => array('name' => $name
                    )
                );
                throw new ParametersException($error);
            }
        }
    }

    public static function get_quote_value(string $name = null){
        $name = self::get_db_name($name);
        $db_type = self::get_db_type($name);
        switch($db_type){
            case 'pgsql':
            case 'mysql': return"'";
            default: {
                $error = array('title' => 'Parameters problem',
                    'info' => 'DB type is not exists in connect list #3',
                    'data' => array('name' => $name
                    )
                );
                throw new ParametersException($error);
            }
        }
    }

    public static function get_join(array $data = [],string $name = null){
        if(empty($data['join'])){
            $error = ['title' => 'DB query parameters error', 'info' => 'DB query array have not JOIN key', 'data' => $data];
            throw new DbQueryParametersException($error);
        }
        if(!is_array($data['join'])){
            $error = ['title' => 'DB query parameters error', 'info' => 'Query parameters of JOIN is not array', 'data' => $data];
            throw new DbQueryParametersException($error);
        }
        $join ='';
        $value_list = [];
        $name = self::get_db_name($name);
        $column_quote = self::get_quote_column($name);
        foreach($data['join'] as $row)
            if(!empty($row['table'])){
                $type = empty($row['type']) ? 'INNER JOIN' : (strtoupper($row['type']).' JOIN');
                $rename = empty($row['rename']) ? '':$row['rename'];
                $join_add = null;
                list($where,$value_add_list) = self::get_where($row, $name);
                $value_list=array_merge($value_add_list,$value_list);
                if(!empty($row['join'])){
                    list($join_add,$value_add_list)=self::get_join($row,$name);
                    $value_list=array_merge($value_add_list,$value_list);
                }
                if(empty($join_add))
                    $join .=  $type.' '.$column_quote.$row['table'].$column_quote.(empty($rename) ? '' : (' AS '.$column_quote.$rename.$column_quote)).' ON '.$where;
                else
                    $join .=  $type.' ('.$column_quote.$row['table'].$column_quote.(empty($rename) ? '' : (' AS '.$column_quote.$rename.$column_quote)).' '.$join_add.') '.$where;
            }
            return [(empty($join) ? '':' ').$join, $value_list];
    }

    public static function get_order(array $data = [], string $name = null){
        if(!is_array($data['order'])){ $error = ['title' => 'DB query parameters error', 'info' => 'Query parameters of ORDER is not array', 'data' => $data]; throw new DbQueryParametersException($error); }
        $order_list = [];
        $quote = self::get_quote_column($name);
        $name = self::get_db_name($name); #pre($data['order']);
        foreach($data['order'] as $row){ #pre($row); pre(Data::is_associative_arrays($row));
            if(Data::is_associative_array($row)){
                $temp = self::get_column_name($row, false, $name); #pred($row);
                if(!empty($row['direction']))
                    switch(strtolower($row['direction'])){
                        case 'desc':
                        case 'asc': {
                            $temp .=  ' '. strtoupper($row['direction']);
                            break;
                        }
                    }
                $order_list[] = $temp;
            } else if(Data::is_string($row)) $order_list[] = $quote.$row.$quote;
        } #        pred($order_list);
        return count($order_list) === 0 ? '' : implode(', ', $order_list);
    }

    public static function get_group(array $data = [], string $name = null){
        if(!is_array($data['group'])){ $error = ['title' => 'DB query parameters error', 'info' => 'Query parameters of GROUP is not array']; throw new DbQueryParametersException($error); }
        $group_list = [];
        $quote = self::get_quote_column($name);
        foreach($data['group'] as $row)
            if(Data::is_associative_array($row)) $group_list[] = self::get_column_name($row,false,$name);
            else if(Data::is_string($row)) $group_list[] = $quote.$row.$quote;
        return count($group_list) === 0?'':implode(', ',$group_list);
    }

    public static function get_limit(array $data = [],string $name = null){
        if(is_integer($data['limit'])) return $data['limit'];
        if(empty($data['limit'])) return '';
        if(!is_array($data['limit'])){
            $error = [
                'title' => 'DB query parameters error',
                'info' => 'Query parameters of LIMIT is not array',
                'data' => $data];
            throw new DbQueryParametersException($error);
        }
        $c = count($data['limit']);
        if($c === 0){
            $error = [
                'title' => 'DB query parameters error',
                'info' => 'Query parameters of LIMIT have not parameters',
                'data' => $data];
            throw new DbQueryParametersException($error);
        }
        if($c === 1) return $data['limit'][0];
        if($c === 2){
            if(self::is_mysql($name))
                return implode(', ',array_values($data['limit']));
            else if(self::is_postgresql($name))
                return $data['limit'][1].' OFFSET '.$data['limit'][0];
            else {
                $error = [
                    'title' => 'DB query parameters error',
                    'info' => 'DB type is not valid',
                    'data' => $data];
                throw new DbQueryParametersException($error);
            }
        } else {
            $error = [
                'title' => 'DB query parameters error',
                'info' => 'Query parameters of LIMIT array have more 2 parameters',
                'data' => $data];
            throw new DbQueryParametersException($error);
        }
    }

    public static function get_duplicate(array $data = [],string $name = null){
        if(empty($data['duplicate'])) return '';
        if(!is_array($data['duplicate'])){
            $error = array('title' => 'DB query parameters error',
                'info' => 'Query parameters of DUPLICATE is not array',
                'data' => $data
            );
            throw new DbQueryParametersException($error);
        }
        if(count($data['duplicate']) === 0){
            $error = array('title' => 'DB query parameters error',
                'info' => 'Query parameters of DUPLICATE have not parameters',
                'data' => $data
            );
            throw new DbQueryParametersException($error);
        }
        if(self::is_mysql($name)) return'';
        else if(self::is_postgresql($name)){
            switch($data['duplicate']['type']){
                case 'ignore':
                    return 'ON CONFLICT ("id") DO NOTHING';
                default:
                    return'';
            }
        }
        else {
            $error = array('title' => 'DB query parameters error',
                'info' => 'DB type is not valid',
                'data' => $data
            );
            throw new DbQueryParametersException($error);
        }
    }

    public static function get_select(array $data = [],string $name = null){
        #if(!is_array($data['select']) && is_string($data['select'])){ $data['select'] = [$data['select']]; }
        if(!is_array($data['select'])){
            $error = ['title' => 'DB query parameters error', 'info' => 'Query parameters of SELECT is not array', 'data' => $data];
            throw new DbQueryParametersException($error);
        }
        $select_list = [];
        $quote = self::get_quote_column($name);
        foreach($data['select'] as $row)
            if(!empty($row)){
                if(Data::is_associative_array($row)){
                    if(!empty($row['column']) || !empty($row['function'])) $select_list[] = self::get_column_name($row, false, $name);
                    else {
                        $error = ['title' => 'DB query parameters error', 'info' => 'Select column is empty', 'data' => $data];
                        throw new DbQueryParametersException($error);
                    }
                }
                else if(is_string($row))
                    $select_list[] = $quote.$row.$quote;
                else {
                    $error = ['title' => 'DB query parameters error', 'info' => 'Select row have not valid type', 'data' => $data];
                    throw new DbQueryParametersException($error);
                }
            }
            else {
                $error = ['title' => 'DB query parameters error', 'info' => 'Select row is empty', 'data' => $data];
                throw new DbQueryParametersException($error);
            }
        return implode(', ',$select_list);
    }

    public static function get_set(array $data = [], string $name = null){
        if(!is_array($data['set'])){
            $error = ['title' => 'DB query parameters error', 'info' => 'Query parameters of SET is not array', 'data' => $data];
            throw new DbQueryParametersException($error);
        }
        $set_list = [];
        $value_list = [];
        $name = self::get_db_name($name);
        $column_quote = self::get_quote_column($name);
        if(Data::is_associative_array($data['set'])){
            foreach($data['set'] as $key => $value){
                $column = $column_quote.$key.$column_quote;
                if(Data::is_associative_array($value)){
                    if(!empty($value['function']))
                        $set_list[] = $column.'='.$value['function'];
                    else if(!empty($value['value'])){
                        $set_list[] = $column.' = ?';
                        $value_list[] = $value['value'];
                    }
                } else {
                    $set_list[] = $column.' = ?';
                    $value_list[] = $value;
                }
            }
        }
        else if(Data::is_array($data['set'])){
            foreach($data['set'] as $row)
                if(!empty($row['column'])){ #$table = empty($row['table']) ? '':$row['table'];
                    $column = self::get_column_name($row); # $set_list[] = $column.' = ?'; # $set_list[] =(empty($table) ? '':($column_quote.$table.$column_quote.'.')).$column_quote.$row['column'].$column_quote.' = ?';
                    if(!empty($row['function'])) $set_list[] = $column.'='.$row['function'];
                    else if(!empty($row['value'])){
                        if(Data::is_associative_array($row['value'])){
                            if(!empty($row['value']['function'])) $set_list[] = $column.'='.$row['value']['function'];
                        } else {
                            $set_list[] = $column.' = ?';
                            $value_list[] = $row['value'];
                        }
                    }
                }
                else if(!empty($row['update'])){
                    list($select_query,$value_list_add) = self::get_select_query($row, $name);
                    $set_list[] ='('.$column_quote.implode($column_quote.','.$column_quote,$row['update']).$column_quote.') = ('.$select_query.')';
                    $value_list =array_merge($value_list,$value_list_add);
                }
                else if(!empty($row['function'])) $set_list[] = $row['function'];
        }
        return [implode(', ', $set_list), $value_list];
    }

    public static function get_table_name(array $data = []){
        if(empty($data['table']) && empty($data['tableas'])){
            $error = ['title' => 'DB query parameters error', 'info' => 'Query parameters of TABLE is empty', 'data' => $data];
            throw new DbQueryParametersException($error);
        }
        if(is_string($data['table'])) return $data['table'];
        if(!is_array($data['table'])){
            $error = ['title' => 'DB query parameters error', 'info' => 'Query parameters of TABLE is not array', 'data' => $data];
            throw new DbQueryParametersException($error);
        }
        return empty($data['table']['name'])?false:$data['table']['name'];
    }

    public static function get_column_name(array $data = [], bool $is_join = false, string $name = null){
        $join = $is_join ? '_join' : '';
        if(empty($data['column'. $join]) && empty($data['function'. $join])){
            $error = array('title' => 'DB query parameters error',
                'info' => 'Query parameters of column name is empty',
                'data' => $data
            );
            throw new DbQueryParametersException($error);
        }
        $name = self::get_db_name($name);
        $quote = self::get_quote_column($name);
        if(isset($data['function'.$join])) $column = $data['function'.$join];
        else
            $column = $quote . $data['column'. $join] . $quote; #pred($column);
        if(!empty($data['table'. $join])) $column = $quote.$data['table'.$join].$quote.'.'.$column;
        if(!empty($data['rename'. $join])) $column .=  ' AS '. $quote . $data['rename'. $join] . $quote;
        return $column;
    }

    public static function get_validation_value_list_from_join($table_default,array $list = []){
        foreach($list as $row){
            if(isset($row['join']))
                if(!self::get_validation_value_list_from_join($table_default,$row['join'])){
                    $error = array('title' => 'DB query parameters error',
                        'info' => 'Query parameters in JOIN list is not valid',
                        'data' => array('row' => $row,
                            'list' => $list
                        )
                    );
                    throw new DbValidationValueException($error);
                }
            if(isset($row['where']))
                if(!self::get_validation_value_list($table_default,$row['where'])){
                    $error = array('title' => 'DB query parameters error',
                        'info' => 'Query parameters in JOIN list is not valid for WHERE',
                        'data' => array('row' => $row,
                            'list' => $list
                        )
                    );
                    throw new DbValidationValueException($error);
                }
        }
        return true;
    }

    public static function validation_value(array $data = []){
        $table_default=self::get_table_name($data);
        $is_valid_set =true;
        $is_valid_where =true;
        $is_valid_join =true;
        if(isset($data['set'])) $is_valid_set=self::get_validation_value_list($table_default,$data['set']);
        if(isset($data['join'])) $is_valid_join=self::get_validation_value_list_from_join($table_default,$data['join']);
        if(isset($data['where'])) $is_valid_where=self::get_validation_value_list($table_default,$data['where']);
        return $is_valid_set&&$is_valid_join&&$is_valid_where;
    }

    public static function exec(string $query = null, string $name = null){
        self::is_empty_query($query);
        $name = self::get_db_name($name);
        try {
            return self::$db_connect_list[$name]['connect']->exec($query);
        } catch(\PDOException $error){ pre($error); # if(hand)
            $data = ['title' => 'PDO Exception', 'info' => 'PDO cannot make exec', 'data' => ['db_name' => $name, 'query' => $query]]; throw new DbPdoException($error, $data);
        }
    }

    public static function execr(string $query = null, string $name = null){
        self::is_empty_query($query);
        $name = self::get_db_name($name);
        try {
            return self::$db_connect_list[$name]['connect']->exec($query);
        } catch(\PDOException $error){ pre($error); # if(hand)
            $data = ['error' => $error, 'title' => 'PDO Exception', 'info' => 'PDO cannot make exec', 'data' => ['db_name' => $name, 'query' => $query]];
            return $data;
        }
    }

    public static function insert(array $data = [], bool $need_insert_id = true, array $return_list = [], string $name = null, array $return_on_conflict_list = []){
        self::isset_table_parameters($data);
        self::isset_values_parameters($data);
        if(Data::is_associative_array($data['values'])){
            foreach($data['values'] as $column => $value)
                if(!DbValidationValue::init(self::get_table_name($data), $column, $value)){
                    $error = ['title' => 'DB query parameter valid problem', 'info' => 'Parameter in value list is not valid',
                        'data' => ['line' => ['table' => $data['table'], 'column' => $column, 'value' => $value], 'data' => $data]];
                    throw new DbValidationValueException($error);
                }
            $value_len = count($data['values']);
            $value_key_list = array_keys($data['values']);
            $data['values'] = [$data['values']];
        } else if(Data::is_array($data['values'])){
            if(!count($data['values'])){
                $error = ['title' => 'DB query parameters problem', 'info' => 'Values list is empty', 'data' => ['data' => $data]];
                throw new DbQueryParametersException($error);
            }
            $current_len = count($data['values'][0]);
            $cvals = count($data['values']);
            for($i=1; $i < $cvals; $i++){
                $cvalsi = count($data['values'][$i]);
                if($current_len !== $cvalsi){
                    $error = ['title' => 'DB query parameters problem', 'info' => 'ProfileList parameters in values list have not same length', 'data' => ['data' => $data]];
                    throw new DbQueryParametersException($error);
                }
            }
            foreach($data['values'] as $row)
                foreach($row as $column => $value)
                    if(!DbValidationValue::init(self::get_table_name($data), $column, $value)){
                        $error = ['title' => 'DB query parameter valid problem',
                            'info' => 'Parameter in value list is not valid',
                            'data' => ['row' => $row, 'line' => ['table' => $data['table'], 'column' => $column, 'value' => $value], 'data' => $data]];
                        throw new DbValidationValueException($error);
                    }
            $value_len = count($data['values'][0]);
            $value_key_list = array_keys($data['values'][0]);
        } else {
            $error = ['title' => 'DB query parameter problem', 'info' => 'Query is not valid', 'data' => ['data' => $data]];
            throw new DbQueryParametersException($error);
        }
        $table = self::get_table_name_full($data,$name);
        $name = self::get_db_name($name);
        $quote = self::get_quote_column($name);
        $duplicate = self::get_duplicate($data,$name);
        $query ='INSERT INTO ' .$table. ' ('. $quote . implode($quote .','. $quote, $value_key_list) . $quote .') VALUES';
        $query_list = [];
        $value_list = [];
        foreach($data['values'] as $row){
            $query_list[] ='('. implode(', ', array_fill(0, $value_len, '?')) . ')';
            $temp = [];
            foreach($row as $value){
                if(is_null($value) || $value === '') $value='null';
                $temp[] = $value;
            }
            $value_list = array_merge($value_list,$temp);
        }
        $query .= implode(',', $query_list);
        if(!empty($duplicate)) $query .= ' '. $duplicate;
        if(self::is_postgresql($name)){
            $return_query_list = [];
            if(!count($return_on_conflict_list)){
                if($need_insert_id) $return_query_list[] = 'id';
                if(count($return_list)) $return_query_list=array_merge($return_query_list,$return_list);
                if(count($return_query_list)) $query .= ' RETURNING "'.implode('","',$return_query_list).'"';
            } else {
                $conflict_line ='ON CONFLICT ("'.implode('","',$return_on_conflict_list['column_list']).'")';
                $conflict_line .= ' DO UPDATE SET ';
                $update_list = [];
                foreach($return_on_conflict_list['column_list'] as $column_name) $update_list[] = '"'.$column_name.'"=EXCLUDED."'.$column_name.'"';
                $set_list = '';
                if(isset($return_on_conflict_list['update_list']))
                    if(count($return_on_conflict_list['update_list']) > 0){
                        list($set_list,$set_value_list)=self::get_set($return_on_conflict_list['update_list'],$name);
                        $value_list=array_merge($value_list,$set_value_list);
                    }
                $conflict_line .= implode(', ',$update_list).(!empty($set_list) ? (','.$set_list):'');
                if(count($return_query_list) > 0)
                    $return_on_conflict_list['return_list'] = array_merge($return_query_list,$return_on_conflict_list['return_list']);
                $conflict_line .= ' RETURNING "'.implode('","',$return_on_conflict_list['return_list']).'"';
                $query .= ' '.$conflict_line;
            }
        }
        $r = self::prepare('insert', $query,$value_list, $need_insert_id,$name);
        return $r;
    }

    public static function get_select_query(array $data = [], string $name = null){

        self::isset_select_parameters($data);
        self::isset_table_parameters($data);
        $select = self::get_select($data, $name);
        $name = self::get_db_name($name);
        $db_type = self::get_db_type($name);
        $table = self::get_table_name_full($data, $name);
        $straight = '';
        $join = '';
        $where = '';
        $group = '';
        $order = ''; #$limit = self::$limit_default;
        $value_list = [];
        if(!empty($data['join'])){
            self::isset_join_parameters($data);
            list($join, $value_add_list) = self::get_join($data, $name);
            $value_list = array_merge($value_list, $value_add_list);
            if($db_type ===  'mysql') $straight = ' STRAIGHT_JOIN';
        }

        if(!empty($data['where'])){  #if($data['table'] === 'journal') pred($data);
            list($where, $value_add_list) = self::get_where($data, $name);
            $value_list = array_merge($value_list, $value_add_list);
        }

        if(!empty($data['group'])){
            self::isset_group_parameters($data);
            $group = self::get_group($data, $name);
        }
        if(!empty($data['order'])){ #pre($data['order']); pre($name);
            self::isset_order_parameters($data);
            $order = self::get_order($data, $name); #pred($order);
        }
        if(!empty($data['limit'])){
            self::isset_limit_parameters($data);
            $limit = self::get_limit($data, $name);
        }
        $query = 'SELECT'. $straight .' '. $select .' FROM '. $table . $join
            . (empty($where) ? '' : (' WHERE '. $where))
            . (empty($group) ? '' : (' GROUP BY '. $group))
            . (empty($order) ? '' : (' ORDER BY '. $order))
            . (empty($limit) ? '' : (' LIMIT '.$limit)); #pre($query);
        return [$query, $value_list];
    }

    public static function get_select_queryc(array $data = [], string $name = null){

        self::isset_select_parameters($data);
        self::isset_table_parameters($data);
        $select = self::get_select($data, $name);
        $name = self::get_db_name($name);
        $db_type = self::get_db_type($name);
        $table = self::get_table_name_full($data, $name);
        $straight = '';
        $join = '';
        $where = '';
        $group = '';
        $order = ''; #$limit = self::$limit_default;
        $value_list = [];
        if(!empty($data['join'])){
            self::isset_join_parameters($data);
            list($join, $value_add_list) = self::get_join($data, $name);
            $value_list = array_merge($value_list, $value_add_list);
            if($db_type ===  'mysql') $straight = ' STRAIGHT_JOIN';
        }
        #pred($data);
        if(!empty($data['where'])){
            #if($data['table'] === 'journal') pred($data);
            list($where, $value_add_list) = self::get_where($data, $name);
            #if($data['table'] === 'journal') pred($data);
            #pre($data['where']);
            $value_list = array_merge($value_list, $value_add_list);
            #if($data['table'] === 'journal') pred($data);
        }
        if(!empty($data['group'])){
            self::isset_group_parameters($data);
            $group = self::get_group($data, $name);
        }
        if(!empty($data['order'])){ #pre($data['order']); pre($name);
            self::isset_order_parameters($data);
            $order = self::get_order($data, $name); #pred($order);
        }
        if(!empty($data['limit'])){
            self::isset_limit_parameters($data);
            $limit = self::get_limit($data, $name);
        }
        $query = 'SELECT'. $straight .' '. $select .' FROM '. $table . $join
            . (empty($where) ? '' : (' WHERE '. $where))
            . (empty($group) ? '' : (' GROUP BY '. $group))
            . (empty($order) ? '' : (' ORDER BY '. $order))
            . (empty($limit) ? '' : (' LIMIT '.$limit)); #pre($query);
        return [$query, $value_list];
    }

    public static function select(array $data = [], string $name = null){
        list($query, $value_list) = self::get_select_query($data, $name);
        #if($value_list[0] !== '37.9.129.6' && strpos($query, 'name_lower') === false && strpos($query, 'token') === false && strpos($query, 'ip_') === false && strpos($query, '_user') === false && strpos($query, '_lang') === false && strpos($query, '_browser') === false && strpos($query, 'xavier_info') === false) pred($query);
        # pred($value_list); if(strpos($query, 'xavier_info') !== false){ pre($query); pred($value_list); }
        $r = self::prepare('select', $query, $value_list, false, $name);
        #if(strpos($query, 'traffic_violation') !== false){  pre($query, $value_list); #pred($r);  #pred(debug_backtrace());  }
        #if(strpos($query, 'traffic_violation') !== false){  pre($query); pred($value_list); } #pred($r);  #pred(debug_backtrace());  }
        #if(strpos($query, 'date_start_track') !== false){  pre($query); pred($value_list); } #pred($r);  #pred(debug_backtrace());  }
        return $r; #return self::prepare('select',$query,$value_list,false,$name);
    }

    public static function selectd(array $data = []){
        self::$show_qurey = true;
        list($query, $value_list) = self::get_select_query($data);
        $r = self::prepare('select', $query, $value_list, false);
        return $r;
    }

    public static function selectc(array $data = [], string $name = null){
        list($query, $value_list) = self::get_select_query($data, $name);
        #if($value_list[0] !== '37.9.129.6' && strpos($query, 'name_lower') === false && strpos($query, 'token') === false && strpos($query, 'ip_') === false && strpos($query, '_user') === false && strpos($query, '_lang') === false && strpos($query, '_browser') === false && strpos($query, 'xavier_info') === false) pred($query);
        # pred($value_list); if(strpos($query, 'xavier_info') !== false){ pre($query); pred($value_list); }
        $r = self::prepare('select', $query, $value_list, false, $name);
        #if(strpos($query, 'traffic_violation') !== false){  pre($query, $value_list); #pred($r);  #pred(debug_backtrace());  }
        #if(strpos($query, 'traffic_violation') !== false){  pre($query); pred($value_list); } #pred($r);  #pred(debug_backtrace());  }
        return $r; #return self::prepare('select',$query,$value_list,false,$name);
    }

    public static function delete(array $data = [], string $name = null){
        self::isset_table_parameters($data);
        self::isset_where_parameters($data);
        if(!self::validation_value($data)){
            $error = ['title' => 'DB query parameter have valid problem', 'info' => 'Parameters is not valid', 'data' => $data];
            throw new DbValidationValueException($error);
        }
        list($where, $value_list) = self::get_where($data, $name); #pred($where);
        $table = self::get_table_name_full($data, $name);
        $name = self::get_db_name($name);
        $db_type = self::get_db_type($name);
        $limit ='';
        if($db_type === 'mysql' && !empty($data['limit'])) $limit = self::get_limit($data, $name);
        $query = 'DELETE FROM '. $table .' '. (empty($where) ? '' : (' WHERE '.$where)) . (empty($limit) ? '' : (' LIMIT '.$limit)); #pred($query);
        #if(1 || \Config::$is_query_debug) pre(self::qass($query, $value_list));
        #pred(self::qass($query, $value_list));
        #pre(self::prepare('delete', $query, $value_list, true, $name));
        return self::prepare('delete', $query, $value_list, true, $name);
    }

    public static function vacuum_full(string $table = null, string $name = null){
        if(empty($table)){ $error = ['title' => 'Parameters problem', 'info' => 'Table is empty']; throw new ParametersException($error); }
        $name = self::get_db_name($name);
        $query ='VACUUM FULL "'.$table.'"';
        return self::exec($query,$name);
    }

    public static function update(array $data = [], string $name = null, $extra = null){
        self::isset_table_parameters($data);
        self::isset_set_parameters($data);
        self::isset_where_parameters($data);
        if(!self::validation_value($data)){
            $error = ['title' => 'DB query parameter have valid problem',  'info' => 'Parameters is not valid', 'data' => $data]; #pred($error);
            throw new DbValidationValueException($error);
        }
        list($set, $value_list) = self::get_set($data,$name);
        list($where, $value_add_list) = self::get_where($data, $name);
        $table = self::get_table_name_full($data,$name);
        $name = self::get_db_name($name);
        $db_type = self::get_db_type($name);
        $limit = '';
        $value_list = array_merge($value_list, $value_add_list);
        if($db_type === 'mysql' && !empty($data['limit'])) $limit = self::get_limit($data,$name);
        $query = 'UPDATE '.$table.' SET '. $extra . $set.(empty($where) ? '' : (' WHERE '.$where)) . (empty($limit) ? '' : (' LIMIT '.$limit)); #pred($query); #pre($error);
        #if(strpos($query, 'journal') !== false && strpos($query, 'UPDATE') !== false) pred($query);# pred(44444);
        return self::prepare('update', $query, $value_list, true, $name);
    }

    public static function qass($string, $data){
        $indexed = $data == array_values($data);
        foreach($data as $k => $v){
            if(is_string($v)) $v = "'$v'"; #else pred($v);
            if($indexed) $string=preg_replace('/\?/',$v,$string,1);
            else $string=str_replace(":$k",$v,$string);
        }
        return $string;
    }

    public static function prepare(string $query_type = null, string $query = null, array $value_list = [], $need_insert_id = true, string $name = null){
        #pred(debug_backtrace());
        #if(self::$show_qurey){ pre($query); pred(debug_backtrace());}
        if(0){ # QUERY DEBUG!! #  || \Config::$is_query_debug
            pre($query);
            pre($value_list);
            pre(self::qass($query, $value_list));
            pre($value_list); pre(self::qass($query, $value_list));
            #echo " === === === === === === === === === === === \n";            echo $query."\n";
            #print_r($value_list);            echo " === === === === === === === === === === === \n";
        }
        self::$query_last = $query;
        self::$value_last = $value_list;
        #if(strpos($query, 'journal') !== false && strpos($query, 'UPDATE') !== false) $f = 1;
        #if(strpos($query, 'journal_image') !== false && strpos($query, 'SELECT') !== false) $f = 1;
        #if(strpos($query, 'journal') !== false && strpos($query, 'UPDATE') !== false) pre($query);# pred(44444);
        #if(strpos($query, 'journal') !== false && strpos($query, 'UPDATE') !== false) pred($query);# pred(44444);
        #if(strpos($query, 'DESC LIMIT 100 OFFSET 0') === false) pred($query);# pred(44444);
        #if(strpos($query, 'date_create0') !== false) pred(debug_backtrace());# pred(44444);
        #if(strpos($query, 'traffic_violation') !== false) pred(debug_backtrace());# pred(44444);
        if(0){
            if(strpos($query, 'date_start_track') !== false){ pre($query); pre($value_list); pre(self::qass($query, $value_list)); }
            if(strpos($query, 'tid') !== false){ pre($query); pre($value_list); pre(self::qass($query, $value_list)); }
            if(strpos($query, 'image') !== false){ pre($query); pre($value_list); pre(self::qass($query, $value_list)); }
            if(strpos($query, 'video') !== false){ pre($query); pre($value_list); pre(self::qass($query, $value_list)); }
        } # pred(self::$show_qurey);
        #if(self::$show_qurey){ pre($query); pre($value_list); pred(self::qass($query, $value_list)); }
        self::is_empty_query($query);
        $name = self::get_db_name($name);
        try { # if(self::$show_qurey){ pred($query); }
            $query_statement = self::$db_connect_list[$name]['connect']->prepare($query); #pred(debug_backtrace());
            self::$db_connect_list[$name]['connect']->beginTransaction();
            $num = 1; #if($f) pred($query); #if($f) pre($value_list);
            #if($f) pre($value_list[5]); #if($f) pred(self::get_parameters_type($value_list[5]));
            #if(self::$show_qurey) pre($value_list); if(self::$show_qurey) pred($value_list[1]);
            foreach($value_list as $row){
                $type = self::get_parameters_type($row);# pre($type); #if($f) #pred(\PDO::PARAM_NULL); #pre($type);
                if(is_array($num)){ pre($num); pre(debug_backtrace()); }
                if(is_array($row)){ pre($row); pre('$row <b>Notice</b>:  Array to string conversion !!! '); pre(debug_backtrace()); }
                if(is_array($type)){ pre($type); pre(debug_backtrace()); }
                #if(strpos($query, 'tid') !== false){ pre($num); pre($row); pre($type); }
                # if(self::$show_qurey){ pre($row); pre($type); }
                $query_statement->bindValue($num, $row, $type);
                $num++;
            }  #$query_statement->bindParam(':keyword', '(value::integer+2)::varchar', \PDO::PARAM_STR);
            #if(self::$show_qurey){ pre($query); pred($rr); }
            #if(self::$show_qurey){ pre($value_list); pred($query_statement); }
            if(self::$show_qurey){ pre(self::qass($query, $value_list)); }
            $rr = $query_statement->execute();
            # if(self::$show_qurey){ pre($query); pred($rr); }
            #if(1 && strpos($query, 'upload_server') !== false){ pred($rr); }
            self::$db_connect_list[$name]['connect']->commit(); #pred($query_type);
            #if(1 && strpos($query, 'upload_server') !== false){ pred($query_type); }
            switch($query_type){ #pre(self::qass($query, $value_list));
                case 'select':{ #$r = $query_statement->fetchAll(\PDO::FETCH_ASSOC); #if(1 && strpos($query, 'upload_server') !== false){ pred($r); }
                    #if(self::$show_qurey){ pre($query); pred($rr); }
                    #if(self::$show_qurey){ $r = $query_statement->fetchAll(\PDO::FETCH_ASSOC); pred($r);};
                    return $query_statement->fetchAll(\PDO::FETCH_ASSOC);
                }
                case 'insert': { #pred($need_insert_id);
                    if($need_insert_id){
                        if(self::is_postgresql($name)){
                            $list = $query_statement->fetchAll(\PDO::FETCH_ASSOC); #pred($list); #pre(debug_backtrace());
                        } else if(self::is_mysql($name)) $list = [self::get_insert_id($name)];
                        else throw new DbParametersException(['title' => 'DB parameters problem', 'info' => 'Unknown DB type', 'data' => ['name' => $name, 'type' => self::get_db_type($name)]]); #if(\Config::$is_query_debug) pre($list);
                        return $list;
                    }
                    return self::$db_connect_list[$name]['connect']->errorCode() === '00000';
                }
                case 'update': {
                    #pre($name);
                    $r = self::$db_connect_list[$name]['connect']->errorCode() === '00000'; #pred($r);
                    if(!$r){ pre(self::$db_connect_list[$name]['connect']->errorCode()); pred($r);
                        $r = ['query_type' => $query_type, 'q' => self::qass($query, $value_list), 'query' => $query, 'value_list' => $value_list, 'need_insert_id' => $need_insert_id,'db_name' => $name];
                        pre($r);
                        pred(debug_backtrace());
                    } else {
                        #$r = ['query_type' => $query_type, 'q' => self::qass($query, $value_list), 'query' => $query, 'value_list' => $value_list, 'need_insert_id' => $need_insert_id,'db_name' => $name];
                        #pre($r);
                    }
                    # pred(self::$db_connect_list[$name]['connect']->errorCode());
                    # pre(self::qass($query, $value_list));
                    #return self::$db_connect_list[$name]['connect']->errorCode() === '0000';
                    return $r;
                }
                default: return self::$db_connect_list[$name]['connect']->errorCode() === '00000';
            } #$r = self::$db_connect_list[$name]['connect']->errorCode() === '00000'; return $r;
        } catch(\PDOException $error){
            #if(self::$show_qurey){ pre($query); pred($rr); }
            #pre($query_type); pre(self::$query_last);pre(self::$value_last); #pre(self::qass(self::$query_last, self::$value_last));pre($error);
            #pre(self::qass($query, $value_list));
            $r = ['query_type' => $query_type, 'q' => self::qass($query, $value_list), 'query' => $query, 'value_list' => $value_list, 'need_insert_id' => $need_insert_id,'db_name' => $name]; #pre($r); #if(self::$show_qurey){ pred($r); }
            self::$db_connect_list[$name]['connect']->rollback();
            $data = ['title' => 'PDO Exception', 'info' => 'PDO cannot make transaction', 'error' => $error, 'data' => ['query_type' => $query_type, 'query' => $query, 'value_list' => $value_list, 'need_insert_id' => $need_insert_id, 'db_name' => $name]]; #pre($data); pre(debug_backtrace());
            if(self::$show_qurey){ pred($data); }
            self::$last_error = $data; #pred($data);
            return $data; # throw new DbPdoException($error, $data);            throw new \Exception(json_encode([$error, $data]));
        }
    }

    public static function set_max_current_value_in_sequence(string $table = null, string $name = null){
        if(empty($table)){ $error = ['table' => 'DB parameters problem', 'info' => 'Table name is empty']; throw new DbParametersException($error); }
        $db_type = self::get_db_type($name);
        switch($db_type){
            case 'pgsql': return self::exec('SELECT setval(\''.$table.'_id_seq\', COALESCE((SELECT MAX("id")+1 FROM "'.$table.'"), 1), false)');
            default: return false;
        }
    }

    public static function truncate_table(string $table = null, string $name = null){
        if(empty($table)){ $error = ['table' => 'DB parameters problem', 'info' => 'Table name is empty']; throw new DbParametersException($error); }
        $db_type=self::get_db_type($name);
        switch($db_type){ # case 'pgsql': return self::exec('TRUNCATE "'.$table.'" RESTART IDENTITY');
            case 'pgsql': return self::exec('TRUNCATE "'.$table.'" RESTART IDENTITY'); # case 'mysql': return self::exec('TRUNCATE `'.$table.'`');
            default: return false;
        }
    }
}