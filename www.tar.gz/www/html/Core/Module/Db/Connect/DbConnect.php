<?php

namespace Core\Module\Db\Connect;

use Core\Module\Db\Db;
use Core\Module\Exception\DbPdoConnectException;
use Core\Module\Exception\DbQueryParametersException;

class DbConnect {

    public static function init(array $db_config = []){ #pred($db_config);
        if(empty($db_config['type'])){
            $error = ['title' => 'DB problem with config', 'info' => 'DB config have not DB type'];
            throw new DbQueryParametersException($error);
        }

        if(empty(Db::$db_connect_list[$db_config['name']])){
            Db::$db_connect_list[$db_config['name']] = $db_config;
            $reconnect = [\PDO::ATTR_PERSISTENT => true];
            if(empty($db_config['login'])){ $error = ['title' => 'DB problem with config', 'info' => 'DB login in config is empty']; pre($error); throw new DbQueryParametersException($error); }
            if(empty($db_config['name'])){ $error = ['title' => 'DB problem with config', 'info' => 'DB name in config is empty']; pre($error); throw new DbQueryParametersException($error); }

            $connect_query = $db_config['type'] .':host='. $db_config['host'] .';port='. $db_config['port'] .';dbname='. $db_config['name'];
            try {
                Db::$db_connect_list[$db_config['name']]['connect'] = new \PDO($connect_query, $db_config['login'], $db_config['password'], $reconnect);
                Db::$db_connect_list[$db_config['name']]['connect']->setAttribute(\PDO::ATTR_ERRMODE,\PDO::ERRMODE_EXCEPTION);
                return true;
            } catch(\PDOException $error){ #pred(Db::$db_connect_list);
                $data = ['title' => 'PDO connect exception', 'info' => 'PDO cannot make connect', 'q' => $connect_query];
                if(strpos($error->getMessage(), 'does not exist')) pred('PDO cannot make connect - DB not exist'); #pred($error->getMessage());
                pre($error); pre($data);
                throw new DbPdoConnectException($error, $data);
            } #pred(Db::$db_connect_list);
        }
        return false;
    }
}