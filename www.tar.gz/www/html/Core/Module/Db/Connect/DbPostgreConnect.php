<?php

namespace Core\Module\Db\Connect;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryParametersException;

use Core\Module\Worktime\Worktime;

class DbPostgreConnect {

    public static function init(){
        Worktime::set_timestamp_point('DataBase Connect Start');
        $config = \Config::$db;
        if(empty($config)){ $error = ['title' => 'DB config problem', 'info' => 'DB config is empty']; pred($error); throw new DbQueryParametersException($error); }
        if(!DbConnect::init($config)){ $error = ['title' => 'DB connect problem', 'info' => 'DB was not connect']; pred($error); throw new DbQueryParametersException($error); }
        Db::$db_host_default = $config['host'];
        Db::$db_name_default = $config['name'];
        Db::$db_login_default = $config['login'];
        Db::$db_password_default = $config['password'];
        Db::$db_port_default = $config['port'];
        $r = Db::execr("SET TIME ZONE 'UTC'");
        Worktime::set_timestamp_point('DataBase Connect Done');
        return true;
    }
}