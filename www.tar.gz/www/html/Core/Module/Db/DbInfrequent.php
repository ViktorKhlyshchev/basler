<?php

namespace Core\Module\Db;

use Core\Modules\Data;
use Core\Module\Exception\ParametersException;

trait DbInfrequent {

    public static function is_mysql(string $name = null){
        $name = self::get_db_name($name);
        $db_type = self::get_db_type($name);
        return $db_type === 'mysql';
    }

    public static function is_postgresql(string $name = null){
        $name = self::get_db_name($name);
        $db_type = self::get_db_type($name);
        return $db_type === 'pgsql';
    }

    public static function get_db_type(string $name = null){
        $name = self::get_db_name($name);
        if(empty(self::$db_connect_list[$name])){ $error = ['title' => 'Parameters problem', 'info' => 'DB name is not exists in connect list', 'data' => ['name' => $name]]; throw new ParametersException($error); }
        if(empty(self::$db_connect_list[$name]['type'])){ $error = ['title' => 'Parameters problem', 'info' => 'DB type is not exists in connect list #1', 'data' => ['name' => $name]]; throw new ParametersException($error); }
        return self::$db_connect_list[$name]['type'];
    }

    public static function get_db_name(string $name = null){
        if(!empty($name)) return $name;
        if(!empty(self::$db_name_default)) return self::$db_name_default;
        $error = ['title' => 'DB parameters problem', 'info' => 'DB name is empty']; pre($error); throw new DbParametersException($error);
    }

    public static function isset_row(string $table = null, int $type = null, array $where_list = [],string $name = null){
        $error_info_list = [];
        if(empty($table)) $error_info_list[] = 'Table name is empty';
        if(count($where_list) === 0) $error_info_list[] = 'Where list is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('table' => $table,
                    'name' => $name
                )
            );
            throw new ParametersException($error);
        }
        $where_temp_list = [];
        $where_list =array_merge($where_temp_list,$where_list);
        if(!is_null($type)){
            if(Data::is_associative_array($where_list)){
                if(!isset($where_list['type']))
                    $where_list['type'] = $type;
            }
            else if(Data::is_array($where_list)) $where_list[] = array('column' => 'type',
                    'value' => $type
                );
            else {
                $error = array('title' => 'System error',
                    'info' => 'Where list is not array'
                );
                throw new PhpException($error);
            }
        }
        $q = array('select' => array(
                 array('function' => 'COUNT(*)',
                    'rename' => 'len'
                )
            ),
            'table' => $table,
            'where' => $where_list,
            'limit' => 1
        );
        $r = Db::select($q,$name);
        if(count($r) === 0) return false;
        return $r[0]['len']>0;
    }

    public static function disconnect(string $name = null){
        $name = self::get_db_name($name);
        if(empty(self::$db_connect_list[$name])){
            $error = array('title' => 'DB problem with connect list',
                'info' => 'DB name is not exists in connect list',
                'db_name' => $name,
                'coonnect_key_list' => array_keys(self::$db_connect_list)
            );
            throw new DbQueryParametersException($error);
        }
        if(self::$db_name_default === $name){
            self::$db_name_default = null;
            self::$db_host_default = null;
            self::$db_login_default = null;
            self::$db_password_default = null;
            self::$db_port_default = null;
        }
        self::$db_connect_list[$name] = null;
        return true;
    }
}