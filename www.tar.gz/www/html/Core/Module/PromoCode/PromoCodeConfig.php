<?php

namespace Core\Module\PromoCode;

class PromoCodeConfig{

    /** @var int */
    public static $user_invite_profit_money =100;

    /** @var int */
    public static $user_reg_profit_money =50;

}