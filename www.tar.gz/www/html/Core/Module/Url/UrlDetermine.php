<?php

namespace Core\Module\Url;

use Core\Module\Exception\ParametersException;
use Core\Module\Worktime\Worktime;

class UrlDetermine {

    private static function set_host(){
        $_SERVER['HTTP_HOST'] = strtok($_SERVER['HTTP_HOST'],  ':');
        if(empty($_SERVER['HTTP_HOST'])){
            $error = array('title' => 'URL parameter problem',
                'info' => 'HTTP_HOST is empty',
                'data' => $_SERVER
            );
            throw new ParametersException($error);
        }
        Url::$host = $_SERVER['HTTP_HOST'];
    }

    private static function set_url(){
        if(empty($_SERVER['HTTP_HOST'])){
            $error = array('title' => 'URL parameter problem',
                'info' => 'HTTP_HOST is empty',
                'data' => $_SERVER
            );
            throw new ParametersException($error);
        }
        Url::$url = str_replace('?'.$_SERVER['QUERY_STRING'], '', $_SERVER['REQUEST_URI']);
    }

    static function set_request_page($rp = null){
        if(!$rp) $rp = $_SERVER['REQUEST_URI'];
        $strpos = strpos($rp,  '?');
        if($strpos !== false) $rp = substr($rp,  0,  $strpos);
        define('RP',  $rp);
        $erp = array_slice(explode('/',  $rp),  -1)[0];
        if($erp === '')
            define('ERP',  array_slice(explode('/',  $rp),  -2)[0]);
        else
            define('ERP',  $erp);
    }

    static function set_ajax($rp = null){ #pred($_SERVER);
        if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest' || strpos(RP, '/api/json/get_trigger') === 0) define('ajax',  1); else define('ajax',  0);
    }

    public static function init(){
        Worktime::set_timestamp_point('URL Determine Start');
        self::set_host();
        Url::$query = $_SERVER['QUERY_STRING'];
        self::set_url();
        Url::$list = Url::get_url_list(Url::$url);
        Url::$default_list = Url::get_url_list(Url::$url, false);
        self::set_request_page();
        self::set_ajax();
        Worktime::set_timestamp_point('URL Determine Finish');
        return true;
    }
}