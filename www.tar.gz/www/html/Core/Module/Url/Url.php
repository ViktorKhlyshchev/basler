<?php

namespace Core\Module\Url;

class Url {

    public static $url;
    public static $site_url;
    public static $host;
    public static $query;
    public static $shell_action;
    public static $list = [];

    public static $default_list = [];

    public static function reset_data(){
        self::$url = null;
        self::$host = null;
        self::$query = null;
        self::$list = [];
        return true;
    }

    public static function get_url_without_query(string $link = null){
        return strtok($link, '?');
    }

    public static function get_url_list(string $link = null, bool $is_lower = true){
        if(empty($link)) return [];
        $link = self::get_url_without_query($link);
        $list = mb_split('\/', $link);
        $r_list = [];
        foreach($list as $row) if(!empty($row)) $r_list[] = $is_lower ? strtolower(trim($row)) : trim($row);
        return $r_list;
    }

    public static function get_url(string $path = null){ #pred($_SERVER);
        if(cli) return RP;
        $url = $_SERVER['REQUEST_SCHEME'] .'://'. $_SERVER['HTTP_HOST'] . str_replace(realpath(DR), '', $path);
        return $url;
    }

    function siteURLR(){
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
        $domainName = $_SERVER['HTTP_HOST'];
        return $protocol.$domainName;
    }

    public static function site_url_w_dir($array = false){

        if(self::$site_url) return self::$site_url;

        $protocol = "";
        $host = "";
        $port = "";
        $dir = "";

        // Get protocol
        if(array_key_exists("HTTPS", $_SERVER) && $_SERVER["HTTPS"] != ""){
            if($_SERVER["HTTPS"] == "on"){ $protocol = "https"; }
            else { $protocol = "http"; }
        } elseif(array_key_exists("REQUEST_SCHEME", $_SERVER) && $_SERVER["REQUEST_SCHEME"] != ""){ $protocol = $_SERVER["REQUEST_SCHEME"]; }

        // Get host
        if(array_key_exists("HTTP_X_FORWARDED_HOST", $_SERVER) && $_SERVER["HTTP_X_FORWARDED_HOST"] != ""){ $host = trim(end(explode(',', $_SERVER["HTTP_X_FORWARDED_HOST"]))); }
        elseif(array_key_exists("SERVER_NAME", $_SERVER) && $_SERVER["SERVER_NAME"] != ""){ $host = $_SERVER["SERVER_NAME"]; }
        elseif(array_key_exists("HTTP_HOST", $_SERVER) && $_SERVER["HTTP_HOST"] != ""){ $host = $_SERVER["HTTP_HOST"]; }
        elseif(array_key_exists("SERVER_ADDR", $_SERVER) && $_SERVER["SERVER_ADDR"] != ""){ $host = $_SERVER["SERVER_ADDR"]; }
        //elseif(array_key_exists("SSL_TLS_SNI", $_SERVER) && $_SERVER["SSL_TLS_SNI"] != ""){ $host = $_SERVER["SSL_TLS_SNI"]; }

        // Get port
        if(array_key_exists("SERVER_PORT", $_SERVER) && $_SERVER["SERVER_PORT"] != ""){ $port = $_SERVER["SERVER_PORT"]; }
        elseif(stripos($host, ":") !== false){ $port = substr($host, (stripos($host, ":")+1)); }
        // Remove port from host
        $host = preg_replace("/:\d+$/", "", $host);

        // Get dir
        if(array_key_exists("SCRIPT_NAME", $_SERVER) && $_SERVER["SCRIPT_NAME"] != ""){ $dir = $_SERVER["SCRIPT_NAME"]; }
        elseif(array_key_exists("PHP_SELF", $_SERVER) && $_SERVER["PHP_SELF"] != ""){ $dir = $_SERVER["PHP_SELF"]; }
        elseif(array_key_exists("REQUEST_URI", $_SERVER) && $_SERVER["REQUEST_URI"] != ""){ $dir = $_SERVER["REQUEST_URI"]; }
        // Shorten to main dir
        pred($dir);
        if(stripos($dir, "/") !== false){ $dir = substr($dir, 0, (strripos($dir, "/")+1)); }

        // Create return value
        if(!$array){
            if($port == "80" || $port == "443" || $port == ""){ $port = ""; }
            else { $port = ":".$port; }
            return htmlspecialchars($protocol."://".$host.$port.$dir, ENT_QUOTES);
        } else { return ["protocol" => $protocol, "host" => $host, "port" => $port, "dir" => $dir]; }
    }

    public static function site_url($array = false){

        if(self::$site_url) return self::$site_url;

        $protocol = '';
        $host = '';
        $port = '';
        $dir = '';

        // Get protocol
        if(array_key_exists('HTTPS', $_SERVER) && $_SERVER['HTTPS'] !== ''){
            if($_SERVER['HTTPS'] === 'on'){ $protocol = 'https'; }
            else { $protocol = 'http'; }
        } elseif(array_key_exists('REQUEST_SCHEME', $_SERVER) && $_SERVER['REQUEST_SCHEME'] != ''){ $protocol = $_SERVER['REQUEST_SCHEME']; }

        // Get host
        #pred($_SERVER); 1. HTTP_HOST 2. SERVER_ADDR !!! HTTP_REFERER
        if(array_key_exists('HTTP_HOST', $_SERVER) && $_SERVER['HTTP_HOST'] !== '') $host = $_SERVER['HTTP_HOST'];
        if(!$host && array_key_exists('SERVER_ADDR', $_SERVER) && $_SERVER['SERVER_ADDR'] !== '') $host = $_SERVER['SERVER_ADDR'];
        if(!$host && array_key_exists('HTTP_X_FORWARDED_HOST', $_SERVER) && $_SERVER['HTTP_X_FORWARDED_HOST'] != '') $host = trim(end(explode(',', $_SERVER['HTTP_X_FORWARDED_HOST'])));
        if(!$host && array_key_exists('SERVER_NAME', $_SERVER) && $_SERVER['SERVER_NAME'] !== '') $host = $_SERVER['SERVER_NAME'];
        //elseif(array_key_exists('SSL_TLS_SNI', $_SERVER) && $_SERVER['SSL_TLS_SNI'] != ''){ $host = $_SERVER['SSL_TLS_SNI']; }
        /*
        [USER] => www-data
        [HOME] => /var/www
        [HTTP_COOKIE] => PPA_id=decpu4l4pno20lf8plp8upttan; webfx-tree-cookie-persistence=wfxt-4+wfxt-6; token=c2c5b820bfe8347f862472883e2d068b7c27961f
        [HTTP_ACCEPT_LANGUAGE] => ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7
        [HTTP_ACCEPT_ENCODING] => gzip, deflate
        [HTTP_REFERER] => http://10.0.1.1/admin/settings
        [HTTP_ACCEPT] => text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,/*;q=0.8,application/signed-exchange;v=b3;q=0.9
        [HTTP_USER_AGENT] => Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36 OPR/80.0.4170.63
        [HTTP_UPGRADE_INSECURE_REQUESTS] => 1
        [HTTP_CACHE_CONTROL] => max-age=0
        [HTTP_CONNECTION] => keep-alive
        [HTTP_HOST] => 10.0.1.1
        [REDIRECT_STATUS] => 200
        [SERVER_NAME] => localhost
        [SERVER_PORT] => 80
        [SERVER_ADDR] => 10.0.1.1
        [REMOTE_PORT] => 46492
        [REMOTE_ADDR] => 10.0.200.40
        [SERVER_SOFTWARE] => nginx/1.14.0
        [GATEWAY_INTERFACE] => CGI/1.1
        [REQUEST_SCHEME] => http
        [SERVER_PROTOCOL] => HTTP/1.1
        [DOCUMENT_ROOT] => /var/www/html
        [DOCUMENT_URI] => /index.php
        [REQUEST_URI] => /admin/track
        [SCRIPT_NAME] => /index.php
        [CONTENT_LENGTH] =>
        [CONTENT_TYPE] =>
        [REQUEST_METHOD] => GET
        [QUERY_STRING] =>
        [SCRIPT_FILENAME] => /var/www/html/index.php
        [PATH_INFO] =>
        [FCGI_ROLE] => RESPONDER
        [PHP_SELF] => /index.php
        [REQUEST_TIME_FLOAT] => 1636984829.8161
        [REQUEST_TIME] => 1636984829
        */

        // Get port
        if(array_key_exists('SERVER_PORT', $_SERVER) && $_SERVER['SERVER_PORT'] !== ''){ $port = $_SERVER['SERVER_PORT']; }
        elseif(stripos($host, ':') !== false){ $port = substr($host, (stripos($host, ':')+1)); }
        // Remove port from host
        $host = preg_replace('/:\d+$/', '', $host);
        #pred($host);

        // Get dir
        if(array_key_exists('SCRIPT_NAME', $_SERVER) && $_SERVER['SCRIPT_NAME'] !== ''){ $dir = $_SERVER['SCRIPT_NAME']; }
        elseif(array_key_exists('PHP_SELF', $_SERVER) && $_SERVER['PHP_SELF'] !== ''){ $dir = $_SERVER['PHP_SELF']; }
        elseif(array_key_exists('REQUEST_URI', $_SERVER) && $_SERVER['REQUEST_URI'] != ''){ $dir = $_SERVER['REQUEST_URI']; }
        // Shorten to main dir

        if(stripos($dir, '/') !== false){ $dir = substr($dir, 0, (strripos($dir, '/')+1)); }
        if($dir === '/') $dir = '';
        // Create return value
        if(!$array){
            if($port == '80' || $port == '443' || $port == ''){ $port = ''; }
            else { $port = ':'. $port; }
            return htmlspecialchars($protocol.'://'.$host.$port.$dir, ENT_QUOTES);
        } else { return ['protocol' => $protocol, 'host' => $host, 'port' => $port, 'dir' => $dir]; }
    }
}