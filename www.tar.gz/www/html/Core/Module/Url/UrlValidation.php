<?php

namespace Core\Module\Url;

use Core\Module\Exception\ParametersException;

class UrlValidation{

    /**
     * @param string|null $link
     * @return false|int
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function is_valid_url(string $link = null){

        if(empty($link)){

            $error = array('title' => 'Parameters problem',
                'info' => 'URL is empty'
            );

            throw new ParametersException($error);

        }

        return preg_match('/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i',$link);

    }

}