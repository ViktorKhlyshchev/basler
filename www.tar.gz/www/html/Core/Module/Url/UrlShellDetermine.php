<?php

namespace Core\Module\Url;

use Core\Module\Exception\ParametersException;

class UrlShellDetermine {

    private static function set_action(){ #pred(debug_backtrace());
        if(!isset($_POST['action'])){
            $error = [ 'title' => ParametersException::$title, 'info' => 'Shell action is not exists'];
            throw new ParametersException($error);
        }
        Url::$shell_action = $_REQUEST['action'];
        return true;
    }

    private static function set_query(){
        global $argv;
        $_POST = [];
        if(!count($argv)) return false;
        $list = [];
        for($i = 1; $i < count($argv); $i++){
            $r = mb_split("=",$argv[$i]);
            if(count($r) ===  2) $list[$r[0]] = $r[1];
        }
        $_POST = $list;
        $_REQUEST = $list;
        if(!defined('hand')){ if(isset($_POST['hand']) && $_POST['hand']) define('hand', true); else define('hand', false); }
        if(isset($_POST['debug']) && $_POST['debug']) \Config::$is_debug = true;
        if(isset($_POST['qdebug']) && $_POST['qdebug']) \Config::$is_query_debug = true;
        return true;
    }

    public static function init(){ # Request::init
        Url::$host = gethostname();
        self::set_query();
        self::set_action();
        return true;
    }
}