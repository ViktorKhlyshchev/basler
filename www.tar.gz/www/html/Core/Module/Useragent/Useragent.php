<?php

namespace Core\Module\Useragent;

use Core\Module\Db\Db;
use Core\Module\Encrypt\Hash;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class Useragent {

    public static $useragent_id;
    public static $useragent;
    public static $useragent_hash;

    public static function reset_data(){
        self::$useragent_id = null;
        self::$useragent = null;
        self::$useragent_hash = null;
    }

    public static function isset_useragent_id(int $useragent_id = null){
        if(empty($useragent_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Useragent ID is empty'
            );
            throw new ParametersException($error);
        }
        return Db::isset_row_id($useragent_id,'_useragent',0);
    }

    public static function isset_useragent(string $useragent = null){
        if(empty($useragent)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Useragent is empty #1'
            );
            throw new ParametersException($error);
        }
        $where_list = array('useragent' => $useragent
        );
        return Db::isset_row('_useragent',0,$where_list);
    }

    public static function isset_useragent_hash(string $useragent_hash = null){
        if(empty($useragent_hash)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Useragent hash is empty'
            );
            throw new ParametersException($error);
        }
        $where_list = array('hash' => $useragent_hash
        );
        return Db::isset_row('_useragent',0,$where_list);
    }

    public static function isset_useragent_default(){
        if(empty(self::$useragent)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Useragent is empty #2'
            );
            throw new ParametersException($error);
        }
        self::$useragent_id=self::get_useragent_id_from_useragent(self::$useragent);
        return !empty(self::$useragent_id);
    }

    public static function get_useragent_hash(string $useragent = null){
        if(empty($useragent)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Useragent is empty #3'
            );
            #throw new ParametersException($error);
        }
        return Hash::get_sha1_encode($useragent);
    }

    public static function get_useragent_from_useragent_id(int $useragent_id = null){
        if(empty($useragent_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Useragent ID is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array(
                 array('column' => 'useragent'
                )
            ),
            'table' => '_useragent',
            'where' => array(
                 array('column' => 'id',
                    'value' => $useragent_id
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'limit' => 1
        );
        $r = Db::select($q);
        return count($r)==0?null:$r[0]['useragent'];
    }

    public static function get_useragent_id_from_useragent_hash(string $useragent_hash = null){
        if(empty($useragent_hash)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Useragent hash is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array(
                 array('column' => 'id'
                )
            ),
            'table' => '_useragent',
            'where' => array(
                 array('column' => 'hash',
                    'value' => $useragent_hash
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'limit' => 1
        );
        $r = Db::select($q);
        return count($r)==0?null:$r[0]['id'];
    }

    public static function get_useragent_id_from_useragent(string $useragent = null){
        if(empty($useragent)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Useragent is empty #4'
            );
            #throw new ParametersException($error);
        }
        $useragent_hash=self::get_useragent_hash($useragent);
        return self::get_useragent_id_from_useragent_hash($useragent_hash);
    }

    public static function get_useragent_id_default(){
        if(!empty(self::$useragent_id)) return self::$useragent_id;
        $error_info_list = [];
        if(empty(self::$useragent)) $error_info_list[] = 'Useragent default is empty';
        else if(empty(self::$useragent_hash))
            self::$useragent_hash=self::get_useragent_hash_default();
        if(empty(self::$useragent_hash)) $error_info_list[] = 'Useragent hash default is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );
            #throw new ParametersException($error);
        }
        self::$useragent_id=self::get_useragent_id_from_useragent_hash(self::$useragent_hash);
        if(empty(self::$useragent_id))
            self::$useragent_id=self::add_useragent(self::$useragent);
        if(empty(self::$useragent_id)){
            $error = array('title' => 'DB query problem',
                'info' => 'Useragent was not added'
            );
            throw new DbQueryException($error);
        }
        return self::$useragent_id;
    }

    public static function get_useragent_default(){
        return empty(self::$useragent) ? null : self::$useragent;
    }

    public static function get_useragent_hash_default(){
        return empty(self::$useragent_hash) ? null : self::$useragent_hash;
    }

    public static function add_useragent(string $useragent = null){
        if(empty($useragent)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Useragent is empty #5'
            );
            #throw new ParametersException($error);
        }
        $useragent_hash=self::get_useragent_hash($useragent);
        $q = array('table' => '_useragent',
            'values' => array(
                 array('hash' => $useragent_hash,
                    'useragent' => $useragent,
                    'date_create' => 'NOW()'
                )
            )
        );
        $conflict_list = [
            'column_list' => [
                'hash'
            ],
            'update_list' => [
                'set' => [
                    'date_update' => 'NOW()',
                    'type' => 0
                ]
            ],
            'return_list' => [
                'id'
            ]
        ];
        $r = Db::insert($q,true,[],null,$conflict_list);
        if(count($r) === 0){
            $error = array('title' => 'DB query problem',
                'info' => 'New useragent was not added'
            );
            throw new DbQueryException($error);
        }
        return $r[0]['id'];
    }

    public static function add_useragent_default(){
        if(empty(self::$useragent)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Default useragent is empty'
            );
            throw new ParametersException($error);
        }
        $useragent_id=self::add_useragent(self::$useragent);
        if(empty($useragent_id)){
            $error = array('title' => 'DB query problem',
                'info' => 'New useragent was not added'
            );
            throw new DbQueryException($error);
        }
        self::$useragent_id = $useragent_id;
        return self::$useragent_id;
    }

    public static function remove_useragent_id(int $useragent_id = null){
        if(empty($useragent_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Useragent ID is empty'
            );
            throw new ParametersException($error);
        }
        if(!Db::pseudo_delete_from_id($useragent_id,'_useragent',0)){
            $error = array('title' => 'DB query problem',
                'info' => 'Useragent was not removed'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_useragnet(string $useragent = null, string $useragent_hash = null){
        if(empty($useragent)&&empty($useragent_hash)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Useragent and useragent hash are empty'
            );
            throw new ParametersException($error);
        }
        $where_list = [];
        if(!empty($useragent)) $where_list['useragent'] = $useragent;
        if(!empty($useragent_hash)) $where_list['useragent_hash'] = $useragent_hash;
        if(!Db::pseudo_delete_from_where_list('_useragent',0,$where_list)){
            $error = array('title' => 'DB query problem',
                'info' => 'Useragent was not removed'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function set_useragent_id_default(int $useragent_id = null){
        self::$useragent_id = empty($useragent_id) ? null : $useragent_id;
    }

    public static function set_useragent_default(string $useragent = null){
        self::$useragent = empty($useragent) ? null : $useragent;
    }

    public static function set_useragent_hash_default(string $useragent_hash = null){
        self::$useragent_hash = empty($useragent_hash) ? null : $useragent_hash;
    }
}