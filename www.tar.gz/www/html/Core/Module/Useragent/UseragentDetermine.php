<?php

namespace Core\Module\Useragent;

use Core\Module\Exception\ParametersException; # use Core\Module\Worktime\Worktime;

class UseragentDetermine {

    private static function set_client_useragent_to_default(){ #if(empty($_SERVER['HTTP_USER_AGENT'])) pred($_SERVER);
        if(empty($_SERVER['HTTP_USER_AGENT'])){ $error = ['title' => 'Parameters problem', 'info' => 'The client did not pass the useragent #11']; if(hand){ pre($error); pred(debug_backtrace()); } throw new ParametersException($error); }
        Useragent::set_useragent_default($_SERVER['HTTP_USER_AGENT']);
    }

    private static function set_client_useragent_hash_to_default(){
        if(empty($_SERVER['HTTP_USER_AGENT'])){ $error = ['title' => 'Parameters problem', 'info' => 'The client did not pass the useragent #22'];  pre($error); pred(debug_backtrace());if(hand){ pre($error); pred(debug_backtrace()); } throw new ParametersException($error); }
        $useragent_hash = Useragent::get_useragent_hash($_SERVER['HTTP_USER_AGENT']);
        Useragent::set_useragent_hash_default($useragent_hash);
    }

    private static function set_client_useragent_id_to_default(){
        Useragent::$useragent_id = Useragent::get_useragent_id_default();
    }

    public static function init(){ #return; # Worktime::set_timestamp_point('Useragent Determine Start');
        self::set_client_useragent_to_default();
        self::set_client_useragent_hash_to_default();
        self::set_client_useragent_id_to_default(); # Worktime::set_timestamp_point('Useragent Determine Finish');
    }
}