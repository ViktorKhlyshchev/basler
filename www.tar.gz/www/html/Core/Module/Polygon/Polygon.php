<?php

namespace Core\Module\Polygon;

class Polygon{

    /**
     * @param int|null $car_x
     * @param int|null $car_y
     * @param array $point_list
     * @return bool|int
     */
    public static function is_point_inside_zone(int $car_x = null, int $car_y = null, array $point_list = []){

        $npol =count($point_list);
        $j = $npol-1;
        $c =0;

        for($i=0;$i<$npol;$i++){

            if((
                    (
                        ($point_list[$i]['y'] <= $car_y) && ($car_y<$point_list[$j]['y'])
                    ) || (($point_list[$j]['y'] <= $car_y) && ($car_y<$point_list[$i]['y']))
                )
                && ($car_x>($point_list[$j]['x'] - $point_list[$i]['x']) * ($car_y - $point_list[$i]['y']) / ($point_list[$j]['y'] - $point_list[$i]['y']) + $point_list[$i]['x'])
            )
                $c=!$c;

            $j = $i;

        }

        return $c;

    }

    /**
     * @param array $zone_list
     * @param array $track_list
     * @return bool
     */
    public static function is_point_list_inside_zone(array $zone_list = [], array $track_list = []){

        foreach($track_list['converted_track_list'] as $point_data)
            if(self::is_point_inside_zone($point_data['x'],$point_data['y'],$zone_list))
                return true;

        return false;

    }

    /**
     * @param array $zone_list
     * @param array $track_list
     * @param array $track_key_list
     * @return bool
     */
    public static function is_point_list_with_key_list_inside_zone(array $zone_list = [], array $track_list = [], array $track_key_list = []){

        foreach($track_list['converted_double_track_list'] as $point_data){

            $inside_count=0;

            foreach($track_key_list as $key)
                if(isset($point_data[$key]))
                    if(self::is_point_inside_zone($point_data[$key]['x'],$point_data[$key]['y'],$zone_list))
                        $inside_count++;

            if($inside_count==count($track_key_list))
                return true;

        }

        return false;

    }

    /**
     * @param array $zone_list
     * @param array $track_list
     * @return bool
     */
    public static function get_point_inside_zone(array $zone_list = [], array $track_list = []){

        $point_count=0;

        foreach($track_list as $key => $track_point_list)
            foreach($track_point_list as $point_data)
                if(self::is_point_inside_zone($point_data['x'],$point_data['y'],$zone_list))
                    $point_count++;

        return $point_count;

    }

}