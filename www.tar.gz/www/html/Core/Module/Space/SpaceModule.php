<?php

namespace Core\Module\Space;

class SpaceModule {

    public static $dir = '/var/www';

    public static function get_disk_space(string $dir = null){

        if(empty($dir)) $dir = self::$dir;

        if(is_dir($dir)){
            $disk_total = disk_total_space($dir);
            $disk_free = disk_free_space($dir);
            $disk_usage = $disk_total-$disk_free;

            return [
                'disk_total' => $disk_total,
                'disk_free' => $disk_free,
                'disk_usage' => $disk_usage
            ];
        } /*else {            $disk_total = 0; # 'N/A'            $disk_free = 0;            $disk_usage = 0; */
    }
}