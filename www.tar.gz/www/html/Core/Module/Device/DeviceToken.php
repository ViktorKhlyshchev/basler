<?php

namespace Core\Module\Device;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class DeviceToken {

    public static $device_token_id;
    public static $device_hash;
    public static $device_token;

    public static function reset_data(){
        self::$device_token_id = null;
        self::$device_hash = null;
        self::$device_token = null;
        return true;
    }

    public static function isset_device_token_id(int $device_token_id = null){
        if(empty($device_token_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Device token ID is empty'
            );
            throw new ParametersException($error);
        }
        return Db::isset_row_id($device_token_id,'_device_token',0);
    }

    public static function isset_device_hash(string $device_hash = null){
        if(empty($device_hash)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Device hash is empty'
            );
            throw new ParametersException($error);
        }
        $where_list = array('hash' => $device_hash
        );
        return Db::isset_row('_device_token',0,$where_list);
    }

    public static function isset_device_token(string $device_token = null){
        if(empty($device_token)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Device token is empty'
            );
            throw new ParametersException($error);
        }
        $where_list = array('token' => $device_token
        );
        return Db::isset_row('_device_token',0,$where_list);
    }

    public static function get_device_token_id_from_device_hash(string $device_hash = null){
        if(empty($device_hash)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Device hash is empty'
            );
            throw new ParametersException($error);
        }
        $where_list = array('hash' => $device_hash
        );
        $device_token_id=Db::get_row_id('_device_token',0,$where_list);
        if(empty($device_token_id)) return null;
        return $device_token_id;
    }

    public static function get_device_token_data_from_hash(string $device_hash = null){
        if(empty($device_hash)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Device hash is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('id',
                'device_firm_id',
                'device_model_id',
                'os_id',
                'os_version_id',
                'hash',
                'token'),
            'table' => '_device_token',
            'where' => array('hash' => $device_hash, 'type' => 0),
            'type' => 1
        );
        $r = Db::select($q);
        if(count($r) === 0) return null;
        return array('id' => $r[0]['id'],
            'device_firm_id' => $r[0]['device_firm_id'],
            'device_model_id' => $r[0]['device_model_id'],
            'os_id' => $r[0]['os_id'],
            'os_version_id' => $r[0]['os_version_id'],
            'hash' => $r[0]['hash'],
            'token' => $r[0]['token']
        );
    }

    public static function get_device_token_id_from_device_hash_and_token(string $device_hash = null, string $device_token = null){
        $error_info_list = [];
        if(empty($device_hash)) $error_info_list[] = 'Device hash is empty';
        if(empty($device_token)) $error_info_list[] = 'Device token is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('device_hash' => $device_hash,
                    'device_token' => $device_token
                )
            );
            throw new ParametersException($error);
        }
        $where_list = array('hash' => $device_hash,
            'token' => $device_token
        );
        $device_token_id=Db::get_row_id('_device_token',0,$where_list);
        if(empty($device_token_id)) return null;
        return $device_token_id;
    }

    public static function get_device_token_id_from_device_token(string $device_token = null){
        if(empty($device_token)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Device token is empty'
            );
            throw new ParametersException($error);
        }
        $where_list = array('token' => $device_token
        );
        $device_token_id=Db::get_row_id('_device_token',0,$where_list);
        if(empty($device_token_id)) return null;
        return $device_token_id;
    }

    public static function add_device_token(int $device_firm_id = null, int $device_model_id = null, int $os_id = null, int $os_version_id = null, string $device_hash = null, string $device_token = null, bool $is_google=false,bool $is_apple=false){
        $error_info_list = [];
        if(empty($device_firm_id)) $error_info_list[] = 'Device firm ID is empty';
        if(empty($device_model_id)) $error_info_list[] = 'Device model ID is empty';
        if(empty($os_id)) $error_info_list[] = 'OS ID is empty';
        if(empty($os_version_id)) $error_info_list[] = 'OS version ID is empty';
        if(empty($device_hash)) $error_info_list[] = 'Device hash is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );
            throw new ParametersException($error);
        }
        $value_list = array('device_firm_id' => $device_firm_id,
            'device_model_id' => $device_model_id,
            'os_id' => $os_id,
            'os_version_id' => $os_version_id,
            'hash' => $device_hash,
            'google' => (int)$is_google,
            'apple' => (int)$is_apple,
            'date_create' => 'NOW()',
            'date_update' => 'NOW()'
        );
        if(!empty($device_token)) $value_list['token'] = $device_token;
        $q = array('table' => '_device_token',
            'values' => array(
                $value_list
            )
        );
        $r = Db::insert($q);
        if(count($r) === 0){
            $error = array('title' => 'DB query problem',
                'info' => 'Device token was not added',
                'data' => array('device_firm_id' => $device_firm_id,
                    'device_model_id' => $device_model_id,
                    'os_id' => $os_id,
                    'os_version_id' => $os_version_id,
                    'hash' => $device_hash,
                    'token' => $device_token,
                    'query' => $q
                )
            );
            throw new DbQueryException($error);
        }
        return $r[0]['id'];
    }

    public static function update_device_token(int $device_token_id = null, int $device_firm_id = null, int $device_model_id = null, int $os_id = null, int $os_version_id = null, string $device_hash = null, string $device_token = null){
        if(empty($device_token_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Device token ID is empty'
            );
            throw new ParametersException($error);
        }
        if(empty($device_firm_id)
            &&empty($device_model_id)
            &&empty($os_id)
            &&empty($os_version_id)
            &&empty($device_hash)
            &&empty($device_token)
        ){
            $error = array('title' => 'Parameters problem',
                'info' => 'All parameters are empty'
            );
            throw new ParametersException($error);
        }
        $set_list = [];
        if(!empty($device_firm_id)) $set_list['device_firm_id'] = $device_firm_id;
        if(!empty($device_model_id)) $set_list['device_model_id'] = $device_model_id;
        if(!empty($os_id)) $set_list['os_id'] = $os_id;
        if(!empty($os_version_id)) $set_list['os_version_id'] = $os_version_id;
        if(!empty($device_hash)) $set_list['hash'] = $device_hash;
        if(!empty($device_token)) $set_list['token'] = $device_token;
        if(count($set_list) === 0) return false;
        $set_list['date_update'] = 'NOW()';
        if(!Db::update_data_from_id($device_token_id,'_device_token',$set_list,0)){
            $error = array('title' => 'DB query problem',
                'info' => 'Device token was not updated',
                'data' => array('set_list' => $set_list,
                    'device_token_id' => $device_token_id
                )
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_device_token_id(int $device_token_id = null){
        if(empty($device_token_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Device token ID is empty'
            );
            throw new ParametersException($error);
        }
        if(!Db::pseudo_delete_from_id($device_token_id,'_device_token',0)){
            $error = array('title' => 'DB query problem',
                'info' => 'Device token was not removed',
                'data' => array('device_token_id' => $device_token_id
                )
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_device_token_from_device_token(string $device_token = null){
        if(empty($device_token)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Device token is empty'
            );
            throw new ParametersException($error);
        }
        $where_list = array('token' => $device_token
        );
        if(!Db::pseudo_delete_from_where_list('_device_token',0,$where_list)){
            $error = array('title' => 'DB query problem',
                'info' => 'Device token was not removed',
                'data' => array('device_token' => $device_token
                )
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_device_token_from_device_hash(string $device_hash = null){
        if(empty($device_hash)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Device hash is empty'
            );
            throw new ParametersException($error);
        }
        $where_list = array('hash' => $device_hash
        );
        if(!Db::pseudo_delete_from_where_list('_device_token',0,$where_list)){
            $error = array('title' => 'DB query problem',
                'info' => 'Device token was not removed',
                'data' => array('device_hash' => $device_hash
                )
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_device_token_from_device_hash_and_device_token(string $device_hash = null, string $device_token = null){
        $error_info_list = [];
        if(empty($device_hash)) $error_info_list[] = 'Device hash is empty';
        if(empty($device_token)) $error_info_list[] = 'Device token is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('device_hash' => $device_hash,
                    'device_token' => $device_token
                )
            );
            throw new ParametersException($error);
        }
        $where_list = array('hash' => $device_hash,
            'token' => $device_token
        );
        if(!Db::pseudo_delete_from_where_list('_device_token',0,$where_list)){
            $error = array('title' => 'DB query problem',
                'info' => 'Device token was not removed',
                'data' => array('device_hash' => $device_hash,
                    'device_token' => $device_token
                )
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function set_device_token_id_default(int $device_token_id = null){
        self::$device_token_id = empty($device_token_id) ? null : $device_token_id;
        return true;
    }

    public static function set_device_token_default(string $device_token = null){
        self::$device_token = empty($device_token) ? null : $device_token;
        return true;
    }

    public static function set_device_hash_default(string $device_hash = null){
        self::$device_hash = empty($device_hash) ? null : $device_hash;
        return true;
    }
}