<?php

namespace Core\Module\Device;

class DeviceType{

    /** @var string */
    public static $device_type;

    /** $var bool */
    public static $is_mobile =false;

    /** $var bool */
    public static $is_tablet =false;

    /**
     * @return bool
     */
    public static function reset_data(){

        self::$device_type = null;
        self::$is_mobile =false;
        self::$is_tablet =false;

        return true;

    }

    /**
     * @return mixed
     */
    public static function is_tablet(){

        return self::$is_mobile;

    }

    /**
     * @return bool
     */
    public static function is_mobile(){

        return self::$is_mobile;

    }

    /**
     * @param string|null $device_type
     * @return bool
     */
    public static function set_device_type(string $device_type = null){

        self::$device_type = empty($device_type) ? null : strtolower($device_type);

        return true;

    }

    /**
     * @param bool|null $is_mobile
     * @return bool
     */
    public static function set_is_mobile(bool $is_mobile = null){

        self::$is_mobile = empty($is_mobile) ? null : $is_mobile;

        return true;

    }

    /**
     * @param bool|null $is_tablet
     * @return bool
     */
    public static function set_is_tablet(bool $is_tablet = null){

        self::$is_tablet = empty($is_tablet) ? null : $is_tablet;

        return true;

    }


}