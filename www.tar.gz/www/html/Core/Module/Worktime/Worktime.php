<?php

namespace Core\Module\Worktime;

use Common\Modules\Date;

class Worktime {

    public static $timestamp_start;
    public static $timestamp_finish;
    public static $timestamp_list = [];
    public static $delta;
    private static $is_finish = false;

    public static function reset_data(){
        self::$timestamp_start = null;
        self::$timestamp_finish = null;
        self::$timestamp_list = [];
        self::$delta = null;
        self::$is_finish = false;
        return true;
    }

    public static function get_full_info(){
        $data = ['delta' => self::$delta];
        if(WorktimeConfig::$need_worktime_list) $data['list'] = self::$timestamp_list;
        return $data;
    }

    public static function get_delta(){
        if(self::$is_finish) return self::$delta;
        $timestamp_now = Date::get_timestamp_ms();
        return $timestamp_now-self::$timestamp_start;
    }

    public static function finish(){
        self::$is_finish = true;
        self::$timestamp_finish = Date::get_timestamp_ms();
        self::set_timestamp_point('Finish timer');
        if(!empty(self::$timestamp_finish)&&!empty(self::$timestamp_start)) self::$delta = round(self::$timestamp_finish - self::$timestamp_start, WorktimeConfig::$round_length);
    }

    public static function set_timestamp_point($info = null){
        $timestamp_last = count(self::$timestamp_list) == 0 ? 0 : self::$timestamp_list[count(self::$timestamp_list) - 1]['timestamp'];
        $timestamp_now = Date::get_timestamp_ms();
        $temp = ['delta' => 0, 'timestamp' => $timestamp_now];
        if(!empty($timestamp_last)){
            $temp['delta'] = $timestamp_now - $timestamp_last;
            $temp['delta_round'] = round($timestamp_now - $timestamp_last, 5) * 1000;
        }
        if(!empty($info)) $temp['info'] = $info;
        self::$timestamp_list[] = $temp;
        return true;
    }

    public static function start(){
        self::$is_finish = false;
        self::$timestamp_start = Date::get_timestamp_ms();
        self::set_timestamp_point('Start timer');
        return true;
    }
}