<?php

namespace Core\Module\Error;

use Core\Modules\Log;

class RecoverableErrorException extends \ErrorException{

    /**
     * RecoverableErrorException constructor.
     * @param $message
     * @param $code
     * @param $severity
     * @param $filename
     * @param $lineno
     * @param $previous
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\ParametersException
     * @throws \Core\Module\Exception\SystemException
     */
    public function __construct($message,$code,$severity,$filename,$lineno,$previous){

        $error = array('type' => 'E_RECOVERABLE_ERROR',
            'title' => array('ru' => 'Фатальные ошибки с возможностью обработки',
                'en' => 'Catchable fatal error'),
            'info' => array('ru' => 'Фатальные ошибки с возможностью обработки. Такие ошибки указывают, что, вероятно, возникла опасная ситуация, но при этом, скриптовый движок остается в стабильном состоянии. Если такая ошибка не обрабатывается функцией, определенной пользователем для обработки ошибок (см. set_error_handler()), выполнение приложения прерывается, как происходит при ошибках E_ERROR.',
                'en' => 'Catchable fatal error. It indicates that a probably dangerous error occurred, but was not leave the Engine in an unstable state. If the error is not caught by a user defined handle (see also set_error_handler()), the application aborts as it was an E_ERROR.'),
            'code' => $code,
            'line' => $lineno,
            'file' => $filename,
            'severity' => $severity,
            'message' => $message,
            'previous' => $previous
        );

        Log::init($error);

        die;

    }

}