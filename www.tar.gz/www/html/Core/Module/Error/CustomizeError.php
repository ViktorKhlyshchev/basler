<?php

namespace Core\Module\Error;

use Core\Module\Response\ResponseServerError;
use Core\Module\Worktime\Worktime;

class CustomizeError {
    
    public static $is_error=false;
    
    public static function init(){
        Worktime::set_timestamp_point('Customize Error Start');
        set_error_handler(array('Core\Module\Error\CustomizeError', 'error_handler'));
        register_shutdown_function(array('Core\Module\Error\CustomizeError', 'error_fatal_handler'));
        ob_start();
        Worktime::set_timestamp_point('Customize Error Finish');
        return true;
    }
    
    public static function error_fatal_handler(){
        #pred(error_reporting());
        if(error_reporting() === 0) return false;
        $error=error_get_last();
        if(isset($error)){
            switch($error['type']){
                case E_ERROR:
                    throw new FatalErrorException($error['message'], $error['type'], null, $error['file'], $error['line'], null);
                case E_WARNING:
                    throw new WarningException($error['message'], $error['type'], null, $error['file'], $error['line'], null);
                case E_PARSE:
                    throw new ParseException($error['message'], $error['type'], null, $error['file'], $error['line'], null);
                case E_NOTICE:
                    throw new NoticeException($error['message'], $error['type'], null, $error['file'], $error['line'], null);
                case E_CORE_ERROR:
                    throw new CoreErrorException($error['message'], $error['type'], null, $error['file'], $error['line'], null);
                case E_CORE_WARNING:
                    throw new CoreWarningException($error['message'], $error['type'], null, $error['file'], $error['line'], null);
                case E_COMPILE_ERROR:
                    throw new CompileErrorException($error['message'], $error['type'], null, $error['file'], $error['line'], null);
                case E_COMPILE_WARNING:
                    throw new CoreWarningException($error['message'], $error['type'], null, $error['file'], $error['line'], null);
                case E_USER_ERROR:
                    throw new UserErrorException($error['message'], $error['type'], null, $error['file'], $error['line'], null);
                case E_USER_WARNING:
                    throw new UserWarningException($error['message'], $error['type'], null, $error['file'], $error['line'], null);
                case E_USER_NOTICE:
                    throw new UserNoticeException($error['message'], $error['type'], null, $error['file'], $error['line'], null);
                case E_STRICT:
                    throw new StrictException($error['message'], $error['type'], null, $error['file'], $error['line'], null);
                case E_RECOVERABLE_ERROR:
                    throw new RecoverableErrorException($error['message'], $error['type'], null, $error['file'], $error['line'], null);
                case E_DEPRECATED:
                    throw new DeprecatedException($error['message'], $error['type'], null, $error['file'], $error['line'], null);
                case E_USER_DEPRECATED:
                    throw new UserDeprecatedException($error['message'], $error['type'], null, $error['file'], $error['line'], null);
            }
            ob_end_flush();
        }
        else
            ob_end_flush();
        return true;
    }
    
    public static function error_handler($err_severity, $err_msg, $err_file, $err_line, array $err_context){
        if(error_reporting() === 0) return false;
        self::$is_error=true;
        ResponseServerError::init();
        switch($err_severity){
            case E_ERROR:
                throw new FatalErrorException($err_msg, 0, $err_severity, $err_file, $err_line, $err_context);
            case E_WARNING:
                throw new WarningException($err_msg, 0, $err_severity, $err_file, $err_line, $err_context);
            case E_PARSE:
                throw new ParseException($err_msg, 0, $err_severity, $err_file, $err_line, $err_context);
            case E_NOTICE:
                throw new NoticeException($err_msg, 0, $err_severity, $err_file, $err_line, $err_context);
            case E_CORE_ERROR:
                throw new CoreErrorException($err_msg, 0, $err_severity, $err_file, $err_line, $err_context);
            case E_CORE_WARNING:
                throw new CoreWarningException($err_msg, 0, $err_severity, $err_file, $err_line, $err_context);
            case E_COMPILE_ERROR:
                throw new CompileErrorException($err_msg, 0, $err_severity, $err_file, $err_line, $err_context);
            case E_COMPILE_WARNING:
                throw new CoreWarningException($err_msg, 0, $err_severity, $err_file, $err_line, $err_context);
            case E_USER_ERROR:
                throw new UserErrorException($err_msg, 0, $err_severity, $err_file, $err_line, $err_context);
            case E_USER_WARNING:
                throw new UserWarningException($err_msg, 0, $err_severity, $err_file, $err_line, $err_context);
            case E_USER_NOTICE:
                throw new UserNoticeException($err_msg, 0, $err_severity, $err_file, $err_line, $err_context);
            case E_STRICT:
                throw new StrictException($err_msg, 0, $err_severity, $err_file, $err_line, $err_context);
            case E_RECOVERABLE_ERROR:
                throw new RecoverableErrorException($err_msg, 0, $err_severity, $err_file, $err_line, $err_context);
            case E_DEPRECATED:
                throw new DeprecatedException($err_msg, 0, $err_severity, $err_file, $err_line, $err_context);
            case E_USER_DEPRECATED:
                throw new UserDeprecatedException($err_msg, 0, $err_severity, $err_file, $err_line, $err_context);
            default:
                throw new UnknownException($err_msg, 0, $err_severity, $err_file, $err_line, $err_context);
        }
    }
}
