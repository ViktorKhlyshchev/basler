<?php

namespace Core\Module\Error;

use Core\Modules\Log;

class FatalErrorException extends \ErrorException{

    /**
     * FatalErrorException constructor.
     * @param $message
     * @param $code
     * @param $severity
     * @param $filename
     * @param $lineno
     * @param $previous
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\ParametersException
     * @throws \Core\Module\Exception\SystemException
     */
    public function __construct($message,$code,$severity,$filename,$lineno,$previous){

        $error = array('type' => 'E_ERROR',
            'title' => array('ru' => 'Фатальные ошибки времени выполнения.',
                'en' => 'Fatal run-time errors.'),
            'info' => array('ru' => 'Фатальные ошибки времени выполнения. Это неустранимые средствами самого скрипта ошибки, такие как ошибка распределения памяти и т.п. Выполнение скрипта в таком случае прекращается.',
                'en' => 'Fatal run-time errors. These indicate errors that can not be recovered from, such as a memory allocation problem. Execution of the script is halted.'),
            'code' => $code,
            'line' => $lineno,
            'file' => $filename,
            'severity' => $severity,
            'message' => $message,
            'previous' => $previous
        );

        Log::init($error);

        die;

    }

}