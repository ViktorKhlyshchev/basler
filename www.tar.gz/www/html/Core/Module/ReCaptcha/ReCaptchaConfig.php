<?php

namespace Core\Module\ReCaptcha;

class ReCaptchaConfig{

    /** @var string */
    public static $url ='https://www.google.com/recaptcha/api/siteverify';

    /** @var string */
    public static $key_public ='';

    /** @var string */
    public static $key_private ='';

}