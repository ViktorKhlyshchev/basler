<?php

namespace Core\Module\Path;

use Configs\DirConfig;

class Path{

    /** @var string */
    public static $DR;

    /**
     * @return bool
     */
    public static function reset_data(){

        self::$DR = null;

        return true;

    }

    /**
     * @return bool
     */
    public static function set_DR(){

        self::$DR =DR;
        DirConfig::$DR =DR;

        return true;

    }

    /**
     * @return string
     */
    public static function get_DR(){

        if(!empty(self::$DR)) return self::$DR;

        self::set_DR();

        return self::$DR;

    }

}