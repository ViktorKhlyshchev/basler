<?php

namespace Core\Module\App;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class App{

    /** @var int */
    public static $app_id;

    /** @var string */
    public static $app_name;

    /** @var string */
    public static $app_info;

    /**
     * Reset default data
     */
    public static function reset_data(){

        self::$app_id = null;
        self::$app_name = null;
        self::$app_info = null;

    }

    /**
     * @param string|null $app_name
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_app(string $app_name = null){

        if(empty($app_name)){

            $error = array('title' => 'Parameters problem',
                'info' => 'App name is empty'
            );

            throw new ParametersException($error);

        }

        $where_list = array('name_lower' => strtolower($app_name)
        );

        return Db::isset_row('_app',0,$where_list);

    }

    /**
     * @param int|null $app_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_app_id(int $app_id = null){

        if(empty($app_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'App ID is empty'
            );

            throw new ParametersException($error);

        }

        return Db::isset_row_id($app_id,'_app',0);

    }

    /**
     * @param string|null $app_name
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_app_id(string $app_name = null){

        if(empty($app_name)){

            $error = array('title' => 'Parameters problem',
                'info' => 'App name is empty'
            );

            throw new ParametersException($error);

        }

        $where_list = array('name_lower' => strtolower($app_name)
        );

        return Db::get_row_id('_app',0,$where_list);

    }

    /**
     * @param int|null $app_id
     * @param array $column_list
     * @return mixed|null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_app_data_from_app_id(int $app_id = null, array $column_list = []){

        if(empty($app_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'App ID is empty'
            );

            throw new ParametersException($error);

        }

        if(count($column_list) === 0)
            $column_list = array('id',
                'name',
                'info'
            );

        $data=Db::get_data_from_id($app_id,'_app',$column_list,0);

        if(empty($data)) return null;

        return $data;

    }

    /**
     * @param string|null $app_name
     * @param array $column_list
     * @return array|bool|null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_app_data_from_app_name(string $app_name = null, array $column_list = []){

        if(empty($app_name)){

            $error = array('title' => 'Parameters problem',
                'info' => 'App name is empty'
            );

            throw new ParametersException($error);

        }

        if(count($column_list) === 0)
            $column_list = array('id',
                'name',
                'info'
            );

        $q = array('select' => $column_list,
            'table' => '_app',
            'where_list' => array('name_lower' => strtolower($app_name),
                'type' => 0
            )
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r;

    }

    /**
     * @param string|null $app_name
     * @param string|null $app_info
     * @return mixed
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function add_app(string $app_name = null, string $app_info = null){

        if(empty($app_name)){

            $error = array('title' => 'Parameters problem',
                'info' => 'App name is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('table' => '_app',
            'values' => array('name_lower' => strtolower($app_name),
                'info' => empty($app_info) ? null : $app_info,
                'date_create' => 'NOW()',
                'date_update' => 'NOW()'
            )
        );

        $r = Db::insert($q);

        if(count($r) === 0){

            $error = array('title' => 'DB query problem',
                'info' => 'App was not added'
            );

            throw new DbQueryException($error);

        }

        return $r[0]['id'];

    }

    /**
     * @param string|null $app_name
     * @param bool $need_remove_app_version
     * @return array|bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_app(string $app_name = null, bool $need_remove_app_version=true){

        if(empty($app_name)){

            $error = array('title' => 'Parameters problem',
                'info' => 'App name is empty'
            );

            throw new ParametersException($error);

        }

        if($need_remove_app_version){

            $app_id=self::get_app_id($app_name);

            if(!empty($app_id))
                if(!AppVersion::remove_app_version($app_id)){

                    $error = array('title' => 'DB query problem',
                        'info' => 'App version was not removed'
                    );

                    throw new DbQueryException($error);

                }

        }

        $where_list = array('name_lower' => strtolower($app_name)
        );

        return Db::pseudo_delete_from_where_list('_app',0,$where_list);

    }

    /**
     * @param int|null $app_id
     * @param bool $need_remove_app_version
     * @return array|bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_app_id(int $app_id = null, bool $need_remove_app_version=true){

        if(empty($app_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'App ID is empty'
            );

            throw new ParametersException($error);

        }

        if($need_remove_app_version)
            if(!AppVersion::remove_app_version($app_id)){

                $error = array('title' => 'DB query problem',
                    'info' => 'App version was not removed'
                );

                throw new DbQueryException($error);

            }

        return Db::pseudo_delete_from_id($app_id,'_app',0);

    }


    /**
     * @param int|null $app_id
     * @return bool
     */
    public static function set_app_id_default(int $app_id = null){

        self::$app_id = empty($app_id) ? null : $app_id;

        return true;

    }

    /**
     * @param string|null $app_name
     * @return bool
     */
    public static function set_app_name_default(string $app_name = null){

        self::$app_name = empty($app_name) ? null : $app_name;

        return true;

    }

    /**
     * @param string|null $app_info
     * @return bool
     */
    public static function set_app_info_default(string $app_info = null){

        self::$app_info = empty($app_info) ? null : $app_info;

        return true;

    }

}