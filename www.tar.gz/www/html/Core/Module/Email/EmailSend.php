<?php

namespace Core\Module\Email;

use Core\Module\Exception\ParametersException;

class EmailSend {
    
    private static $email_list;
    
    private static $email_default;
    
    private static $title;
    
    private static $message;
    
    private static $file_list;
    
    private static $content;
    
    private static $separator;
    
    private static $headers;
    
    public static function reset_data(){
        self::$email_list = null;
        self::$email_default = null;
        self::$title = null;
        self::$message = null;
        self::$file_list = null;
        self::$content = null;
        self::$separator = null;
        self::$headers = null;
        return true;
    }
    
    private static function set_header_mime(){
        self::$headers ="From: ".\Config::$project_name." <".self::$email_default.">".EmailConfig::$email_eol;
        self::$headers .= "MIME-Version: 1.0".EmailConfig::$email_eol;
        self::$headers .= "Content-Type: multipart/mixed; boundary=\"".self::$separator."\"".EmailConfig::$email_eol;
        self::$headers .= "Content-Transfer-Encoding: 7bit".EmailConfig::$email_eol;
        self::$headers .= "This is a MIME encoded message.".EmailConfig::$email_eol;
        return true;
    }
    
    private static function set_header_html(string $email = null){
        if(empty($email)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Email is empty'
            );
            throw new ParametersException($error);
        }
        $list = array(
            "Reply-To: ".self::$email_default,
            "Return-Path: ".self::$email_default,
            "MIME-Version: 1.0",
            "Content-Type: text/html; charset=\"utf-8\"",
            "Content-Transfer-Encoding: 8bit",
            "From: ".\Config::$project_name." <".self::$email_default.">",
            "To: ".$email." <".$email.">",
            "X-Mailer: PHP/".phpversion(),
            "X-Priority: 3"
        );
        self::$headers=implode(EmailConfig::$email_eol,$list);
        return true;
    }
    
    private static function set_content(){
        self::$content ="--".self::$separator.EmailConfig::$email_eol;
        self::$content .= "Content-Type: text/html; charset=\"utf-8\"".EmailConfig::$email_eol;
//        self::$content .= "Content-Type: text/html; charset=\"iso-8859-1\"".EmailConfig::$email_eol;
        self::$content .= "Content-Transfer-Encoding: 8bit".EmailConfig::$email_eol;
        self::$content .= "<html>".EmailConfig::$email_eol;
        self::$content .= "<head>".EmailConfig::$email_eol;
        self::$content .= "".EmailConfig::$email_eol;
        self::$content .= "<title>".self::$title."</title>".EmailConfig::$email_eol;
        self::$content .= "</head>".EmailConfig::$email_eol;
        self::$content .= "<body>";
        self::$content .= self::$message.EmailConfig::$email_eol;
        self::$content .= "</body>";
        self::$content .= "</html>";
        return true;
    }
    
    private static function send(){
        $send_list = [];
        foreach(self::$email_list as $email){
            self::set_header_html($email);
            $send_list[$email] = mail($email, self::$title, self::$message, self::$headers);
        }
        return count($send_list) > 0;
    }
    
    private static function attach_file_list(){
        foreach(self::$file_list as $file_path)
            if(file_exists($file_path)){
                $path_list = mb_split('\/',$file_path);
                $file_name =end($path_list);
                $content =file_get_contents($file_path);
                $content =chunk_split(base64_encode($content));
                
                self::$content .= "--".self::$separator.EmailConfig::$email_eol;
                self::$content .= "Content-Type: application/octet-stream; name=\"".$file_name."\"".EmailConfig::$email_eol;
                self::$content .= "Content-Transfer-Encoding: base64".EmailConfig::$email_eol;
                self::$content .= "Content-Disposition: attachment".EmailConfig::$email_eol;
                self::$content .= $content.EmailConfig::$email_eol;
                self::$content .= "--".self::$separator."--";
            }
        return true;
    
    }
    
    public static function init(array $email_list = [], string $title = null, string $message = null, string $email_default = null, array $file_list = []){
        $error_info_list = [];
        if(count($email_list) === 0) $error_info_list[] = 'Email list is empty';
        if(empty($title)) $error_info_list[] = 'Title is empty';
        if(empty($message)) $error_info_list[] = 'Message is empty';
        if(count($error_info_list) > 0){
            $error = ['title' => 'Parameters problem', 'info' => $error_info_list];
            throw new ParametersException($error);
        }
        self::$email_list=EmailValidation::get_valid_email_list($email_list);
        if(count(self::$email_list) === 0){
            $error = ['title' => 'Parameters problem', 'info' => 'Email list is empty'];
            throw new ParametersException($error);
        }
        self::$title = $title;
        self::$message = $message;
        self::$file_list = empty($file_list) ? [] : $file_list;
        self::$email_default = empty($email_default) ? (\Config::$email_default):strtolower($email_default);
        self::$separator =md5(time());
        self::$content ='';
        self::set_content();
        self::attach_file_list();
        return self::send();
    }
}