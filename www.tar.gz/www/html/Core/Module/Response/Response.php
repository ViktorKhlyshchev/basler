<?php

namespace Core\Module\Response;

use Core\Module\Exception\ParametersException;
use Core\Module\Header\HeaderCode;
use Core\Module\Header\HeaderContentType;
use Core\Modules\Json;
use Core\Module\Worktime\Worktime;

class Response {

    public static $type = 'page';
    public static $data = [];
    public static $is_json = true;
    public static $is_already_send = false;
    public static $is_already_send_parent = false;

    public static function reset_data(){
        self::$type = 'page';
        self::$data = [];
        self::$is_already_send = false;
        return true;
    }

    public static function give_response(){
        if(self::$is_already_send_parent) return false;
        self::$is_already_send_parent = true;
        if(empty(self::$type)){
            $error = ['title' => 'Parameters problem', 'info' => 'Response type is empty'];
            HeaderCode::init(502);
            throw new ParametersException($error);
        }
        Worktime::finish(); #pred(debug_backtrace());
        switch(self::$type){
            case 'page':
            case 'json':{
                HeaderContentType::init('application/json');
                if(isset($_SERVER['HTTP_HOST']) && \Config::$is_debug) self::$data['host'] = $_SERVER['HTTP_HOST'];
                self::$data['worktime'] = Worktime::get_delta();
                echo Json::encode(self::$data);
                break;
            } # case 'page':{// self::$data['worktime'] = Worktime::get_delta();//    echo '<pre>'.print_r(self::$data, true).'</pre>';//  break;//   }
            case 'shell':{
                self::$data['worktime'] = Worktime::get_delta();
                if(self::$is_json)
                    echo Json::encode(self::$data);
                else
                    print_r(self::$data);
                break;
            }
        }
        return true;
    }
}