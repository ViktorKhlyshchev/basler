<?php

namespace Core\Module\Response;

use Core\Content\Error\ErrorContent;
use Core\Module\Header\HeaderCode;
use Core\Module\Worktime\Worktime;

class ResponseServerError extends Response {

    public static function init(array $data = null){ #pred(debug_backtrace());
        if(!empty($data)) self::$data = $data;
        HeaderCode::init(500);
        static::$data = ['error' => ErrorContent::get_error('server_error', self::$data), 'worktime' => Worktime::get_delta()];
        return true;
        return self::give_response();
    }
}