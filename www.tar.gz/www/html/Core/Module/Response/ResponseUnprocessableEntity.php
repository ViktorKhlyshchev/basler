<?php

namespace Core\Module\Response;

use Core\Content\Error\ErrorContent;
use Core\Module\Header\HeaderCode;
use Core\Module\Worktime\Worktime;

class ResponseUnprocessableEntity extends Response {

    public static function init(array $data = null){# pred(debug_backtrace());  # Unprocessable entity #1
        if(!empty($data)) self::$data = $data;
        HeaderCode::init(422);
        static::$data = ['error' => ErrorContent::get_error('unprocessable_entity', self::$data), 'worktime' => Worktime::get_delta()];
        return self::give_response();
    }
}