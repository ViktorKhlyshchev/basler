<?php

namespace Core\Module\Response;

use Core\Module\Header\HeaderCode;
use Core\Module\Worktime\Worktime;

class ResponseCustom extends Response {
    
    public static function init(array $data = null){
        if(!empty($data)) self::$data = $data;
        HeaderCode::init(200);
        self::$data['worktime'] = Worktime::get_delta();
        static::$data = self::$data;
        return self::give_response();
    }
}