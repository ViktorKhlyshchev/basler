<?php

namespace Core\Module\Response;

use Core\Content\Error\ErrorContent;
use Core\Module\Header\HeaderCode;
use Core\Module\Worktime\Worktime;

class ResponseNotFound extends Response {

    public static function init(array $data = null){
        if(!empty($data)) self::$data = $data;
        HeaderCode::init(404);
        static::$data = ['error' => ErrorContent::get_error('not_found', self::$data), 'worktime' => Worktime::get_delta()];
        return self::give_response();
    }
}