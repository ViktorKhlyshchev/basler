<?php

namespace Core\Module\Response;

use Common\Models\History; # use Core\Module\Header\HeaderCode;
use Core\Module\Token\Token;

class ResponseSuccess extends Response {

    public static function init(array $data = [], bool $is_json = true){
        self::$data = $data;
        self::$data['token'] = Token::$token_hash; #if(!cli) HeaderCode::init(200); //set_header_status()
        self::give_response();
        return History::update_success();
    }
}