<?php

namespace Core\Module\User;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class UserBlock {

    public static $user_block_id;

    public static $action_user_id;

    public static $user_block_admin_info;

    public static $user_block_user_info;

    public static $user_date_block;

    public static $column_name_list = array('id',
        'action_user_id',
        'admin_info',
        'user_info',
        'date_create',
        'date_update',
        'date_remove',
        'date_recovery'
    );

    public static function reset_data(){ # Reset default data

        self::$user_block_id = null;
        self::$action_user_id = null;
        self::$user_block_admin_info = null;
        self::$user_block_user_info = null;
        self::$user_date_block = null;
    }

    public static function isset_user_block(int $user_id = null){

        if(empty($user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User ID is empty'
            );
            throw new ParametersException($error);
        }

        $where_list = array('user_id' => $user_id
        );

        return Db::isset_row('_user_block', 0, $where_list);
    }

    public static function get_user_block_full_from_column_name(int $user_id = null, array $column_name_list = []){

        $error_info_list = [];

        if(empty($user_id)) $error_info_list[] = 'User ID is empty';

        if(count($column_name_list) == 0) $error_info_list[] = 'Column name list is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);
        }

        $column_name_checked_list = [];

        foreach($column_name_list as $column_name)
            if(!empty($column_name))
                if(array_search($column_name, self::$column_name_list !== false))
                    $column_name_checked_list[] = $column_name;

        if(count($column_name_checked_list) == 0){
            $error = array('title' => 'Parameters problem',
                'info' => 'Column name list is empty'
            );

            throw new ParametersException($error);
        }

        $q = array('select' => $column_name_checked_list,
            'table' => '_user_block',
            'where' => array('user_id' => $user_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) == 0) return null;

        return $r[0];
    }

    public static function get_user_block_full_info(int $user_id = null){

        if(empty($user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User ID is empty'
            );

            throw new ParametersException($error);
        }

        $user_block_info = self::get_user_block_full_from_column_name($user_id, self::$column_name_list);

        if(empty($user_block_info)) return null;

        $data = array('id' => $user_block_info[0]['id'],
            'action_user_id' => $user_block_info[0]['action_user_id'],
            'date_create' => $user_block_info[0]['date_create']
        );

        if(!empty($user_block_info[0]['admin_info'])) $data['admin_info'] = $user_block_info[0]['admin_info'];

        if(!empty($user_block_info[0]['user_info'])) $data['user_info'] = $user_block_info[0]['user_info'];

        return $data;
    }

    public static function get_user_block_admin_info(int $user_id = null){

        if(empty($user_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'User ID is empty'
            );

            throw new ParametersException($error);
        }

        $column_name_list = ['id', 'admin_info'];

        $user_block_info = self::get_user_block_full_from_column_name($user_id, $column_name_list);

        if(empty($user_block_info)) return null;

        $data = array('id' => $user_block_info[0]['id']
        );

        if(!empty($user_block_info[0]['admin_info'])) $data['admin_info'] = $user_block_info[0]['admin_info'];

        return $data;
    }

    public static function get_user_block_user_info(int $user_id = null){

        if(empty($user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User ID is empty'
            );

            throw new ParametersException($error);
        }

        $column_name_list = array('id',
            'user_info'
        );

        $user_block_info = self::get_user_block_full_from_column_name($user_id, $column_name_list);

        if(empty($user_block_info)) return null;

        $data = array('id' => $user_block_info[0]['id']
        );

        if(!empty($user_block_info[0]['user_info'])) $data['user_info'] = $user_block_info[0]['user_info'];

        return $data;
    }

    public static function get_user_block_list(array $user_id_list = []){

        if(count($user_id_list) == 0){

            $error = array('title' => 'Parameters problem',
                'info' => 'User ID list is empty'
            );

            throw new ParametersException($error);
        }

        $id_list = [];

        foreach($user_id_list as $user_id)
            if(!empty($user_id)) $id_list[] = $user_id;

        if(count($id_list) == 0){
            $error = array('title' => 'Parameters problem',
                'info' => 'User ID list is empty'
            );

            throw new ParametersException($error);
        }

        $q = array('select' => array('user_id'),
            'table' => '_user_block',
            'where' => array('user_id' => $id_list,
                'type' => 0
            )
        );

        $r = Db::select($q);

        if(count($r) == 0) return [];

        $list = [];

        foreach($r as $row)
            $list[] = $row['user_id'];

        return $list;
    }

    public static function add_user_block(int $action_user_id = null, int $user_id = null, string $admin_info = null, string $user_info = null){

        $error_info_list = [];

        if(empty($action_user_id)) $error_info_list[] = 'Action user ID is empty';

        if(empty($user_id)) $error_info_list[] = 'User ID is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);
        }

        $value_list = array('action_user_id' => $action_user_id,
            'user_id' => $user_id,
            'date_create' => 'NOW()'
        );

        if(!empty($admin_info)) $value_list['admin_info'] = $admin_info;

        if(!empty($user_info)) $value_list['user_info'] = $user_info;

        $q = array('table' => '_user_block',
            'values' => $value_list
        );

        $r = Db::insert($q);

        if(count($r) == 0){

            $error = array('title' => 'DB query pronlem',
                'info' => $error_info_list
            );

            throw new DbQueryException($error);
        }

        return $r[0]['id'];
    }

    public static function remove_user_block_id(int $user_block_id = null){

        if(empty($user_block_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'User block ID is empty'
            );

            throw new ParametersException($error);

        }

        if(!Db::pseudo_delete_from_id($user_block_id, '_user_block', 0)){

            $error = array('title' => 'DB query problem',
                'info' => 'User block was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;
    }

    public static function remove_user_block(int $user_id = null){

        if(empty($user_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'User ID is empty'
            );

            throw new ParametersException($error);

        }

        $where_list = array('user_id' => $user_id
        );

        if(!Db::pseudo_delete_from_where_list('_user_block', 0, $where_list)){

            $error = array('title' => 'DB query problem',
                'info' => 'User block was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    public static function set_user_block_id_default(int $user_block_id = null){
        self::$user_block_id = empty($user_block_id) ? null : $user_block_id;
    }

    public static function set_action_user_id_default(int $action_user_id = null){
        self::$action_user_id = empty($action_user_id) ? null : $action_user_id;
    }

    public static function set_user_block_admin_info(string $user_block_admin_info = null){

        self::$user_block_admin_info = empty($user_block_admin_info) ? null : $user_block_admin_info;

    }

    public static function set_user_block_user_info(string $user_block_user_info = null){
        self::$user_block_user_info = empty($user_block_user_info) ? null : $user_block_user_info;
    }

}