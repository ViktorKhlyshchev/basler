<?php

namespace Core\Module\User;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class UserBalanceTransaction{

    /** @var string */
    public static $tn='_user_balance_transaction';

    /**
     * @param array $user_id_list
     * @return array
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_user_balance_isset_transaction(array $user_id_list = []){

        if(count($user_id_list) === 0) return [];

        $q = [
            'select' => [
                'user_id'
            ],
            'table' => self::$tn,
            'where' => [
                'user_id' => $user_id_list,
                'action' => [
                    'auto_payment',
                    'promo_code',
                    'promo_login_invite',
                    'promo_login_use',
                    'add_hand_money',
                    'confirm_email_money',
                ],
                'type' => 0
            ],
            'group' => [
                [
                    'column' => 'user_id'
                ]
            ]
        ];

        $r = Db::select($q);

        if(count($r) === 0) return [];

        $list = [];

        foreach($r as $row)
            $list[$row['user_id']] = $row['user_id'];

        return $list;

    }

    /**
     * @param string|null $hash
     * @param bool $is_confirm
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_user_balance_transaction_id_from_hash(string $hash = null, bool $is_confirm=false){

        if(empty($hash)){

            $error = [
                'title' => ParametersException::$title,
                'info' => 'Hash is empty'
            ];

            throw new ParametersException($error);

        }

        $where_list = [
            'hash' => $hash,
            'is_confirm' => (int)$is_confirm
        ];

        return Db::get_row_id(self::$tn,0,$where_list);

    }

    /**
     * @param int|null $user_id
     * @return array
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_user_balance_transaction_list(int $user_id = null){

        if(empty($user_id)){

            $error = [
                'title' => ParametersException::$title,
                'info' => 'User ID is empty'
            ];

            throw new ParametersException($error);

        }

        $q = [
            'table' => self::$tn,
            'select' => [
                'id',
                'wallet_name_id',
                'user_wallet_address',
                'target_wallet_address',
                'action',
                'transaction_sum',
                'transaction_wallet_sum',
                'balance',
                'promo_code',
                'date_create'
            ],
            'where' => [
                'user_id' => $user_id,
                'type' => 0
            ],
            'order' => [
                [
                    'column' => 'id',
                    'direction' => 'desc'
                ]
            ]
        ];

        $r = Db::select($q);

        if(count($r) === 0) return [];

        $list = [];

        foreach($r as $row)
            $list[] = [
                'id' => $row['id'],
                'wallet_name_id' => $row['wallet_name_id'],
                'action' => $row['action'],
                'transaction_sum' => $row['transaction_sum'],
                'transaction_wallet_sum' => $row['transaction_wallet_sum'],
                'balance' => $row['balance'],
                'user_wallet_address' => $row['user_wallet_address'],
                'target_wallet_address' => $row['target_wallet_address'],
                'promo_code' => $row['promo_code'],
                'date_create' => strtotime($row['date_create'])
            ];

        return $list;

    }

    /**
     * @param int|null $user_id
     * @param int|null $wallet_name_id
     * @param int|null $user_wallet_id
     * @param int|null $target_wallet_id
     * @param int|null $user_wallet_donate_id
     * @param string|null $action
     * @param float|null $sum
     * @param string|null $info
     * @param float|null $balance
     * @param string|null $user_wallet_address
     * @param string|null $target_wallet_address
     * @param float|null $transaction_wallet_sum
     * @param string|null $promo_code
     * @return int
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function add_user_balance_transaction(int $user_id = null, int $wallet_name_id = null, int $user_wallet_id = null, int $target_wallet_id = null, int $user_wallet_donate_id = null, string $action = null, float $sum = null, string $info = null, float $balance = null, string $user_wallet_address = null, string $target_wallet_address = null, float $transaction_wallet_sum = null, string $promo_code = null){

        $error_info_list = [];

        if(empty($user_id)) $error_info_list[] = 'User ID is empty';

        if(empty($action)) $error_info_list[] = 'Action is empty';

        if(empty($sum)) $error_info_list[] = 'Sum is empty';

        if(count($error_info_list) > 0){

            $error = [
                'title' => ParametersException::$title,
                'info' => $error_info_list
            ];

            throw new ParametersException($error);

        }

        $q = [
            'table' => self::$tn,
            'values' => [
                'user_id' => $user_id,
                'wallet_name_id' => $wallet_name_id,
                'user_wallet_id' => $user_wallet_id,
                'target_wallet_id' => $target_wallet_id,
                'user_wallet_donate_id' => $user_wallet_donate_id,
                'action' => $action,
                'transaction_sum' => $sum,
                'transaction_wallet_sum' => $transaction_wallet_sum,
                'balance' => empty($balance) ? null : $balance,
                'user_wallet_address' => empty($user_wallet_address) ? null : $user_wallet_address,
                'target_wallet_address' => empty($target_wallet_address) ? null : $target_wallet_address,
                'info' => empty($info) ? null : $info,
                'promo_code' => empty($promo_code) ? null : $promo_code,
                'date_create' => 'NOW()',
                'date_update' => 'NOW()',
                'type' => 0
            ]
        ];

        $r = Db::insert($q);

        if(count($r) === 0){

            $error = [
                'title' => DbQueryException::$title,
                'info' => 'User balance transaction was not add'
            ];

            throw new DbQueryException($error);

        }

        return $r[0]['id'];

    }

    /**
     * @param int|null $user_balance_transaction_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function update_user_balance_transaction_to_confirmed(int $user_balance_transaction_id = null){

        if(empty($user_balance_transaction_id)){

            $error = [
                'title' => ParametersException::$title,
                'info' => 'User balance transaction ID is empty'
            ];

            throw new ParametersException($error);

        }

        $q = [
            'table' => self::$tn,
            'set' => [
                'is_confirm' => 1,
                'date_update' => 'NOW()'
            ],
            'where' => [
                'id' => $user_balance_transaction_id,
                'type' => 0
            ]
        ];

        if(!Db::update($q)){

            $error = [
                'title' => DbQueryException::$title,
                'info' => 'User balance transaction was not update'
            ];

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $user_balance_transaction_id
     * @param float $balance
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function update_balance_in_user_balance_transaction(int $user_balance_transaction_id = null, float $balance=0){

        if(empty($user_balance_transaction_id)){

            $error = [
                'title' => ParametersException::$title,
                'info' => 'User balance transaction ID is empty'
            ];

            throw new ParametersException($error);

        }

        $q = [
            'table' => self::$tn,
            'set' => [
                'balance' => $balance,
                'date_update' => 'NOW()'
            ],
            'where' => [
                'id' => $user_balance_transaction_id,
                'type' => 0
            ]
        ];

        if(!Db::update($q)){

            $error = [
                'title' => DbQueryException::$title,
                'info' => 'User balance transaction was not update'
            ];

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $user_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_user_balance_transaction(int $user_id = null){

        if(empty($user_id)){

            $error = [
                'title' => ParametersException::$title,
                'info' => 'User ID is empty'
            ];

            throw new ParametersException($error);

        }

        $where_list = [
            'user_id' => $user_id
        ];

        if(!Db::pseudo_delete_from_where_list(self::$tn,0,$where_list)){

            $error = [
                'title' => DbQueryException::$title,
                'info' => 'User balance was not remove'
            ];

            throw new DbQueryException($error);

        }

        return true;

    }

}