<?php

namespace Core\Module\User;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class UserBalance{

    /** @var string */
    public static $tn='_user_balance';

    /**
     * @param int|null $user_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_user_balance(int $user_id = null){

        if(empty($user_id)){

            $error = [
                'title' => ParametersException::$title,
                'info' => 'User ID is empty'
            ];

            throw new ParametersException($error);

        }

        $where_list = [
            'user_id' => $user_id
        ];

        return Db::isset_row(self::$tn,0,$where_list);

    }

    /**
     * @param int|null $user_id
     * @return int|null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_user_balance(int $user_id = null){

        if(empty($user_id)){

            $error = [
                'title' => ParametersException::$title,
                'info' => 'User ID is empty'
            ];

            throw new ParametersException($error);

        }

        $q = [
            'table' => self::$tn,
            'select' => [
                'balance'
            ],
            'where' => [
                'user_id' => $user_id,
                'type' => 0
            ],
            'limit' => 1
        ];

//        print_r($q);

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0]['balance'];

    }

    /**
     * @param int|null $user_id
     * @return int|null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_user_balance_id(int $user_id = null){

        if(empty($user_id)){

            $error = [
                'title' => ParametersException::$title,
                'info' => 'User ID is empty'
            ];

            throw new ParametersException($error);

        }

        $q = [
            'table' => self::$tn,
            'select' => [
                'id'
            ],
            'where' => [
                'user_id' => $user_id,
                'type' => 0
            ],
            'limit' => 1
        ];

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0]['id'];

    }

    /**
     * @param array $user_id_list
     * @return array
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_user_balance_list(array $user_id_list = []){

        if(count($user_id_list) === 0) return [];

        $q = [
            'table' => self::$tn,
            'select' => [
                'user_id',
                'balance'
            ],
            'where' => [
                'user_id' => $user_id_list,
                'type' => 0
            ]
        ];

        $r = Db::select($q);

        if(count($r) === 0) return [];

        $list = [];

        foreach($r as $row)
            $list[$row['user_id']] = $row['balance'];

        return $list;

    }

    /**
     * @param int|null $user_id
     * @return mixed
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function add_user_balance(int $user_id = null){

        if(empty($user_id)){

            $error = [
                'title' => ParametersException::$title,
                'info' => 'User ID is empty'
            ];

            throw new ParametersException($error);

        }

        $q = [
            'table' => self::$tn,
            'values' => [
                'user_id' => $user_id,
                'balance' => 0,
                'date_create' => 'NOW()',
                'date_update' => 'NOW()',
                'type' => 0
            ]
        ];

        $r = Db::insert($q);

        if(count($r) === 0){

            $error = [
                'title' => DbQueryException::$title,
                'info' => 'User balance was not add'
            ];

            throw new DbQueryException($error);

        }

        return $r[0]['id'];

    }

    /**
     * @param int|null $user_id
     * @param float $balance
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function update_user_balance(int $user_id = null, float $balance=0){

        if(empty($user_id)){

            $error = [
                'title' => ParametersException::$title,
                'info' => 'User ID is empty'
            ];

            throw new ParametersException($error);

        }

        $q = [
            'table' => self::$tn,
            'set' => [
                'balance' => $balance,
                'date_update' => 'NOW()'
            ],
            'where' => [
                'user_id' => $user_id,
                'type' => 0
            ]
        ];

        if(!Db::update($q)){

            $error = [
                'title' => DbQueryException::$title,
                'info' => 'User balance was not update'
            ];

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $user_id
     * @param float $balance
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function add_money_user_balance(int $user_id = null, float $balance=0){

        if(empty($user_id)){

            $error = [
                'title' => ParametersException::$title,
                'info' => 'User ID is empty'
            ];

            throw new ParametersException($error);

        }

        $q = [
            'table' => self::$tn,
            'set' => [
                'balance' => [
                    'function' => 'balance + '.$balance
                ],
                'date_update' => 'NOW()'
            ],
            'where' => [
                'user_id' => $user_id,
                'type' => 0
            ]
        ];

        if(!Db::update($q)){

            $error = [
                'title' => DbQueryException::$title,
                'info' => 'User balance was not update'
            ];

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $user_id
     * @param float $balance
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_money_user_balance(int $user_id = null, float $balance=0){

        if(empty($user_id)){

            $error = [
                'title' => ParametersException::$title,
                'info' => 'User ID is empty'
            ];

            throw new ParametersException($error);

        }

        $q = [
            'table' => self::$tn,
            'set' => [
                'balance' => [
                    'function' => 'balance - '.$balance
                ],
                'date_update' => 'NOW()'
            ],
            'where' => [
                'user_id' => $user_id,
                'type' => 0
            ]
        ];

        if(!Db::update($q)){

            $error = [
                'title' => DbQueryException::$title,
                'info' => 'User balance was not update'
            ];

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $user_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_user_balance(int $user_id = null){

        if(empty($user_id)){

            $error = [
                'title' => ParametersException::$title,
                'info' => 'User ID is empty'
            ];

            throw new ParametersException($error);

        }

        $where_list = [
            'user_id' => $user_id
        ];

        if(!Db::pseudo_delete_from_where_list(self::$tn,0,$where_list)){

            $error = [
                'title' => DbQueryException::$title,
                'info' => 'User balance was not remove'
            ];

            throw new DbQueryException($error);

        }

        return true;

    }

}