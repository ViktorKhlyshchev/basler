<?php

namespace Core\Module\User;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class UserLogin {

    public static $user_login_id;
    public static $login;
    public static $password;
    public static $tn = '_user_login';

    public static function reset_data(){
        self::$user_login_id = null;
        self::$login = null;
        self::$password = null;
        return true;
    }

    public static function is_verify_password(int $user_id = null,string $password = null){
        $error_info_list = [];
        if(empty($user_id)) $error_info_list[] = 'User ID is empty';
        if(empty($password)) $error_info_list[] = 'Password is empty';
        if(count($error_info_list) > 0){
            $error = [
                'title' => ParametersException::$title,
                'info' => $error_info_list
            ];
            throw new ParametersException($error);
        }
        $where_list = [
            'user_id' => $user_id,
            'password' => $password
        ];
        return Db::isset_row(self::$tn,0,$where_list);
    }

    public static function isset_user_login_in_active(string $login = null, int $user_id = null){
        if(empty($login)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Login is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('id'),
            'table' => self::$tn,
            'where' => array(
                 array('column' => 'login',
                    'value' => strtolower($login)
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'limit' => 1
        );
        if(!empty($user_id)) $q['where'][] = array('column' => 'user_id',
                'method' => '!=',
                'value' => $user_id
            );
        $r = Db::select($q);
        return count($r) > 0;
    }

    public static function isset_user_login_in_all(string $login = null){
        if(empty($login)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Login is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('id'),
            'table' => self::$tn,
            'where' => array('login' => strtolower($login),
                'type' => [0, 1]
            ),
            'limit' => 1
        );
        $r = Db::select($q);
        return count($r) > 0;
    }

    public static function add_user_login(int $user_id = null, string $login = null, string $password = null){
        $error_info_list = [];
        if(empty($user_id)) $error_info_list['user_id'] = 'User ID is empty';
        if(empty($login)) $error_info_list['login_id'] = 'Login is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );
            throw new ParametersException($error);
        }
        $q = array('table' => self::$tn,
            'values' => array('user_id' => $user_id,
                'login' => strtolower($login),
                'date_create' => 'NOW()'
            )
        );
        if(!empty($password)) $q['values']['password'] = $password;
        $r = Db::insert($q);
        if(count($r) === 0){
            $error = ['title' => 'DB query problem', 'info' => 'User login was not added'];
            throw new ParametersException($error);
        }
        return $r[0]['id'];
    }

    public static function replace_user_login_for_user_id(int $user_id = null,string $login = null){
        $error_info_list = [];
        if(empty($user_id)) $error_info_list[] = 'User ID is empty';
        if(empty($login)) $error_info_list[] = 'Login is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );
            throw new ParametersException($error);
        }
        self::remove_user_login_from_user_id($user_id);
        return self::add_user_login($user_id,$login);
    }

    public static function check_user_password(int $user_id = null,string $password = null){
        $error_info_list = [];
        if(empty($user_id)) $error_info_list['user_id'] = 'User ID is empty';
        if(empty($password)) $error_info_list['password'] = 'Password is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );
            throw new ParametersException($error);
        }
        $where_list = array('user_id' => $user_id,
            'password' => $password
        );
        return Db::isset_row(self::$tn,0,$where_list);
    }

    public static function get_user_id(string $login = null,string $password = null){
        $error_info_list = [];
        if(empty($password)) $error_info_list[] = 'Password is empty';
        if(empty($login)) $error_info_list[] = 'Login is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('user_id'),
            'table' => self::$tn,
            'where' => array('login' => $login,
                'password' => $password, 'type' => 0),
            'limit' => 1
        );
        $r = Db::select($q);
        if(count($r) === 0) return null;
        return $r[0]['user_id'];
    }

    public static function get_user_id_from_login(string $login = null){
        $error_info_list = [];
        if(empty($login)) $error_info_list[] = 'Login is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('user_id'),
            'table' => self::$tn,
            'where' => array('login' => $login, 'type' => 0),
            'limit' => 1
        );
        $r = Db::select($q);
        if(count($r) === 0) return null;
        return $r[0]['user_id'];
    }

    public static function get_user_login_info(string $login = null, string $password = null){ #pre(func_get_args());
        $error_info_list = [];
        if(empty($password)) $error_info_list[] = 'Password is empty';
        if(empty($login)) $error_info_list[] = 'Login is empty';
        if(count($error_info_list)){
            $error = ['title' => 'Parameters problem', 'info' => $error_info_list];
            throw new ParametersException($error);
        }
        $q = ['table' => self::$tn, 'select' => ['user_id', 'type'], 'where' => ['login' => $login, 'password' => $password, 'type' => 0], 'limit' => 1]; #pred($q);
        $r = Db::select($q); #pre(Db::$query_last);pred($r);
        if(count($r) === 0) return null;
        return ['user_id' => $r[0]['user_id'],  'type' => $r[0]['type']];
    }

    public static function get_user_login_info_from_user_id(int $user_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem', 'info' => 'User ID is empty');
            throw new ParametersException($error);
        }
        $q = array('select' => array('id', 'login', 'password'),
            'table' => self::$tn,
            'where' => array('user_id' => $user_id, 'type' => 0),
            'limit' => 1
        );
        $r = Db::select($q);
        if(count($r) === 0) return null;
        return ['id' => $r[0]['id'], 'login' => $r[0]['login'], 'password' => $r[0]['password']];
    }

    public static function get_user_login(int $user_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem', 'info' => 'User ID is empty');
            throw new ParametersException($error);
        }
        $q = array('select' => array('login'),
            'table' => self::$tn,
            'where' => array('user_id' => $user_id, 'type' => 0),
            'limit' => 1
        );
        $r = Db::select($q);
        if(count($r) === 0) return null;
        return $r[0]['login'];
    }

    public static function get_user_login_data(int $user_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem', 'info' => 'User ID is empty');
            throw new ParametersException($error);
        }
        $q = array('select' => array('id', 'login', 'password'),
            'table' => self::$tn,
            'where' => array('user_id' => $user_id, 'type' => 0),
            'limit' => 1
        );
        $r = Db::select($q);
        if(count($r) === 0) return null;
        return array('id' => $r[0]['id'],
            'login' => $r[0]['login'],
            'password' => $r[0]['password']
        );
    }

    public static function get_user_login_default(){

        if(!empty(self::$login)) return self::$login;

        if(empty(User::$user_id)){return;
            $error = array('title' => 'Parameters problem', 'info' => 'Default user ID is empty #5');
            throw new ParametersException($error);
            return;
        }
        self::$login = self::get_user_login(User::$user_id);
        return self::$login;
    }

    public static function remove_user_login_from_user_id_and_login(int $user_id = null,string $login = null){
        $error_info_list = [];
        if(empty($user_id)) $error_info_list[] = 'User ID is empty';
        if(empty($login)) $error_info_list[] = 'Login is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem', 'info' => $error_info_list);
            throw new ParametersException($error);
        }
        $q = array('table' => self::$tn,
            'set' => array('date_remove' => 'NOW()', 'type' => 1),
            'where' => array('user_id' => $user_id,
                'login' => $login,
                'type' => 0
            )
        );
        return Db::update($q);
    }

    public static function remove_user_login_from_user_id(int $user_id = null){
        if(empty($user_id)){
            $error = ['title' => 'Parameters problem', 'info' => 'User ID is empty'];
            throw new ParametersException($error);
        }
        $q = ['table' => self::$tn,
            'set' => ['date_remove' => 'NOW()', 'type' => 1],
            'where' => ['user_id' => $user_id, 'type' => 0]];
        return Db::update($q);
    }

    public static function remove_user_login_id(int $user_login_id = null){
        if(empty($user_login_id)){
            $error = ['title' => 'Parameters problem', 'info' => 'User login ID is empty'];
            throw new ParametersException($error);
        }
        $q = ['table' => self::$tn,
            'set' => ['date_remove' => 'NOW()', 'type' => 1],
            'where' => ['id' => $user_login_id, 'type' => 0]
        ];
        return Db::update($q);
    }

    public static function remove_user_login(int $user_id = null){
        if(empty($user_id)){ $error = ['title' => 'Parameters problem', 'info' => 'User ID is empty']; throw new ParametersException($error); }
        $where_list = ['user_id' => $user_id];
        if(!Db::pseudo_delete_from_where_list(self::$tn,0,$where_list)){ $error = ['title' => DbQueryException::$title, 'info' => 'User login was not remove']; throw new DbQueryException($error); }
        return true;
    }
}