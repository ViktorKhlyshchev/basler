<?php

namespace Core\Module\User;

use Core\Module\Db\Db;
use Core\Module\Email\EmailValidation;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class UserEmail {

    public static $tn = '_user_email';

    public static $user_email_id;

    public static $user_email;

    public static $user_email_list;

    public static function reset_data(){
        self::$user_email_id = null;
        self::$user_email = null;
        self::$user_email_list = null;
    }

    public static function isset_user_email_id(int $user_email_id = null){
        if(empty($user_email_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User email ID is empty'
            );
            throw new ParametersException($error);
        }
        return Db::isset_row_id($user_email_id, '_user_email', 0);
    }

    public static function isset_user_email_in_active_list(string $email = null, int $user_id = null){
        if(empty($email)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Email is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('id'),
            'table' => '_user_email',
            'where' => array(
                 array('column' => 'email',
                    'value' => $email
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'limit' => 1
        );
        if(!empty($user_id)) $q['where']['user_id'] = array('column' => 'user_id',
                'method' => '!=',
                'value' => $user_id
            );
        $r = Db::select($q);
        return count($r) > 0;
    }

    public static function get_user_len(){
        return Db::get_row_len(self::$tn, 0);
    }

    public static function isset_user_email_in_all_list(string $email = null, int $user_id = null){
        if(empty($email)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Email is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('id'),
            'table' => '_user_email',
            'where' => array('email' => $email,
                'type' => [0, 1]
            ),
            'limit' => 1
        );
        if(!empty($user_id)) $q['where']['user_id'] = array('column' => 'user_id',
                'method' => '!=',
                'value' => $user_id
            );
        $r = Db::select($q); #pred($q);
        return count($r) > 0;
    }

    public static function get_user_email_id(int $user_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User ID is empty'
            );
            throw new ParametersException($error);
        }
        $q = [
            'table' => self::$tn,
            'select' => [
                'id'
            ],
            'where' => [
                'user_id' => $user_id,
                'type' => 0
            ],
            'limit' => 1
        ];
        $r = Db::select($q);
        if(count($r) == 0) return null;
        return $r[0]['id'];
    }

    public static function get_user_email_list_for_mailing(int $start = 0, int $len = 100){
        $q = [
            'table' => self::$tn,
            'select' => [
                'user_id',
                'email'
            ],
            'where' => [
                'type' => 0
            ],
            'limit' => [$start, $len]
        ];
        $r = Db::select($q);
        if(count($r) == 0) return [];
        $list = [];
        foreach($r as $row)
            $list[] = [
                'user_id' => $row['user_id'],
                'email' => $row['email']
            ];
        return $list;
    }

    public static function add_user_email(int $user_id = null, string $user_email = null){
        $error_info_list = [];
        if(empty($user_id)) $error_info_list[] = 'User ID is empty';
        if(empty($user_email)) $error_info_list[] = 'User email is empty';
        else if(!EmailValidation::is_valid_email($user_email)) $error_info_list[] = 'User email is not valid';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );
            throw new ParametersException($error);
        }
        $q = array('table' => '_user_email',
            'values' => array('user_id' => $user_id,
                'email' => strtolower($user_email),
                'date_create' => 'NOW()'
            )
        );
        $r = Db::insert($q);
        if(count($r) == 0){
            $error = array('title' => 'DB query problem',
                'info' => 'User email was not added'
            );
            throw new DbQueryException($error);
        }
        return $r[0]['id'];
    }

    public static function get_user_email_list(int $user_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User ID is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('email'),
            'table' => '_user_email',
            'where' => array('user_id' => $user_id,
                'type' => 0
            )
        );
        $r = Db::select($q);
        if(count($r) == 0) return [];
        $list = [];
        foreach($r as $row)
            $list[] = $row['email'];
        return $list;
    }

    public static function get_user_email_last(int $user_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User ID is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('email'),
            'table' => '_user_email',
            'where' => array('user_id' => $user_id, 'type' => 0),
            'order' => array(
                 array('column' => 'date_create',
                    'direct' => 'desc'
                )
            ),
            'limit' => 1
        );
        $r = Db::select($q);
        if(count($r) == 0) return [];
        return $r[0]['email'];
    }

    public static function get_user_id(string $email = null){
        if(empty($email)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Email is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('user_id'),
            'table' => '_user_email',
            'where' => array('email' => $email, 'type' => 0),
            'limit' => 1
        );
        $r = Db::select($q);
        if(count($r) == 0) return null;
        return $r[0]['user_id'];
    }

    public static function get_user_email_info(string $email = null){
        if(empty($email)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Email is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('user_id',
                'type'),
            'table' => '_user_email',
            'where' => array('email' => $email, 'type' => 0),
            'limit' => 1
        );
        $r = Db::select($q);
        if(count($r) == 0) return null;
        return array('user_id' => $r[0]['user_id'],
            'type' => $r[0]['type']
        );
    }

    public static function remove_user_email_id(int $user_email_id = null){
        if(empty($user_email_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User email ID is empty'
            );
            throw new ParametersException($error);
        }
        if(!Db::pseudo_delete_from_id($user_email_id, '_user_email', 0)){
            $error = array('title' => 'DB query problem',
                'info' => 'User email was not removed'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_user_email(int $user_id = null, string $user_email = null){
        if(empty($user_email)&&empty($user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'All parameters are empty'
            );
            throw new ParametersException($error);
        }
        $where_list = [];
        if(!empty($user_id)) $where_list['user_id'] = $user_id;
        if(!empty($user_email)) $where_list['email'] = $user_email;
        if(!Db::pseudo_delete_from_where_list('_user_email', 0, $where_list)){
            $error = array('title' => 'DB query problem',
                'info' => 'User email was not removed'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_user_email_to_unshow(int $user_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'All parameters are empty'
            );
            throw new ParametersException($error);
        }
        $q = [
            'table' => self::$tn,
            'set' => [
                'date_update' => 'NOW()',
                'date_remove' => 'NOW()',
                'type' => 2
            ],
            'where' => [
                'user_id' => $user_id,
                'type' => 0
            ]
        ];
        if(!Db::update($q)){
            $error = array('title' => 'DB query problem',
                'info' => 'User email was not removed'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function set_user_email_id_default(int $user_email_id = null){
        self::$user_email_id = empty($user_email_id) ? null : $user_email_id;
    }

    public static function set_user_email_default(string $user_email = null){
        self::$user_email = empty($user_email) ? null : $user_email;
    }

    public static function set_user_email_list(array $user_email_list = null){
        self::$user_email_list = empty($user_email_list) ? null : $user_email_list;
    }
}
