<?php

namespace Core\Module\User;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;
use Core\Module\Session\Session;
use Core\Module\Token\Token;

class UserLogout {

    public static $user_logout_id;
    public static $tn = '_user_logout';

    public static function isset_user_logout_id(int $user_logout_id = null){
        if(empty($user_logout_id)){
            $error = ['title' => 'Parameters problem', 'info' => 'User logout ID is empty'];
            throw new ParametersException($error);
        }
        return Db::isset_row_id($user_logout_id,'_user_logout',0);
    }

    public static function isset_user_logout(int $user_id = null, int $token_id = null, int $session_id = null){
        if(empty($user_id)&&empty($token_id)&&empty($session_id)){
            $error = array('title' => 'Paramteres problem', 'info' => 'All parameters are empty');
            throw new ParametersException($error);
        }
        $where_list = [];
        if(!empty($user_id)) $where_list['user_id'] = $user_id;
        if(!empty($token_id)) $where_list['token_id'] = $token_id;
        if(!empty($session_id)) $where_list['session_id'] = $session_id;
        if(!count($where_list)){
            $error = array('title' => 'Paramteres problem', 'info' => 'All parameters are empty');
            throw new ParametersException($error);
        }
        return Db::isset_row('_user_logout',0,$where_list);
    }

    public static function add_user_logout(int $user_id = null, int $token_id = null, int $session_id = null){

        $error_info_list = [];
        if(empty($user_id)) $error_info_list[] = 'User ID is empty';
        if(empty($token_id)) $error_info_list[] = 'Token ID is empty';
        if(empty($session_id)) $error_info_list[] = 'Session ID is empty';
        if(count($error_info_list)){
            $error = ['title' => 'Parameters problem', 'info' => $error_info_list];
            throw new ParametersException($error);
        }
        $q = ['table' => self::$tn, 'values' => ['user_id' => $user_id, 'token_id' => $token_id, 'session_id' => $session_id, 'date_create' => 'NOW()']];
        $r = Db::insert($q); #pre($q); pre($r);
        if(!count($r)){ $error = ['title' => 'DB query problem', 'info' => 'User logout was not added']; throw new DbQueryException($error); }
        return $r[0]['id'];
    }

    public static function add_user_logout_default(){
        $error_info_list = [];
        if(empty(User::$user_id)) $error_info_list[] = 'User ID is empty';
        if(empty(Token::$token_id)) $error_info_list[] = 'Token ID is empty';
        if(empty(Session::$session_id)) $error_info_list[] = 'Session ID is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );
            throw new ParametersException($error);
        }
        self::$user_logout_id=self::add_user_logout(User::$user_id,Token::$token_id,Session::$session_id);
        if(empty(self::$user_logout_id)){
            $error = array('title' => 'DB query problem',
                'info' => 'User logout was not added'
            );
            throw new DbQueryException($error);
        }
        return self::$user_logout_id;
    }

    public static function remove_user_logout_id(int $user_logout_id = null){
        if(empty($user_logout_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User logout ID is empty'
            );
            throw new ParametersException($error);
        }
        if(!Db::pseudo_delete_from_id($user_logout_id,'_user_logout',0)){
            $error = array('title' => 'DB query problem',
                'info' => 'User logout was not removed'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_user_logout(int $user_id = null, int $token_id = null, int $session_id = null){
        $error_info_list = [];
        if(empty($user_id)) $error_info_list[] = 'User ID is empty';
        if(empty($token_id)) $error_info_list[] = 'Token ID is empty';
        if(empty($session_id)) $error_info_list[] = 'Session ID is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );
            throw new ParametersException($error);
        }
        $where_list = [];
        if(!empty($user_id)) $where_list['user_id'] = $user_id;
        if(!empty($token_id)) $where_list['token_id'] = $token_id;
        if(!empty($session_id)) $where_list['session_id'] = $session_id;
        if(count($where_list) === 0){
            $error = array('title' => 'Paramteres problem',
                'info' => 'All parameters are empty'
            );
            throw new ParametersException($error);
        }
        if(!Db::pseudo_delete_from_where_list('_user_logout',0,$where_list)){
            $error = array('title' => 'DB query problem',
                'info' => 'User logout was not removed'
            );
            throw new DbQueryException($error);
        }
        return true;
    }
}