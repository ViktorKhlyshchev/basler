<?php

namespace Core\Module\User;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class UserDevice {

    public static $user_device_id;
    public static $user_device_list;

    public static function reset_data(){
        self::$user_device_id = null;
        self::$user_device_list = [];
    }

    public static function isset_user_device_id(int $user_device_id = null){
        if(empty($user_device_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User device ID is empty'
            );
            throw new ParametersException($error);
        }
        return Db::isset_row_id($user_device_id,'_user_device',0);
    }

    public static function isset_user_device_from_device_token_id(int $device_token_id = null){
        if(empty($device_token_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Device token ID is empty'
            );
            throw new ParametersException($error);
        }
        $where_list = array('device_token_id' => $device_token_id
        );
        return Db::isset_row('_user_device',0,$where_list);
    }

    public static function get_user_device_list(int $user_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User ID is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('device_firm_id',
                'device_model_id',
                'device_token_id',
                'os_id',
                'os_version_id'),
            'table' => '_user_device',
            'where' => array('user_id' => $user_id,
                'type' => 0
            )
        );
        $r = Db::select($q);
        if(count($r) === 0) return [];
        $list = [];
        foreach($r as $row)
            $list[] = array('device_firm_id' => $row['device_firm_id'],
                'device_model_id' => $row['device_model_id'],
                'device_token_id' => $row['device_token_id'],
                'os_id' => $row['os_id'],
                'os_version_id' => $row['os_version_id']
            );
        return $list;
    }

    public static function get_user_device_data(int $user_id = null, int $device_token_id = null){
        $error_info_list = [];
        if(empty($user_id)) $error_info_list['user_id'] = 'User ID is empty';
        if(empty($device_token_id)) $error_info_list['device_token_id'] = 'Device token ID is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('id',
                'device_firm_id',
                'device_model_id',
                'device_token_id',
                'os_id',
                'os_version_id'),
            'table' => '_user_device',
            'where' => array('user_id' => $user_id,
                'device_token_id' => $device_token_id, 'type' => 0),
            'limit' => 1
        );
        $r = Db::select($q);
        if(count($r) === 0) return null;
        return array('id' => $r[0]['id'],
            'device_firm_id' => $r[0]['device_firm_id'],
            'device_model_id' => $r[0]['device_model_id'],
            'device_token_id' => $r[0]['device_token_id'],
            'os_id' => $r[0]['os_id'],
            'os_version_id' => $r[0]['os_version_id']
        );
    }

    public static function get_user_device_id(int $user_id = null, int $device_firm_id = null, int $device_model_id = null, int $device_token_id = null, int $os_id = null, int $os_version_id = null){
        if(empty($user_id)
            &&empty($device_firm_id)
            &&empty($device_model_id)
            &&empty($device_token_id)
            &&empty($os_id)
            &&empty($os_version_id)
        ){
            $error = array('title' => 'Parameters problem',
                'info' => 'All parameters are empty'
            );
            throw new ParametersException($error);
        }
        $where_list = [];
        if(!empty($user_id)) $where_list['user_id'] = $user_id;
        if(!empty($device_firm_id)) $where_list['device_firm_id'] = $device_firm_id;
        if(!empty($device_model_id)) $where_list['device_model_id'] = $device_model_id;
        if(!empty($device_token_id)) $where_list['device_token_id'] = $device_token_id;
        if(!empty($os_id)) $where_list['os_id'] = $os_id;
        if(!empty($os_version_id)) $where_list['os_version_id'] = $os_version_id;
        if(count($where_list) === 0){
            $error = array('title' => 'Parameters problem',
                'info' => 'All parameters are empty'
            );
            throw new ParametersException($error);
        }
        return Db::get_row_id('_user_device',0,$where_list);
    }

    public static function get_user_id_from_device_token_id(int $device_token_id = null){
        if(empty($device_token_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Device token ID is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('user_id'),
            'table' => '_user_device',
            'where' => array('device_token_id' => $device_token_id, 'type' => 0),
            'limit' => 1
        );
        $r = Db::select($q);
        if(count($r) === 0) return null;
        return $r[0]['user_id'];
    }

    public static function add_user_device(int $user_id = null, int $device_firm_id = null, int $device_model_id = null, int $device_token_id = null, int $os_id = null, int $os_version_id = null, bool $is_google=false,bool $is_apple=false){
        $error_info_list = [];
        if(empty($user_id)) $error_info_list[] = 'User ID is empty';
        if(empty($device_firm_id)) $error_info_list[] = 'Device firm ID is empty';
        if(empty($device_model_id)) $error_info_list[] = 'Device model ID is empty';
        if(empty($os_id)) $error_info_list[] = 'OS ID is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );
            throw new ParametersException($error);
        }
        $q = array('table' => '_user_device',
            'values' => array('user_id' => $user_id,
                'device_firm_id' => $device_firm_id,
                'device_model_id' => $device_model_id,
                'device_token_id' => $device_token_id,
                'os_id' => $os_id,
                'os_version_id' => $os_version_id,
                'google' => (int)$is_google,
                'apple' => (int)$is_apple,
                'date_create' => 'NOW()',
                'date_update' => 'NOW()'
            )
        );
        $r = Db::insert($q);
        if(count($r) === 0){
            $error = array('title' => 'DB query problem',
                'info' => 'User device was not added'
            );
            throw new DbQueryException($error);
        }
        return $r[0]['id'];
    }

    public static function remove_user_device_id(int $user_device_id = null){
        if(empty($user_device_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User device ID is empty'
            );
            throw new ParametersException($error);
        }
        if(!Db::pseudo_delete_from_id($user_device_id,'_user_device',0)){
            $error = array('title' => 'DB query problem',
                'info' => 'User device was not removed'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_user_device(int $user_id = null, int $device_firm_id = null, int $device_model_id = null, int $device_token_id = null, int $os_id = null, int $os_version_id = null){
        if(empty($user_id)
            &&empty($device_firm_id)
            &&empty($device_model_id)
            &&empty($device_token_id)
            &&empty($os_id)
            &&empty($os_version_id)
        ){
            $error = array('title' => 'Parameters problem',
                'info' => 'All parameters are empty'
            );
            throw new ParametersException($error);
        }
        $where_list = [];
        if(!empty($user_id)) $where_list['user_id'] = $user_id;
        if(!empty($device_firm_id)) $where_list['device_firm_id'] = $device_firm_id;
        if(!empty($device_model_id)) $where_list['device_model_id'] = $device_model_id;
        if(!empty($device_token_id)) $where_list['device_token_id'] = $device_token_id;
        if(!empty($os_id)) $where_list['os_id'] = $os_id;
        if(!empty($os_version_id)) $where_list['os_version_id'] = $os_version_id;
        if(count($where_list) === 0){
            $error = array('title' => 'Parameters problem',
                'info' => 'All parameters are empty'
            );
            throw new ParametersException($error);
        }
        if(!Db::pseudo_delete_from_where_list('_user_device',0,$where_list)){
            $error = array('title' => 'DB query problem',
                'info' => 'User device was not removed'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function set_user_device_id_default(int $user_device_id = null){
        self::$user_device_id = empty($user_device_id) ? null : $user_device_id;
    }

    public static function set_user_device_list_default(array $user_device_list = null){
        self::$user_device_list = empty($user_device_list) ? null : $user_device_list;
    }
}