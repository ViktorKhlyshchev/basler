<?php

namespace Core\Module\User;

use Core\Module\Exception\ParametersException;
use Configs\UserHashTypeConfig;

class UserHashTypeValidation {

    public static function isset_user_hash_type_id(int $user_hash_type_id = null){
        if(empty($user_hash_type_id)){
            $error = ['title' => ParametersException::$title, 'info' => 'User hash type ID is empty'];
            throw new ParametersException($error);
        }
        return array_search($user_hash_type_id, UserHashTypeConfig::$user_hash_type_id_list) !== false;
    }

    public static function isset_user_hash_type_name(string $user_hash_type_name = null){
        if(empty($user_hash_type_name)){
            $error = ['title' => ParametersException::$title, 'info' => 'User hash type name is empty'];
            throw new ParametersException($error);
        }
        return isset(UserHashTypeConfig::$user_hash_type_id_list[$user_hash_type_name]);
    }
}