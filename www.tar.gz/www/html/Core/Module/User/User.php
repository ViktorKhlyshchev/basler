<?php

namespace Core\Module\User;

use Common\Modules\Date;
use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;
use Configs\UserAccessTypeConfig;

class User {

    public static $user_id;
    public static $date_create;
    public static $date_online;
    public static $date_block;
    public static $date_unblock;
    public static $date_remove;
    public static $date_recovery;

    public static $date_list = array('date_create' => null,
        'date_online' => null,
        'date_block' => null,
        'date_unblock' => null,
        'date_remove' => null,
        'date_recovery' => null
    );

    public static $tn = '_user';

    public static function reset_data(){
        self::$user_id = null;
        self::$date_create = null;
        self::$date_online = null;
        self::$date_block = null;
        self::$date_unblock = null;
        self::$date_remove = null;
        self::$date_recovery = null;
        return true;
    }

    public static function get_user_email_checked_all_len(string $user_access_type_name = null){
        $user_access_type_id = UserAccessTypeConfig::get_user_access_type_id($user_access_type_name);
        $q = [
            'select' => [['function' => 'COUNT(*)', 'rename' => 'len']],
            'table' => self::$tn,
            'join' => [
                [
                    'table' => UserAccess::$tn,
                    'where' => [
                        [
                            'table' => self::$tn,
                            'table_join' => UserAccess::$tn,
                            'column' => 'id',
                            'column_join' => 'user_id'
                        ],
                        [
                            'table' => UserAccess::$tn,
                            'column' => 'user_access_type_id',
                            'value' => $user_access_type_id
                        ],
                        [
                            'table' => UserAccess::$tn,
                            'column' => 'type',
                            'value' => 0
                        ]
                    ]
                ]
            ],
            'where' => [
                [
                    'table' => self::$tn,
                    'column' => 'type',
                    'value' => 0
                ]
            ]
        ];
        $r = Db::select($q);
        if(!count($r)) return null;
        return $r[0]['len'];
    }

    public static function get_user_email_checked_all_30_days_len(string $user_access_type_name = null){
        $timestamp_to = Date::get_timestamp();
        $timestamp_from = $timestamp_to-30*24*3600;
        $user_access_type_id = UserAccessTypeConfig::get_user_access_type_id($user_access_type_name);
        $q = [
            'select' => array(
                 array('function' => 'COUNT(*)',
                    'rename' => 'len'
                )
            ),
            'table' => self::$tn,
            'join' => [
                [
                    'table' => UserAccess::$tn,
                    'where' => [
                        [
                            'table' => self::$tn,
                            'table_join' => UserAccess::$tn,
                            'column' => 'id',
                            'column_join' => 'user_id'
                        ],
                        [
                            'table' => UserAccess::$tn,
                            'column' => 'user_access_type_id',
                            'value' => $user_access_type_id
                        ],
                        [
                            'table' => UserAccess::$tn,
                            'column' => 'type',
                            'value' => 0
                        ]
                    ]
                ]
            ],
            'where' => [
                [
                    'table' => self::$tn,
                    'column' => 'date_create',
                    'method' => '>=',
                    'value' => Date::get_date_time_full($timestamp_from)
                ],
                [
                    'table' => self::$tn,
                    'column' => 'date_create',
                    'method' => '<=',
                    'value' => Date::get_date_time_full($timestamp_to)
                ],
                [
                    'table' => self::$tn,
                    'column' => 'type',
                    'value' => 0
                ]
            ]
        ];
        $r = Db::select($q);
        if(count($r) === 0) return null;
        return $r[0]['len'];
    }

    public static function get_date_online(int $user_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User ID is empty'
            );
            throw new ParametersException($error);
        }
        $q = ['table' => self::$tn, 'select' => ['date_online'], 'where' => ['id' => $user_id, 'type' => 0], 'limit' => 1];
        $r = Db::select($q);
        if(count($r) === 0) return null;
        return empty($r[0]['date_online']) ? null : strtotime($r[0]['date_online']);
    }

    public static function is_login(int $user_id = null){
        if(empty($user_id)) return !empty(self::$user_id);
        $error = ['title' => 'Parameters problem', 'info' => 'Code for indenty auth of user is not exists'];
        throw new ParametersException($error);
    }

    public static function isset_user_id(int $user_id = null){
        if(empty($user_id)){
            $error = ['title' => 'Parameters problem', 'info' => 'User ID is empty'];
            throw new ParametersException($error);
        }
        return Db::isset_row_id($user_id, '_user', 0);
    }

    public static function isset_user_id_default(){
        if(empty(self::$user_id)){
            $error = ['title' => 'Parameters problem', 'info' => 'Default user ID is empty #1'];
            throw new ParametersException($error);
        }
        return self::isset_user_id(self::$user_id);
    }

    public static function isset_user_default(){
        return !empty(self::$user_id);
    }

    public static function get_user_data(int $user_id = null){
        if(empty($user_id)){
            $error = ['title' => 'Parameters problem', 'info' => 'User_id is empty'];
            throw new ParametersException($error);
        }
        $q = array('select' => ['date_create', 'date_online', 'date_block', 'date_unblock', 'date_remove', 'date_recovery'],
            'table' => '_user',
            'where' => array('id' => $user_id, 'type' => 0),
            'limit' => 1
        );
        $r = Db::select($q);
        if(count($r) === 0) return self::$date_list;
        return array('date_create' => $r[0]['date_create'],
            'date_online' => $r[0]['date_online'],
            'date_block' => $r[0]['date_block'],
            'date_unblock' => $r[0]['date_unblock'],
            'date_remove' => $r[0]['date_remove'],
            'date_recovery' => $r[0]['date_recovery']
        );
    }

    public static function get_user_reg_count(int $day_len = 10){
        $date_time = Date::get_date_for_db(Date::get_timestamp()-$day_len*24*3600).' 00:00:00';
        $q = [
            'table' => self::$tn,
            'select' => [
                [
                    'function' => 'COUNT(*) as len'
                ],
                [
                    'function' => "DATE(date_create AT TIME ZONE 'UTC+3') as d"
                ]
            ],
            'where' => [
                'date_create' => [
                    'method' => '>=',
                    'value' => $date_time
                ],
                'type' => 0
            ],
            'group' => [
                [
                    'function' => "DATE(date_create AT TIME ZONE 'UTC+3')"
                ]
            ]
        ];
        $r = Db::select($q);
        if(count($r) === 0) return [];
        $list = [];
        foreach($r as $row)
            $list[$row['d']] = (int)$row['len'];
        return $list;
    }

    public static function get_user_reg_count_confirmed_email(int $day_len = 10){
        $date_time = Date::get_date_for_db(Date::get_timestamp()-$day_len*24*3600).' 00:00:00';
        $q = [
            'table' => self::$tn,
            'select' => [
                [
                    'function' => 'COUNT(*) as len'
                ],
                [
                    'function' => "DATE(date_create AT TIME ZONE 'UTC+3') as d"
                ]
            ],
            'where' => [
                'date_create' => [
                    'method' => '>=',
                    'value' => $date_time
                ],
                'date_email_check' => [
                    'method' => '!=',
                    'value' => null
                ],
                'type' => 0
            ],
            'group' => [
                [
                    'function' => "DATE(date_create AT TIME ZONE 'UTC+3')"
                ]
            ]
        ];
        $r = Db::select($q);
        if(count($r) === 0) return [];
        $list = [];
        foreach($r as $row)
            $list[$row['d']] = (int)$row['len'];
        return $list;
    }

    public static function get_user_data_default(){
        if(empty(self::$user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Default user ID is empty #2'
            );
            throw new ParametersException($error);
        }
        $user_data = self::get_user_data(self::$user_id);
        if(count($user_data) == 0){
            $error = array('title' => 'DB query problem',
                'info' => 'User din not get data',
                'data' => array('user_id' => self::$user_id
                )
            );
            throw new DbQueryException($error);
        }
        return $user_data;
    }

    public static function add_user($uname = null){
        $values = ['date_create' => 'NOW()', 'date_update' => 'NOW()', 'type' => 0];
        if($uname) $values['name'] = $uname;
        $q = ['table' => '_user', 'values' => $values];
        $r = Db::insert($q);
        if(count($r) === 0) throw new DbQueryException(['title' => 'DB query problem', 'info' => 'User was not added']);
        return $r[0]['id'];

        /*if($uname){
            $values['name'] = $uname;
            $values = array('date_create' => 'NOW()',
                    'date_update' => 'NOW()',
                    'type' => 0
                );
            $q = array('table' => '_user_login',
                'values' => $values
            );
            $r = Db::insert($q);
        }*/
    }

    public static function add_user_default($uname = null){
        $user_id = self::add_user($uname);
        if(empty($user_id)){
            $error = array('title' => 'User DB problem',
                'info' => 'New user was not make'
            );
            throw new DbQueryException($error);
        }
        self::$user_id = $user_id;
        return true;
    }

    public static function update_user_date_online(int $user_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User_id is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('table' => '_user',
            'set' => array('date_online' => 'NOW()'),
            'where' => array(
                 array('column' => 'id',
                    'value' => $user_id
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            )
        );
        if(!Db::update($q)){
            $error = array('title' => 'DB query problem',
                'info' => 'User date online was not updated'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function update_user_date_update(int $user_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User_id is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('table' => '_user',
            'set' => array('date_update' => 'NOW()'),
            'where' => array('id' => $user_id,
                'type' => 0
            )
        );
        if(!Db::update($q)){
            $error = array('title' => 'DB query problem',
                'info' => 'User date online was not updated'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function update_user_date_block(int $user_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User_id is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('table' => '_user',
            'set' => array('date_update' => 'NOW()',
                'date_block' => 'NOW()',
                'date_unblock' => null,
            ),
            'where' => array('id' => $user_id,
                'type' => 0
            )
        );
        if(!Db::update($q)){
            $error = array('title' => 'DB query problem',
                'info' => 'User date online was not updated'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function update_user_date_email_check(int $user_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User_id is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('table' => '_user',
            'set' => array('date_update' => 'NOW()',
                'date_email_check' => 'NOW()'),
            'where' => array('id' => $user_id,
                'type' => 0
            )
        );
        if(!Db::update($q)){
            $error = array('title' => 'DB query problem',
                'info' => 'User date email check was not update'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function update_user_date_unblock(int $user_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User_id is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('table' => '_user',
            'set' => array('date_update' => 'NOW()',
                'date_block' => null,
                'date_unblock' => 'NOW()',
            ),
            'where' => array('id' => $user_id,
                'type' => 0
            )
        );
        if(!Db::update($q)){
            $error = array('title' => 'DB query problem',
                'info' => 'User date online was not updated'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function update_user_date_online_default(){
        if(empty(self::$user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Default user ID is empty #3'
            );
            throw new ParametersException($error);
        }
        if(!self::update_user_date_online(self::$user_id)){
            $error = array('title' => 'DB query problem',
                'info' => 'Default user dare online was not updated'
            );
            throw new DbQueryException($error);
        }
        self::$date_online = Date::get_timestamp();
        return true;
    }

    public static function block_user_id(int $user_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User_id is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('table' => '_user',
            'set' => array('date_block' => 'NOW()',
                'type' => 1
            ),
            'where' => array('id' => $user_id, 'type' => 0),
            'limit' => 1
        );
        if(!Db::update($q)){
            $error = array('title' => 'DB query problem',
                'info' => 'User was not blocked'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function unblock_user_id(int $user_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User_id is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('table' => '_user',
            'set' => array('date_unblock' => 'NOW()', 'type' => 0),
            'where' => array('id' => $user_id,
                'type' => 0
            )
        );
        if(!Db::update($q)){
            $error = array('title' => 'DB query problem',
                'info' => 'User was not unblocked'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function recovery_user_id(int $user_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User ID is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('table' => '_user',
            'set' => array('date_recovery' => 'NOW()', 'type' => 0),
            'where' => array('id' => $user_id,
                'type' => 1
            ),
            'limit' => 1
        );
        if(!Db::update($q)){
            $error = array('title' => 'DB query problem',
                'info' => 'User was not recovered'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function set_user_data_default(){
        if(empty(self::$user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Default user ID is empty #4'
            );
            throw new ParametersException($error);
        }
        $user_data = self::get_user_data_default();
        self::$date_create = $user_data['date_create'];
        self::$date_online = $user_data['date_online'];
        self::$date_block = $user_data['date_block'];
        self::$date_unblock = $user_data['date_unblock'];
        self::$date_remove = $user_data['date_remove'];
        self::$date_recovery = $user_data['date_recovery'];
        return true;
    }

    public static function set_user_id_default(int $user_id = null){
        self::$user_id = empty($user_id) ? null : $user_id;
        return true;
    }

    public static function set_user_date_create_default(int $user_date_create = null){
        self::$date_create = empty($user_date_create) ? null : $user_date_create;
        return true;
    }

    public static function set_user_date_online_default(int $user_date_online = null){
        self::$date_online = empty($user_date_online) ? null : $user_date_online;
        return true;
    }

    public static function set_user_date_block_default(int $user_date_block = null){
        self::$date_block = empty($user_date_block) ? null : $user_date_block;
        return true;
    }

    public static function set_user_date_remove_default(int $user_date_remove = null){
        self::$date_remove = empty($user_date_remove) ? null : $user_date_remove;
        return true;
    }

    public static function set_user_date_unblock_default(int $user_date_unblock = null){
        self::$date_unblock = empty($user_date_unblock) ? null : $user_date_unblock;
        return true;
    }

    public static function set_user_date_recovery_default(int $user_date_recovery = null){
        self::$date_recovery = empty($user_date_recovery) ? null : $user_date_recovery;
        return true;
    }

    public static function remove_user_id(int $user_id = null, bool $need_remove_child = true){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem',                'info' => 'User ID is empty'            );
            throw new ParametersException($error);
        }
        if(!Db::pseudo_delete_from_id($user_id, self::$tn, 0)){ #pred($user_id);
            $error = [
                'title' => DbQueryException::$title,
                'info' => 'User was not remove'
            ];
            throw new DbQueryException($error);
        }
        if(!$need_remove_child) return true;
            if(!UserAccess::remove_user_access($user_id)){
                $error = [
                    'title' => DbQueryException::$title,
                    'info' => 'User access was not remove'
                ];
                throw new DbQueryException($error);
            }
//            if(!UserAddress::remove_user_address($user_id)){//
//                $error = [//                    'title' => DbQueryException::$title, //                    'info' => 'User address was not remove'//                ];
////                throw new DbQueryException($error);////            }
            if(!UserAvatar::remove_user_avatar($user_id)){
                $error = [
                    'title' => DbQueryException::$title,
                    'info' => 'User avatar was not remove'
                ];
                throw new DbQueryException($error);
            }
            if(!UserBlock::remove_user_block($user_id)){
                $error = [
                    'title' => DbQueryException::$title,
                    'info' => 'User block was not remove'
                ];
                throw new DbQueryException($error);
            }
            if(!UserData::remove_user_data($user_id)){
                $error = [
                    'title' => DbQueryException::$title,
                    'info' => 'User data was not remove'
                ];
                throw new DbQueryException($error);
            }
            if(!UserDevice::remove_user_device($user_id)){
                $error = [
                    'title' => DbQueryException::$title,
                    'info' => 'User devices were not remove'
                ];
                throw new DbQueryException($error);
            }
            if(!UserEmail::remove_user_email($user_id)){
                $error = [
                    'title' => DbQueryException::$title,
                    'info' => 'User email was not remove'
                ];
                throw new DbQueryException($error);
            }
            if(!UserHash::remove_user_hash($user_id)){
                $error = [
                    'title' => DbQueryException::$title,
                    'info' => 'User hash was not remove'
                ];
                throw new DbQueryException($error);
            }
            if(!UserLogin::remove_user_login($user_id)){
                $error = [
                    'title' => DbQueryException::$title,
                    'info' => 'User login was not remove'
                ];
                throw new DbQueryException($error);
            }
//            if(!UserPhone::remove_user_phone($user_id)){
//                $error = [//                    'title' => DbQueryException::$title, //                    'info' => 'User login was not remove'//                ];
////                throw new DbQueryException($error);////            }
        return true;
    }
}