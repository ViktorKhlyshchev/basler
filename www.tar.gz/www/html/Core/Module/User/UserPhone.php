<?php

namespace Core\Module\User;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;
use Core\Module\Phone\PhoneValidation;

class UserPhone{

    /** @var int */
    public static $user_phone_id;

    /** @var int */
    public static $county_code;

    /** @var int */
    public static $zone_code;

    /** @var string */
    public static $user_phone_number;

    /** @var string */
    public static $user_phone_number_full;

    /** @var array */
    public static $user_phone_list;

    /**
     * Reset default data
     */
    public static function reset_data(){

        self::$user_phone_id = null;
        self::$county_code = null;
        self::$zone_code = null;
        self::$user_phone_number = null;
        self::$user_phone_number_full = null;

    }

    /**
     * @param int|null $user_phone_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_user_phone_id(int $user_phone_id = null){

        if(empty($user_phone_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'User phone ID is empty'
            );

            throw new ParametersException($error);

        }

        return Db::isset_row_id($user_phone_id,'_user_phone',0);

    }

    /**
     * @param int|null $user_id
     * @param int|null $country_code
     * @param int|null $zone_code
     * @param string|null $number
     * @param string|null $number_full
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_user_phone(int $user_id = null, int $country_code = null, int $zone_code = null, string $number = null, string $number_full = null){

        $error_info_list = [];

        if(empty($user_id)) $error_info_list[] = 'User ID is empty';

        if(empty($number_full)) $error_info_list[] = 'Phone number full is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $where_list = array('user_id' => $user_id,
            'number_full' => $number_full
        );

        if(!empty($country_code)) $where_list['country_code'] = $country_code;

        if(!empty($zone_code)) $where_list['zone_code'] = $zone_code;

        if(!empty($number)) $where_list['number'] = $number_full;

        return Db::isset_row('_user_phone',0,$where_list);

    }

    /**
     * @param int|null $user_id
     * @param int|null $country_code
     * @param int|null $zone_code
     * @param string|null $number
     * @param string|null $number_full
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_user_phone_id(int $user_id = null, int $country_code = null, int $zone_code = null, string $number = null, string $number_full = null){

        $error_info_list = [];

        if(empty($user_id)) $error_info_list[] = 'User ID is empty';

        if(empty($number_full)) $error_info_list[] = 'Phone number full is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $where_list = array('user_id' => $user_id,
            'number_full' => $number_full
        );

        if(!empty($country_code)) $where_list['country_code'] = $country_code;

        if(!empty($zone_code)) $where_list['zone_code'] = $zone_code;

        if(!empty($number)) $where_list['number'] = $number;

        return Db::get_row_id('_user_phone',0,$where_list);

    }

    /**
     * @param int|null $user_phone_id
     * @return array|null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_user_phone_data(int $user_phone_id = null){

        if(empty($user_phone_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'User phone ID is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('user_id',
                'country_code',
                'zone_code',
                'number',
                'number_full'),
            'table' => '_user_phone',
            'where' => array('id' => $user_phone_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return array('user_id' => $r[0]['user_id'],
            'country_code' => $r[0]['country_code'],
            'zone_code' => $r[0]['zone_code'],
            'number' => $r[0]['number'],
            'number_full' => $r[0]['number_full']
        );

    }

    /**
     * @param int|null $user_id
     * @return array
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_user_phone_list(int $user_id = null){

        if(empty($user_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'User ID is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('user_id',
                'country_code',
                'zone_code',
                'number',
                'number_full'),
            'table' => '_user_phone',
            'where' => array('user_id' => $user_id,
                'type' => 0
            )
        );

        $r = Db::select($q);

        if(count($r) === 0) return [];

        $list = [];

        foreach($r as $row)
            $list[] = array('user_id' => $row['user_id'],
                'country_code' => $row['country_code'],
                'zone_code' => $row['zone_code'],
                'number' => $row['number'],
                'number_full' => $row['number_full']
            );

        return $list;

    }

    /**
     * @param int|null $user_id
     * @param int|null $country_code
     * @param int|null $zone_code
     * @param string|null $number
     * @param string|null $number_full
     * @return mixed
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function add_user_phone(int $user_id = null, int $country_code = null, int $zone_code = null, string $number = null, string $number_full = null){

        $error_info_list = [];

        if(empty($user_id)) $error_info_list[] = 'User ID is empty';

        if(empty($number_full)) $error_info_list[] = 'Phone number full is empty';
        else if(!PhoneValidation::is_valid_phone($number_full)) $error_info_list[] = 'Phone number full is not valid';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $value_list = array('user_id' => $user_id,
            'number_full' => $number_full,
            'date_create' => 'NOW()'
        );

        if(!empty($country_code)) $value_list['country_code'] = $country_code;

        if(!empty($zone_code)) $value_list['zone_code'] = $zone_code;

        if(!empty($number)) $value_list['number'] = $number;

        $q = array('table' => '_user_phone',
            'values' => $value_list
        );

        $r = Db::insert($q);

        if(count($r) === 0){

            $error = array('title' => 'DB query problem',
                'info' => 'User phone was not added'
            );

            throw new DbQueryException($error);

        }

        return $r[0]['id'];

    }

    /**
     * @param int|null $user_phone_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_user_phone_id(int $user_phone_id = null){

        if(empty($user_phone_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'User phone ID is empty'
            );

            throw new ParametersException($error);

        }

        if(!Db::pseudo_delete_from_id($user_phone_id,'_user_phone',0)){

            $error = array('title' => 'DB query problem',
                'info' => 'User phone was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $user_id
     * @param int|null $country_code
     * @param int|null $zone_code
     * @param string|null $number
     * @param string|null $number_full
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_user_phone(int $user_id = null, int $country_code = null, int $zone_code = null, string $number = null, string $number_full = null){

        if(empty($user_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'User ID is empty'
            );

            throw new ParametersException($error);

        }

        $where_list = array('user_id' => $user_id
        );

        if(!empty($number_full)) $where_list['number_full'] = $number_full;

        if(!empty($country_code)) $where_list['country_code'] = $country_code;

        if(!empty($zone_code)) $where_list['zone_code'] = $zone_code;

        if(!empty($number)) $where_list['number'] = $number;

        if(!empty($number_full)) $where_list['number_full'] = $number_full;

        if(!Db::pseudo_delete_from_where_list('_user_phone',0,$where_list)){

            $error = array('title' => 'DB query problem',
                'info' => 'User phone was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $user_phone_id
     */
    public static function set_user_phone_id_default(int $user_phone_id = null){

        self::$user_phone_id = empty($user_phone_id) ? null : $user_phone_id;

    }

    /**
     * @param int|null $country_code
     */
    public static function set_country_code_default(int $country_code = null){

        self::$county_code = empty($country_code) ? null : $country_code;

    }

    /**
     * @param int|null $zone_code
     */
    public static function set_zone_code_default(int $zone_code = null){

        self::$zone_code = empty($zone_code) ? null : $zone_code;

    }

    /**
     * @param string|null $user_phone_number
     */
    public static function set_user_phone_number_default(string $user_phone_number = null){

        self::$user_phone_number = empty($user_phone_number) ? null : $user_phone_number;

    }

    /**
     * @param string|null $user_phone_number_full
     */
    public static function set_user_phone_number_full_default(string $user_phone_number_full = null){

        self::$user_phone_number_full = empty($user_phone_number_full) ? null : $user_phone_number_full;

    }

}