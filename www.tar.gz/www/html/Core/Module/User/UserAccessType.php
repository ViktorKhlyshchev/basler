<?php

namespace Core\Module\User;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;
use Configs\UserAccessTypeConfig;

class UserAccessType {

    public static $tn='_user_access_type';

    public static function isset_user_access_type_id(int $user_access_type_id = null){
        if(empty($user_access_type_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User access type ID is empty'
            );
            throw new ParametersException($error);
        }
        return Db::isset_row_id($user_access_type_id,'_user_access_type',0);
    }

    public static function isset_user_access_name(string $user_access_type_name = null){
        if(empty($user_access_type_name)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User access name is empty'
            );
            throw new ParametersException($error);
        }
        $where_list = array('name' => $user_access_type_name
        );
        return Db::isset_row('_user_access_type',0,$where_list);
    }

    public static function get_user_access_type_id(string $user_access_type_name = null){
        if(empty($user_access_type_name)){
            $error = array('title' => 'Parameters problem', 'info' => 'User access type name is empty');
            throw new ParametersException($error);
        }
        if(!isset(UserAccessTypeConfig::$user_access_type_name_list[$user_access_type_name])){
            $error = array('title' => 'Parameters problem', 'info' => 'User access type name is not exist');
            throw new ParametersException($error);
        }
        return UserAccessTypeConfig::$user_access_type_name_list[$user_access_type_name];
    }

    public static function get_user_access_type_name(int $user_access_type_id = null){
        if(empty($user_access_type_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User access ID is empty'
            );
            throw new ParametersException($error);
        }
        if(!UserAccessTypeValidation::isset_user_access_type_id($user_access_type_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User access ID is not exist'
            );
            throw new ParametersException($error);
        }
        return UserAccessTypeConfig::get_user_access_type_name($user_access_type_id);
    }

    public static function get_user_access_type_id_list(array $user_access_type_name_list = []){
        if(count($user_access_type_name_list) === 0){
            $error = array('title' => 'Parameters problem',
                'info' => 'User access type name list is empty'
            );
            throw new ParametersException($error);
        }
        $user_access_type_id_list = [];
        foreach($user_access_type_name_list as $user_access_type_name)
            if(!empty($user_access_type_name))
                if(isset(UserAccessTypeConfig::$user_access_type_name_list[$user_access_type_name]))
                    $user_access_type_id_list[] = self::get_user_access_type_id($user_access_type_name);
        return $user_access_type_id_list;
    }

    public static function get_user_access_type_name_list(array $user_access_type_id_list = []){
        if(count($user_access_type_id_list) === 0){
            $error = array('title' => 'Parameters problem',
                'info' => 'User access type ID list is empty'
            );
            throw new ParametersException($error);
        }
        $user_access_type_name_list = [];
        foreach($user_access_type_id_list as $user_access_type_id)
            if(!empty($user_access_type_id))
                if(UserAccessTypeValidation::isset_user_access_type_id($user_access_type_id))
                    $user_access_type_name_list[] = self::get_user_access_type_name($user_access_type_id);
        return $user_access_type_name_list;
    }

    public static function add_user_access_type(string $user_access_type_name = null){
        if(empty($user_access_type_name)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User access type name is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('table' => '_user_access_type',
            'values' => array('name' => $user_access_type_name,
                'date_create' => 'NOW()'
            )
        );
        $r = Db::insert($q);
        if(count($r) === 0){
            $error = array('title' => 'DB query problem',
                'info' => 'User access type was not added'
            );
            throw new DbQueryException($error);
        }
        return $r[0]['id'];
    }

    public static function remove_user_access_type_id(int $user_access_type_id = null){
        if(empty($user_access_type_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User access type ID is empty'
            );
            throw new ParametersException($error);
        }
        if(!Db::pseudo_delete_from_id($user_access_type_id,'_user_access_type',0)){
            $error = array('title' => 'DB query problem',
                'info' => 'User access type was not removed'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_user_access_type(string $user_access_type_name = null){
        if(empty($user_access_type_name)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User access type name is empty'
            );
            throw new ParametersException($error);
        }
        $where_list = array('name' => $user_access_type_name
        );
        if(!Db::pseudo_delete_from_where_list('_user_access_type',0,$where_list)){
            $error = array('title' => 'DB query problem',
                'info' => 'User access type was not removed'
            );
            throw new DbQueryException($error);
        }
        return true;
    }
}