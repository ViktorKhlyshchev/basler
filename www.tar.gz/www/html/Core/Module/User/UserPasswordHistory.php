<?php

namespace Core\Module\User;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class UserPasswordHistory{

    /** @var array */
    public static $user_password_list;

    /**
     * @param int|null $user_password_history_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_user_password_history_id(int $user_password_history_id = null){

        if(empty($user_password_history_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'User password history ID is empty'
            );

            throw new ParametersException($error);

        }

        return Db::isset_row_id($user_password_history_id,'_user_password_history',0);

    }

    /**
     * @param int|null $user_id
     * @param string|null $password
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_user_pasword_history(int $user_id = null, string $password = null){

        $error_info_list = [];

        if(empty($user_id)) $error_info_list[] = 'User ID is empty';

        if(empty($password)) $error_info_list[] = 'Password is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $where_list = array('user_id' => $user_id,
            'password' => $password
        );

        return Db::isset_row('_user_password_history',0,$where_list);

    }

    /**
     * @param int|null $user_id
     * @param string|null $password
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_user_password_history_id(int $user_id = null, string $password = null){

        $error_info_list = [];

        if(empty($user_id)) $error_info_list[] = 'User ID is empty';

        if(empty($password)) $error_info_list[] = 'Password is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $where_list = array('user_id' => $user_id,
            'password' => $password
        );

        return Db::get_row_id('_user_password_history',0,$where_list);

    }

    /**
     * @param int|null $user_id
     * @return array
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_user_password_history_list(int $user_id = null){

        if(empty($user_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'User ID is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('id',
                'password',
                'date_create'),
            'table' => '_user_password_history',
            'where' => array('user_id' => $user_id, 'type' => 0),
            'order' => array(
                 array('column' => 'date_create',
                    'direct' => 'desc'
                )
            )
        );

        $r = Db::select($q);

        if(count($r) === 0) return [];

        $list = [];

        foreach($r as $row)
            $list[] = array('id' => $row['id'],
                'password' => $row['password'],
                'date_create' => $row['date_create']
            );

        return $list;

    }

    /**
     * @param int|null $user_id
     * @param string|null $password
     * @return mixed
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function add_user_password_history(int $user_id = null, string $password = null){

        $error_info_list = [];

        if(empty($user_id)) $error_info_list[] = 'User ID is empty';

        if(empty($password)) $error_info_list[] = 'Password is empty';
        else if(!UserLoginValidation::is_valid_user_password($password)) $error_info_list[] = 'Password is not valid';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $q = array('table' => '_user_password_history',
            'values' => array('user_id' => $user_id,
                'password' => $password,
                'date_create' => 'NOW()'
            )
        );

        $r = Db::insert($q);

        if(count($r) === 0){

            $error = array('title' => 'DB query problem',
                'info' => 'User password history was not added'
            );

            throw new DbQueryException($error);

        }

        return $r[0]['id'];

    }

    /**
     * @param int|null $user_password_history_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_user_password_history_id(int $user_password_history_id = null){

        if(empty($user_password_history_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'User password history ID is empty'
            );

            throw new ParametersException($error);

        }

        if(!Db::pseudo_delete_from_id($user_password_history_id,'_user_password_history',0)){

            $error = array('title' => 'DB query problem',
                'info' => 'User password history was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $user_id
     * @param string|null $password
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_user_password_history(int $user_id = null, string $password = null){

        if(empty($user_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'User ID is empty'
            );

            throw new ParametersException($error);

        }

        $where_list = array('user_id' => $user_id
        );

        if(!empty($password)) $where_list['password'] = $password;

        if(!Db::pseudo_delete_from_where_list('_user_password_history',0,$where_list)){

            $error = array('title' => 'DB query problem',
                'info' => 'User password history was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param array|null $user_password_list
     */
    public static function set_user_password_list(array $user_password_list = null){

        self::$user_password_list = empty($user_password_list) ? null : $user_password_list;

    }

}