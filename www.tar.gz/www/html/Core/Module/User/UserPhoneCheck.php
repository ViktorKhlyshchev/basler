<?php

namespace Core\Module\User;

use Core\Module\Code\Code;
use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class UserPhoneCheck{

    /** @var int */
    public static $user_phone_check_id;

    /** @var int */
    public static $user_phone_id;

    /** @var string */
    public static $hash;

    /** @var string */
    public static $code;

    /** @var bool */
    public static $is_check;

    /**
     * Reset default data
     */
    public static function reset_data(){

        self::$user_phone_check_id = null;
        self::$user_phone_id = null;
        self::$hash = null;
        self::$code = null;
        self::$is_check = null;

    }

    /**
     * @param int|null $user_phone_check_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_user_phone_check_id(int $user_phone_check_id = null){

        if(empty($user_phone_check_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'User phone check ID is empty'
            );

            throw new ParametersException($error);

        }

        return Db::isset_row_id($user_phone_check_id,'_user_phone_check',0);

    }

    /**
     * @param int|null $user_id
     * @param int|null $user_phone_id
     * @param string|null $code
     * @param string|null $hash
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_user_phone_check(int $user_id = null, int $user_phone_id = null, string $code = null, string $hash = null){

        if(empty($user_id)&&empty($user_phone_id)&&empty($code)&&empty($hash)){

            $error = array('title' => 'Parameters problem',
                'info' => 'App parameters are empty'
            );

            throw new ParametersException($error);

        }

        $where_list = [];

        if(!empty($user_id)) $where_list['user_id'] = $user_id;

        if(!empty($user_phone_id)) $where_list['user_phone_id'] = $user_phone_id;

        if(!empty($code)) $where_list['code'] = $code;

        if(!empty($hash)) $where_list['hash'] = $hash;

        if(count($where_list) === 0){

            $error = array('title' => 'Parameters problem',
                'info' => 'App parameters are empty'
            );

            throw new ParametersException($error);

        }

        return Db::isset_row('_user_phone_check',0,$where_list);

    }

    /**
     * @param int|null $user_id
     * @param int|null $user_phone_id
     * @param string|null $code
     * @param string|null $hash
     * @return bool|null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function is_user_phone_check(int $user_id = null, int $user_phone_id = null, string $code = null, string $hash = null){

        if(empty($user_id)&&empty($user_phone_id)&&empty($code)&&empty($hash)){

            $error = array('title' => 'Parameters problem',
                'info' => 'App parameters are empty'
            );

            throw new ParametersException($error);

        }

        $where_list = [];

        if(!empty($user_id)) $where_list['user_id'] = $user_id;

        if(!empty($user_phone_id)) $where_list['user_phone_id'] = $user_phone_id;

        if(!empty($code)) $where_list['code'] = $code;

        if(!empty($hash)) $where_list['hash'] = $hash;

        if(count($where_list) === 0){

            $error = array('title' => 'Parameters problem',
                'info' => 'App parameters are empty'
            );

            throw new ParametersException($error);

        }

        $where_list['type'] = 0;

        $q = array('select' => array('check'),
            'table' => '_user_phone_check',
            'where' => $where_list,
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return (bool)$r[0]['check'];

    }

    /**
     * @param int|null $user_phone_check_id
     * @return bool|null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function is_user_phone_check_id(int $user_phone_check_id = null){

        if(empty($user_phone_check_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'User phone check ID is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('check'),
            'table' => '_user_phone_check',
            'where' => array('id' => $user_phone_check_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return (bool)$r[0]['check'];

    }

    /**
     * @return array
     */
    public static function get_user_phone_code_and_hash(){

        $code =Code::get_code_number(6);
        $hash =Code::get_code_hash($code);

        return array('code' => $code,
            'hash' => $hash
        );

    }

    /**
     * @param int|null $user_id
     * @param int|null $user_phone_id
     * @param string|null $code
     * @param string|null $hash
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_user_phone_check_id(int $user_id = null, int $user_phone_id = null, string $code = null, string $hash = null){

        if(empty($user_id)&&empty($user_phone_id)&&empty($code)&&empty($hash)){

            $error = array('title' => 'Parameters problem',
                'info' => 'App parameters are empty'
            );

            throw new ParametersException($error);

        }

        $where_list = [];

        if(!empty($user_id)) $where_list['user_id'] = $user_id;

        if(!empty($user_phone_id)) $where_list['user_phone_id'] = $user_phone_id;

        if(!empty($code)) $where_list['code'] = $code;

        if(!empty($hash)) $where_list['hash'] = $hash;

        if(count($where_list) === 0){

            $error = array('title' => 'Parameters problem',
                'info' => 'App parameters are empty'
            );

            throw new ParametersException($error);

        }

        return Db::get_row_id('_user_phone_check',0,$where_list);

    }

    /**
     * @param int|null $user_id
     * @param int|null $user_phone_id
     * @param string|null $code
     * @param string|null $hash
     * @return mixed
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function add_user_phone_check(int $user_id = null, int $user_phone_id = null, string $code = null, string $hash = null){

        if(empty($user_id)&&empty($user_phone_id)&&empty($code)&&empty($hash)){

            $error = array('title' => 'Parameters problem',
                'info' => 'App parameters are empty'
            );

            throw new ParametersException($error);

        }

        $value_list = [];

        if(!empty($user_id)) $value_list['user_id'] = $user_id;

        if(!empty($user_phone_id)) $value_list['user_phone_id'] = $user_phone_id;

        if(!empty($code)) $value_list['code'] = $code;

        if(!empty($hash)) $value_list['hash'] = $hash;

        if(count($value_list) === 0){

            $error = array('title' => 'Parameters problem',
                'info' => 'App parameters are empty'
            );

            throw new ParametersException($error);

        }

        $value_list['date_create'] = 'NOW()';

        $q = array('table' => '_user_phone_check',
            'values' => $value_list
        );

        $r = Db::insert($q);

        if(count($r) === 0){

            $error = array('title' => 'DB query problem',
                'info' => 'User phone check was not added'
            );

            throw new DbQueryException($error);

        }

        return $r[0]['id'];

    }

    /**
     * @param int|null $user_id
     * @param int|null $user_phone_id
     * @param string|null $code
     * @param string|null $hash
     * @param bool $is_check
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function update_user_phone_check_status(int $user_id = null, int $user_phone_id = null, string $code = null, string $hash = null, bool $is_check=true){

        if(empty($user_id)&&empty($user_phone_id)&&empty($code)&&empty($hash)){

            $error = array('title' => 'Parameters problem',
                'info' => 'App parameters are empty'
            );

            throw new ParametersException($error);

        }

        if(is_null($is_check)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Check status is null'
            );

            throw new ParametersException($error);

        }

        $where_list = [];

        if(!empty($user_id)) $where_list['user_id'] = $user_id;

        if(!empty($user_phone_id)) $where_list['user_phone_id'] = $user_phone_id;

        if(!empty($code)) $where_list['code'] = $code;

        if(!empty($hash)) $where_list['hash'] = $hash;

        if(count($where_list) === 0){

            $error = array('title' => 'Parameters problem',
                'info' => 'App parameters are empty'
            );

            throw new ParametersException($error);

        }

        $q = array('table' => '_user_phone_check',
            'set' => array('check' => $is_check,
                'date_update' => 'NOW()'),
            'where' => $where_list
        );

        if(!Db::update($q)){

            $error = array('title' => 'DB query problem',
                'info' => 'User phone check status was not updated'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $user_phone_check_id
     * @param bool $is_check
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function update_user_phone_check_status_from_user_phone_check_id(int $user_phone_check_id = null, bool $is_check=true){

        $error_info_list = [];

        if(empty($user_phone_check_id)) $error_info_list[] = 'User phone check ID is empty';

        if(is_null($is_check)) $error_info_list[] = 'Check status is null';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $q = array('table' => '_user_phone_check',
            'set' => array('check' => $is_check,
                'date_update' => 'NOW()'),
            'where' => array('id' => $user_phone_check_id,
                'type' => 0
            )
        );

        if(!Db::update($q)){

            $error = array('title' => 'DB query problem',
                'info' => 'User phone check status was not updated'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $user_id
     * @param int|null $user_phone_id
     * @param string|null $code
     * @param string|null $hash
     * @param bool $is_check
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_user_phone_check(int $user_id = null, int $user_phone_id = null, string $code = null, string $hash = null, bool $is_check=true){

        if(empty($user_id)&&empty($user_phone_id)&&empty($code)&&empty($hash)){

            $error = array('title' => 'Parameters problem',
                'info' => 'App parameters are empty'
            );

            throw new ParametersException($error);

        }

        if(is_null($is_check)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Check status is null'
            );

            throw new ParametersException($error);

        }

        $where_list = [];

        if(!empty($user_id)) $where_list['user_id'] = $user_id;

        if(!empty($user_phone_id)) $where_list['user_phone_id'] = $user_phone_id;

        if(!empty($code)) $where_list['code'] = $code;

        if(!empty($hash)) $where_list['hash'] = $hash;

        if(count($where_list) === 0){

            $error = array('title' => 'Parameters problem',
                'info' => 'App parameters are empty'
            );

            throw new ParametersException($error);

        }

        if(!Db::pseudo_delete_from_where_list('_user_phone_check',0,$where_list)){

            $error = array('title' => 'DB qeury problem',
                'info' => 'User phone check was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $user_phone_check_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_user_phone_check_id(int $user_phone_check_id = null){

        if(empty($user_phone_check_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'User phone check ID is empty'
            );

            throw new ParametersException($error);

        }

        if(!Db::pseudo_delete_from_id($user_phone_check_id,'_user_phone_check',0)){

            $error = array('title' => 'DB qeury problem',
                'info' => 'User phone check was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $user_phone_check_id
     */
    public static function set_user_phone_check_id_default(int $user_phone_check_id = null){

        self::$user_phone_check_id = empty($user_phone_check_id) ? null : $user_phone_check_id;

    }

    /**
     * @param int|null $user_phone_id
     */
    public static function set_user_phone_id_default(int $user_phone_id = null){

        self::$user_phone_id = empty($user_phone_id) ? null : $user_phone_id;

    }

    /**
     * @param string|null $code
     */
    public static function set_code_default(string $code = null){

        self::$code = empty($code) ? null : $code;

    }

    /**
     * @param string|null $hash
     */
    public static function set_hash_default(string $hash = null){

        self::$hash = empty($hash) ? null : $hash;

    }

    /**
     * @param bool|null $is_check
     */
    public static function set_is_check_default(bool $is_check = null){

        self::$is_check = empty($is_check) ? null : $is_check;

    }

}