<?php

namespace Core\Module\User;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class UserHash {

    public static $user_hash_id;
    public static $user_hash_type_id;
    public static $code;
    public static $hash;
    public static $tn = '_user_hash';

    public static function reset_data(){
        self::$user_hash_id = null;
        self::$user_hash_type_id = null;
        self::$code = null;
        self::$hash = null;
    }

    public static function get_api_keys_list($user_hash_type_id, $type = null){ #public static function get_api_keys_list(array $user_hash_type_ids_list = []){ #pred($user_hash_type_ids_list);
        $q = ['table' => self::$tn,
            'select' => [
                'id',
                'user_id',
                'user_hash_type_id',
                'code',
                'hash',
                'date_create',
                'date_use',
                'type'
            ],
            'where' => ['user_hash_type_id' => $user_hash_type_id]]; #'user_hash_type_id' => $user_hash_type_ids_list 'limit' => 1

        if(!is_null($type)) $q['where']['type'] = $type; #pred($q);
        $r = Db::select($q); # pred($r);
        return $r;
    }

    public static function get_api_keys_byuid($user_id, $type = null){
        $q = ['table' => self::$tn,
            'select' => [
                'id',
                'user_id',
                'user_hash_type_id',
                'code',
                'hash',
                'date_create',
                'date_use',
                'type'
            ], 'where' => ['user_id' => $user_id]];

        if(!is_null($type)) $q['where']['type'] = $type;

        $r = Db::select($q);
        return $r;
    }

    public static function isset_user_hash_id(int $user_hash_id = null){
        if(empty($user_hash_id)){ $error = ['title' => 'Parameters problem', 'info' => 'User hash ID is empty']; throw new ParametersException($error); }
        return Db::isset_row_id($user_hash_id, self::$tn, 0);
    }

    public static function isset_user_hash(int $user_id = null, int $user_hash_type_id = null, string $code = null, string $hash = null, bool $is_hash_use = null){

        if(empty($user_id) && empty($user_hash_type_id) && empty($code) && empty($hash)){
            $error = array('title' => 'Parameters problem',
                'info' => 'All parameters are empty'
            );
            throw new ParametersException($error);
        }

        $where_list = [];

        if(!empty($user_id)) $where_list['user_id'] = $user_id;

        if(!empty($user_hash_type_id)) $where_list['user_hash_type_id'] = $user_hash_type_id;

        if(!empty($code)) $where_list['code'] = $code;

        if(!empty($hash)) $where_list['hash'] = $hash;

        if(!is_null($is_hash_use)) $where_list['date_use'] = $is_hash_use ? 'IS NOT null' : null;

        return Db::isset_row(self::$tn, 0, $where_list);
    }

    public static function get_user_hash_data(int $user_hash_id = null, int $user_hash_type_id = null){ #pre(func_get_args());

        if(empty($user_hash_id)){ $error = ['title' => 'Parameters problem', 'info' => 'User hash ID is empty']; throw new ParametersException($error); }

        $q = ['table' => self::$tn,
            'select' => ['id',
                'user_id',
                'user_hash_type_id',
                'code',
                'hash',
                'date_create',
                'date_use'],
            'where' => ['id' => $user_hash_id, 'type' => 0], 'limit' => 1
        ];

        if(!is_null($user_hash_type_id)) $q['where']['user_hash_type_id'] = $user_hash_type_id;

        $r = Db::select($q); # pred($r);

        if(!count($r)) return null;

        return array('id' => $r[0]['id'],
            'user_id' => $r[0]['user_id'],
            'user_hash_type_id' => $r[0]['user_hash_type_id'],
            'code' => $r[0]['code'],
            'hash' => $r[0]['hash'],
            'date_create' => $r[0]['date_create'],
            'date_use' => $r[0]['date_use']
        );
    }

    public static function get_user_id(string $hash = null, int $user_hash_type_id = null){

        if(empty($hash)){
            $error = array('title' => 'Parameters problem',
                'info' => array('hash' => 'Hash is empty'
                )
            );
            throw new ParametersException($error);
        }

        $q = array('select' => array('user_id'),
            'table' => self::$tn,
            'where' => array('hash' => $hash, 'type' => 0),
            'limit' => 1
        );

        if(!is_null($user_hash_type_id)) $q['where']['user_hash_type_id'] = $user_hash_type_id;

        $r = Db::select($q);

        if(count($r) == 0) return null;

        return $r[0]['user_id'];
    }

    public static function get_user_hash_data_from_hash(string $hash = null, int $user_hash_type_id = null, bool $is_hash_use = null){

        if(empty($hash)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Hash is empty'
            );
            throw new ParametersException($error);
        }

        $q = array('select' => array('id',
                'user_id',
                'user_hash_type_id',
                'code',
                'login',
                'hash',
                'date_create',
                'date_use'),
            'table' => self::$tn,
            'where' => array('hash' => $hash, 'type' => 0),
            'limit' => 1
        );

        if(!is_null($user_hash_type_id)) $q['where']['user_hash_type_id'] = $user_hash_type_id;

        if(!is_null($is_hash_use)) $q['where']['date_use'] = $is_hash_use ? 'IS NOT null' : null;

        $r = Db::select($q);

        if(count($r) == 0) return null;

        return array('id' => $r[0]['id'],
            'user_id' => $r[0]['user_id'],
            'user_hash_type_id' => $r[0]['user_hash_type_id'],
            'code' => $r[0]['code'],
            'login' => $r[0]['login'],
            'hash' => $r[0]['hash'],
            'date_create' => $r[0]['date_create'],
            'date_use' => $r[0]['date_use']
        );
    }

    public static function get_user_hash_id(int $user_id = null, int $user_hash_type_id = null, string $code = null, string $hash = null, bool $is_hash_use = null){

        if(empty($user_id) && empty($user_hash_type_id) && empty($code) && empty($hash)){
            $error = array('title' => 'Parameters problem',
                'info' => 'All parameters are empty'
            );
            throw new ParametersException($error);
        }

        $where_list = [];

        if(!empty($user_id)) $where_list['user_id'] = $user_id;

        if(!empty($user_hash_type_id)) $where_list['user_hash_type_id'] = $user_hash_type_id;

        if(!empty($code)) $where_list['code'] = $code;

        if(!empty($hash)) $where_list['hash'] = $hash;

        if(!is_null($is_hash_use)) $where_list['date_use'] = $is_hash_use ? 'IS NOT null' : null;

        return Db::get_row_id(self::$tn, 0, $where_list);
    }

    public static function add_user_hash(int $user_id = null, int $user_hash_type_id = null, string $code = null, string $hash = null, string $login = null){

        $error_info_list = [];

        if(empty($user_id)) $error_info_list[] = 'User ID is empty';

        if(empty($user_hash_type_id)) $error_info_list[] = 'User hash type ID is empty';

        if(empty($hash)) $error_info_list[] = 'Hash is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);
        }

        $q = array('table' => self::$tn,
            'values' => [
                'user_id' => $user_id,
                'user_hash_type_id' => $user_hash_type_id,
                'code' => empty($code) ? null : $code,
                'login' => empty($login) ? null : $login,
                'hash' => $hash,
                'date_create' => 'NOW()',
                'date_update' => 'NOW()',
                'type' => 0
            ]
        );

        $r = Db::insert($q);

        if(count($r) == 0){

            $error = [
                'title' => DbQueryException::$title,
                'info' => 'User hash was not added'
            ];

            throw new DbQueryException($error);

        }

        return $r[0]['id'];
    }

    public static function update_user_hash_date_use(int $user_id = null, int $user_hash_type_id = null, string $code = null, string $hash = null){

        if(empty($user_id) && empty($user_hash_type_id) && empty($code) && empty($hash)){

            $error = array('title' => 'Parameters problem',
                'info' => 'All parameters are empty'
            );

            throw new ParametersException($error);

        }

        $where_list = [];

        if(!empty($user_id)) $where_list['user_id'] = $user_id;

        if(!empty($user_hash_type_id)) $where_list['user_hash_type_id'] = $user_hash_type_id;

        if(!empty($code)) $where_list['code'] = $code;

        if(!empty($hash)) $where_list['hash'] = $hash;

        $q = array('table' => self::$tn,
            'set' => array('date_use' => 'NOW()',
                'date_update' => 'NOW()',
                'type' => '2'),
            'where' => $where_list
        );

        if(!Db::update($q)){
            $error = array('title' => 'DB query problem',
                'info' => 'User hash date use was not updated'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function update_user_hash_date_use_from_user_hash_id(int $user_hash_id = null){

        if(empty($user_hash_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User hash ID is empty'
            );
            throw new ParametersException($error);
        }

        $q = array('table' => self::$tn,
            'set' => array('date_use' => 'NOW()',
                'date_update' => 'NOW()',
                'type' => '2'),
            'where' => [
                'id' => $user_hash_id,
                'type' => 0
            ]
        );

        if(!Db::update($q)){
            $error = array('title' => 'DB query problem',
                'info' => 'User hash date use was not updated'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function update_user_hash_use_from_user_hash_id(int $user_hash_id = null){

        if(empty($user_hash_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User hash ID is empty'
            );
            throw new ParametersException($error);
        }

        $q = array('table' => self::$tn,
            'set' => array('date_use' => 'NOW()',
                'date_update' => 'NOW()',
                'type' => '2'),
            'where' => array('id' => $user_hash_id,
                'type' => 0
            )
        );

        if(!Db::update($q)){
            $error = array('title' => 'DB query problem',
                'info' => 'User hash date use was not updated'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_user_hash_id(int $user_hash_id = null){

        if(empty($user_hash_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User hash ID is empty'
            );
            throw new ParametersException($error);
        }

        if(!Db::pseudo_delete_from_id($user_hash_id, self::$tn, 0)){
            $error = array('title' => 'DB query problem',
                'info' => 'User hash was not removed'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_user_hash(int $user_id = null, int $user_hash_type_id = null, string $code = null, string $hash = null){

        if(empty($user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User ID is empty'
            );
            throw new ParametersException($error);
        }

        $where_list = ['user_id' => $user_id];

        if(!empty($user_hash_type_id)) $where_list['user_hash_type_id'] = $user_hash_type_id;

        if(!empty($code)) $where_list['code'] = $code;

        if(!empty($hash)) $where_list['hash'] = $hash;

        if(!Db::pseudo_delete_from_where_list(self::$tn, 0, $where_list)){

            $error = array('title' => 'DB query problem',
                'info' => 'User hash was not removed'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function set_user_hash_id_default(int $user_hash_id = null){
        self::$user_hash_id = empty($user_hash_id) ? null : $user_hash_id;
    }

    public static function set_user_hash_type_id_default(int $user_hash_type_id = null){
        self::$user_hash_type_id = empty($user_hash_type_id) ? null : $user_hash_type_id;
    }

    public static function set_code_default(string $code = null){
        self::$code = empty($code) ? null : $code;
    }

    public static function set_hash_default(string $hash = null){
        self::$hash = empty($hash) ? null : $hash;
    }
}