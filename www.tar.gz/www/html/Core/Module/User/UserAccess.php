<?php

namespace Core\Module\User;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;
use Configs\UserAccessTypeConfig;

class UserAccess {

    public static $tn = '_user_access';
    public static $user_access_id;
    public static $user_access_id_list = [];
    public static $is_root = false;
    public static $is_dev = false;
    public static $is_admin = false;
    public static $is_profile = false;
    public static $is_profile_wallet = false;
    public static $is_bot = false;
    public static $is_app = false;
    public static $is_web = false;
    public static $is_debug = false;
    public static $is_guest = false;
    public static $is_test = false;
    public static $is_promo_radar = false;
    public static $is_api_statistics = false;
    public static $uatns = []; # user access type names
    public static $uatnsjs = []; # user access type names array for JS

    public static function reset_data(){
        self::$user_access_id = null;
        self::$user_access_id_list = [];
        self::set_user_access_type_name_list_default([]);
        return true;
    }

    public static function reset_user_access_list(){
        self::$is_root = false;
        self::$is_dev = false;
        self::$is_admin = false;
        self::$is_profile = false;
        self::$is_profile_wallet = false;
        self::$is_bot = false;
        self::$is_app = false;
        self::$is_web = false;
        self::$is_guest = false;
        self::$is_api_statistics = false;
        return true;
    }

    public static function isset_user_access_id(int $user_access_id = null){
        if(empty($user_access_id)){
            $error = ['title' => 'Parameters problem', 'info' => 'User access ID is empty'];
            throw new ParametersException($error);
        }
        return Db::isset_row_id($user_access_id, '_user_access', 0);
    }

    public static function isset_user_access(int $user_id = null, string $user_access_type_name = null){
        $error_info_list = [];
        if(empty($user_id)) $error_info_list[] = 'User ID is empty';
        if(empty($user_access_type_name)) $error_info_list[] = 'User access type name is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );
            throw new ParametersException($error);
        }
        $user_access_type_id = UserAccessType::get_user_access_type_id($user_access_type_name);
        if(empty($user_access_type_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User access type name is not valid'
            );
            throw new ParametersException($error);
        }
        $where_list = array('user_id' => $user_id,
            'user_access_type_id' => $user_access_type_id
        );
        return Db::isset_row('_user_access', 0, $where_list);
    }

    public static function get_user_access_id(int $user_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem', 'info' => 'User ID is empty');
            throw new ParametersException($error);
        }
        $where_list = array('user_id' => $user_id
        );
        return Db::get_row_id('_user_access', 0, $where_list);
    }

    public static function get_list_access(array $access_list = []){
        return UserAccessTypeConfig::get_user_access_type_list($access_list);
    }

    public static function get_prepare_user_access_type_name_list(array $user_access_type_name_list = []){
        if(count($user_access_type_name_list) == 0) return [];
        $list = [];
        foreach($user_access_type_name_list as $user_access_type_name)
            if(array_search($user_access_type_name, UserAccessTypeConfig::$user_access_type_name_list)!== false)
                $list[] = $user_access_type_name;
        return $list;
    }

    public static function get_user_access_type_name_list(int $user_id = null){
        if(empty($user_id)){ $error = ['title' => 'Parameters problem', 'info' => 'User ID is empty']; throw new ParametersException($error);}
        $q = ['table' => self::$tn,
            'select' => ['id', 'user_access_type_id'],
            'where' => ['user_id' => $user_id, 'type' => 0]
        ];
        $r = Db::select($q);
        if(!count($r)) return [];
        $user_access_type_id_list = [];
        foreach($r as $row) if(!empty($row['user_access_type_id'])) $user_access_type_id_list[] = $row['user_access_type_id'];
        return UserAccessType::get_user_access_type_name_list($user_access_type_id_list);
    }

    public static function get_user_access_list_default(){
        if(empty(User::$user_id)){
            $error = ['title' => 'Parameters problem', 'info' => 'User ID is empty'];
            throw new ParametersException($error);
        }
        $user_access_type_name_list = self::get_user_access_type_name_list(User::$user_id);
        if(!count($user_access_type_name_list)){ return; #pred(debug_backtrace());
            $error = ['title' => 'DB query problem', 'info' => 'User access list is empty'];
            throw new ParametersException($error);
            return;
        }
        return self::set_user_access_type_name_list_default($user_access_type_name_list);
    }

    public static function get_user_len_from_access_type_id(int $user_access_type_id = null){
        if(empty($user_access_type_id)){
            $error = ['title' => ParametersException::$title,  'info' => 'User access type ID is empty'];
            throw new ParametersException($error);
        }
        $where_list = ['user_access_type_id' => $user_access_type_id];
        return Db::get_row_len(self::$tn, 0, $where_list);
    }

    public static function add_user_access(int $user_id = null, array $user_access_type_name_list = []){
        $error_info_list = [];
        if(empty($user_id)) $error_info_list[] = 'User ID is empty';
        if(!count($user_access_type_name_list)) $error_info_list[] = 'User access type name list is empty';
        if(count($error_info_list) > 0){ $error = ['title' => 'Parameters problem', 'info' => $error_info_list]; throw new ParametersException($error); }
        $user_access_type_id_list = UserAccessType::get_user_access_type_id_list($user_access_type_name_list); #pred($user_access_type_id_list);
        if(!count($user_access_type_id_list)){
            $error = array('title' => 'Db query problem', 'info' => 'Access list is empty');
            throw new ParametersException($error);
        }
        $value_list = [];
        foreach($user_access_type_id_list as $user_access_type_id)
            if(!empty($user_access_type_id)) $value_list[] = [
                    'user_id' => $user_id,
                    'user_access_type_id' => $user_access_type_id,
                    'date_create' => 'NOW()',
                    'date_update' => 'NOW()',
                    'type' => 0
                ];
        if(!count($value_list)){ $error = array('title' => 'Parameters problem', 'info' => 'Access list is empty'); throw new ParametersException($error); }
        $q = array('table' => '_user_access', 'values' => $value_list);
        $r = Db::insert($q);
        if(!count($r)){ $error = array('title' => 'DB query problem', 'info' => 'User access was not added'); throw new DbQueryException($error); }
        return $r;
    }

    public static function remove_user_access_id(int $user_access_id = null){
        if(empty($user_access_id)){
            $error = ['title' => 'Parameters problem', 'info' => 'User access ID is empty'];
            throw new ParametersException($error);
        }
        $q = ['table' => self::$tn,
            'set' => ['date_remove' => 'NOW()', 'type' => 1],
            'where' => ['id' => $user_access_id, 'type' => 0]
        ];
        if(!Db::update($q)){
            $error = ['title' => 'DB query problem', 'info' => 'User access was not removed'];
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_user_access(int $user_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem', 'info' => 'User ID is empty');
            throw new ParametersException($error);
        }
        $q = ['table' => self::$tn,
            'set' => ['date_remove' => 'NOW()', 'type' => 1],
            'where' => ['user_id' => $user_id, 'type' => 0]
        ];
        if(!Db::update($q)){
            $error = ['title' => 'Db query problem', 'info' => 'User access was not remove','data' => ['user_id' => $user_id, 'query' => $q]];
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_user_access_type(int $user_id = null, array $user_access_type_name_list = []){
        $error_info_list = [];
        if(empty($user_id)) $error_info_list[] = 'User ID is empty';
        if(!count($user_access_type_name_list)) $error_info_list[] = 'User access type name list is empty';
        if(count($error_info_list) > 0){ $error = ['title' => 'Parameters problem', 'info' => $error_info_list];  throw new ParametersException($error); }
        $user_access_type_id_list = UserAccessType::get_user_access_type_id_list($user_access_type_name_list);
        if(!count($user_access_type_id_list)){ $error = ['title' => 'Parameters problem', 'info' => 'User access type ID list is empty']; throw new ParametersException($error); }
        $q = ['table' => self::$tn,
            'set' => ['date_remove' => 'NOW()', 'type' => 1],
            'where' => ['user_id' => $user_id, 'user_access_type_id' => $user_access_type_id_list, 'type' => 0]
        ];
        if(!Db::update($q)){ $error = ['title' => 'DB query probelm', 'info' => 'User access was not remove']; throw new DbQueryException($error); }
        return true;
    }

    public static function remove_user_access_id_list(array $user_access_id_list = []){
        if(!count($user_access_id_list)){
            $error = ['title' => 'Parameters problem', 'info' => 'User access ID list is empty'];
            throw new ParametersException($error);
        }
        $id_list = [];
        foreach($user_access_id_list as $user_access_id) if(!empty($user_access_id)) $id_list[] = $user_access_id;
        if(!count($id_list)){
            $error = ['title' => 'Parameters problem', 'info' => 'User access ID list is empty'];
            throw new ParametersException($error);
        }
        return Db::pseudo_delete_from_id_list($id_list, '_user_access', 0);
    }

    public static function set_user_access_id_default(int $user_access_id = null){
        self::$user_access_id = empty($user_access_id) ? null : $user_access_id;
    }

    public static function set_user_access_type_name_list_default(array $user_access_type_name_list = []){
        self::reset_user_access_list(); # pred(debug_backtrace()); #
        #pred($user_access_type_name_list);
        foreach($user_access_type_name_list as $user_access_type_name){
            self::$uatns[$user_access_type_name] = $user_access_type_name;
            self::$uatnsjs[] = $user_access_type_name;
            switch($user_access_type_name){
                case 'root': { self::$is_root = true; break; }
                case 'dev': { self::$is_dev = true; break; }
                case 'admin': { self::$is_admin = true; break; }
                case 'profile': { self::$is_profile = true; break; }
                case 'profile_wallet': { self::$is_profile_wallet = true; break; }
                case 'bot': { self::$is_bot = true; break; }
                case 'app': { self::$is_app = true; break; }
                case 'web': { self::$is_web = true; break; }
                case 'debug': { self::$is_debug = true; break; }
                case 'guest': { self::$is_guest = true; break; }
                case 'test': { self::$is_test = true; break; }
                case 'promo_radar': { self::$is_promo_radar = true; break; }
                case 'api_statistics': { self::$is_api_statistics = true; break; }
                default: {
                    $error = ['title' => 'Parameters problem', 'info' => 'User access parameter from list is not exists', 'data' => ['list' => $user_access_type_name_list, 'key' => $user_access_type_name]];
                    throw new ParametersException($error);
                }
            }
        }
        return true;
    }
}