<?php

namespace Core\Module\User;

use Core\Module\Exception\ParametersException;
use Configs\UserAccessTypeConfig;

class UserAccessTypeValidation {
    public static function isset_user_access_name(string $name = null){
        if(empty($name)){
            $error = ['title' => ParametersException::$title, 'info' => 'Name is empty'];
            throw new ParametersException($error);
        }
        return isset(UserAccessTypeConfig::$user_access_type_name_list[$name]);
    }

    public static function isset_user_access_type_id(int $index = null){
        if(is_null($index)){
            $error = ['title' => ParametersException::$title, 'info' => 'Index is not set'];
            throw new ParametersException($error);
        }
        $name = array_search($index,UserAccessTypeConfig::$user_access_type_name_list);
        return $name !== false;
    }
}