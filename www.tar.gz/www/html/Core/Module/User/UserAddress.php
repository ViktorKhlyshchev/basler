<?php

namespace Core\Module\User;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class UserAddress{

    /** @var int */
    public static $user_address_id;

    /** @var int */
    public static $continent_id;

    /** @var int */
    public static $country_id;

    /** @var int */
    public static $city_id;

    /** @var string */
    public static $street_name;

    /** @var string */
    public static $home;

    /** @var string */
    public static $building;

    /** @var string */
    public static $apartment;

    /** @var string */
    public static $postcode;

    /**
     * @return bool
     */
    public static function reset_data(){

        self::$user_address_id = null;
        self::$continent_id = null;
        self::$country_id = null;
        self::$city_id = null;
        self::$street_name = null;
        self::$home = null;
        self::$building = null;
        self::$apartment = null;
        self::$postcode = null;

        return true;

    }

    /**
     * @param int|null $user_id
     * @param int|null $continent_id
     * @param int|null $country_id
     * @param int|null $city_id
     * @param string|null $street_name
     * @param string|null $home
     * @param string|null $building
     * @param string|null $apartment
     * @param string|null $postcode
     * @return mixed
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function add_user_address(int $user_id = null, int $continent_id = null, int $country_id = null, int $city_id = null, string $street_name = null, string $home = null, string $building = null, string $apartment = null, string $postcode = null){

        $error_info_list = [];

        if(empty($user_id)) $error_info_list[] = 'User ID is empty';

        if(empty($continent_id)) $error_info_list[] = 'Continent ID is empty';

        if(empty($country_id)) $error_info_list[] = 'Country ID is empty';

        if(empty($city_id)) $error_info_list[] = 'City ID is empty';

        if(empty($street_name)) $error_info_list[] = 'Street name is empty';

        if(empty($home)) $error_info_list[] = 'Home is empty';

        if(empty($building)) $error_info_list[] = 'Building is empty';

        if(empty($apartment)) $error_info_list[] = 'Apartment is empty';

        if(empty($postcode)) $error_info_list[] = 'Postcode is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $q = array('table' => '_user_address',
            'values' => array('user_id' => $user_id,
                'continent_id' => $continent_id,
                'country_id' => $country_id,
                'city_id' => $city_id,
                'street_name' => $street_name,
                'home' => $home,
                'building' => $building,
                'apartment' => $apartment,
                'postcode' => $postcode,
                'date_create' => 'NOW()',
                'date_update' => 'NOW()'
            )
        );

        $r = Db::insert($q);

        if(count($r) === 0){

            $error = array('title' => 'DB query problem',
                'info' => 'User address was not added'
            );

            throw new DbQueryException($error);

        }

        return $r[0]['id'];

    }

    /**
     * @param int|null $user_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_user_address(int $user_id = null){

        if(empty($user_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'User ID is empty'
            );

            throw new ParametersException($error);

        }

        $where_list = array('user_id' => $user_id
        );

        if(!Db::pseudo_delete_from_where_list('_user_address',0,$where_list)){

            $error = array('title' => 'DB query problem',
                'info' => 'User address was not removed'
            );

            throw new ParametersException($error);

        }

        return true;

    }

}