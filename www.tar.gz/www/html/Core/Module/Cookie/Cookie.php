<?php

namespace Core\Module\Cookie;

use Core\Modules\Bearer;
use Common\Modules\Date;
use Core\Module\Token\Token;
use Configs\TokenConfig;
use Configs\CookieConfig;
use Core\Module\Url\Url;

class Cookie {

    public static function isset_token(){
        switch(Url::$host){
            case 'api.aist':
            case 'api.aist.ru': return !empty($_GET['token']) || !empty($_POST['token']);
            default: return !empty($_COOKIE['token']);
        }
    }

    public static function get_token(){
        switch(Url::$host){
            case 'api.aist':
            case 'api.aist.ru':{
                if(!empty($_GET['token'])) return $_GET['token'];
                if(!empty($_POST['token'])) return $_POST['token'];
                $bearer_token = Bearer::get_bearer_token();
                if(!empty($bearer_token)) return $bearer_token;
                return null;
            }
            default:{
                if(!empty($_GET['token'])) return $_GET['token'];
                if(!empty($_POST['token'])) return $_POST['token'];
                $bearer_token = Bearer::get_bearer_token();
                if(!empty($bearer_token)) return $bearer_token;
                return empty($_COOKIE['token']) ? null : $_COOKIE['token'];
            }
        }
    }

    public static function create_token(int $timestamp = null, string $dir = '', string $host = ''){
        if(empty($timestamp)) $timestamp = Date::get_timestamp(Token::get_token_date_live(TokenConfig::$is_keep));
        if(empty($dir)) if(CookieConfig::$is_dir) $dir = CookieConfig::$dir_default;
        if(empty($host)) if(CookieConfig::$is_host) $host = Url::$host;
        return setcookie('token', Token::$token_hash, $timestamp, $dir, $host, \Config::$http_type == 'https');
    }

    public static function update_token(){
        return self::create_token();
    }

    public static function remove_token(string $dir = '', string $host = ''){
        if(empty($dir)) if(CookieConfig::$is_dir) $dir = CookieConfig::$dir_default;
        if(empty($host)) if(CookieConfig::$is_host) $host = Url::$host;
        return setcookie('token', null, 1, $dir, $host);
    }
}