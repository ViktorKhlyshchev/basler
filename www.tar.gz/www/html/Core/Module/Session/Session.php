<?php

namespace Core\Module\Session;

use Common\Modules\Date;
use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;
use Core\Module\Token\Token;
use Core\Module\User\User;

class Session {

    public static $session_id;
    public static $session_date_live;
    public static $tn = '_session';

    public static function reset_data(){
        self::$session_id = null;
        self::$session_date_live = null;
        return true;
    }

    public static function isset_session_id(int $session_id = null){
        if(empty($session_id)){
            $error = ['title' => 'Parameters problem', 'info' => 'Session ID is empty'];
            throw new ParametersException($error);
        }
        $q = ['select' => [['column' => 'id']],
            'table' => self::$tn,
            'where' => array(
                 array('column' => 'id',
                    'value' => $session_id
                ),
                 array('column' => 'date_live',
                    'method' => '>',
                    'value' => Date::get_date_time_full()
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ), 'limit' => 1];
        $r = Db::select($q);
        return !empty($r);
    }

    public static function isset_session(int $user_id = null, int $token_id = null){
        if(empty($token_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Token ID is empty'
            );
            throw new ParametersException($error);
        }
        $where_list = array(
             array('column' => 'token_id',
                'value' => $token_id
            ),
             array('column' => 'date_live',
                'method' => '>',
                'value' => Date::get_date_time_full()
            )
        );
        if(!empty($user_id)) $where_list[] = array('column' => 'user_id',
                'value' => $user_id
            );
        return Db::isset_row('_session',0,$where_list);
    }

    public static function get_session_id(int $user_id = null, int $token_id = null){
        if(empty($token_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Token ID is empty'
            );
            throw new ParametersException($error);
        }
        $where_list = array(
             array('column' => 'token_id',
                'value' => $token_id
            ),
             array('column' => 'date_live',
                'method' => '>',
                'value' => Date::get_date_time_full()
            ),
             array('column' => 'type',
                'value' => 0
            )
        );
        if(!empty($user_id)) $where_list[] = array('column' => 'user_id',
                'value' => $user_id
            );
        $q = array('select' => array(
                 array('column' => 'id'
                )
            ),
            'table' => self::$tn,
            'where' => $where_list,
            'limit' => 1
        );
        $r = Db::select($q);
        if(count($r) === 0) return null;
        return $r[0]['id'];
    }

    public static function get_session_date_live(){
        return Date::get_date_time_full(Date::get_timestamp() + SessionConfig::$session_date_delta);
    }

    public static function add_session(int $user_id = null, int $token_id = null){ # pred(func_get_args());

        $error_info_list = [];
        if(empty($token_id)) $error_info_list[] = 'Token ID is empty';
        if(count($error_info_list)){ $error = ['title' => 'Parameters problem', 'info' => $error_info_list, 'data' => ['user_id' => $user_id, 'token_id' => $token_id]]; throw new ParametersException($error); }
        $session_date_live =self::get_session_date_live();
        $value_list = ['token_id' => $token_id, 'date_create' => 'NOW()', 'date_live' => $session_date_live];
        if(!empty(User::$user_id)) $value_list['user_id'] = User::$user_id;
        $q = ['table' => self::$tn, 'values' => array($value_list)];
        $r = Db::insert($q);
        if(!count($r)){ $error = ['title' => 'DB query problem', 'info' => 'New session was not added', 'data' => ['user_id' => $user_id, 'token_id' => $token_id, 'query' => $q]]; throw new DbQueryException($error); }
        return $r[0]['id'];
    }

    public static function add_session_default(){

        self::$session_date_live = self::get_session_date_live();
        self::$session_id = self::add_session(User::$user_id, Token::$token_id);
        if(empty(self::$session_id)){
            $error = ['title' => 'DB query problem', 'info' => 'Session was not removed', 'data' => ['token_id' => Token::$token_id, 'user_id' => User::$user_id, 'date_live' => self::$session_date_live]];
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_session(int $user_id = null, int $token_id = null){
        if(empty($token_id)&&empty($user_id)){ $error = ['title' => 'Parameters problem', 'info' => 'Token ID and user ID are empty']; throw new ParametersException($error); }
        $where_list = [];
        if(!empty($user_id)) $where_list['user_id'] = $user_id;
        if(!empty($token_id)) $where_list['token_id'] = $token_id;
        if(!Db::pseudo_delete_from_where_list('_session',0,$where_list)){ $error = ['title' => 'DB query problem', 'info' => 'Session was not removed']; throw new DbQueryException($error); }
        return true;
    }

    public static function remove_session_id(int $session_id = null){
        if(empty($session_id)){ $error = ['title' => 'Parameters problem', 'info' => 'Session ID is empty']; throw new ParametersException($error); }
        if(!Db::pseudo_delete_from_id($session_id, '_session', 0)){ $error = ['title' => 'DB query problem', 'info' => 'Session was not removed']; throw new DbQueryException($error); }
        return true;
    }

    public static function remove_session_id_default(){
        if(empty(self::$session_id)){ $error = ['title' => 'Parameters problem', 'info' => 'Default session ID is empty']; throw new ParametersException($error); }
        return self::remove_session_id(self::$session_id);
    }

    public static function update_session_date_live(int $session_id = null, string $session_date_live = null){
        if(empty($session_id)){
            $error = ['title' => 'Parameters problem', 'info' => 'Session ID is empty'];
            throw new ParametersException($error);
        }
        if(empty($session_date_live)) $session_date_live=self::get_session_date_live();
        $q = ['table' => self::$tn,
            'set' => [['column' => 'date_update', 'value' => 'NOW()'], ['column' => 'date_live', 'value' => $session_date_live]],
            'where' => [['column' => 'id', 'value' => $session_id]]
        ];
        if(!Db::update($q)){
            $error = ['title' => 'DB query problem', 'info' => 'Session was not updated date live', 'data' => ['session_id' => $session_id, 'query' => $q]];
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function update_session_date_live_default(){
        if(empty(self::$session_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Default session ID is empty'
            );
            throw new ParametersException($error);
        }
        self::$session_date_live=self::get_session_date_live();
        if(!self::update_session_date_live(self::$session_id, self::$session_date_live)){
            $error = array('title' => 'DB query problem',
                'info' => 'Default session date live was not updated'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function set_session_id_default(int $session_id = null){
        self::$session_id = empty($session_id) ? null : $session_id;
    }

    public static function set_session_date_live(int $session_date_live = null){
        self::$session_date_live = empty($session_date_live) ? null : $session_date_live;
    }
}