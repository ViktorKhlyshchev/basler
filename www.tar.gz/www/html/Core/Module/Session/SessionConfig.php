<?php

namespace Core\Module\Session;

class SessionConfig {

    public static $session_date_delta = 300;

    public static function reset_data(){
        self::$session_date_delta = 300;
        return true;
    }

    public static function set_session_date_delta(int $seconds = 300){
        self::$session_date_delta = $seconds;
        return true;
    }
}