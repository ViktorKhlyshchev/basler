<?php

namespace Core\Module\Lang;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class LangLocalization{

    /** @var int */
    public static $lang_localization_id;

    /** @var int */
    public static $lang_id;

    /** @var int */
    public static $content_lang_id;

    /** @var string */
    public static $lang_name;

    /**
     * Reset default data
     * @return bool
     */
    public static function reset_data(){

        self::$lang_localization_id = null;
        self::$lang_id = null;
        self::$content_lang_id = null;
        self::$lang_name = null;

        return true;

    }

    /**
     * @param int|null $lang_localization_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_lang_localization_id(int $lang_localization_id = null){

        if(empty($lang_localization_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Lang localization ID is empty'
            );

            throw new ParametersException($error);

        }

        return Db::isset_row_id($lang_localization_id,'_lang_localization',0);

    }

    /**
     * @param int|null $lang_id
     * @param int|null $content_lang_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_lang_localization(int $lang_id = null, int $content_lang_id = null){

        if(empty($lang_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Lang ID is empty'
            );

            throw new ParametersException($error);

        }

        $where_list = array('lang_id' => $lang_id
        );

        if(!empty($content_lang_id)) $where_list['content_lang_id'] = $content_lang_id;

        return Db::isset_row('_lang_localization',0,$where_list);

    }

    /**
     * @param int|null $lang_id
     * @param int|null $content_lang_id
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_lang_localization_id(int $lang_id = null, int $content_lang_id = null){

        if(empty($lang_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Lang ID is empty'
            );

            throw new ParametersException($error);

        }

        $where_list = array('lang_id' => $lang_id
        );

        if(!empty($content_lang_id)) $where_list['content_lang_id'] = $content_lang_id;

        return Db::get_row_id('_lang_localization',0,$where_list);

    }

    /**
     * @param int|null $lang_id
     * @param int|null $content_lang_id
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_lang_name(int $lang_id = null, int $content_lang_id = null){

        $error_info_list = [];

        if(empty($lang_id)) $error_info_list[] = 'Lang ID is empty';

        if(empty($content_lang_id)) $error_info_list[] = 'Content lang ID is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('name'),
            'table' => '_lang_localization',
            'where' => array('lang_id' => $lang_id,
                'content_lang_id' => $content_lang_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0]['name'];

    }

    /**
     * @param int|null $lang_localization_id
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_lang_name_from_lang_localization_id(int $lang_localization_id = null){

        if(empty($lang_localization_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Lang localization ID is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('name'),
            'table' => '_lang_localization',
            'where' => array('id' => $lang_localization_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0]['name'];

    }

    /**
     * @param int|null $lang_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_lang_localization(int $lang_id = null){

        if(empty($lang_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Lang ID is empty'
            );

            throw new ParametersException($error);

        }

        $where_list = array('lang_id' => $lang_id
        );

        if(!Db::pseudo_delete_from_where_list('_lang_localization',0,$where_list)){

            $error = array('title' => 'DB query problem',
                'info' => 'Lang localization was not remvoed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $lang_localization_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_lang_localization_id(int $lang_localization_id = null){

        if(empty($lang_localization_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Lang localization ID is empty'
            );

            throw new ParametersException($error);

        }

        if(!Db::pseudo_delete_from_id($lang_localization_id,'_lang_localization',0)){

            $error = array('title' => 'DB query problem',
                'info' => 'Lang localization was not remvoed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $lang_localization_id
     */
    public static function set_lang_localization_id_default(int $lang_localization_id = null){

        self::$lang_localization_id = empty($lang_localization_id) ? null : $lang_localization_id;

    }

    /**
     * @param int|null $lang_id
     */
    public static function set_lang_id_default(int $lang_id = null){

        self::$lang_id = empty($lang_id) ? null : $lang_id;

    }

    /**
     * @param int|null $content_lang_id
     */
    public static function set_content_lang_id_default(int $content_lang_id = null){

        self::$content_lang_id = empty($content_lang_id) ? null : $content_lang_id;

    }

    /**
     * @param string|null $lang_name
     */
    public static function set_lang_name_default(string $lang_name = null){

        self::$lang_name = empty($lang_name) ? null : $lang_name;

    }

}