<?php

namespace Core\Module\Token;

use Core\Module\App\App;
use Core\Module\Browser\Browser;
use Core\Module\Browser\BrowserVersion;
use Common\Modules\Date;
use Core\Module\Db\Db;
use Core\Module\Device\DeviceToken;
use Core\Module\Encrypt\Hash;
use Common\Modules\Ip;
use Core\Module\Lang\Lang;
use Core\Module\Lang\LangKeyboard;
use Core\Module\Os\Os;
use Core\Module\Os\OsVersion;
use Core\Module\Timezone\Timezone;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;
use Core\Module\User\User;
use Core\Module\Useragent\Useragent;
use Configs\TokenConfig;

class Token {

    public static $token_id;
    public static $token_hash;
    public static $token_date_create;
    public static $token_date_update;
    public static $token_date_live;
    public static $token_date_remove;
    public static $token_date_recovery;
    private static $tn = '_token';

    public static function reset_data(){

        self::$token_id = null;
        self::$token_hash = null;
        self::$token_date_create = null;
        self::$token_date_update = null;
        self::$token_date_live = null;
        self::$token_date_remove = null;
        self::$token_date_recovery = null;
        return true;
    }

    public static function reset_token_default(){
        if(!empty(self::$token_id)) self::remove_token_id_default();
        self::add_token_default(false);
        return true;
    }

    public static function isset_token_id(int $token_id = null){
        if(empty($token_id)){
            $error = ['title' => 'Parameters problem', 'info' => 'Token ID is empty'];
            throw new ParametersException($error);
        }
        return Db::isset_row_id($token_id, '_tokne', 0);
    }

    public static function isset_token_from_token_hash(string $token_hash = null){
        if(empty($token_hash)){
            $error = ['title' => 'Token parameter problem', 'info' => 'Token hash is empty'];
            throw new ParametersException($error);
        }
        $where_list = ['hash' => $token_hash];
        return Db::isset_row('_token', 0, $where_list);
    }

    public static function isset_token_from_user_id(int $user_id = null){
        if(empty($user_id)){
            $error = ['title' => 'Parameters problem', 'info' => 'User ID is empty'];
            throw new ParametersException($error);
        }
        $where_list = ['user_id' => $user_id];
        return Db::isset_row('_token', 0, $where_list);
    }

    public static function get_token_date_live(bool $is_keep = true){
        $keep_delta = $is_keep ? (12*31*24*3600) : TokenConfig::$keep_delta;
        return Date::get_date_time_full(Date::get_timestamp()+$keep_delta);
    }

    public static function get_token_hash_default(){
        if(empty(self::$token_hash)){
            self::$token_hash = self::get_token_hash();
            return self::$token_hash;
        }
        return self::$token_hash;
    }

    public static function get_token_hash(){
        $hash_list = [];
        $timestamp_ms = Date::get_timestamp();
        $hash_list[] = Useragent::$useragent_hash;
        $hash_list[] = User::$user_id;
        $hash_list[] = Ip::$ip_id;
        $hash_list[] = Timezone::$timezone_id;
        $hash_list[] = Os::$os_id;
        $hash_list[] = Browser::$browser_id;
        $hash_list[] = BrowserVersion::$browser_version_id;
        $hash_list[] = App::$app_id;
        $hash_list[] = Lang::$lang_id;
        $hash_list[] = LangKeyboard::$lang_keyboard_id;
        $hash_list[] = $timestamp_ms;
        $hash_list[] = rand(0, $timestamp_ms);
        return Hash::get_sha1_encode(implode(' : ', $hash_list));
    }

    public static function get_array_from_data(array $data = []){
        if(!count($data)) return [];
        return array('token_id' => $data[0]['id'],
            'user_id' => $data[0]['user_id'],
            'ip_id' => $data[0]['ip_id'],
            'timezone_id' => $data[0]['timezone_id'],
            'useragent_id' => $data[0]['useragent_id'],
            'os_id' => $data[0]['os_id'],
            'os_version_id' => $data[0]['os_version_id'],
            'browser_id' => $data[0]['browser_id'], #'browser_version_id' => $data[0]['browser_version_id'],
            'device_token_id' => $data[0]['device_token_id'],
            'app_id' => $data[0]['app_id'],
            'lang_id' => $data[0]['lang_id'],
            'lang_keyboard_id' => $data[0]['lang_keyboard_id'],
            'is_keep' => (bool)$data[0]['is_keep']
        );
    }

    public static function get_token_data_from_token_id(int $token_id = null){
        if(empty($token_id)){
            $error = ['title' => 'Token parameter problem', 'info' => 'Token ID is empty'];
            throw new ParametersException($error);
        }
        $q = ['select' => ['id',
                'user_id',
                'ip_id',
                'timezone_id',
                'useragent_id',
                'os_id',
                'os_version_id',
                'browser_id',
                'browser_version_id',
                'device_token_id',
                'app_id',
                'app_version_id',
                'lang_id',
                'lang_keyboard_id',
                'is_keep'],
            'table' => self::$tn, 'where' => ['id' => $token_id, 'type' => 0], 'limit' => 1
        ];
        $r = Db::select($q);
        if(count($r) === 0) return [];
        return self::get_array_from_data($r);
    }

    public static function get_token_data_from_hash(string $hash = null){
        if(empty($hash)){
            $error = ['title' => 'Token parameter problem', 'info' => 'Token hash is empty'];
            throw new ParametersException($error);
        }
        # to remove - device_firm_id continent_id country_id region_id city_id 'device_firm_id',  'device_model_id',  'user_device_token_id',  'app_version_id',
        # 'browser_version_id',
        $q = ['table' => self::$tn,
              'select' => ['id',
                        'user_id',
                        'ip_id',
                        'timezone_id',
                        'useragent_id',
                        'os_id',
                        'os_version_id',
                        'browser_id',
                        'device_token_id',
                        'app_id',
                        'lang_id',
                        'lang_keyboard_id',
                        'is_keep'],
            'where' => [['column' => 'hash', 'value' => $hash],
                ['column' => 'date_live', 'method' => '>', 'value' => Date::get_date_time_full()],
                ['column' => 'type', 'value' => 0]],
            'limit' => 1
        ]; #pred($q);
        $r = Db::select($q);
        if(!count($r)) return [];
        return self::get_array_from_data($r);
    }

    public static function get_token_id_from_token_hash(string $token_hash = null){
        if(empty($token_hash)){
            $error = ['title' => 'Token parameter problem', 'info' => 'Token hash is empty'];
            throw new ParametersException($error);
        }
        $q = ['select' => ['column' => 'id'],
            'table' => self::$tn,
            'where' => ['hash' => $token_hash, 'type' => 0],
            'limit' => 1];
        $r = Db::select($q);
        return count($r) === 0 ? null : $r[0]['id'];
    }

    public static function get_token_id_from_user_id(int $user_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'User ID is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('id'),
            'table' => self::$tn,
            'where' => array('user_id' => $user_id,
                'type' => 0
            )
        );
        $r = Db::select($q);
        if(count($r) === 0) return [];
        $list = [];
        foreach($r as $row) $list[] = $row['id'];
        return $list;
    }

    public static function add_token(string $token_hash = null, bool $is_keep = true){
        if(empty($token_hash)){
            $error = array('title' => 'Token parameter problem',
                'info' => 'Default token hash is empty'
            );
            throw new ParametersException($error);
        }
        $token_date_live = self::get_token_date_live($is_keep);
        $q = array('table' => self::$tn,
            'values' => array(
                 array('user_id' => User::$user_id,
                    'ip_id' => Ip::$ip_id,
                    'timezone_id' => Timezone::$timezone_id,
                    'useragent_id' => Useragent::$useragent_id,
                    'os_id' => Os::$os_id,
                    'os_version_id' => OsVersion::$os_version_id,
                    'browser_id' => Browser::$browser_id,
                    #'browser_version_id' => BrowserVersion::$browser_version_id,
                    'device_token_id' => DeviceToken::$device_token_id,
                    'app_id' => App::$app_id,
                    'lang_id' => Lang::$lang_id,
                    'lang_keyboard_id' => LangKeyboard::$lang_keyboard_id,
                    'hash' => $token_hash,
                    'is_keep' => (int)$is_keep,
                    'date_create' => 'NOW()',
                    'date_update' => 'NOW()',
                    'date_live' => $token_date_live,
                    'type' => 0
                )
            )
        );
        $conflict_list = [
            'column_list' => [
                'hash'
            ],
            'update_list' => [
                'set' => [
                    'date_update' => 'NOW()',
                    'date_recovery' => 'NOW()',
                    'type' => 0
                ]
            ],
            'return_list' => [
                'id'
            ]
        ];
        $r = Db::insert($q, true, [], null, $conflict_list);
        if(count($r) === 0){
            $error = array('title' => 'Token DB problem',
                'info' => 'New token was not added',
                'data' => array('query' => $q
                )
            );
            throw new DbQueryException($error);
        }
        return $r[0]['id'];
    }

    public static function add_token_default(bool $is_old_hash = true){
        if($is_old_hash && !empty(self::$token_hash)) $token_hash = self::$token_hash; else $token_hash = self::get_token_hash_default();
        $token_id = self::add_token($token_hash, TokenConfig::$is_keep);
        if(empty($token_id)){
            $error = ['title' => 'Token DB problem', 'info' => 'New token was not added'];
            throw new DbQueryException($error);
        }
        $token_date_live = self::get_token_date_live(TokenConfig::$is_keep);
        self::set_token_id_default($token_id);
        self::set_token_date_create_default(Date::get_timestamp());
        self::set_token_date_live_default($token_date_live);
        return true;
    }

    public static function update_token_date_live_from_token_id(int $token_id = null, string $token_date_live = null){
        if(empty($token_id)){
            $error = ['title' => 'Token parameter problem', 'info' => 'Token ID is empty'];
            throw new ParametersException($error);
        }
        if(empty($token_date_live)) $token_date_live = self::get_token_date_live();
        $q = array('table' => self::$tn,
            'set' => array(
                 array('column' => 'date_update',
                    'value' => 'now()'
                ),
                 array('column' => 'date_live',
                    'value' => $token_date_live
                )
            ),
            'where' => array(
                 array('column' => 'id',
                    'value' => $token_id
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'limit' => 1
        );
        if(!Db::update($q)){
            $error = array('title' => 'Token remove problem',
                'info' => 'Token date live fail',
                'data' => array('token_id' => self::$token_id
                )
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function update_token_date_update_from_token_id(int $token_id = null){
        if(empty($token_id)){
            $error = array('title' => 'Token parameter problem',
                'info' => 'Token ID is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('table' => self::$tn,
            'set' => array(
                 array('column' => 'date_update',
                    'value' => 'now()'
                )
            ),
            'where' => array(
                 array('column' => 'id',
                    'value' => $token_id
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'limit' => 1
        );
        if(!Db::update($q)){
            $error = array('title' => 'Token remove problem',
                'info' => 'Default token date update fail',
                'data' => array('token_id' => self::$token_id
                )
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function update_token_date_live_default(){
        if(empty(self::$token_id)){
            $error = array('title' => 'Token parameter problem',
                'info' => 'Default token ID is empty'
            );
            throw new ParametersException($error);
        }
        $token_date_live = self::get_token_date_live(TokenConfig::$is_keep);
        if(!self::update_token_date_live_from_token_id(self::$token_id, $token_date_live)){
            $error = array('title' => 'Token remove problem',
                'info' => 'Default token date live fail',
                'data' => array('token_id' => self::$token_id,
                    'date_live' => $token_date_live
                )
            );
            throw new DbQueryException($error);
        }
        self::set_token_date_live_default($token_date_live);
        return true;
    }

    public static function update_token_date_update_default(){
        if(empty(self::$token_id)){
            $error = array('title' => 'Token parameter problem',
                'info' => 'Default token ID is empty'
            );
            throw new ParametersException($error);
        }
        if(!self::update_token_date_update_from_token_id(self::$token_id)){
            $error = array('title' => 'Token remove problem',
                'info' => 'Default token date update fail',
                'data' => array('token_id' => self::$token_id
                )
            );
            throw new DbQueryException($error);
        }
        self::$token_date_update = Date::get_timestamp();
        return true;
    }

    public static function update_token_useragent_id(){
        if(empty(self::$token_id)){
            $error = array('title' => 'Token parameter problem',
                'info' => 'Default token ID is empty'
            );
            throw new ParametersException($error);
        }
        return true;
    }

    public static function update_token_user_id(int $token_id = null, int $user_id = null){
        $error_info_list = [];
        if(empty($token_id)) $error_info_list[] = 'Token ID is empty';
        if(empty($user_id)) $error_info_list[] = 'User ID is empty';
        if(count($error_info_list) > 0){
            $error = ['title' => 'Token parameter problem', 'info' => $error_info_list, 'data' => ['token_id' => $token_id, 'user_id' => $user_id]];
            throw new ParametersException($error);
        }
        $q = ['table' => self::$tn, 'set' => ['user_id' => $user_id, 'date_update' => 'NOW()'], 'where' => ['id' => $token_id, 'type' => 0]];
        if(!Db::update($q)){
            $error = ['title' => 'Token DB problem',
                'info' => 'Token was not recovery',
                'data' => ['token_id' => $token_id,  'user_id' => $user_id, 'query' => $q]
            ];
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function update_token_orange_id(int $token_id = null, int $orange_id = null){
        $error_info_list = [];
        if(empty($token_id)) $error_info_list[] = 'Token ID is empty';
        if(empty($orange_id)) $error_info_list[] = 'User ID is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Token parameter problem',
                'info' => $error_info_list,
                'data' => array('token_id' => $token_id,
                    'orange_id' => $orange_id
                )
            );
            throw new ParametersException($error);
        }
        $q = array('table' => self::$tn,
            'set' => array('user_id' => User::$user_id,
                'orange_id' => $orange_id,
                'date_update' => 'NOW()'),
            'where' => array('id' => $token_id,
                'type' => 0
            )
        );
        if(!Db::update($q)){
            $error = array('title' => 'Token DB problem',
                'info' => 'Token was not recovery',
                'data' => array('token_id' => $token_id,
                    'orange_id' => $orange_id,
                    'query' => $q
                )
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function update_token_user_device_id(int $token_id = null, int $user_device_id = null){
        $error_info_list = [];
        if(empty($token_id)) $error_info_list[] = 'Token ID is empty';
        if(empty($user_device_id)) $error_info_list[] = 'User device ID is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Token parameter problem',
                'info' => $error_info_list
            );
            throw new ParametersException($error);
        }
        $q = array('table' => self::$tn,
            'set' => array('user_device_token_id' => $user_device_id,
                'date_update' => 'NOW()'),
            'where' => array('id' => $token_id,
                'type' => 0
            )
        );
        if(!Db::update($q)){
            $error = ['title' => 'Token DB problem', 'info' => 'Token was not recovery'];
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function update_token_user_id_default(){
        if(empty(User::$user_id)){
            $error = ['title' => 'Token parameter problem', 'info' => 'User ID is empty'];
            throw new ParametersException($error);
        }
        return self::update_token_user_id(self::$token_id, User::$user_id);
    }

    public static function update_token_device_data(int $token_id = null, int $os_id = null, int $os_version_id = null, int $device_firm_id = null, int $device_model_id = null, int $device_token_id = null, int $user_device_token_id = null, int $app_id = null, int $app_version_id = null){
        if(empty($token_id)){
            $error = ['title' => 'Token parameter problem', 'info' => 'Token ID is empty'];
            throw new ParametersException($error);
        }
        $q = array('table' => self::$tn,
            'set' => array('os_id' => $os_id,
                'os_version_id' => $os_version_id,
                'device_firm_id' => $device_firm_id,
                'device_model_id' => $device_model_id,
                'device_token_id' => $device_token_id,
                'user_device_token_id' => $user_device_token_id,
                'app_id' => $app_id,
                'app_version_id' => $app_version_id,
                'date_update' => 'NOW()'),
            'where' => array('id' => $token_id,
                'type' => 0
            )
        );
        $r = Db::update($q);
        if(count($r) === 0){
            $error = array('title' => 'DB query problem',
                'info' => 'Token was not updated'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_token_from_token_hash(string $token_hash = null){
        if(empty($token_hash)){ $error = ['title' => 'Token parameter problem', 'info' => 'Token hash is empty']; throw new ParametersException($error); }
        if(Db::pseudo_delete_from_where_list('_token', 1, ['hash' => $token_hash])) return true;
        $error = ['title' => 'Token DB problem', 'info' => 'Token was not removed', 'data' => ['hash' => $token_hash]];
        throw new DbQueryException($error);

    }

    public static function remove_token_from_token_id(int $token_id = null){
        if(empty($token_id)){
            $error = ['title' => 'Token parameter problem', 'info' => 'Token ID is empty'];
            throw new ParametersException($error);
        }
        if(!Db::pseudo_delete_from_id($token_id, '_token', 0)){
            $error = ['title' => 'Token DB problem', 'info' => 'Token was not remove'];
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_all_tokens_by_user_id(int $user_id = null, int $token_id = null){
        if(empty($user_id)){
            $error = array('title' => 'Token parameter problem',
                'info' => 'User ID is empty'
            );
            throw new ParametersException($error);
        }
        $where_list = ['user_id' => User::$user_id];
        if(!empty($token_id)) $where_list['id'] = [
                'method' => '!=',
                'value' => $token_id,
            ];
        if(!Db::pseudo_delete_from_where_list('_token', 0, $where_list)){
            $error = array('title' => 'Token DB problem',
                'info' => 'Token was not remove'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_token_id_default(){
        if(empty(self::$token_id)){
            $error = array('title' => 'Token parameter problem',
                'info' => 'Default token ID is empty'
            );
            throw new ParametersException($error);
        }
        if(!self::remove_token_from_token_id(self::$token_id)){
            $error = ['title' => 'Token remove problem', 'info' => 'Default token ID was not removed'];
            throw new DbQueryException($error);
        }
        self::reset_data();
        return true;
    }

    public static function remove_token_default_from_token_hash(){
        if(empty(self::$token_hash)){
            $error = ['title' => 'Token parameter problem', 'info' => 'Default token hash is empty'];
            throw new ParametersException($error);
        }
        if(!self::remove_token_from_token_hash(self::$token_hash)){
            $error = array('title' => 'Token remove problem', 'info' => 'Default token date update fail', 'data' => array('token_id' => self::$token_id, 'token_hash' => self::$token_hash));
            throw new DbQueryException($error);
        }
        self::reset_data();
        return true;
    }

    public static function recovery_token_from_token_id(int $token_id = null){
        if(empty($token_id)){
            $error = array('title' => 'Token parameter problem',
                'info' => 'Token ID is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('table' => self::$tn,
            'set' => array(
                 array('column' => 'date_update',
                    'value' => 'now()'
                ),
                 array('column' => 'date_recovery',
                    'value' => 'now()'
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'where' => array(
                 array('column' => 'id',
                    'value' => $token_id
                ),
                 array('column' => 'type',
                    'value' => 1
                )
            ),
            'limit' => 1
        );
        if(!Db::update($q)){
            $error = array('title' => 'Token DB problem',
                'info' => 'Token was not recovery',
                'data' => array('tokek_id' => $token_id
                )
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function recovery_token_from_token_hash(string $token_hash = null){
        if(empty($token_hash)){
            $error = array('title' => 'Token parameter problem',
                'info' => 'Token hash is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('table' => self::$tn,
            'set' => array(
                 array('column' => 'date_update',
                    'value' => 'now()'
                ),
                 array('column' => 'date_recovery',
                    'value' => 'now()'
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'where' => array(
                 array('column' => 'hash',
                    'value' => $token_hash
                ),
                 array('column' => 'type',
                    'value' => 1
                )
            ),
            'limit' => 1
        );
        if(!Db::update($q)){
            $error = array('title' => 'Token DB problem',
                'info' => 'Token was not recovery',
                'data' => array('hash' => $token_hash
                )
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function set_token_id_default(int $token_id = null){
        self::$token_id = empty($token_id) ? null : $token_id;
        return true;
    }
     public static function set_token_hash_default(string $token_hash = null){
        self::$token_hash = empty($token_hash) ? null : $token_hash;
        return true;
    }

    public static function set_token_date_create_default(string $token_date_create = null){
        self::$token_date_create = empty($token_date_create) ? null : $token_date_create;
        return true;
    }

    public static function set_token_date_update_default(string $token_date_update = null){
        self::$token_date_update = empty($token_date_update) ? null : $token_date_update;
        return true;
    }

    public static function set_token_date_live_default(string $token_date_live = null){
        self::$token_date_live = empty($token_date_live) ? null : $token_date_live;
        return true;
    }

    public static function set_token_date_remove_default(string $token_date_remove = null){
        self::$token_date_remove = empty($token_date_remove) ? null : $token_date_remove;
        return true;
    }

    public static function set_token_date_recovery_default(string $token_date_recovery = null){
        self::$token_date_recovery = empty($token_date_recovery) ? null : $token_date_recovery;
        return true;
    }
}