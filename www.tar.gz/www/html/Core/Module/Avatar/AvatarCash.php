<?php

namespace Core\Module\Avatar;

use Core\Module\Exception\ParametersException;

class AvatarCash{

    /** @var array */
    public static $avatar_list = [];

    /**
     * @param int|null $avatar_id
     * @param string|null $param
     * @return bool
     */
    public static function isset_avatar_parameter_in_cash(int $avatar_id = null, string $param = null){

        $error_info_list = [];

        if(empty($avatar_id)) $error_info_list[] = 'Avatar ID is empty';

        if(empty($param)) $error_info_list[] = 'Parameter is empty';

        if(empty(self::$avatar_list[$avatar_id])) return false;

        return !empty(self::$avatar_list[$avatar_id][$param]);

    }

    /**
     * @param int|null $avatar_id
     * @param string|null $param
     * @return null
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_avatar_parameter_in_cash(int $avatar_id = null, string $param = null){

        $error_info_list = [];

        if(empty($avatar_id)) $error_info_list[] = 'Avatar ID is empty';

        if(empty($param)) $error_info_list[] = 'Parameter is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('avatar_id' => $avatar_id,
                    'param' => $param
                )
            );

            throw new ParametersException($error);

        }

        if(empty(self::$avatar_list[$avatar_id])) return null;

        return empty(self::$avatar_list[$avatar_id][$param]) ? null : self::$avatar_list[$avatar_id][$param];

    }

    /**
     * @param int|null $avatar_id
     * @param string|null $param
     * @param null $value
     * @param bool $is_rewrite
     * @return bool
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function add_avatar_parameter_in_cash(int $avatar_id = null, string $param = null, $value = null, bool $is_rewrite=true){

        $error_info_list = [];

        if(empty($avatar_id)) $error_info_list[] = 'Avatar ID is empty';

        if(empty($param)) $error_info_list[] = 'Parameters is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('avatar_id' => $avatar_id,
                    'param' => $param,
                    'value' => $value,
                    'is_rewrite' => $is_rewrite
                )
            );

            throw new ParametersException($error);

        }

        if(empty(self::$avatar_list[$avatar_id]))
            self::$avatar_list[$avatar_id] = [];

        if($is_rewrite)
            self::$avatar_list[$avatar_id][$param] = $value;

        return true;

    }

}