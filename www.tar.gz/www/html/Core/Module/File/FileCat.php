<?php

namespace Core\Module\File;

use Common\Modules\Date;
use Core\Module\Db\Db;
use Core\Modules\Dir;
use Configs\DirConfig;
use Core\Module\Encrypt\HashFile;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;
use Core\Module\Exception\PathException;
use Core\Module\Exception\PhpException;
use Core\Module\Exception\ShellExecException;
use Core\Module\Os\Os;
use Core\Module\OsServer\OsServer;
use Core\Module\User\User;

class FileCat{

    /** @var int */
    private static $file_id;

    /** @var string */
    private static $date_create;

    /** @var int */
    private static $chunk_len;

    /** @var string */
    private static $file_content_type;

    /** @var string */
    private static $file_extension;

    /** @var int */
    private static $file_size;

    /** @var string */
    private static $dir;

    /** @var string */
    private static $file_path;

    /** @var string */
    private static $file_mime_type;

    /** @var string */
    private static $dir_chunk;

    /** @var string */
    private static $file_hash;

    /**
     * @return bool
     */
    public static function reset_data(){

        self::$file_id = null;
        self::$date_create = null;
        self::$chunk_len = null;
        self::$file_content_type = null;
        self::$file_extension = null;
        self::$file_size = null;
        self::$dir = null;
        self::$file_path = null;
        self::$file_mime_type = null;
        self::$dir_chunk = null;
        self::$file_hash = null;

        return true;

    }

    /**
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws PhpException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function isset_file_id(){

        if(empty(self::$file_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'File ID is empty'
            );

            throw new ParametersException($error);

        }

        $select_list = array('user_id',
            'chunk_len',
            'file_size',
            'file_content_type',
            'file_extension',
            'uploaded',
            'prepared',
            'date_create'
        );

        $file_data=Db::get_data_from_id(self::$file_id,'_file',$select_list,0);

        $error_info_list = [];

        if(empty($file_data)) $error_info_list[] = 'File ID is not exists';

        if($file_data['user_id']!=User::$user_id)
            $error_info_list[] = 'You don\'t have access for this file';

        if(empty($file_data['uploaded'])) $error_info_list[] = 'File don\'t have full upload';

        if(!empty($file_data['prepared'])) $error_info_list[] = 'File already prepared';

        if(empty($file_data['chunk_len'])) $error_info_list[] = 'File chunk length is zero';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('file_id' => self::$file_id,
                    'user_id' => User::$user_id,
                    'file_data' => $file_data
                )
            );

            throw new ParametersException($error);

        }

        self::$chunk_len = $file_data['chunk_len'];
        self::$file_size = $file_data['file_size'];
        self::$file_extension = mb_strtolower($file_data['file_extension'],'utf-8');
        self::$file_content_type = $file_data['file_content_type'];
        self::$date_create = $file_data['date_create'];

        return true;

    }

    /**
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function update_file_preparing(){

        $q = array('table' => '_file',
            'set' => array('preparing' => 1,
                'date_create' => 'NOW()'),
            'where' => array('id' => self::$file_id,
                'type' => 0
            )
        );

        if(!Db::update($q)){

            $error = array('title' => 'DB query problem',
                'info' => 'File prepared was not updated'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function update_file_prepared(){

        $q = array('table' => '_file',
            'set' => array(
                 array('column' => 'hash',
                    'value' => self::$file_hash
                ),
                 array('column' => 'file_mime_type',
                    'value' => self::$file_mime_type
                ),
                 array('column' => 'preparing',
                    'value' => 0
                ),
                 array('column' => 'prepared',
                    'value' => 1
                ),
                 array('column' => 'date_create',
                    'value' => 'NOW()'
                )
            ),
            'where' => array('id' => self::$file_id,
                'type' => 0
            )
        );

        if(!Db::update($q)){

            $error = array('title' => 'DB query problem',
                'info' => 'File prepared was not updated'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * Set file hash
     */
    private static function set_file_hash(){

        self::$file_hash=HashFile::get_sha1_encode(self::$file_path);

    }

    /**
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws PathException
     * @throws PhpException
     * @throws ShellExecException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function cat_file_chunk(){

        $file_list = [];
        $DR =Dir::get_root_dir();

        for($index=1;$index<=self::$chunk_len;$index++){

            $file_path = $DR.'/'.self::$dir_chunk.'/'.$index.'.tmp';

            if(!file_exists($file_path)){

                $error = array('title' => 'System problem',
                    'info' => 'File chunk is not exists'
                );

                throw new PhpException($error);

            }

            $file_list[] = $file_path;

        }

        $error_info_list = [];

        if(count($file_list) === 0)
            $error_info_list[] = 'File chunk list is empty';

        if(count($file_list)!=self::$chunk_len)
            $error_info_list[] = 'File chunk length is not correct';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Path problem',
                'info' => $error_info_list,
                'data' => array('file_id' => self::$file_id,
                    'user_id' => User::$user_id,
                    'dir' => self::$dir,
                    'dir_chunk' => self::$dir_chunk
                )
            );

            throw new PathException($error);

        }

        if(OsServer::$is_windows){

            $file_list =str_replace('/','\\',$file_list);
            $file_path =str_replace('/','\\',$DR.'/'.self::$file_path);

            $q='copy /b "'.implode('"+"',$file_list).'" "'.$file_path.'"';

        }
        else
            $q='cat '.implode(' ',$file_list).' > '.$DR.'/'.self::$file_path;

        shell_exec($q);

        if(!file_exists(self::$file_path)){

            $error = array('title' => 'Shell exec problem',
                'info' => $error_info_list,
                'data' => array('file_id' => self::$file_id,
                    'user_id' => User::$user_id,
                    'dir' => self::$dir,
                    'dir_chunk' => self::$dir_chunk,
                    'file_path' => self::$file_path,
                    'query' => $q
                )
            );

            throw new ShellExecException($error);

        }

        return true;

    }

    /**
     * @throws DbQueryException
     * @throws ParametersException
     * @throws PathException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function valid_file_size(){

        $file_size=filesize(self::$file_path);

        if(self::$file_size != $file_size){

            $error = array('title' => 'Path problem',
                'info' => 'Result file size on drive is not correct',
                'data' => array('file_id' => self::$file_id,
                    'user_id' => User::$user_id,
                    'dir' => self::$dir,
                    'dir_chunk' => self::$dir_chunk,
                    'file_path' => self::$file_path,
                    'file_size_result' => $file_size,
                    'file_size' => self::$file_size
                )
            );

            throw new PathException($error);

        }

    }

    /**
     * @throws DbQueryException
     * @throws ParametersException
     * @throws PathException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function set_file_mime_type(){

        self::$file_mime_type=FileType::get_file_mime_type(self::$file_path);

        if(!isset(FileConfig::$file_mime_type_list[self::$file_mime_type])){

            $error = array('title' => 'File problem',
                'info' => 'File mime type have not access',
                'data' => array('file_id' => self::$file_id,
                    'date_create' => self::$date_create,
                    'user_id' => User::$user_id,
                    'dir' => self::$dir,
                    'file_path' => self::$file_path,
                    'file_mime_type' => self::$file_mime_type
                )
            );

            throw new PathException($error);

        }

        if(array_search(self::$file_extension,FileConfig::$file_mime_type_list[self::$file_mime_type]) === false){

            $error = array('title' => 'File problem',
                'info' => 'File type not exists in file config',
                'data' => array('file_id' => self::$file_id,
                    'date_create' => self::$date_create,
                    'user_id' => User::$user_id,
                    'dir' => self::$dir,
                    'file_path' => self::$file_path,
                    'file_mime_type' => self::$file_mime_type,
                    'file_extension' => self::$file_extension
                )
            );

            throw new PathException($error);

        }

    }

    /**
     * @throws DbQueryException
     * @throws ParametersException
     * @throws PathException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function set_dir(){

        $date_path =Date::get_date_path(self::$date_create,DirConfig::$dir_upload);
        self::$dir = $date_path.'/'.self::$file_id;

        if(!file_exists(self::$dir)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Dir is not exists',
                'data' => array('file_id' => self::$file_id,
                    'date_create' => self::$date_create,
                    'user_id' => User::$user_id,
                    'dir' => self::$dir
                )
            );

            throw new PathException($error);

        }

    }

    /**
     * @throws DbQueryException
     * @throws ParametersException
     * @throws PathException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function set_dir_chunk(){

        self::$dir_chunk=self::$dir.'/chunk';

        if(!file_exists(self::$dir_chunk)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Dir for chunk is not exists',
                'data' => array('file_id' => self::$file_id,
                    'date_create' => self::$date_create,
                    'user_id' => User::$user_id,
                    'dir' => self::$dir,
                    'dir_chunk' => self::$dir_chunk
                )
            );

            throw new PathException($error);

        }

        $file_len=scandir(self::$dir_chunk);

        if(count($file_len)==2){

            $error = array('title' => 'Parameters problem',
                'info' => 'Dir for chunk is empty',
                'data' => array('file_id' => self::$file_id,
                    'date_create' => self::$date_create,
                    'user_id' => User::$user_id,
                    'dir' => self::$dir,
                    'dir_chunk' => self::$dir_chunk
                )
            );

            throw new PathException($error);

        }

    }

    /**
     * @throws DbQueryException
     * @throws ParametersException
     * @throws PathException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function set_file_path(){

        self::$file_path=self::$dir.'/'.self::$file_id.'.'.self::$file_extension;

        if(file_exists(self::$file_path)){

            $error = array('title' => 'Parameters problem',
                'info' => 'File already exists on the disk',
                'data' => array('file_id' => self::$file_id,
                    'date_create' => self::$date_create,
                    'user_id' => User::$user_id,
                    'dir' => self::$dir,
                    'file_path' => self::$file_path
                )
            );

            throw new PathException($error);

        }

    }

    /**
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws PathException
     * @throws PhpException
     * @throws ShellExecException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function set(){

        if(self::isset_file_id()){

            self::update_file_preparing();

            self::set_dir();
            self::set_dir_chunk();
            self::set_file_path();

            self::cat_file_chunk();

            self::valid_file_size();

            self::set_file_mime_type();
            self::set_file_hash();

            self::update_file_prepared();

            return true;

        }

        return false;

    }

    /**
     * @param int|null $file_id
     * @return array|null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws PathException
     * @throws PhpException
     * @throws ShellExecException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function init(int $file_id = null){

        self::$file_id = (int)$file_id;

        if(self::set()) return array('file_id' => self::$file_id,
                'file_size' => self::$file_size
            );

        return null;

    }

}