<?php

namespace Core\Module\File;

use Common\Modules\Date;
use Core\Module\Db\Db;
use Core\Modules\Dir;
use Configs\DirConfig;
use Core\Module\Exception\DbParametersException;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\FileException;
use Core\Module\Exception\ParametersException;
use Core\Module\Exception\PathException;

use Core\Module\User\User;

class File {

    public static $tn = '_file';

    public static function isset_file_id(int $file_id = null){
        if(empty($file_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'File ID is empty'
            );
            throw new ParametersException($error);
        }
        return Db::isset_row_id($file_id,'_file');
    }

    public static function isset_file(int $file_id = null){
        if(empty($file_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'File ID is empty'
            );
            throw new ParametersException($error);
        }
        return Db::isset_row_id($file_id,'_file');
    }

    private static function isset_file_chunk_index(int $file_id = null,int $chunk_index = null){
        $error_info_list = [];
        if(empty($file_id)) $error_info_list[] = 'File ID is empty';
        if(is_null($chunk_index)) $error_info_list[] = 'Chunk index is null';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('file_id' => $file_id,
                    'chunk_index' => $chunk_index
                )
            );
            throw new ParametersException($error);
        }
        $where_list = array(
             array('column' => 'file_id',
                'value' => $file_id
            ),
             array('column' => 'index',
                'value' => $chunk_index
            )
        );
        return Db::isset_row('_file_item',0,$where_list);
    }

    private static function isset_file_chunk_id(int $file_chunk_id = null){
        if(empty($file_chunk_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'File chunk ID is empty'
            );
            throw new ParametersException($error);
        }
        return Db::isset_row_id($file_chunk_id,'_file_item',0);
    }

    public static function isset_file_link(string $file_path = null){
        $r = @get_headers($file_path);
        if(!isset($r[0])) return false;
        foreach($r as $row){
            switch($row){
                case 'HTTP/1.0 404 Not Found':
                case 'HTTP/1.0 302 Found':
                    return false;
                case 'Content-Type: text/html':
                    return false;
            }
        }
        return true;
    }

    public static function isset_file_hash(string $hash = null){
        if(empty($hash)){
            $error = array('title' => 'Parameters problem',
                'info' => 'File hash is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('id'),
            'table' => '_file',
            'where' => array(
                 array('column' => 'file_id',
                    'value' => null
                ),
                 array('column' => 'hash',
                    'value' => $hash
                ),
                 array('column' => 'prepared',
                    'value' => 1
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'limit' => 1
        );
        $r = Db::select($q);
        return count($r) > 0;
    }

    public static function get_file_dir(int $file_id = null,string $file_extension = null,string $date_create = null){
        $error_info_list = [];
        if(empty($file_id)) $error_info_list[] = 'file ID is empty';
//        if(empty($file_extension))
//            $error_info_list[] = 'File type is empty';
        if(empty($date_create)) $error_info_list[] = 'Date create is empty';
        if(FileParametersCash::isset_file_parameter_in_cash($file_id,'file_dir')) return FileParametersCash::get_file_parameter_in_cash($file_id,'file_dir');
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('file_id' => $file_id,
                    'file_extension' => $file_extension,
                    'date_create' => $date_create
                )
            );
            throw new ParametersException($error);
        }
        $date_path = Date::get_date_path($date_create,DirConfig::$dir_upload);
        $file_path = $date_path.'/'.$file_id;
        if(cli) $file_path = DR.'/'.$file_path;
        if(!file_exists($file_path))
            Dir::create_dir($file_path);
        FileParametersCash::add_file_parameter_in_cash($file_id,$file_path);
        return $file_path;
    }

    public static function get_file_dir_list(array $file_id_list = []){
        if(count($file_id_list) == 0){
            $error = array('title' => 'Parameters problem',
                'info' => 'File ID list is empty'
            );
            throw new ParametersException($error);
        }

        $q = array('select' => array('id',
                'file_extension',
                'date_create'),
            'table' => '_file',
            'where' => array('id' => $file_id_list,
                'type' => 0
            )
        );
        $r = Db::select($q);

        if(count($r) == 0) return [];

        $list = [];

        foreach($r as $row){
            $file_file_path = self::get_file_dir($row['id'],$row['file_extension'],$row['date_create']);
            if(!file_exists($file_file_path)){
                $error = array('title' => 'File path problem',
                    'info' => 'File dir is not exists'
                );
                throw new PathException($error);
            }
            $list[$row['id']] = $file_file_path;
            FileParametersCash::add_file_parameter_in_cash($row['id'],'file_dir',$file_file_path);

        }
        return $list;
    }

    public static function get_file_id_from_hash(string $hash = null){
        if(empty($hash)){
            $error = array('title' => 'Parameters problem',
                'info' => 'File hash is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('id'),
            'table' => '_file',
            'where' => array(
                 array('column' => 'file_id',
                    'value' => null
                ),
                 array('column' => 'hash',
                    'value' => $hash
                ),
                 array('column' => 'prepared',
                    'value' => 1
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'limit' => 1
        );
        $r = Db::select($q);
        if(count($r) == 0) return null;
        return empty($r[0]['id']) ? null : $r[0]['id'];
    }

    public static function get_file_data(int $file_id = null,bool $is_uploaded = true,bool $is_prepared = true){
        if(empty($file_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'File ID is empty'
            );
            throw new ParametersException($error);
        }
        $column_list = array('user_id',
            'hash',
            'chunk_uploaded',
            'chunk_len',
            'chunk_size',
            'file_size',
            'file_mime_type',
            'file_content_type',
            'file_extension',
            'uploaded',
            'date_create'
        );
        $where_list = array('uploaded' => (int)$is_uploaded,
            'prepared' => (int)$is_prepared
        );
        if(!empty($file_id)) $where_list['id'] = $file_id;
        $data = Db::get_data_from_id($file_id,'_file',$column_list,0,$where_list);
        if(empty($data)) return null;
        return $data;
    }

    public static function get_file_path(int $file_id = null,string $file_extension = null,string $date_create = null){
        $error_info_list = [];
        if(empty($file_id)) $error_info_list[] = 'File ID is empty';
        if(empty($file_extension)) $error_info_list[] = 'File type is empty';
        if(empty($date_create)) $error_info_list[] = 'Date create is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('file_id' => $file_id,
                    'file_extension' => $file_extension,
                    'date_create' => $date_create
                )
            );
            throw new ParametersException($error);
        }
        $date_path = Date::get_date_path($date_create,DirConfig::$dir_upload);
        return $date_path.'/'.$file_id.'.'.$file_extension;
    }

    public static function get_file_duration(int $file_id = null){
        if(empty($file_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'File ID is empty'
            );
            throw new ParametersException($error);
        }
        $r = Db::get_data_from_id($file_id,'_file',array('duration'),0);
        if(count($r) == 0) return null;
        $duration = empty($r[0]['duration']) ? null : $r[0]['duration'];
        FileParametersCash::add_file_parameter_in_cash($file_id,'duration',$duration);
        return $duration;
    }

    public static function get_file_size(int $file_id = null){
        if(empty($file_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'File ID is empty'
            );
            throw new ParametersException($error);
        }
        $r = Db::get_data_from_id($file_id,'_file',array('file_size'),0);
        if(count($r) == 0) return null;
        $file_size = empty($r[0]['file_size']) ? null : $r[0]['file_size'];
        FileParametersCash::add_file_parameter_in_cash($file_id,'file_size',$file_size);
        return $file_size;
    }

    public static function get_file_mime_type_from_path(string $file_path = null){
        if(empty($file_path)){
            $error = [
                'title' => ParametersException::$title,
                'info' => 'File path is empty'
            ];
            throw new ParametersException($error);
        }
        if(!file_exists($file_path)){
            $error = [
                'title' => FileException::$title,
                'info' => 'File is not exists'
            ];
            throw new FileException($error);
        }
        return FileType::get_file_mime_type($file_path);
    }

    public static function get_file_content_type_from_path(string $file_path = null){
        if(empty($file_path)){
            $error = [
                'title' => ParametersException::$title,
                'info' => 'File path is empty'
            ];
            throw new ParametersException($error);
        }
        if(!file_exists($file_path)){
            $error = [
                'title' => FileException::$title,
                'info' => 'File is not exists'
            ];
            throw new FileException($error);
        }
        $file_mime_type = self::get_file_mime_type_from_path($file_path);
        if(empty($file_mime_type)){
            $error = [
                'title' => FileException::$title,
                'info' => 'File mime type is empty'
            ];
            throw new FileException($error);
        }
        $list = mb_split('/',$file_mime_type);
        if(count($list)<2){
            $error = [
                'title' => ParametersException::$title,
                'info' => 'File mime type is not valid'
            ];
            throw new ParametersException($error);
        }
        return $list[0];
    }

    public static function get_file_extension_from_file_path(string $file_path = null){
        if(empty($file_path)){
            $error = ['title' => ParametersException::$title, 'info' => 'File name is empty'];
            throw new ParametersException($error);
        }
        $file_path = Dir::get_global_dir($file_path);
        if(!file_exists($file_path)) return null;
//        if(!file_exists($file_path)){
//
//            $error = [
//                'title' => FileException::$title,
//                'info' => 'File is not exists'
//            ];
//
//            throw new FileException($error);
//
//        }
        return pathinfo($file_path,PATHINFO_EXTENSION);
    }

    public static function get_file_extension_from_file_name(string $file_name = null){
        if(empty($file_name)){
            $error = ['title' => ParametersException::$title, 'info' => 'File name is empty'];
            throw new ParametersException($error);
        }
        $list = mb_split('\.',$file_name);
        if(count($list) < 2) return null;
        return end($list);
    }

    public static function get_file_date_create(int $file_id = null){
        if(empty($file_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'File ID is empty'
            );
            throw new ParametersException($error);
        }
        if(FileParametersCash::isset_file_parameter_in_cash($file_id,'date_create')) return FileParametersCash::get_file_parameter_in_cash($file_id,'date_create');
        $r = Db::get_data_from_id($file_id,'_file',array('date_create'),0);
        if(count($r) == 0) return null;
        $date_create = empty($r[0]['date_create']) ? null : $r[0]['date_create'];
        FileParametersCash::add_file_parameter_in_cash($file_id,'date_create',$date_create);
        return $date_create;
    }

    public static function get_file_path_from_file_id(int $file_id = null,bool $need_path = false){
        if(empty($file_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'File ID is empty'
            );
            throw new ParametersException($error);
        }
        if(FileParametersCash::isset_file_parameter_in_cash($file_id,'file_path')) return FileParametersCash::get_file_parameter_in_cash($file_id,'file_path');
        $column_list = [];
        $file_extension = null;
        $date_create = null;
        if(FileParametersCash::isset_file_parameter_in_cash($file_id,'file_extension')) $file_extension = FileParametersCash::get_file_parameter_in_cash($file_id,'file_extension');
        else
            $column_list[] = 'file_extension';
        if(FileParametersCash::isset_file_parameter_in_cash($file_id,'date_create')) $date_create = FileParametersCash::get_file_parameter_in_cash($file_id,'date_create');
        else
            $column_list[] = 'date_create';
        if(count($column_list) > 0){
            $r = Db::get_data_from_id($file_id,'_file',$column_list,0);
            if(!empty($r['file_extension'])){
                $file_extension = $r['file_extension'];
                FileParametersCash::add_file_parameter_in_cash($file_id,'file_extension',$file_extension);
            }
            if(!empty($r['date_create'])){
                $date_create = $r['date_create'];
                FileParametersCash::add_file_parameter_in_cash($file_id,'date_create',$date_create);
            }
        }
        if(empty($date_create)
            &&empty($file_extension)
        ){
            $error = array('title' => 'DB query problem',
                'info' => 'System cannot get file date create',
                'data' => array('file_id' => $file_id,
                    'file_extension' => $file_extension,
                    'date_create' => $date_create
                )
            );
            throw new DbParametersException($error);
        }
        $file_dir = self::get_file_dir($file_id,$file_extension,$date_create);
        $file_path = $file_dir.'/'.$file_id;
//        if(cli)
//            $file_path = DR.'/'.$file_path;
        if(!empty($file_extension)) $file_path.= '.'.$file_extension;
        if(!$need_path)
            if(!file_exists($file_path)){
                $error = array('title' => 'File path problem',
                    'info' => 'File file is not exists',
                    'data' => array('file_id' => $file_id,
                        'file_path' => $file_path
                    )
                );
                throw new PathException($error);
            }
        FileParametersCash::add_file_parameter_in_cash($file_id,'file_path',$file_path);
        return $file_path;
    }

    public static function get_file_path_from_file_id_list(array $file_id_list = []){
        if(count($file_id_list) == 0){
            $error = array('title' => 'Parameters problem',
                'info' => 'File ID list is empty'
            );
            throw new ParametersException($error);
        }
        $file_extension = null;
        $file_path = null;
        $date_create = null;
        $file_list = [];
        $select_file_id_list = [];
        foreach($file_id_list as $file_id)
            if(!isset($file_list[$file_id])){
                if(FileParametersCash::isset_file_parameter_in_cash($file_id,'file_path'))
                    $file_list[$file_id] = FileParametersCash::get_file_parameter_in_cash($file_id,'file_path');
                else{
                    if(FileParametersCash::isset_file_parameter_in_cash($file_id,'file_extension'))
                        $file_extension = FileParametersCash::get_file_parameter_in_cash($file_id,'file_extension');
                    if(FileParametersCash::isset_file_parameter_in_cash($file_id,'date_create'))
                        $date_create = FileParametersCash::get_file_parameter_in_cash($file_id,'date_create');
                    if(empty($file_extension) || empty($date_create)
                    )
                        $select_file_id_list[] = $file_id;
                    else
                        $file_list[$file_id] = self::get_file_path($file_id,$file_extension,$date_create);
                }
            }
        if(count($select_file_id_list) > 0){
            $select_list = array('id',
                'file_extension',
                'date_create'
            );
            $r = Db::get_data_from_id_list($select_file_id_list,'_file',$select_list,0);
            foreach($r as $row){
                $file_id = $row['id'];
                $file_extension = $row['file_extension'];
                $date_create = $row['date_create'];
                $file_path = self::get_file_path($file_id,$file_extension,$date_create);
                if(cli)
                    $file_path = DR.'/'.$file_path;
                $file_list[$file_id] = $file_path;
                FileParametersCash::add_file_parameter_in_cash($file_id,'file_extension',$file_extension);
                FileParametersCash::add_file_parameter_in_cash($file_id,'date_create',$date_create);
                FileParametersCash::add_file_parameter_in_cash($file_id,'file_path',$file_path);
            }
        }
        return $file_list;
    }

    public static function add_file(string $file_hash = null,int $chunk_uploaded = null,int $chunk_len = null,int $chunk_size = null,int $file_size = null,string $file_mime_type = null,string $file_content_type = null,string $file_extension = null,bool $uploaded = false,bool $preparing = false,bool $prepared = false,string $source_link = null){
        $error_info_list = [];
        if(empty($file_hash)) $error_info_list[] = 'File hash is empty';
        if(is_null($chunk_uploaded)) $error_info_list[] = 'Chunk uploaded is not set';
        if(is_null($chunk_size)) $error_info_list[] = 'Chunk size is not set';
        if(empty($chunk_len)) $error_info_list[] = 'Chunk length is empty';
        if(empty($file_size)) $error_info_list[] = 'File size is empty';
        if(empty($file_mime_type)) $error_info_list[] = 'File mime type is empty';
        if(empty($file_content_type)) $error_info_list[] = 'File content type is empty';
        if(count($error_info_list) > 0){
            $error = [
                'title' => ParametersException::$title,
                'info' => $error_info_list
            ];
            throw new ParametersException($error);
        }
        $q = [
            'table' => '_file',
            'values' => [
                'user_id' => User::$user_id,
                'hash' => $file_hash,
                'chunk_uploaded' => $chunk_uploaded,
                'chunk_len' => $chunk_len,
                'chunk_size' => $chunk_size,
                'file_size' => $file_size,
                'file_mime_type' => $file_mime_type,
                'file_content_type' => $file_content_type,
                'file_extension' => $file_extension,
                'uploaded' => (int)$uploaded,
                'preparing' => (int)$preparing,
                'prepared' => (int)$prepared,
                'source_link' => empty($source_link) ? null : $source_link,
                'date_create' => 'NOW()',
                'date_update' => 'NOW()',
                'type' => 0
            ]
        ];
        $r = Db::insert($q,true,['date_create']);
        if(count($r) == 0){
            $error = [
                'title' => DbQueryException::$title,
                'info' => 'File was not add'
            ];
            throw new DbQueryException($error);
        }
        FileParametersCash::add_file_parameter_in_cash($r[0]['id'],'date_create',$r[0]['date_create']);
        return $r[0]['id'];
    }

    public static function update_file(int $file_id = null,string $file_hash = null,int $chunk_uploaded = null,int $chunk_len = null,int $chunk_size = null,int $file_size = null,string $file_mime_type = null,string $file_content_type = null,string $file_extension = null,bool $uploaded = false,bool $preparing = false,bool $prepared = false,string $source_link = null){
        $error_info_list = [];
        if(empty($file_id)) $error_info_list[] = 'File ID is empty';
        if(empty($file_hash)) $error_info_list[] = 'File hash is empty';
        if(is_null($chunk_uploaded)) $error_info_list[] = 'Chunk uploaded is not set';
        if(is_null($chunk_size)) $error_info_list[] = 'Chunk size is not set';
        if(empty($chunk_len)) $error_info_list[] = 'Chunk length is empty';
        if(empty($file_size)) $error_info_list[] = 'File size is empty';
        if(empty($file_mime_type)) $error_info_list[] = 'File mime type is empty';
        if(empty($file_content_type)) $error_info_list[] = 'File content type is empty';
        if(count($error_info_list) > 0){
            $error = [
                'title' => ParametersException::$title,
                'info' => $error_info_list
            ];
            throw new ParametersException($error);
        }
        $q = [
            'table' => '_file',
            'set' => [
                'hash' => $file_hash,
                'chunk_uploaded' => $chunk_uploaded,
                'chunk_len' => $chunk_len,
                'chunk_size' => $chunk_size,
                'file_size' => $file_size,
                'file_mime_type' => $file_mime_type,
                'file_content_type' => $file_content_type,
                'file_extension' => $file_extension,
                'uploaded' => (int)$uploaded,
                'preparing' => (int)$preparing,
                'prepared' => (int)$prepared,
                'date_update' => 'NOW()',
                'type' => 0
            ],
            'where' => [
                'id' => $file_id,
                'type' => 0
            ]
        ];
        if(!empty($source_link)) $q['set']['source_link'] = $source_link;
        if(!Db::update($q)){
            $error = [
                'title' => DbQueryException::$title,
                'info' => 'File was not add'
            ];
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function update_file_extension(int $file_id = null,string $file_extension = null){
        $error_info_list = [];
        if(empty($file_id)) $error_info_list[] = 'File ID is empty';
        if(empty($file_extension)) $error_info_list[] = 'File extension is empty';
        if(count($error_info_list) > 0){
            $error = [
                'title' => ParametersException::$title,
                'info' => $error_info_list
            ];
            throw new ParametersException($error);
        }
        $q = [
            'table' => '_file',
            'set' => [
                'file_extension' => $file_extension,
                'date_update' => 'NOW()',
                'type' => 0
            ],
            'where' => [
                'id' => $file_id,
                'type' => 0
            ]
        ];
        if(!Db::update($q)){
            $error = [
                'title' => DbQueryException::$title,
                'info' => 'File was not add'
            ];
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function add_file_without_params(string $file_extension = null,bool $uploaded = false,bool $preparing = false,bool $prepared = false,string $source_link = null){
        $q = [
            'table' => '_file',
            'values' => [
                'user_id' => User::$user_id,
                'file_extension' => $file_extension,
                'uploaded' => (int)$uploaded,
                'preparing' => (int)$preparing,
                'prepared' => (int)$prepared,
                'date_create' => 'NOW()',
                'date_update' => 'NOW()',
                'type' => 0
            ]
        ];
        if(!empty($source_link)) $q['values']['source_link'] = $source_link;
        $r = Db::insert($q,true,['date_create']);
        if(count($r) == 0){
            $error = [
                'title' => DbQueryException::$title,
                'info' => 'File was not add'
            ];
            throw new DbQueryException($error);
        }
        FileParametersCash::add_file_parameter_in_cash($r[0]['id'],'date_create',$r[0]['date_create']);
        return $r[0]['id'];
    }

    public static function remove_file_id(int $file_id = null){
        if(empty($file_id)){
            $error = [
                'title' => ParametersException::$title,
                'info' => 'File ID is empty'
            ];
            throw new ParametersException($error);
        }
        $where_list = [
            'id' => $file_id
        ];
        if(!Db::pseudo_delete_from_where_list(self::$tn,0,$where_list)){
            $error = [
                'title' => DbQueryException::$title,
                'info' => 'File was not remove'
            ];
            throw new DbQueryException($error);
        }
        return true;
    }
}