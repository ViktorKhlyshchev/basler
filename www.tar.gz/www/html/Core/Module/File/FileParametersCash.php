<?php

namespace Core\Module\File;

use Core\Module\Exception\ParametersException;

class FileParametersCash{

    /** @var array */
    public static $file_list = [];

    /**
     * @param int|null $file_id
     * @return bool
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_file_id_in_cash(int $file_id = null){

        if(empty($file_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'File ID is empty'
            );

            throw new ParametersException($error);

        }

        return isset(self::$file_list[$file_id]);

    }

    /**
     * @param int|null $file_id
     * @param string|null $param
     * @return bool
     */
    public static function isset_file_parameter_in_cash(int $file_id = null, string $param = null){

        $error_info_list = [];

        if(empty($file_id)) $error_info_list[] = 'File ID is empty';

        if(empty($param)) $error_info_list[] = 'Parameter is empty';

        if(empty(self::$file_list[$file_id])) return false;

        return !empty(self::$file_list[$file_id][$param]);

    }

    /**
     * @param int|null $file_id
     * @param string|null $param
     * @return null
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_file_parameter_in_cash(int $file_id = null, string $param = null){

        $error_info_list = [];

        if(empty($file_id)) $error_info_list[] = 'Image ID is empty';

        if(empty($param)) $error_info_list[] = 'Parameter is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('file_id' => $file_id,
                    'param' => $param
                )
            );

            throw new ParametersException($error);

        }

        if(empty(self::$file_list[$file_id])) return null;

        return empty(self::$file_list[$file_id][$param]) ? null : self::$file_list[$file_id][$param];

    }

    /**
     * @param int|null $file_id
     * @param string|null $param
     * @param null $value
     * @param bool $is_rewrite
     * @return bool
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function add_file_parameter_in_cash(int $file_id = null, string $param = null, $value = null, bool $is_rewrite=true){

        $error_info_list = [];

        if(empty($file_id)) $error_info_list[] = 'File ID is empty';

        if(empty($param)) $error_info_list[] = 'Parameters is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('file_id' => $file_id,
                    'param' => $param,
                    'value' => $value,
                    'is_rewrite' => $is_rewrite
                )
            );

            throw new ParametersException($error);

        }

        if(empty(self::$file_list[$file_id]))
            self::$file_list[$file_id] = [];

        if($is_rewrite)
            self::$file_list[$file_id][$param] = $value;

        return true;

    }

    /**
     * @param int|null $file_id
     * @return bool
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_file_from_cash(int $file_id = null){

        if(empty($file_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'File ID is empty'
            );

            throw new ParametersException($error);

        }

        if(self::isset_file_id_in_cash($file_id))
            unset($file_id);

        return true;

    }

    /**
     * @param int|null $file_id
     * @param string|null $param
     * @return bool
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_file_parameter_from_cash(int $file_id = null, string $param = null){

        $error_info_list = [];

        if(empty($file_id)) $error_info_list[] = 'File ID is empty';

        if(empty($param)) $error_info_list[] = 'Parameter is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('file_id' => $file_id,
                    'param' => $param,
                )
            );

            throw new ParametersException($error);

        }

        if(self::isset_file_id_in_cash($file_id))
            if(self::isset_file_parameter_in_cash($file_id,$param))
                unset(self::$file_list[$file_id]);

        return true;

    }

    /**
     * @param int|null $file_id
     * @param array $param_list
     * @return bool
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_file_parameters_list_form_cash(int $file_id = null, array $param_list = []){

        $error_info_list = [];

        if(empty($file_id)) $error_info_list[] = 'File ID is empty';

        if(count($param_list) === 0)
            $error_info_list[] = 'Parameters list is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('file_id' => $file_id,
                    'param_list' => $param_list,
                )
            );

            throw new ParametersException($error);

        }

        if(self::isset_file_id_in_cash($file_id))
            foreach($param_list as $param)
                if(self::remove_file_parameter_from_cash($file_id,$param))
                    return true;

        return true;

    }

}