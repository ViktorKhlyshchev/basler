<?php

namespace Core\Module\Video;

use Common\Modules\Date;
use Core\Module\Db\Db;
use Core\Modules\Dir;
use Configs\DirConfig;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;
use Core\Module\Exception\PathException;
use Core\Module\User\User;

class Video {

    public static $tn='_video';

    public static function isset_video_id(int $video_id = null){
        if(empty($video_id)){
            $error = array('title' => 'Parameters problem', 'info' => 'Video ID is empty');
            throw new ParametersException($error);
        }
        return Db::isset_row_id($video_id,'_video',0);
    }

    public static function isset_video_id_list(array $videos_ids = []){
        if(count($videos_ids)){
            $error = array('title' => 'Parameters problem',                'info' => 'Video ID list is empty'            );
            throw new ParametersException($error);
        }
        return Db::isset_row_id_list($videos_ids,'_video');
    }

    public static function get_video_id_from_video_list(array $video_list = []){
        if(count($video_list) === 0) return [];
        $list = [];
        foreach($video_list as $row) if(!empty($row['video_id'])) $list[] = $row['video_id'];
        return $list;
    }

    public static function get_videos_ids(array $videos_ids = []){
        if(count($videos_ids) === 0){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video ID list is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('id'),
            'table' => '_video',
            'where' => array('id' => $videos_ids,
                'type' => 0
            )
        );
        $r = Db::select($q);
        if(count($r) === 0) return [];
        $list = [];
        foreach($r as $row)
            $list[] = $row['id'];
        return $list;
    }

    public static function get_video_file_path(int $video_id = null, string $file_extension = null, string $date_create = null, string $prefix = null){
        $error_info_list = [];
        if(empty($video_id)) $error_info_list[] = 'Video ID is empty';
        if(empty($file_extension)) $error_info_list[] = 'File type is empty';
        if(empty($date_create)) $error_info_list[] = 'Date create is empty';
        if(VideoCash::isset_video_parameter_in_cash($video_id,'file_path')) return VideoCash::get_video_parameter_in_cash($video_id,'file_path');
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('video_id' => $video_id,
                    'file_extension' => $file_extension,
                    'date_create' => $date_create
                )
            );
            throw new ParametersException($error);
        }
        $date_path =Date::get_date_path($date_create,DirConfig::$dir_video);
        $file_path = $date_path.'/'.$video_id.'/'.$video_id.(empty($prefix)?'':('_'.$prefix)).'.'.$file_extension;
        VideoCash::add_video_parameter_in_cash($video_id,$file_path);
        return $file_path;
    }

    public static function get_video_dir(int $video_id = null, string $file_extension = null, string $date_create = null){
        $error_info_list = [];
        if(empty($video_id)) $error_info_list[] = 'Video ID is empty';
        if(empty($file_extension)) $error_info_list[] = 'File type is empty';
        if(empty($date_create)) $error_info_list[] = 'Date create is empty';
        if(VideoCash::isset_video_parameter_in_cash($video_id,'video_dir')) return VideoCash::get_video_parameter_in_cash($video_id,'video_dir');
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('video_id' => $video_id,
                    'file_extension' => $file_extension,
                    'date_create' => $date_create
                )
            );
            throw new ParametersException($error);
        }
        $date_path =Date::get_date_path($date_create,DirConfig::$dir_video);
        $file_path = $date_path.'/'.$video_id;
        VideoCash::add_video_parameter_in_cash($video_id,$file_path);
        return $file_path;
    }

    public static function get_video_size(int $video_id = null){
        if(empty($video_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video ID is empty'
            );
            throw new ParametersException($error);
        }
        if(VideoCash::isset_video_parameter_in_cash($video_id,'file_size')) return VideoCash::get_video_parameter_in_cash($video_id,'file_size');
        $r = Db::get_data_from_id($video_id,'_video',array('file_size'),0);
        if(count($r) === 0) return null;
        $file_size = empty($r[0]['file_size']) ? null : $r[0]['file_size'];
        VideoCash::add_video_parameter_in_cash($video_id,'file_size',$file_size);
        return $file_size;
    }

    public static function get_video_date_create(int $video_id = null){
        if(empty($video_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video ID is empty'
            );
            throw new ParametersException($error);
        }
        $r = Db::get_data_from_id($video_id,'_video',array('date_create'),0);
        if(count($r) === 0) return null;
        $date_create = empty($r[0]['date_create']) ? null : $r[0]['date_create'];
        VideoCash::add_video_parameter_in_cash($video_id,'date_create',$date_create);
        return $date_create;
    }

    public static function get_video_duration(int $video_id = null){
        if(empty($video_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video ID is empty'
            );
            throw new ParametersException($error);
        }
        $q = [
            'table' => self::$tn,
            'select' => [
                'duration'
            ],
            'where' => [
                'id' => $video_id,
                'type' => 0
            ],
            'limit' => 1
        ];
        $r = Db::select($q);
        if(count($r) === 0) return null;
        return $r[0]['duration'];
    }

    public static function get_video_file_path_from_video_id(int $video_id = null, string $prefix = null){
        if(empty($video_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video ID is empty'
            );
            throw new ParametersException($error);
        }
        if(VideoCash::isset_video_parameter_in_cash($video_id,'file_path')) return VideoCash::get_video_parameter_in_cash($video_id,'file_path');
        $column_list = [];
        $file_extension = null;
        $date_create = null;
        if(VideoCash::isset_video_parameter_in_cash($video_id,'file_extension')) $file_extension=VideoCash::get_video_parameter_in_cash($video_id,'file_extension');
        else
            $column_list[] = 'file_extension';
        if(VideoCash::isset_video_parameter_in_cash($video_id,'date_create')) $date_create=VideoCash::get_video_parameter_in_cash($video_id,'date_create');
        else
            $column_list[] = 'date_create';
        if(count($column_list) > 0){
            $r = Db::get_data_from_id($video_id,'_video',$column_list,0);
            if(!empty($r['file_extension'])){
                $file_extension = $r['file_extension'];
                VideoCash::add_video_parameter_in_cash($video_id,'file_extension',$file_extension);
            }
            if(!empty($r['date_create'])){
                $date_create = $r['date_create'];
                VideoCash::add_video_parameter_in_cash($video_id,'date_create',$date_create);
            }
        }
        if(empty($date_create) || empty($file_extension)
        )
            return null;
        else{
            $video_file_path=self::get_video_file_path($video_id,$file_extension,$date_create,$prefix);
            if(!file_exists($video_file_path)){
                $error = array('title' => 'File path problem',
                    'info' => 'video file is not exists',
                    'data' => array('video_id' => $video_id,
                        'file_path' => $video_file_path
                    )
                );
                throw new PathException($error);
            }
            VideoCash::add_video_parameter_in_cash($video_id,'file_path',$video_file_path);
            return $video_file_path;
        }
    }

    public static function get_video_dir_from_video_id(int $video_id = null){
        if(empty($video_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video ID is empty'
            );
            throw new ParametersException($error);
        }
        if(VideoCash::isset_video_parameter_in_cash($video_id,'video_dir')) return VideoCash::get_video_parameter_in_cash($video_id,'video_dir');
        $column_list = [];
        $file_extension = null;
        $date_create = null;
        if(VideoCash::isset_video_parameter_in_cash($video_id,'file_extension')) $file_extension=VideoCash::get_video_parameter_in_cash($video_id,'file_extension');
        else
            $column_list[] = 'file_extension';
        if(VideoCash::isset_video_parameter_in_cash($video_id,'date_create')) $date_create=VideoCash::get_video_parameter_in_cash($video_id,'date_create');
        else
            $column_list[] = 'date_create';
        if(count($column_list) > 0){
            $r = Db::get_data_from_id($video_id,'_video',$column_list,0);
            if(!empty($r['file_extension'])){
                $file_extension = $r['file_extension'];
                VideoCash::add_video_parameter_in_cash($video_id,'file_extension',$file_extension);
            }
            if(!empty($r['date_create'])){
                $date_create = $r['date_create'];
                VideoCash::add_video_parameter_in_cash($video_id,'date_create',$date_create);
            }
        }
        if(empty($date_create) || empty($file_extension)
        )
            return null;
        else{
            $video_file_path =self::get_video_dir($video_id,$file_extension,$date_create);
            $video_file_path =Dir::get_global_dir($video_file_path);
            if(!file_exists($video_file_path)){
                $error = array('title' => 'File path problem',
                    'info' => 'Video dir is not exists',
                    'data' => array('video_id' => $video_id,
                        'file_path' => $video_file_path
                    )
                );
                throw new PathException($error);
            }
            VideoCash::add_video_parameter_in_cash($video_id,'video_dir',$video_file_path);
            return $video_file_path;
        }
    }

    public static function get_video_dir_list(array $videos_ids = []){
        if(count($videos_ids) === 0){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video ID list is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('id',
                'file_extension',
                'date_create'),
            'table' => '_video',
            'where' => array('id' => $videos_ids,
                'type' => 0
            )
        );
        $r = Db::select($q);
        if(count($r) === 0) return [];
        $list = [];
        foreach($r as $row){
            $video_file_path=self::get_video_dir($row['id'],$row['file_extension'],$row['date_create']);
//            if(file_exists($video_file_path)){
            $list[$row['id']] = $video_file_path;
            VideoCash::add_video_parameter_in_cash($row['id'],'video_dir',$video_file_path);
//            }
        }
        return $list;
    }

    public static function get_video_file_path_from_video_id_list(array $videos_ids = []){
        if(count($videos_ids) === 0){
            $error = array('title' => 'Parameters problem',
                'info' => 'video ID list is empty'
            );
            throw new ParametersException($error);
        }
        $file_extension = null;
        $file_path = null;
        $date_create = null;
        $video_list = [];
        $select_video_id_list = [];
        foreach($videos_ids as $video_id)
            if(!isset($video_list[$video_id])){
                if(VideoCash::isset_video_parameter_in_cash($video_id,'file_path'))
                    $video_list[$video_id] = VideoCash::get_video_parameter_in_cash($video_id,'file_path');
                else{
                    if(VideoCash::isset_video_parameter_in_cash($video_id,'file_extension'))
                        $file_extension=VideoCash::get_video_parameter_in_cash($video_id,'file_extension');
                    if(VideoCash::isset_video_parameter_in_cash($video_id,'date_create'))
                        $date_create=VideoCash::get_video_parameter_in_cash($video_id,'date_create');
                    if(empty($file_extension) || empty($date_create)
                    )
                        $select_video_id_list[] = $video_id;
                    else
                        $video_list[$video_id] = self::get_video_file_path($video_id,$file_extension,$date_create);
                }
            }
        if(count($select_video_id_list) > 0){
            $select_list = array('id',
                'file_extension',
                'date_create'
            );
            $r = Db::get_data_from_id_list($select_video_id_list,'_video',$select_list,0);
            foreach($r as $row){
                $video_id = $row['id'];
                $file_extension = $row['file_extension'];
                $date_create = $row['date_create'];
                $file_path =self::get_video_file_path($video_id,$file_extension,$date_create);
                $video_list[$video_id] = $file_path;
                VideoCash::add_video_parameter_in_cash($video_id,'file_extension',$file_extension);
                VideoCash::add_video_parameter_in_cash($video_id,'date_create',$date_create);
                VideoCash::add_video_parameter_in_cash($video_id,'file_path',$file_path);
            }
        }
        return $video_list;
    }

    public static function update_video_date_update(array $videos_ids = []){
        if(count($videos_ids) === 0){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video ID list is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('table' => '_video',
            'set' => array('date_update' => 'NOW()'),
            'where' => array('id' => $videos_ids,
                'type' => 0
            )
        );
        if(!Db::update($q)){
            $error = array('title' => 'DB query problem',
                'info' => 'Video list date update was not update',
                'data' => array('video_id_list' => $videos_ids,
                    'query' => $q
                )
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function update_video_id_date_update(int $video_id = null){
        if(empty($video_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video ID is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('table' => '_video',
            'set' => array('date_update' => 'NOW()'),
            'where' => array('id' => $video_id,
                'type' => 0
            )
        );
        if(!Db::update($q)){
            $error = array('title' => 'DB query problem',
                'info' => 'Video list date update was not update',
                'data' => array('video_id' => $video_id,
                    'query' => $q
                )
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function update_video_prepared(int $video_id = null, string $hash = null, int $width = null, int $height = null, int $file_size = null, string $file_mime_type = null, string $file_extension = null, string $source_link = null){
        if(empty($video_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'video_id si empty'
            );
            throw new ParametersException($error);
        }
        $q = array('table' => '_video',
            'set' => array('hash' => $hash,
                'width' => $width,
                'height' => $height,
                'file_size' => $file_size,
                'file_mime_type' => $file_mime_type,
                'file_extension' => $file_extension,
                'preparing' => 0,
                'prepared' => 1,
                'public' => 1,
                'hide' => 0,
                'date_update' => 'NOW()', 'type' => 0),
            'where' => array('id' => $video_id,
                'type' => 0
            )
        );
        if(!empty($source_link)) $q['set']['source_link'] = $source_link;
        if(!Db::update($q)){
            $error = array('title' => 'Parameters problem',
                'info' => 'video ID is empty'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function add_video(int $file_id = null, string $video_type = null, int $file_size = null, string $file_mime_type = null, string $file_extension = null, bool $preparing=false,bool $prepared=false,bool $public=false,bool $hide=false,bool $need_return_date_create=false,string $source_link = null, int $width = null, int $height = null, int $duration = null){
        $error_info_list = [];
//        if(empty($file_id))
//            $error_info_list[] = 'File ID is empty';
        if(empty($video_type)) $error_info_list[] = 'Video type is empty';;
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );
            throw new ParametersException($error);
        }
        $q = array('table' => '_video',
            'values' => array('user_id' => User::$user_id,
                'file_id' => $file_id,
                'video_type' => $video_type,
                'file_size' => $file_size,
                'file_mime_type' => $file_mime_type,
                'file_extension' => $file_extension,
                'duration' => $duration,
                'source_link' => empty($source_link) ? null : $source_link,
                'preparing' => (int)$preparing,
                'prepared' => (int)$prepared,
                'public' => (int)$public,
                'hide' => (int)$hide,
                'date_create' => 'NOW()',
                'date_update' => 'NOW()',
                'type' => 0
            )
        );
        if(!empty($width)) $q['values']['width'] = $width;
        if(!empty($height)) $q['values']['height'] = $height;
        $return_list = [];
        if($need_return_date_create)
            $return_list[] = 'date_create';
        $r = Db::insert($q,true,$return_list);
        if(count($r) === 0){
            $error = array('title' => 'DB query problem',
                'info' => 'video was not added'
            );
            throw new DbQueryException($error);
        }
        if(count($return_list) === 0) return $r[0]['id'];
        else
            return array('id' => $r[0]['id'],
                'date_create' => $r[0]['date_create']
            );
    }

    public static function add_video_full(int $file_id = null, int $video_id = null, string $hash = null, int $width = null, int $height = null, string $video_type = null, int $file_size = null, string $file_mime_type = null, string $file_extension = null, bool $preparing=false,bool $prepared=false,bool $public=false,bool $hide=false,bool $need_return_date_create=false,string $source_link = null){
        $error_info_list = [];
        if(empty($file_id)) $error_info_list[] = 'File ID is empty';
        if(empty($video_type)) $error_info_list[] = 'Video type is empty';;
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );
            throw new ParametersException($error);
        }
        $q = array('table' => '_video',
            'values' => array('user_id' => User::$user_id,
                'file_id' => $file_id,
                'video_id' => $video_id,
                'hash' => $hash,
                'width' => $width,
                'height' => $height,
                'video_type' => $video_type,
                'file_size' => $file_size,
                'file_mime_type' => $file_mime_type,
                'file_extension' => $file_extension,
                'source_link' => empty($source_link) ? null : $source_link,
                'preparing' => (int)$preparing,
                'prepared' => (int)$prepared,
                'public' => (int)$public,
                'hide' => (int)$hide,
                'date_create' => 'NOW()',
                'date_update' => 'NOW()',
                'type' => 0
            )
        );
        $return_list = [];
        if($need_return_date_create)
            $return_list[] = 'date_create';
        $r = Db::insert($q,true,$return_list);
        if(count($r) === 0){
            $error = array('title' => 'DB query problem',
                'info' => 'video was not added'
            );
            throw new DbQueryException($error);
        }
        if(count($return_list) === 0) return $r[0]['id'];
        else
            return array('id' => $r[0]['id'],
                'date_create' => $r[0]['date_create']
            );
    }

    public static function add_video_preparing(int $file_id = null, string $video_type = null, bool $need_return_date_create=false,string $source_link = null){
        $error_info_list = [];
//        if(empty($file_id))
//            $error_info_list[] = 'File ID is empty';
        if(empty($video_type)) $error_info_list[] = 'Video type is empty';;
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );
            throw new ParametersException($error);
        }
        return self::add_video($file_id,$video_type,null,null,null,true,false,false,true,$need_return_date_create,$source_link);
    }

    public static function remove_video_id(int $video_id = null, bool $is_need_remove_video_item=true){
        if(empty($video_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video ID is empty'
            );
            throw new ParametersException($error);
        }
        if($is_need_remove_video_item)
            VideoItem::remove_video_item($video_id);
        if(!Db::pseudo_delete_from_id($video_id,'_video',0)){
            $error = array('title' => 'Db query problem',
                'info' => 'Video ID was not removed'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_video_id_list(array $videos_ids = [],bool $is_need_remove_video_item=true){
        if(!count($videos_ids)){ $error = array('title' => 'Parameters problem', 'info' => 'Video ID list is empty'); throw new ParametersException($error); }
        $id_list = [];
        foreach($videos_ids as $video_id) if(!empty($video_id)) $id_list[] = $video_id;
        if(!count($id_list)){ $error = array('title' => 'Parameters problem', 'info' => 'Video ID list is empty'); throw new ParametersException($error); }
        if($is_need_remove_video_item) VideoItem::pseudo_remove_video_item_list($id_list);
        if(!Db::pseudo_delete_from_id_list($id_list,'_video',0)){ $error = array('title' => 'Db query problem', 'info' => 'Video ID was not removed'); throw new DbQueryException($error); }
        return true;
    }

    public static function delete_video_id_list(array $videos_ids = [], bool $is_need_remove_video_item = true){
        if(!count($videos_ids)){ $error = ['title' => 'Parameters problem', 'info' => 'Video ID list is empty']; throw new ParametersException($error); }
        $q = ['table' => self::$tn, 'where' => ['id' => $videos_ids]];
        if(!Db::delete($q)){ $error = ['title' => 'Db query problem', 'info' => 'Video ID was not removed']; throw new DbQueryException($error); }
        if($is_need_remove_video_item) VideoItem::delete_video_item_list($videos_ids);
        return true;
    }

    public static function delete_videos(array $videos_ids = []){
        if(!count($videos_ids)){ $error = ['title' => 'Parameters problem', 'info' => 'Video ID list is empty']; throw new ParametersException($error); }
        $q = ['table' => self::$tn, 'where' => ['id' => $videos_ids]];
        if(!Db::delete($q)){ $error = ['title' => 'Db query problem', 'info' => 'Video ID was not removed']; throw new DbQueryException($error); }
        return true;
    }

    public static function delete_bid($id = null){
        if(!$id) return;
        $q = ['table' => self::$tn, 'where' => ['id' => (int)$id]];
        return Db::delete($q);
    }

    public static function delete_bids(array $ids = []){
        if(!$ids) return null;
        $q = ['table' => self::$tn, 'where' => ['id' => $ids]]; #pre($q);
        return Db::delete($q);
    }
}