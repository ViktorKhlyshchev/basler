<?php

namespace Core\Module\Video;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;
use Core\Module\User\User;

class VideoItem {

    public static $tn='_video_item';

    public static function get_video_item_hash_link_list(array $video_id_list = [],string $resolution='small'){
        if(count($video_id_list) === 0) return [];
        $q = ['table' => self::$tn,
            'select' => [
                'id',
                'video_id',
                'video_type',
                'date_create',
                'hash_link'
            ],
            'where' => [
                'video_id' => $video_id_list,
                'resolution_type' => $resolution,
                'type' => 0
            ]
        ];
        $r = Db::select($q);
        if(count($r) === 0) return [];
        $list = [];
        foreach($r as $row)
            $list[$row['video_id']] = [
                'id' => $row['id'],
                'video_id' => $row['video_id'],
                'video_type' => $row['video_type'],
                'date_create' => $row['date_create'],
                'hash_link' => $row['hash_link']
            ];
        return $list;
    }

    public static function get_video_item_hash_link_resolution_list(array $video_id_list = [], array $resolution_list = []){
        if(count($video_id_list) === 0) return [];
        $q = ['table' => self::$tn,
            'select' => [
                'id',
                'video_id',
                'video_type',
                'resolution_type',
                'date_create',
                'hash_link',
                'width',
                'height',
                'file_size',
                'file_extension'
            ],
            'where' => [
                'video_id' => $video_id_list,
                'type' => 0
            ]
        ];
        if(count($resolution_list) > 0)
            $q['where']['resolution_type'] = $resolution_list;
        $r = Db::select($q);
        if(count($r) === 0) return [];
        $list = [];
        foreach($r as $row){
            if(!isset($list[$row['video_id']])) $list[$row['video_id']] = [];
            $list[$row['video_id']][$row['resolution_type']] = [
                'id' => $row['id'],
                'video_id' => $row['video_id'],
                'resolution_type' => $row['resolution_type'],
                'video_type' => $row['video_type'],
                'date_create' => $row['date_create'],
                'width' => $row['width'],
                'height' => $row['height'],
                'file_size' => $row['file_size'],
                'hash_link' => $row['hash_link'],
                'file_extension' => $row['file_extension']
            ];
        }
        return $list;
    }

    public static function get_video_item_data(int $video_item_id = null){
        if(empty($video_item_id)){
            $error = [
                'title' => ParametersException::$title,
                'info' => 'Video item ID is empty'
            ];
            throw new ParametersException($error);
        }
        $q = [
            'table' => self::$tn,
            'select' => [
                'file_id',
                'video_id',
                'video_type',
                'date_create'
            ],
            'where' => [
                'id' => $video_item_id,
                'type' => 0
            ],
            'limit' => 1
        ];
        $r = Db::select($q);
        if(count($r) === 0) return null;
        return [
            'file_id' => $r[0]['file_id'],
            'video_id' => $r[0]['video_id'],
            'video_type' => $r[0]['video_type'],
            'date_create' => $r[0]['date_create']
        ];
    }

    public static function get_video_item_hash_list(array $video_id_list = [],string $resolution_type = null){
        if(count($video_id_list) === 0) return [];
        $q = [
            'table' => self::$tn,
            'select' => [
                'video_id',
                'hash'
            ],
            'where' => [
                'video_id' => $video_id_list,
                'resolution_type' => $resolution_type,
                'type' => 0
            ]
        ];
        $r = Db::select($q);
        if(count($r) === 0) return [];
        $list = [];
        foreach($r as $row)
            $list[] = [
                'video_id' => $row['video_id'],
                'hash' => $row['hash']
            ];
        return $list;
    }

    public static function get_video_item_data_from_hash_link(string $hash_link = null){
        if(empty($hash_link)){
            $error = ['title' => ParametersException::$title, 'info' => 'Hash link is empty'];
            throw new ParametersException($error);
        }
        $q = [
            'table' => self::$tn,
            'select' => [
                'id',
                'user_id',
                'file_id',
                'video_id',
                'video_type',
                'resolution_type',
                'file_extension',
                'date_create'
            ],
            'where' => [
                'hash_link' => $hash_link,
                'type' => 0
            ],
            'limit' => 1
        ];
        $r = Db::select($q);
        if(count($r) === 0) return null;
        return [
            'id' => $r[0]['id'],
            'user_id' => $r[0]['user_id'],
            'file_id' => $r[0]['file_id'],
            'video_id' => $r[0]['video_id'],
            'file_extension' => $r[0]['file_extension'],
            'resolution_type' => $r[0]['resolution_type'],
            'date_create' => $r[0]['date_create']
        ];
    }

    public static function get_videos_ids_from_file_id_list(array $file_id_list = [], array $resolution_type_list = []){
        $error_info_list = [];
        if(count($file_id_list) === 0)
            $error_info_list[] = 'File ID list is empty';
        if(count($resolution_type_list) === 0)
            $error_info_list[] = 'Resolution type list is empty';
        if(count($error_info_list) > 0){
            $error = [
                'title' => ParametersException::$title,
                'info' => $error_info_list
            ];
            throw new ParametersException($error);
        }
        $q = [
            'table' => self::$tn,
            'select' => [
                'video_id'
            ],
            'where' => [
                'file_id' => $file_id_list,
                'resolution_type' => $resolution_type_list,
                'type' => 0
            ]
        ];
        $r = Db::select($q);
        if(count($r) === 0) return false;
        $list = [];
        foreach($r as $row)
            $list[] = $row['video_id'];
        return $list;
    }

    public static function get_videos_ids_from_video_id_list(array $video_id_list = [], array $resolution_type_list = []){
        $error_info_list = [];
        if(count($video_id_list) === 0)
            $error_info_list[] = 'File ID list is empty';
        if(count($resolution_type_list) === 0)
            $error_info_list[] = 'Resolution type list is empty';
        if(count($error_info_list) > 0){
            $error = [
                'title' => ParametersException::$title,
                'info' => $error_info_list
            ];
            throw new ParametersException($error);
        }
        $q = [
            'table' => self::$tn,
            'select' => [
                'video_id'
            ],
            'where' => [
                'video_id' => $video_id_list,
                'resolution_type' => $resolution_type_list,
                'type' => 0
            ]
        ];
        $r = Db::select($q);
        if(count($r) === 0) return false;
        $list = [];
        foreach($r as $row)
            $list[] = $row['video_id'];
        return $list;
    }

    public static function get_video_item_id_list(int $video_id = null, bool $is_assoc_resolution_type=false,bool $is_file_extension=false){
        if(empty($video_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video ID is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('id'),
            'table' => '_video_item',
            'where' => array('video_id' => $video_id,
                'type' => 0
            )
        );
        if($is_assoc_resolution_type)
            $q['select'][] = 'resolution_type';
        if($is_file_extension)
            $q['select'][] = 'file_extension';
        $r = Db::select($q);
        if(count($r) === 0) return [];
        $list = [];
        if($is_assoc_resolution_type)
            foreach($r as $row)
                $list[$row['resolution_type']] = $row['id'].($is_file_extension?('.'.$row['file_extension']):'');
        else
            foreach($r as $row)
                $list[] = $row['id'].($is_file_extension?('.'.$row['file_extension']):'');
        return $list;
    }

    public static function get_video_item_id_list_width_size(int $video_id = null, bool $is_assoc_resolution_type=false,bool $is_file_extension=false){
        if(empty($video_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video ID is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('id',
                'width',
                'height'),
            'table' => '_video_item',
            'where' => array('video_id' => $video_id,
                'type' => 0
            )
        );
        if($is_assoc_resolution_type)
            $q['select'][] = 'resolution_type';
        if($is_file_extension)
            $q['select'][] = 'file_extension';
        $r = Db::select($q);
        if(count($r) === 0) return [];
        $list = [];
        if($is_assoc_resolution_type)
            foreach($r as $row)
                $list[$row['resolution_type']] = [
                    'id' => $row['id'].($is_file_extension?('.'.$row['file_extension']):''),
                    'width' => $row['width'],
                    'height' => $row['height']
                ];
        else
            foreach($r as $row)
                $list[] = [
                    'id' => $row['id'].($is_file_extension?('.'.$row['file_extension']):''),
                    'width' => $row['width'],
                    'height' => $row['height']
                ];
        return $list;
    }

    public static function get_video_item_id_list_from_video_id_list(array $video_id_list = [],bool $is_assoc_resolution_type=false,bool $is_file_extension=false){
        if(count($video_id_list) === 0){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video ID is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('id',
                'video_id'),
            'table' => '_video_item',
            'where' => array('video_id' => $video_id_list,
                'type' => 0
            )
        );
        if($is_assoc_resolution_type)
            $q['select'][] = 'resolution_type';
        if($is_file_extension)
            $q['select'][] = 'file_extension';
        $r = Db::select($q);
        if(count($r) === 0) return [];
        $list = [];
        if($is_assoc_resolution_type)
            foreach($r as $row){
                if(!isset($list[$row['video_id']]))
                    $list[$row['video_id']] = [];
                $list[$row['video_id']][$row['resolution_type']] = $row['id'].($is_file_extension?('.'.$row['file_extension']):'');
            }
        else
            foreach($r as $row){
                if(!isset($list[$row['video_id']]))
                    $list[$row['video_id']] = [];
                $list[$row['video_id']][] = $row['id'].($is_file_extension?('.'.$row['file_extension']):'');
            }
        return $list;
    }

    public static function get_video_item_id_list_with_size_from_video_id_list(array $video_id_list = [],bool $is_assoc_resolution_type=false,bool $is_file_extension=false){
        if(count($video_id_list) === 0){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video ID is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('id',
                'video_id',
                'width',
                'height',
                'file_size'),
            'table' => '_video_item',
            'where' => array('video_id' => $video_id_list,
                'type' => 0
            )
        );
        if($is_assoc_resolution_type)
            $q['select'][] = 'resolution_type';
        if($is_file_extension)
            $q['select'][] = 'file_extension';
        $r = Db::select($q);
        if(count($r) === 0) return [];
        $list = [];
        if($is_assoc_resolution_type)
            foreach($r as $row){
                if(!isset($list[$row['video_id']]))
                    $list[$row['video_id']] = [];
                $list[$row['video_id']][$row['resolution_type']] = [
                    'id' => $row['id'].($is_file_extension?('.'.$row['file_extension']):''),
                    'width' => $row['width'],
                    'height' => $row['height'],
                    'file_size' => $row['file_size']
                ];
            }
        else
            foreach($r as $row){
                if(!isset($list[$row['video_id']]))
                    $list[$row['video_id']] = [];
                $list[$row['video_id']][] = [
                    'id' => $row['id'].($is_file_extension?('.'.$row['file_extension']):''),
                    'width' => $row['width'],
                    'height' => $row['height'],
                    'file_size' => $row['file_size']
                ];
            }
        return $list;
    }

    public static function get_video_item_list(array $video_id_list = [],bool $is_assoc=false){
        if(count($video_id_list) === 0){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video ID is empty'
            );
            throw new ParametersException($error);
        }
        $id_list = [];
        foreach($video_id_list as $video_id)
            $id_list[] = $video_id;
        if(count($id_list) === 0){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video ID is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('id',
                'video_id'),
            'table' => '_video_item',
            'where' => array('video_id' => $id_list,
                'type' => 0
            )
        );
        $r = Db::select($q);
        if(count($r) === 0) return [];
        $list = [];
        if($is_assoc)
            foreach($r as $row){
                if(!isset($list[$row['video_id']]))
                    $list[$row['video_id']] = [];
                $list[$row['video_id']][] = $row['id'];
            }
        else
            foreach($r as $row)
                $list[] = $row['id'];
        return $list;
    }

    public static function get_duplicate_video_id_list(array $video_hash_list = []){
        if(count($video_hash_list) === 0){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video ID list is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('video_id'),
            'table' => '_video_item',
            'where' => array('hash' => $video_hash_list,
                'type' => 0
            )
        );
        $r = Db::select($q);
        if(count($r) === 0) return [];
        $list = [];
        foreach($r as $row)
            $list[] = $row['video_id'];
        return $list;
    }

    public static function add_video_item(int $file_id = null, int $video_id = null, int $width = null, int $height = null, string $resolution_type = null, string $video_type = null, int $file_size = null, string $file_mime_type = null, string $file_extension = null, bool $preparing=false,bool $prepared=false,bool $public=false,bool $hide=false,int $duration = null){
        $error_info_list = [];
//        if(empty($file_id))
//            $error_info_list[] = 'File ID is empty';
        if(empty($video_id)) $error_info_list[] = 'video ID is empty';
        if(empty($resolution_type)) $error_info_list[] = 'Resolution type is empty';
        if(empty($video_type)) $error_info_list[] = 'Video type is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );
            throw new ParametersException($error);
        }
        $q = array('table' => '_video_item',
            'values' => array('user_id' => User::$user_id,
                'file_id' => $file_id,
                'video_id' => $video_id,
                'width' => $width,
                'height' => $height,
                'resolution_type' => $resolution_type,
                'video_type' => $video_type,
                'file_size' => $file_size,
                'file_mime_type' => $file_mime_type,
                'file_extension' => $file_extension,
                'duration' => $duration,
                'preparing' => (int)$preparing,
                'prepared' => (int)$prepared,
                'public' => (int)$public,
                'hide' => (int)$hide,
                'date_create' => 'NOW()',
                'date_update' => 'NOW()',
                'type' => 0
            )
        );
        $r = Db::insert($q,true);
        if(count($r) === 0){
            $error = array('title' => 'DB query problem',
                'info' => 'video item was not added'
            );
            throw new DbQueryException($error);
        }
        return $r[0]['id'];
    }

    public static function add_video_item_preparing(int $file_id = null, int $video_id = null, string $resolution_type = null, string $video_type = null){
        $error_info_list = [];
//        if(empty($file_id))
//            $error_info_list[] = 'File ID is empty';
        if(empty($video_id)) $error_info_list[] = 'video ID is empty';
        if(empty($resolution_type)) $error_info_list[] = 'Resolution type is empty';
        if(empty($video_type)) $error_info_list[] = 'Video type is empty';
        if(count($error_info_list) > 0){
            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );
            throw new ParametersException($error);
        }
        return self::add_video_item($file_id,$video_id,null,null,$resolution_type,$video_type,null,null,null,true,false,false,true);
    }

    public static function update_video_item_prepared(int $video_item_id = null, string $hash = null, string $hash_link = null, int $width = null, int $height = null, int $file_size = null, string $file_mime_type = null, string $file_extension = null){
        if(empty($video_item_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video ID is empty'
            );
            throw new ParametersException($error);
        }
        $q = array('table' => '_video_item',
            'set' => array('hash' => $hash,
                'hash_link' => $hash_link,
                'width' => $width,
                'height' => $height,
                'file_size' => $file_size,
                'file_mime_type' => $file_mime_type,
                'file_extension' => $file_extension,
                'preparing' => 0,
                'prepared' => 1,
                'public' => 1,
                'hide' => 0,
                'date_update' => 'NOW()', 'type' => 0),
            'where' => array('id' => $video_item_id,
                'type' => 0
            )
        );
        if(!Db::update($q)){
            $error = array('title' => 'Parameters problem',
                'info' => 'video ID is empty'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_video_item(int $video_id = null){
        if(empty($video_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video ID is empty'
            );
            throw new ParametersException($error);
        }
        $where_list = array('video_id' => $video_id
        );
        if(!Db::pseudo_delete_from_where_list('_video_item',0,$where_list)){
            $error = array('title' => 'DB query problem',
                'info' => 'Video item was not removed'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function remove_video_item_id_list(array $video_item_id_list = []){
        if(count($video_item_id_list) === 0){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video item ID list is empty'
            );
            throw new ParametersException($error);
        }
        $id_list = [];
        foreach($video_item_id_list as $video_item_id) if(!empty($video_item_id)) $id_list[] = $video_item_id;
        if(count($id_list) === 0){
            $error = array('title' => 'Parameters problem',
                'info' => 'Video ID list is empty'
            );
            throw new ParametersException($error);
        }
        if(!Db::pseudo_delete_from_id_list($id_list,'_video_item',0)){
            $error = array('title' => 'DB query problem',
                'info' => 'Video item was not removed'
            );
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function pseudo_remove_video_item_list(array $video_id_list = []){
        if(!count($video_id_list)){ $error = array('title' => 'Parameters problem', 'info' => 'Video ID list is empty'); throw new ParametersException($error); }
        $id_list = [];
        foreach($video_id_list as $video_id) if(!empty($video_id)) $id_list[] = $video_id;
        if(!count($id_list)){ $error = array('title' => 'Parameters problem', 'info' => 'Video ID list is empty'); throw new ParametersException($error); }
        $where_list = array('video_id' => $id_list);
        if(!Db::pseudo_delete_from_where_list('_video_item', 0, $where_list)){
            $error = array('title' => 'DB query problem', 'info' => 'Video item was not removed');
            throw new DbQueryException($error);
        }
        return true;
    }

    public static function delete_video_item_list(array $video_id_list = []){
        if(!count($video_id_list)){ $error = array('title' => 'Parameters problem', 'info' => 'Video ID list is empty'); throw new ParametersException($error); }
        $q = ['table' => self::$tn, 'where' => ['video_id' => $video_id_list]];
        if(!Db::delete($q)){ $error = array('title' => 'DB query problem', 'info' => 'Video item was not removed' ); throw new DbQueryException($error); }
        return true;
    }

    public static function delete_bid($id = null){
        if(!$id) return;
        $q = ['table' => self::$tn, 'where' => ['id' => (int)$id]];
        return Db::delete($q);
    }

    public static function delete_bids(array $ids = []){
        if(!$ids) return null;
        $q = ['table' => self::$tn, 'where' => ['id' => $ids]]; #pre($q);
        return Db::delete($q);
    }

    public static function remove_video_item_id(int $video_item_id = null){
        if(empty($video_item_id)){ $error = array('title' => 'Parameters problem', 'info' => 'Video item ID is empty'); throw new ParametersException($error); }
        if(!Db::pseudo_delete_from_id($video_item_id,'_video_item', 0)){ $error = array('title' => 'DB query problem', 'info' => 'Video item was not removed'); throw new DbQueryException($error); }
        return true;
    }
}