<?php

namespace Core\Module\Video;

use Core\Module\Exception\ParametersException;

class VideoCash{

    /** @var array */
    public static $video_list = [];

    /**
     * @return bool
     */
    public static function reset_data(){

        self::$video_list = [];

        return true;

    }

    /**
     * @param int|null $video_id
     * @param string|null $param
     * @return bool
     */
    public static function isset_video_parameter_in_cash(int $video_id = null, string $param = null){

        $error_info_list = [];

        if(empty($video_id)) $error_info_list[] = 'Video ID is empty';

        if(empty($param)) $error_info_list[] = 'Parameter is empty';

        if(empty(self::$video_list[$video_id])) return false;

        return !empty(self::$video_list[$video_id][$param]);

    }

    /**
     * @param int|null $video_id
     * @param string|null $param
     * @return null
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_video_parameter_in_cash(int $video_id = null, string $param = null){

        $error_info_list = [];

        if(empty($video_id)) $error_info_list[] = 'Video ID is empty';

        if(empty($param)) $error_info_list[] = 'Parameter is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('video_id' => $video_id,
                    'param' => $param
                )
            );

            throw new ParametersException($error);

        }

        if(empty(self::$video_list[$video_id])) return null;

        return empty(self::$video_list[$video_id][$param]) ? null : self::$video_list[$video_id][$param];

    }

    /**
     * @param int|null $video_id
     * @param string|null $param
     * @param null $value
     * @param bool $is_rewrite
     * @return bool
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function add_video_parameter_in_cash(int $video_id = null, string $param = null, $value = null, bool $is_rewrite=true){

        $error_info_list = [];

        if(empty($video_id)) $error_info_list[] = 'Video ID is empty';

        if(empty($param)) $error_info_list[] = 'Parameters is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('video_id' => $video_id,
                    'param' => $param,
                    'value' => $value,
                    'is_rewrite' => $is_rewrite
                )
            );

            throw new ParametersException($error);

        }

        if(empty(self::$video_list[$video_id]))
            self::$video_list[$video_id] = [];

        if($is_rewrite)
            self::$video_list[$video_id][$param] = $value;

        return true;

    }

}