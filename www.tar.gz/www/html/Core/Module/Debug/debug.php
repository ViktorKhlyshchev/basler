<?php

/**
 * Additional debug functions v 1
**/

if(!defined('cli')) define('cli', false);
if(!defined('sil')) define('sil', false);

function vd_pre($arg, $prepend = null){
    if(cli) echo $prepend ."\n"; else echo $prepend .'<br/>';
    var_dump($arg);
}

function pr($arg){
    if(count(func_get_args()) === 1) print_r($arg); else
    foreach(func_get_args() as $arg) print_r($arg);
}

function get_var_name($var){
    foreach($GLOBALS as $var_name => $value) if($value === $var) return $var_name;
    return false;
}

function pre($arg, $cli = null){ #pred(sil);
    if(sil) return;
    if($cli === null) $cli = cli;

    if($cli) echo "\n"; else  echo "\n<pre>";

    $f = __FUNCTION__ .' '. debug_backtrace()[0]['file'];
    if($f === $_SERVER['SCRIPT_NAME'])
        $prepend = $f .' '. debug_backtrace()[0]['line'] .' ';
    else
        $prepend = $f .' '. debug_backtrace()[0]['line'] .' from: '. $_SERVER['SCRIPT_NAME'];

    echo $prepend;
    if(count(func_get_args()) === 1){
        if(empty($arg) || is_bool($arg) || is_null($arg)){
            echo ' '; var_dump($arg);
        } else {
            echo '"'. gettype($arg) .'" '; print_r($arg); # echo '"'. gettype($arg) .'" '; print_r($arg);
        }
        if($cli) echo "\n"; else echo '</pre>';
        return;
    }

    foreach(func_get_args() as $arg)
        if(empty($arg) || is_bool($arg) || is_null($arg)) vd_pre($arg); else print_r($arg);

    if($cli) echo "\n"; else echo '</pre>';
    return;
}

function pree($arg){

    if(cli) echo "\n"; else echo '<pre><b>';

    $f = __FUNCTION__ ." ". debug_backtrace()[0]['file'];
    if($f === $_SERVER['SCRIPT_NAME'])
        $prepend = $f .' '. debug_backtrace()[0]['line'] .' ';
    else
        $prepend = $f .' '. debug_backtrace()[0]['line'] .' from: '. $_SERVER['SCRIPT_NAME'];

    echo $prepend;

    if(count(func_get_args()) === 1){
        if(empty($arg) || is_bool($arg) || is_null($arg)){
            vd_pre($arg);
        } else {
            echo '"'.gettype($arg).'" '; print_r($arg);
        }
        if(cli) echo "\n"; else '</b></pre>';
        return;
    }

    foreach(func_get_args() as $arg)
        if(empty($arg) || is_bool($arg) || is_null($arg)) vd_pre($arg); else print_r($arg);

    if(cli) echo "\n"; else '</b></pre>';
    return;
}

function pred($arg){
    $prepend = __FUNCTION__ ." ". debug_backtrace()[0]['file']." ".debug_backtrace()[0]['line']." from: ".$_SERVER['SCRIPT_NAME']."\n";

    echo "\n<pre>". $prepend;
    if(count(func_get_args()) === 1){
        if(empty($arg) || is_bool($arg) || is_null($arg)){
            vd_pre($arg);
        } else {
            echo '"'.gettype($arg).'" '; print_r($arg);
        }
        echo '</pre>';
        die;
    }

    foreach(func_get_args() as $arg){
        if(empty($arg) || is_bool($arg) || is_null($arg)){ vd_pre($arg); } else print_r($arg);
    }
    echo '</pre>';
    die;
}

function pt(){
    echo '<plaintext>';
    foreach(func_get_args() as $arg){
        print_r($arg);
    }
}

function ptd(){
    echo '<plaintext>';
    foreach(func_get_args() as $arg){
        print_r($arg);
    }
    die;
}

function dd(){
    echo "\n<pre>";
    foreach(func_get_args() as $arg) print_r($arg);
    echo '</pre>';
    die;
}

function vd($arg){
    $prepend = __FUNCTION__ ." ". debug_backtrace()[0]['file']." ".debug_backtrace()[0]['line']." from: ".$_SERVER['SCRIPT_NAME']."\n";
    echo $prepend;
    if(count(func_get_args()) === 1) var_dump($arg); else var_dump(func_get_args());
}

function vdd($arg){
    $prepend = __FUNCTION__ ." ". debug_backtrace()[0]['file']." ".debug_backtrace()[0]['line']." from: ".$_SERVER['SCRIPT_NAME']."\n";
    echo $prepend;
    //if($arg2) pre(debug_backtrace()[1]['file'].' '.debug_backtrace()[1]['line']); else pre(debug_backtrace()[0]['file'].' '.debug_backtrace()[0]['line']);    echo $_SERVER['SCRIPT_NAME'];    echo "\n";
    if(count(func_get_args()) === 1) var_dump($arg); else var_dump(func_get_args());
    die;
}

function pvd(){
    echo "\n";
    echo '<pre>';
    var_dump(func_get_args());
    echo '</pre>';
}

function pvdd(){
    echo "\n";
    echo '<pre>';
    var_dump(func_get_args());
    echo '</pre>';
    die;
}

function vdob(){
    ob_start();
    echo "\n<pre>vdob:";
    var_dump(func_get_args());
    echo "</pre>";
    $return = ob_get_contents();
    ob_end_clean();
    return $return;
}

function alert($text = 'alert'){
    if(!is_string($text)) $text = json_encode($text);
    echo "<script>alert('".$text."')</script>";
}

function cl($text = 'alert'){
    if(!is_string($text)) $text = json_encode($text);
    echo "<script>console.log('".$text."')</script>";
}

function vdf($content = 'debug'){ //var_export
    $now = new DateTime();
    $time = $now->format('Y.m.d_H.i.s');

    if(!is_string($content)){
        $json = json_encode($content);
        if(!$json && json_last_error_msg() === 'Recursion detected')
            $json = json_encode(var_export($content, true));
        $content = &$json;
    }

    $prepend ="\n\n ===  $time \n\n";
    $prepend.= "script: ".debug_backtrace()[0]['file']." \n".debug_backtrace()[0]['line']." \n";
    $prepend.= "from: ".$_SERVER['SCRIPT_NAME']."\n\n";
    $content = $prepend.$content."\n\n === \n\n";

    $dt = $now->format('Y.m.d_H');
    file_put_contents($_SERVER['DOCUMENT_ROOT'].'/.000debug_'. $dt .'.txt', $content, FILE_APPEND); #  $res = #pred($res);
}