<?php

namespace Core\Module\Header;

use Core\Module\Exception\ParametersException;

class HeaderRedirect {

    public static function init(int $code = null, string $link = null){ if($code !== 302) pred(debug_backtrace());
        #if(empty($code)) $code = 301;
        if(empty($code)) $code = 302;
        if(empty($link)) $link = '/';
        switch($code){
            case 301:
            case 302:
            case 303:
            case 307:{
                header('Location: '.$link, true, $code);
                return true;
            }
            default:{
                $error = ['title' => 'Parameters problem', 'info' => 'Header code for redirect is not valid'];
                throw new ParametersException($error);
            }
        }
    }
}