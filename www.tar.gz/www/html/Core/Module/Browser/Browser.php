<?php

namespace Core\Module\Browser;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class Browser{

    /** @var integer */
    public static $browser_id;

    /** @var string */
    public static $browser_name;

    /**
     * Reset default data
     * @return bool
     */
    public static function reset_data(){

        self::$browser_id = null;
        self::$browser_name = null;

        return true;

    }

    /**
     * @param string|null $browser_name
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_browser(string $browser_name = null){

        if(empty($browser_name)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Browser name is empty'
            );

            throw new ParametersException($error);

        }

        $where_list = array('name_lower' => strtolower($browser_name)
        );

        return Db::isset_row('_browser',0,$where_list);

    }

    /**
     * @param int|null $browser_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_browser_id(int $browser_id = null){

        if(empty($browser_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Browser ID is empty'
            );

            throw new ParametersException($error);

        }

        return Db::isset_row_id($browser_id,'_browser',0);

    }

    /**
     * @param string|null $browser_name
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_browser_id(string $browser_name = null){

        if(empty($browser_name)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Browser name is empty'
            );

            throw new ParametersException($error);

        }

        $where_list = array('name_lower' => strtolower($browser_name)
        );

        return Db::get_row_id('_browser',0,$where_list);

    }

    /**
     * @param string|null $browser_id
     * @return |null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_browser_name(string $browser_id = null){

        if(empty($browser_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Browser ID is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('name'),
            'table' => '_browser',
            'where' => array('id' => $browser_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0]['name'];

    }

    /**
     * @param string|null $browser_name
     * @param bool $need_remove_browser_version
     * @return array|bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_browser(string $browser_name = null, bool $need_remove_browser_version=true){

        if(empty($browser_name)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Browser name is empty'
            );

            throw new ParametersException($error);

        }

        if($need_remove_browser_version){

            $browser_id=self::get_browser_id($browser_name);

            if(!empty($browser_id))
                if(!BrowserVersion::remove_browser_version($browser_id)){

                    $error = array('title' => 'DB query problem',
                        'info' => 'Browser version was not removed'
                    );

                    throw new DbQueryException($error);

                }

        }

        $where_list = array('name_lower' => strtolower($browser_name)
        );

        return Db::pseudo_delete_from_where_list('_browser',0,$where_list);

    }

    /**
     * @param int|null $browser_id
     * @param bool $need_remove_browser_version
     * @return array|bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_browser_id(int $browser_id = null, bool $need_remove_browser_version=true){

        if(empty($browser_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Browser ID is empty'
            );

            throw new ParametersException($error);

        }

        if($need_remove_browser_version)
            if(!BrowserVersion::remove_browser_version($browser_id)){

                $error = array('title' => 'DB query problem',
                    'info' => 'Browser version was not removed'
                );

                throw new DbQueryException($error);

            }

        return Db::pseudo_delete_from_id($browser_id,'_browser',0);

    }

    /**
     * @param string|null $browser_name
     * @return mixed
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function add_browser(string $browser_name = null){

        if(empty($browser_name)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Browser name is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('table' => '_browser',
            'values' => array('name' => $browser_name,
                'name_lower' => strtolower($browser_name),
                'date_create' => 'NOW()'
            )
        );

        $r = Db::insert($q);

        if(count($r) === 0){

            $error = array('title' => 'DB query problem',
                'info' => 'Browser version was not added'
            );

            throw new DbQueryException($error);

        }

        return $r[0]['id'];

    }

    /**
     * @param array $browser_name_list
     * @return array|bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function add_browser_list(array $browser_name_list = []){

        if(count($browser_name_list) === 0){

            $error = array('title' => 'Parameters problem',
                'info' => 'Browser name list is empty'
            );

            throw new ParametersException($error);

        }

        $values_list = [];

        foreach($browser_name_list as $browser_name)
            if(!empty($browser_name)) $values_list[] = array('name_lower' => strtolower($browser_name),
                    'name' => $browser_name,
                    'date_create' => 'NOW()',
                    'date_update' => 'NOW()'
                );

        if(count($values_list) === 0){

            $error = array('title' => 'Parameters problem',
                'info' => 'Browser name list is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('table' => '_browser',
            'values' => $values_list
        );

        $r = Db::insert($q);

        if(count($r) === 0){

            $error = array('title' => 'DB query problem',
                'info' => 'Browser name list was not added'
            );

            throw new DbQueryException($error);

        }

        return $r;

    }

    /**
     * @param int|null $browser_id
     * @return bool
     */
    public static function set_browser_id_default(int $browser_id = null){

        self::$browser_id = $browser_id;

        return true;

    }

    /**
     * @param string|null $browser_name
     * @return bool
     */
    public static function set_browser_name_default(string $browser_name = null){

        self::$browser_name = empty($browser_name) ? null : $browser_name;

        return true;

    }

}