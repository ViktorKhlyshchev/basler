<?php

namespace Core\Module\Socket;

use Core\Module\Exception\ParametersException;
use Core\Module\Exception\PhpException;
use Core\Modules\Json;

class TCPSocketClient {

    public static function open_socket(string $ip = null, int $port = null){
        $error_info_list = [];
        if(empty($ip)) $error_info_list[] = 'IP is empty';
        if(empty($port)) $error_info_list[] = 'Port is empty';
        if(count($error_info_list) > 0){
            $error = [
                'title' => ParametersException::$title,
                'info' => $error_info_list
            ];
            throw new ParametersException($error);
        }
        $add = 'tcp://'.$ip.':'.$port; #pre('tcp://'); pre($add);
        $socket = @stream_socket_client($add, $errno, $error_message, 5);
        if(!$socket){
            if(loc) return $socket;
            return $socket;
            $error = ['title' => PhpException::$title, 'info' => 'Socket was not open'];
            throw new PhpException($error);
        }
        return $socket;
    }

    public static function close_socket($socket = null){
        if(empty($socket)) return true;
        if(!stream_socket_shutdown($socket, STREAM_SHUT_RDWR)){
            $error = [
                'title' => PhpException::$title,
                'info' => 'Socket was not close'
            ];
            throw new PhpException($error);
        }
        return true;
    }

    public static function send_message($socket = null, array $data = null){
        if($socket === false) return;
        $sent = stream_socket_sendto($socket, Json::encode($data)."\n", STREAM_OOB);
        if($sent > 0){
//            $r = '';
//
//            $n = 0;
//
//            $seek = 0;
//            $remotereadfile = false;
//            $buffer = '';
//            $cnt = 0;
////            $defaultchunksize = 1024*1024;
//            $defaultchunksize = 1024;
//            $chunksize = $defaultchunksize;
//            $retbytes = true;
//
//            if($seek != 0 && !$remotereadfile)
//                fseek($socket, $seek);
//
//            while (!@feof($socket)){
//
//                if($remotereadfile && $seek != 0 && $cnt+$chunksize > $seek)
//                    $chunksize = $seek-$cnt;
//                else
//                    $chunksize = $defaultchunksize;
//
//                echo 'chunksize: '.$chunksize."\n";
//
//                $buffer.= fread($socket, $chunksize);
//
//                if($retbytes || ($remotereadfile && $seek != 0)){
//                    $cnt + = strlen($buffer);
//                }
//
////                echo"--->>";
////                echo $buffer."'\n";
////                echo mb_strlen($buffer, 'utf-8')."\n\n\n";
//
//                $r.= $buffer;
//
//                if(!$remotereadfile || ($remotereadfile && $cnt > $seek))
//                    echo $buffer;
//
//                $n++;
////
//////                if(mb_strlen($temp, 'utf-8')<1024)
//////                    break;
////
//                if($n>2)
//                    die;
//
//            }
//
//            fclose($socket);
            $r = fread($socket, 1024*1024);
            return $r;
//            if(feof($socket)){
//
//                $r = fread($socket, 1024);
//
//                return $r;
//
//            }
//            else{
//
//                $error = [
//                    'title' => PhpException::$title,
//                    'info' => 'Socket fail'
//                ];
//
//                throw new PhpException($error);
//
//            }
        }
        return null;
    }

    public static function get_response(string $ip = null, int $port = null, array $data = null){
        $error_info_list = [];
        if(empty($ip)) $error_info_list[] = 'IP is empty';
        if(empty($port)) $error_info_list[] = 'Port is empty';
        if(count($error_info_list) > 0){
            $error = [
                'title' => ParametersException::$title,
                'info' => $error_info_list
            ];
            throw new ParametersException($error);
        }
        $socket = self::open_socket($ip, $port, $data);
        $response = self::send_message($socket, $data);
        self::close_socket($socket);
        if(empty($response)) return null;
        return Json::decode($response, 1);
    }
}