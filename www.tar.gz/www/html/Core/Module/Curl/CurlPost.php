<?php

namespace Core\Module\Curl;

use Core\Module\Exception\ParametersException;
use Core\Module\Exception\PhpException;
use Core\Module\Tor\Tor;

class CurlPost {

    private static $url;
    private static $get;
    private static $post;
    private static $data;
    private static $is_multipart;
    private static $status;
    private static $cookie_path;
    private static $need_tor = false;
    private static $proxy;
    private static $proxy_port;
    private static $header_list;
    private static $isset_redirect = false;
    private static $url_redirect;
    private static $url_referer;
    private static $header_info = [];
    private static $error_id;

    private static function reset_data(){
        self::$url = null;
        self::$get = null;
        self::$post = null;
        self::$data = null;
        self::$status = null;
        self::$cookie_path = null;
        self::$need_tor = false;
        self::$header_list = null;
        self::$isset_redirect = false;
        self::$url_redirect = null;
        self::$url_referer = null;
        self::$error_id = null; # self::$header_info = [];
        return true;
    }

    private static function set_data(){
        $curl = curl_init();
        if($curl === false){ $error = ['title' => 'System problem', 'info' => 'CURL was not start']; throw new PhpException($error); } # $user_agent = "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.7.5) Gecko/20041107 Firefox/1.0";
        $user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36";
        curl_setopt($curl, CURLOPT_USERAGENT, $user_agent); # curl_setopt($curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13');
        curl_setopt($curl, CURLINFO_HEADER_OUT, false);
        if(self::$is_multipart) curl_setopt($curl, CURLOPT_HTTPHEADER, 'Content-Type:multipart/form-data'); # if(!empty(self::$cookie_path) && !file_exists(self::$cookie_path)) file_put_contents(self::$cookie_path, '');
        if(!empty(self::$proxy)){
            curl_setopt($curl, CURLOPT_PROXY, self::$proxy);
            curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 10);
            curl_setopt($curl, CURLOPT_TIMEOUT, 10);
        }
        if(!empty(self::$proxy_port)) curl_setopt($curl, CURLOPT_PROXYPORT, self::$proxy_port);
        if(!empty(self::$url_referer)) curl_setopt($curl, CURLOPT_REFERER, self::$url_referer);
        if(!empty(self::$header_list)) curl_setopt($curl, CURLOPT_HTTPHEADER, self::$header_list); else curl_setopt($curl, CURLOPT_HTTPHEADER, ['Accept-Language: en,ru;q=0.9']); # curl_setopt($curl, CURLOPT_HEADER, true); curl_setopt($curl, CURLOPT_VERBOSE, false);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl, CURLOPT_COOKIESESSION, true);
        curl_setopt($curl, CURLOPT_COOKIEJAR, realpath(self::$cookie_path));
        curl_setopt($curl, CURLOPT_COOKIEFILE, realpath(self::$cookie_path)); # curl_setopt($curl, CURLOPT_URL, self::$url.(empty(self::$get)?'':('?'.http_build_query(self::$get)))); curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($curl, CURLOPT_URL, self::$url.(empty(self::$get)?'':('?'.http_build_query(self::$get))));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        if(!empty(self::$post)){
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query(self::$post));
        }
        self::$data = curl_exec($curl);
        self::$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        self::$error_id = curl_errno($curl);
        self::$header_info[] = self::$url;
        self::$header_info[] = curl_getinfo($curl);
        if(!empty(self::$error_id)) return false; # if(nl){ pre(self::$data);  }
        if(self::$status == 301 || self::$status == 302){
            preg_match('/Location:(.*?)\n/', self::$data, $matches);
            $newurl = trim(array_pop($matches));
            curl_close($curl);
            self::$isset_redirect = true;
            self::$url_redirect = $newurl; # echo 'New URL: '.$newurl."\n";
            self::$url = $newurl;
            return self::set_data();
        }
        if(self::$data === false){
            curl_close($curl);
            sleep(1);
            return self::set_data();
        }
        curl_close($curl);
        return true;
    }

    public static function init(
        string $url = null, # 0
        array $get = [], # 1
        array $post = [], # 2
        bool $is_multipart = false, # 3
        string $cookie_path = null, # 4
        bool $need_tor = false, # 5
        string $proxy = null, # 6
        int $proxy_port = null, # 7
        string $url_referer = null, # 8
        array $header_list = null # 9
    ){
        $error_info_list = [];
        if(empty($url)) $error_info_list[] = 'URL is empty';
        if(count($error_info_list)){ $error = ['title' => 'Parameters problem', 'info' => $error_info_list]; throw new ParametersException($error); }
        self::reset_data();
        self::$url = $url;
        self::$get = empty($get) ? null : $get;
        self::$post = $post;
        self::$need_tor = $need_tor;
        self::$proxy = $proxy;
        self::$proxy_port = $proxy_port;
        self::$is_multipart = $is_multipart;
        self::$cookie_path = $cookie_path;
        self::$header_list = $header_list;

        if(self::$need_tor){
            Tor::change_proxy_identity();
            self::$proxy = 'socks5://'.Tor::$ip_address;
            self::$proxy_port = Tor::$port;
        }

        self::set_data();

        return [
            'status' => self::$status,
            'isset_redirect' => self::$isset_redirect,
            'url_redirect' => self::$url_redirect,
            'header_info' => self::$header_info,
            'data' => self::$data
        ];
    }
}