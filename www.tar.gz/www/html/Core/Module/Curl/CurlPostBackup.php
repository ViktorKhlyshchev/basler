<?php

namespace Core\Module\Curl;

use Core\Module\Exception\ParametersException;
use Core\Module\Exception\PhpException;

class CurlPostBackup {

    private static $url;
    private static $get;
    private static $post;
    private static $data;
    private static $is_multipart;
    private static $status;

    private static function reset_data(){
        self::$url = null;
        self::$get = null;
        self::$post = null;
        self::$data = null;
        self::$status = null;
        return true;
    }

    private static function set_data(){
        $curl = curl_init();
        if($curl === false){  $error = ['title' => 'System problem', 'info' => 'CURL was not start']; throw new PhpException($error); }
        if(self::$is_multipart) curl_setopt($curl,CURLOPT_HTTPHEADER ,'Content-Type:multipart/form-data');
        curl_setopt($curl,CURLOPT_URL, self::$url.(empty(self::$get)?'':('?'.http_build_query(self::$get))));
        curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($curl,CURLOPT_POST,1);
        curl_setopt($curl,CURLOPT_POSTFIELDS,http_build_query(self::$post));
        curl_setopt($curl,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13');
        self::$data =curl_exec($curl);
        self::$status =curl_getinfo($curl,CURLINFO_HTTP_CODE);
        if(self::$data === false){ # $error = array(  'title' => 'System problem', 'info' => 'Curl error: '.curl_error($curl)  ); throw new PhpException($error);
            curl_reset($curl);
            curl_close($curl);
            sleep(1);
            return self::set_data();
        }
        curl_reset($curl);
        curl_close($curl);
        return true;
    }

    public static function init(string $url = null, array $get = [], array $post = [], bool $is_multipart = false){
        $error_info_list = [];
        if(empty($url)) $error_info_list[] = 'URL is empty';
        if(!count($post)) $error_info_list[] = 'POST is empty';
        if(count($error_info_list)){ $error = ['title' => 'Parameters problem', 'info' => $error_info_list]; throw new ParametersException($error); }
        self::reset_data();
        self::$url = $url;
        self::$get = empty($get) ? null : $get;
        self::$post = $post;
        self::$is_multipart = $is_multipart;
        self::set_data();
        return ['status' => self::$status, 'data' => self::$data];
    }
}