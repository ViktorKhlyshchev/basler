<?php

namespace Core\Module\Timezone;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class Timezone{

    /** @var int */
    public static $timezone_id;

    /** @var string */
    public static $timezone_name;

    /** @var int */
    public static $offset_utc;

    /**
     * @return bool
     */
    public static function reset_data(){

        self::$timezone_id = null;
        self::$timezone_name = null;
        self::$offset_utc = null;

        return true;

    }

    /**
     * @param int|null $timezone_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_timezone_id(int $timezone_id = null){

        if(empty($timezone_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Timezone ID is empty'
            );

            throw new ParametersException($error);

        }

        return Db::isset_row_id($timezone_id,'_timezone',0);

    }

    /**
     * @param string|null $timezone_name
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_timezone(string $timezone_name = null){

        if(empty($timezone_name)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Timezone name is empty'
            );

            throw new ParametersException($error);

        }

        $where_list = array('name' => $timezone_name
        );

        return Db::isset_row('_timezone',0,$where_list);

    }

    /**
     * @param string|null $timezone_name
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_timezone_id(string $timezone_name = null){

        if(empty($timezone_name)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Timezone name is empty'
            );

            throw new ParametersException($error);

        }

        $where_list = array('name' => $timezone_name
        );

        return Db::get_row_id('_timezone',0,$where_list);

    }

    /**
     * @param int|null $timezone_id
     * @return |null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_timezone_name(int $timezone_id = null){

        if(empty($timezone_name)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Timezone name is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('name'),
            'table' => '_timezone',
            'where' => array('id' => $timezone_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0]['name'];

    }

    /**
     * @param string|null $timezone_name
     * @return mixed
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function add_timezone(string $timezone_name = null){

        if(empty($timezone_name)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Timezone name is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('table' => '_timezone',
            'values' => array('name' => $timezone_name
            )
        );

        $r = Db::insert($q);

        if(count($r) === 0){

            $error = array('title' => 'DB query problem',
                'info' => 'Timezone was not added'
            );

            throw new DbQueryException($error);

        }

        return $r[0]['id'];

    }

    /**
     * @param int|null $timezone_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_timezone_id(int $timezone_id = null){

        if(empty($timezone_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Timezone ID is empty'
            );

            throw new ParametersException($error);

        }

        if(!Db::pseudo_delete_from_id($timezone_id,'_timezone',0)){

            $error = array('title' => 'DB query problem',
                'info' => 'Timezone was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param string|null $timezone_name
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_timezone(string $timezone_name = null){

        if(empty($timezone_name)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Timezone name is empty'
            );

            throw new ParametersException($error);

        }

        $where_list = array('name' => $timezone_name
        );

        if(!Db::pseudo_delete_from_where_list('_timezone',0,$where_list)){

            $error = array('title' => 'DB query problem',
                'info' => 'Timezone was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $timezone_id
     */
    public static function set_timezone_id_default(int $timezone_id = null){

        self::$timezone_id = empty($timezone_id) ? null : $timezone_id;

    }

    /**
     * @param string|null $timezone_name
     */
    public static function set_timezone_name(string $timezone_name = null){

        self::$timezone_name = empty($timezone_name) ? null : $timezone_name;

    }

}