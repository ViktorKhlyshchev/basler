<?php

namespace Core\Module\Lines;

class Lines{

    /**
     * @param float|null $x11
     * @param float|null $y11
     * @param float|null $x12
     * @param float|null $y12
     * @param float|null $x21
     * @param float|null $y21
     * @param float|null $x22
     * @param float|null $y22
     * @return bool
     */
    public static function is_crossing_lines(float $x11 = null, float $y11 = null, float $x12 = null, float $y12 = null, float $x21 = null, float $y21 = null, float $x22 = null, float $y22 = null){

        $maxx1 =max($x11, $x12);
        $maxy1 =max($y11, $y12);
        $minx1 =min($x11, $x12);
        $miny1 =min($y11, $y12);
        $maxx2 =max($x21, $x22);
        $maxy2 =max($y21, $y22);
        $minx2 =min($x21, $x22);
        $miny2 =min($y21, $y22);

        if($minx1>$maxx2 || $maxx1<$minx2 || $miny1>$maxy2 || $maxy1<$miny2
        )
          return false;

        $dx1 = $x12-$x11;
        $dy1 = $y12-$y11;
        $dx2 = $x22-$x21;
        $dy2 = $y22-$y21;
        $dxx = $x11-$x21;
        $dyy = $y11-$y21;

        if(($div = (int)((double)$dy2*$dx1-(double)$dx2*$dy1)) === 0)
          return false;

        if($div>0){

          if(($mul = (int)((double)$dx1*$dyy-(double)$dy1*$dxx))<0 || $mul>$div)
            return false;

          if(($mul = (int)((double)$dx2*$dyy-(double)$dy2*$dxx))<0 || $mul>$div)
             return false;

        }

        if(($mul=-(int)((double)$dx1*$dyy-(double)$dy1*$dxx))<0 || $mul>-$div)
          return false;

        if(($mul=-(int)((double)$dx2*$dyy-(double)$dy2*$dxx))<0 || $mul>-$div)
          return false;

        return true;
}


    /**
     * @param array $track_list
     * @param array $zone_line
     * @return array|bool
     */
    public static function is_crossing_lines_from_track_list(array $track_list = [], array $zone_line = []){

        for($track_index=1;$track_index<count($track_list);$track_index++){

            $track_line_data = [
                $track_list[$track_index-1],
                $track_list[$track_index],
            ];

            if(self::is_crossing_lines(
                $track_line_data[0]['x'],$track_line_data[0]['y'],$track_line_data[1]['x'],$track_line_data[1]['y'],
                $zone_line[0]['x'],$zone_line[0]['y'],$zone_line[1]['x'],$zone_line[1]['y']
            ))
                return [
                    'is_crossing_line' => true,
                    'timestamp' => $track_list[$track_index-1]['timestamp'],
                ];

        }

        return null;

    }

}