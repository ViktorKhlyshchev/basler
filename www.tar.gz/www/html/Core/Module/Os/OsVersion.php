<?php

namespace Core\Module\Os;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class OsVersion{

    /** @var int */
    public static $os_version_id;

    /** @var string */
    public static $os_version;

    /**
     * Reset default data
     * @return bool
     */
    public static function reset_data(){

        self::$os_version_id = null;
        self::$os_version = null;

        return true;

    }

    /**
     * @param int|null $os_id
     * @param string|null $os_version
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_os_version(int $os_id = null, string $os_version = null){

        $error_info_list = [];

        if(empty($os_id)) $error_info_list[] = 'OS ID is empty';

        if(empty($os_version)) $error_info_list[] = 'OS version is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('os_id' => $os_id,
                    'os_version' => $os_version
                )
            );

            throw new ParametersException($error);

        }

        $where_list = array('os_id' => $os_id,
            'version' => strtolower($os_version)
        );

        return Db::isset_row('_os_version',0,$where_list);

    }

    /**
     * @param int|null $os_version_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_os_version_id(int $os_version_id = null){

        if(empty($os_version_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'OS version ID is empty'
            );

            throw new ParametersException($error);

        }

        return Db::isset_row_id($os_version_id,'_os_version',0);

    }

    /**
     * @param int|null $os_id
     * @param string|null $os_version
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_os_version_id(int $os_id = null, string $os_version = null){

        $error_info_list = [];

        if(empty($os_id)) $error_info_list[] = 'OS ID is empty';

        if(empty($os_version)) $error_info_list[] = 'OS version is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('os_id' => $os_id,
                    'os_version' => $os_version
                )
            );

            throw new ParametersException($error);

        }

        $where_list = array('os_id' => $os_id,
            'version' => strtolower($os_version)
        );

        return Db::get_row_id('_os_version',0,$where_list);

    }

    /**
     * @param int|null $os_id
     * @param string|null $os_version
     * @return mixed
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function add_os_version(int $os_id = null, string $os_version = null){

        $error_info_list = [];

        if(empty($os_id)) $error_info_list[] = 'OS ID is empty';

        if(empty($os_version)) $error_info_list[] = 'OS version is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('os_id' => $os_id,
                    'os_version' => $os_version
                )
            );

            throw new ParametersException($error);

        }

        $q = array('table' => '_os_version',
            'values' => array('os_id' => $os_id,
                'version' => strtolower($os_version),
                'date_create' => 'NOW()'
            )
        );

        $r = Db::insert($q);

        if(count($r) === 0){

            $error = array('title' => 'DB query problem',
                'info' => 'OS version was not added'
            );

            throw new DbQueryException($error);

        }

        return $r[0]['id'];

    }

    /**
     * @param int|null $os_id
     * @param string $os_version
     * @return array|bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_os_version(int $os_id = null, string $os_version){

        $error_info_list = [];

        if(empty($os_id)) $error_info_list[] = 'OS ID is empty';

        if(empty($os_version)) $error_info_list[] = 'OS version is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('os_id' => $os_id,
                    'os_version' => $os_version
                )
            );

            throw new ParametersException($error);

        }

        $where_list = array('os_id' => $os_id,
            'version' => strtolower($os_version)
        );

        return Db::pseudo_delete_from_where_list('_os_version',0,$where_list);

    }

    /**
     * @param int|null $os_version_id
     * @return array|bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_os_version_id(int $os_version_id = null){

        if(empty($os_version_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'OS version ID is empty'
            );

            throw new ParametersException($error);

        }

        return Db::pseudo_delete_from_id($os_version_id,'_os_version',0);

    }

    /**
     * @param int|null $os_version_id
     */
    public static function set_os_version_id_default(int $os_version_id = null){

        self::$os_version_id = empty($os_version_id) ? null : $os_version_id;

    }

    /**
     * @param string|null $os_version
     */
    public static function set_os_version_default(string $os_version = null){

        self::$os_version = empty($os_version) ? null : strtolower($os_version);

    }

}