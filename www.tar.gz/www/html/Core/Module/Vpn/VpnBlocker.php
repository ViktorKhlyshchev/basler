<?php

namespace Core\Module\Vpn;

use Core\Module\Curl\CurlGet; # use Core\Module\Exception\AccessDeniedException;
use Core\Module\Exception\ParametersException;
use Common\Modules\Ip;
use Core\Modules\Json;
use Core\Modules\Log;

class VpnBlocker {

    private static $url_check = 'http://api.vpnblocker.net/v2/json';
    private static $data;

    private static function set_success(){
        Ip::$is_vpn = (bool)self::$data['host-ip'];
        return Ip::$is_vpn;
    }

    private static function set_error(){
        Log::init(['Unknown error'],true,true);
        return null;
    }

    public static function init(){
        $url = self::$url_check.'/'.Ip::$ip_address;
        $r = CurlGet::init($url); # pred($r);
        if(empty($r)) return null;
        self::$data = Json::decode($r['data']);
        $error_info_list = [];
        if(empty(self::$data['status'])) $error_info_list[] = 'Status is not exists #1';
        # TO DO - uncomment this line and check this out under dev if(count($error_info_list)){ $error = ['title' => 'Parameters problem', 'info' => $error_info_list]; pre($error); pre(debug_backtrace()); throw new ParametersException($error); }
        switch(self::$data['status']){
            case 'success':
                return self::set_success();
            case 'error':
                return self::set_error();
            default:
                return null;
        }
    }
}