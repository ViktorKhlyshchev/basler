<?php

function autoload($class){
    $path = str_replace('_', '/',$class).'.php';
    $path = str_replace('\\', '/',$path);
    $path = DR .'/'. $path;    #pre(' ===  == == '); pre($path);    pre(file_exists($path));  pre(' ===  === ');
    if(file_exists($path)) return require_once($path);
    return false;
}

spl_autoload_register('autoload');