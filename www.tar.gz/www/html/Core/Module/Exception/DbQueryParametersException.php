<?php

namespace Core\Module\Exception;

use Core\Modules\Log;
use Core\Module\Response\Response;
use Core\Module\Response\ResponseServerError;

class DbQueryParametersException extends \Exception{

    public static $title = 'DB query parameters problem';

    public function __construct(array $data = []){
        if(Response::$is_already_send) return false;
        Response::$is_already_send = true;
        $error = ['title' => 'DB parameters problem', 'place' => ['file' => parent::getFile(), 'line' => parent::getLine()], 'data' => $data]; if(\Config::$is_debug) pre($error);
        ResponseServerError::init();
        Log::init($error);
        die;
    }
}
