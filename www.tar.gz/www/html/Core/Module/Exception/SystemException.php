<?php

namespace Core\Module\Exception;

use Core\Modules\Log;
use Core\Module\Response\Response;
use Core\Module\Response\ResponseServerError;

class SystemException extends \Exception {

    public static $title = 'System problem';
    public static $is_exception = false;

    public function __construct(\Exception $error){

        if(Response::$is_already_send) return false;
        Response::$is_already_send = true;
        self::$is_exception = true;
        $error = [
            'type' => 'System Exception',
            'code' => $error->getCode(),
            'line' => $error->getLine(),
            'file' => $error->getFile(),
            'message' => $error->getMessage(),
            'previous' => $error->getPrevious()
        ]; if(\Config::$is_debug) pre($error);
        ResponseServerError::init();
        Log::init($error);
        die;
    }
}