<?php

namespace Core\Module\Exception;

use Core\Modules\Log;
use Core\Module\Response\Response;
use Core\Module\Response\ResponseAccessDenied;

class AccessDeniedException extends \Exception {

    public static $title = 'Access denied';

    public function __construct(array $data = []){

        if(Response::$is_already_send) return false;
        Response::$is_already_send = true;
        $place = ['place' => ['file' => parent::getFile(), 'line' => parent::getLine()]];
        $error = array_merge($data,$place);
        Log::init($error);
        ResponseAccessDenied::init($data);
        die;
    }
}
