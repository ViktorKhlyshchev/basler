<?php

namespace Core\Module\Exception;

use Core\Modules\Log;
use Core\Module\Response\Response;
use Core\Module\Response\ResponseServerError;

class DbQueryException extends \Exception {

    public static $title = 'DB query problem';

    public function __construct(array $data = []){
        if(Response::$is_already_send) return false;
        Response::$is_already_send = true;
        $place = ['place' => ['file' => parent::getFile(), 'line' => parent::getLine()]];
        $error = array_merge($data,$place);
        if(loc || \Config::$is_debug){
            pre(debug_backtrace());
            pre($error);
        }
        ResponseServerError::init();
        Log::init($error);
        die;
    }
}
