<?php

namespace Core\Module\Exception;

use Core\Modules\Log;
use Core\Module\Response\Response;
use Core\Module\Response\ResponseUnprocessableEntity;

class ParametersException extends \Exception {

    public static $title = 'Parameters problem';

    public function __construct(array $data = []){
        if(Response::$is_already_send) return false;
        Response::$is_already_send = true;
        $place = ['place' => ['file' => parent::getFile(), 'line' => parent::getLine()]];
        $error = array_merge($data, $place); if(\Config::$is_debug) pred($error);
        ResponseUnprocessableEntity::init($data);
        Log::init($error);
        die;
    }
}
