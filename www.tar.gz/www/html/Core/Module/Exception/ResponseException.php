<?php

namespace Core\Module\Exception;

use Core\Modules\Log;
use Core\Module\Response\Response;
use Core\Module\Response\ResponseServerError;

class ResponseException extends \Exception{

    /** @var string */
    public static $title='Response problem';

    /**
     * ResponseException constructor.
     * @param $data
     * @throws DbParametersException
     * @throws DbQueryException
     * @throws DbQueryParametersException
     * @throws DbValidationValueException
     * @throws ParametersException
     * @throws SystemException
     */
    public function __construct($data){

        if(Response::$is_already_send)
            return false;

        Response::$is_already_send=true;

        $place = array('place' => array('file' => parent::getFile(),
                'line' => parent::getLine()
            )
        );

        $error=array_merge($data,$place);

        ResponseServerError::init();

        Log::init($error);

        die;

    }

}

