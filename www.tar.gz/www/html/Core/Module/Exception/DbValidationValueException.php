<?php

namespace Core\Module\Exception;

use Core\Modules\Log;
use Core\Module\Response\Response;
use Core\Module\Response\ResponseServerError;

class DbValidationValueException extends \Exception {

    public static $title = 'DB validation value problem';

    public function __construct(array $data = []){

        if(Response::$is_already_send) return false;
        Response::$is_already_send = true;
        $error = ['title' => 'DB parameters is not valid', 'place' => ['file' => parent::getFile(), 'line' => parent::getLine()], 'data' => $data];
        ResponseServerError::init();
        Log::init($error);
        die;
    }
}
