<?php

namespace Core\Module\Exception;

use Core\Modules\Log;
use Core\Module\Response\Response;
use Core\Module\Response\ResponseServerError;

class PathException extends \Exception {

    public static $title = 'Path problem';

    public function __construct(array $data = []){
        if(Response::$is_already_send) return false;
        Response::$is_already_send = true;
        $place = array('place' => array('file' => parent::getFile(),
                'line' => parent::getLine()
            )
        );
        $error = array_merge($data, $place); if(\Config::$is_debug) pre($error);
        ResponseServerError::init();
        Log::init($error);
        die;
    }
}
