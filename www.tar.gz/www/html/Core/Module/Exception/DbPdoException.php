<?php

namespace Core\Module\Exception;

use Core\Modules\Log;
use Core\Module\Response\Response;
use Core\Module\Response\ResponseServerError;

class DbPdoException extends \PDOException {

    public static $title = 'DB PDO problem';

    public function __construct(\PDOException &$error, array $data = []){
        #pred($error);
        if(Response::$is_already_send) return false;
        Response::$is_already_send = true;
        /*$error = ['type' => 'PDO Exception',
            'title' => 'Db PDO Query Exception',
            'code' => $error->getCode(),
            'line' => $error->getLine(),
            'file' => $error->getFile(),
            'message' => $error->getMessage(),
            'previous' => $error->getPrevious(),
            'data' => $data
        ];*/
        #$error->errorInfo = $data;
        #$error->errorInfo = 123;
        #pred($error);
        return $error;#$error;
        if(loc || \Config::$is_debug){
            pre(debug_backtrace());
            pre($error);
        }

        ResponseServerError::init();
        Log::init($error);
        die;
    }
}