<?php

namespace Core\Module\Exception;

use Core\Modules\Log;
use Core\Module\Response\Response;
use Core\Module\Response\ResponseServerError;

class DbPdoConnectException extends \PDOException {

    public static $title = 'DB PDO connect problem';

    public function __construct(\PDOException $error, array $connect_data){
        if(Response::$is_already_send) return false;
        Response::$is_already_send = true;
        $error = [
            'type' => 'DbConnectException',
            'connect' => $connect_data,
            'code' => $error->getCode(),
            'line' => $error->getLine(),
            'file' => $error->getFile(),
            'message' => $error->getMessage()
        ]; pre($error);
        if(strpos($error['message'], 'could not connect to server') !== false) die('Не могу подключиться к БД! Упала? Поднимай!!');
        ResponseServerError::init();
        Log::init($error);
        die;
    }
}