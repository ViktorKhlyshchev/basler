<?php

namespace Core\Module\Geo;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class RegionLocalization{

    /** @var int */
    public static $region_localization_id;

    /** @var int */
    public static $lang_id;

    /** @var string */
    public static $region_name;

    /**
     * Reset default data
     * @return bool
     */
    public static function reset_data(){

        self::$region_localization_id = null;
        self::$lang_id = null;
        self::$region_name = null;

        return true;

    }

    /**
     * @param int|null $region_localization_id
     * @return bool
     * @throws ParametersException
     */
    public static function isset_region_localization_id(int $region_localization_id = null){

        if(empty($region_localization_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Region localization ID is empty'
            );

            throw new ParametersException($error);

        }

        return Db::isset_row_id($region_localization_id,'_region_localization',0);

    }

    /**
     * @param int|null $region_id
     * @param int|null $lang_id
     * @return bool
     * @throws ParametersException
     */
    public static function isset_region_localization(int $region_id = null, int $lang_id = null){

        $error_info_list = [];

        if(empty($region_id)) $error_info_list[] = 'Region ID is empty';

        if(empty($lang_id)) $error_info_list[] = 'Lang ID is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $where_list = array('region_id' => $region_id,
            'lang_id' => $lang_id
        );

        return Db::isset_row('_region_localization',0,$where_list);

    }

    /**
     * @param int|null $region_id
     * @param int|null $lang_id
     * @return int|null
     * @throws ParametersException
     */
    public static function get_region_localization_id(int $region_id = null, int $lang_id = null){

        $error_info_list = [];

        if(empty($region_id)) $error_info_list[] = 'Region ID is empty';

        if(empty($lang_id)) $error_info_list[] = 'Lang ID is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $where_list = array('region_id' => $region_id,
            'lang_id' => $lang_id
        );

        return Db::get_row_id('_region_localization',0,$where_list);

    }

    /**
     * @param int|null $region_localization_id
     * @return string|null
     * @throws ParametersException
     */
    public static function get_region_name_from_region_localization_id(int $region_localization_id = null){

        if(empty($region_localization_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Region localization ID is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('name'),
            'table' => '_region_localization',
            'where' => array('id' => $region_localization_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0]['name'];

    }

    /**
     * @param int|null $region_id
     * @param int|null $lang_id
     * @return string|null
     * @throws ParametersException
     */
    public static function get_region_name(int $region_id = null, int $lang_id = null){

        $error_info_list = [];

        if(empty($region_id)) $error_info_list[] = 'Region ID is empty';

        if(empty($lang_id)) $error_info_list[] = 'Lang ID is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('name'),
            'table' => '_region_localization',
            'where' => array('region_id' => $region_id,
                'lang_id' => $lang_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0]['name'];

    }

    /**
     * @param int|null $region_id
     * @param int|null $lang_id
     * @param string|null $region_name
     * @return int
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     */
    public static function add_region_localization(int $region_id = null, int $lang_id = null, string $region_name = null){

        $error_info_list = [];

        if(empty($region_id)) $error_info_list[] = 'Region ID is empty';

        if(empty($lang_id)) $error_info_list[] = 'Lang ID is empty';

        if(empty($region_name)) $error_info_list[] = 'Region name is empty';
        else if(!RegionValidation::is_valid_region_name($region_name)) $error_info_list[] = 'Region name is not valid';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $q = array('table' => '_region_localization',
            'values' => array('region_id' => $region_id,
                'lang_id' => $lang_id,
                'name' => $region_name,
                'date' => 'NOW()'
            )
        );

        $r = Db::insert($q);

        if(count($r) === 0){

            $error = array('title' => 'DB query problem',
                'info' => 'Region localization was not added'
            );

            throw new DbQueryException($error);

        }

        return $r[0]['id'];

    }

    /**
     * @param int|null $region_localization_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     */
    public static function remove_region_localization_id(int $region_localization_id = null){

        if(empty($region_localization_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Region localization ID is empty'
            );

            throw new ParametersException($error);

        }

        if(!Db::pseudo_delete_from_id($region_localization_id,'_region_localization',0)){

            $error = array('title' => 'DB query problem',
                'info' => 'Region localization was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $region_id
     * @param int|null $lang_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     */
    public static function remove_region_localization(int $region_id = null, int $lang_id = null){

        $error_info_list = [];

        if(empty($region_id)) $error_info_list[] = 'Region ID is empty';

        if(empty($lang_id)) $error_info_list[] = 'Lang ID is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $where_list = array('region_id' => $region_id,
            'lang_id' => $lang_id
        );

        if(!Db::pseudo_delete_from_where_list('_region_localization',0,$where_list)){

            $error = array('title' => 'DB query problem',
                'info' => 'Region localization was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $region_localization_id
     */
    public static function set_region_localization_id_default(int $region_localization_id = null){

        self::$region_localization_id = empty($region_localization_id) ? null : $region_localization_id;

    }

    /**
     * @param int|null $lang_id
     */
    public static function set_lang_id(int $lang_id = null){

        self::$lang_id = empty($lang_id) ? null : $lang_id;

    }

    /**
     * @param int|null $region_name
     */
    public static function set_region_name(int $region_name = null){

        self::$region_name = empty($region_name) ? null : $region_name;

    }

}