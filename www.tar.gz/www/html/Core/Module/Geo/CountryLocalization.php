<?php

namespace Core\Module\Geo;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;
use Core\Module\Lang\LangConfig;

class CountryLocalization{

    /** @var int */
    public static $country_localization_id;

    /** @var int */
    public static $lang_id;

    /** @var string */
    public static $country_name;

    /**
     * Reset default data
     * @return bool
     */
    public static function reset_data(){

        self::$country_localization_id = null;
        self::$lang_id = null;
        self::$country_name = null;

        return true;

    }

    /**
     * @param int|null $country_localization_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_country_localization_id(int $country_localization_id = null){

        if(empty($country_localization_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Country localization ID is empty'
            );

            throw new ParametersException($error);

        }

        return Db::isset_row_id($country_localization_id,'_country_localization',0);

    }

    /**
     * @param int|null $country_id
     * @param int|null $lang_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_country_name(int $country_id = null, int $lang_id = null){

        if(empty($country_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Country ID is empty'
            );

            throw new ParametersException($error);

        }

        if(empty($lang_id)) $lang_id=LangConfig::$lang_id_default;

        $where_list = array('country_id' => $country_id,
            'lang_id' => $lang_id
        );

        return Db::isset_row('_country_localization',0,$where_list);

    }

    /**
     * @param int|null $country_id
     * @param int|null $lang_id
     * @return int|null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_country_id(int $country_id = null, int $lang_id = null){

        if(empty($country_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Country ID is empty'
            );

            throw new ParametersException($error);

        }

        if(empty($lang_id)) $lang_id=LangConfig::$lang_id_default;

        $where_list = array('country_id' => $country_id,
            'lang_id' => $lang_id
        );

        $country_id=Db::get_row_id('_country_localization',0,$where_list);

        if(empty($country_id)) return null;

        return $country_id;

    }

    /**
     * @param string|null $country_name
     * @param int|null $lang_id
     * @return int|null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_country_id_from_name(string $country_name = null, int $lang_id = null){

        $error_info_list = [];

        if(empty($country_name)) $error_info_list[] = 'Country name is empty';

//        if(empty($lang_id))
//            $error_info_list[] = 'Lang ID is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('country_id'),
            'table' => '_country_localization',
            'where' => array('name' => [
                    'transform' => 'lower',
                    'value' => $country_name
                ], 'type' => 0),
            'limit' => 1
        );

        if(!is_null($lang_id)) $q['where']['lang_id'] = $lang_id;

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0]['country_id'];

    }

    /**
     * @param array $country_name_list
     * @param int|null $lang_id
     * @return array
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_country_id_list_from_name_list(array $country_name_list = [],int $lang_id = null){

        $error_info_list = [];

        if(count($country_name_list) === 0)
            $error_info_list[] = 'Country name is empty';

//        if(empty($lang_id))
//            $error_info_list[] = 'Lang ID is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('country_id',
                'name'),
            'table' => '_country_localization',
            'where' => array('name' => $country_name_list, 'type' => 0),
            'limit' => 1
        );

        if(!is_null($lang_id)) $q['where']['lang_id'] = $lang_id;

        $r = Db::select($q);

        if(count($r) === 0) return [];

        $list = [];

        foreach($r as $row)
            $list[$row['country_id']] = $row['name'];

        return $list;

    }

    /**
     * @param int|null $country_id
     * @param int|null $lang_id
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_country_name(int $country_id = null, int $lang_id = null){

        if(empty($country_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Country ID is empty'
            );

            throw new ParametersException($error);

        }

        if(empty($lang_id)) $lang_id=LangConfig::$lang_id_default;

        $q = array('select' => array('name'),
            'table' => '_country_localization',
            'where' => array('country_id' => $country_id,
                'lang_id' => $lang_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0]['name'];

    }

    /**
     * @return null|string
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_country_name_default(){

        if(empty(self::$country_localization_id)&&empty(self::$lang_id)&&empty(Country::$country_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Default country data is empty'
            );

            throw new ParametersException($error);

        }

        if(!empty(self::$country_localization_id)) return self::get_country_name_from_country_localization_id(self::$country_localization_id);
        else if(!empty(self::$lang_id)&&!empty(Country::$country_id)){

            if(empty(self::$lang_id))
                self::set_lang_id_default(LangConfig::$lang_id_default);

            return self::get_country_name(Country::$country_id, self::$lang_id);

        }

        return null;

    }

    /**
     * @param int|null $country_localization_id
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_country_name_from_country_localization_id(int $country_localization_id = null){

        if(empty($country_localization_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Country localization ID is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('name'),
            'table' => '_country_localization',
            'where' => array('id' => $country_localization_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0]['name'];

    }

    /**
     * @param int|null $country_id
     * @param int|null $lang_id
     * @param string|null $country_name
     * @return mixed
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function add_country_localization(int $country_id = null, int $lang_id = null, string $country_name = null){

        $error_info_list = [];

        if(empty($country_id)) $error_info_list[] = 'Country ID is empty';

        if(empty($lang_id)) $error_info_list[] = 'Lang ID is empty';

        if(empty($country_name)) $error_info_list[] = 'Country name is empty';
        else if(!CountryValidation::is_valid_country_name($country_name)) $error_info_list[] = 'Country name is not valid';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list,
                'data' => array('country_id' => $country_id,
                    'lang_id' => $lang_id,
                    'country_name' => $country_name
                )
            );

            throw new ParametersException($error);

        }

        $q = array('table' => '_country_localization',
            'values' => array('country_id' => $country_id,
                'lang_id' => $lang_id,
                'name' => $country_name,
                'date' => 'NOW()'
            )
        );

        $r = Db::insert($q);

        if(count($r) === 0){

            $error = array('title' => 'DB query problem',
                'info' => 'Country localization was not added',
                'data' => array('country_id' => $country_id,
                    'lang_id' => $lang_id,
                    'country_name' => $country_name
                )
            );

            throw new DbQueryException($error);

        }

        return $r[0]['id'];

    }

    /**
     * @param int|null $country_localization_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_country_localization_id(int $country_localization_id = null){

        if(empty($country_localization_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Country localization ID is empty'
            );

            throw new ParametersException($error);

        }

        if(!Db::pseudo_delete_from_id($country_localization_id,'_country_localization',0)){

            $error = array('title' => 'DB query problem',
                'info' => 'Country localization was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $country_id
     * @param int|null $lang_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_country_localization(int $country_id = null, int $lang_id = null){

        $error_info_list = [];

        if(empty($country_id)) $error_info_list[] = 'Country ID is empty';

        if(empty($lang_id)) $error_info_list[] = 'Lang ID is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $where_list = array('country_id' => $country_id,
            'lang_id' => $lang_id
        );

        if(!Db::pseudo_delete_from_where_list('_country_localization',0,$where_list)){

            $error = array('title' => 'DB query problem',
                'info' => 'Country localization was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $country_localization_id
     * @return bool
     */
    public static function set_country_localization_id_default(int $country_localization_id = null){

        self::$country_localization_id = empty($country_localization_id) ? null : $country_localization_id;

        return true;

    }

    /**
     * @param int|null $lang_id
     * @return bool
     */
    public static function set_country_lang_id_default(int $lang_id = null){

        self::$lang_id = empty($lang_id) ? null : $lang_id;

        return true;

    }

    /**
     * @param string|null $country_name
     * @return bool
     */
    public static function set_country_name_default(string $country_name = null){

        self::$country_name = empty($country_name) ? null : $country_name;

        return true;

    }


}