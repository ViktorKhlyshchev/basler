<?php

namespace Core\Module\Geo;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class Country {

    public static $country_id;
    public static $country_code;
    public static $country_code_full;
    public static $country_code_iso;

    public static function reset_data(){
        self::$country_id = null;
        self::$country_code = null;
        self::$country_code_full = null;
        self::$country_code_iso = null;
        return true;
    }

    public static function isset_country_id(int $country_id = null){
        if(empty($country_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Country ID is empty'
            );
            throw new ParametersException($error);
        }
        return Db::isset_row_id($country_id,'_country',0);
    }

    public static function isset_country_code(string $country_code = null){
        if(empty($country_code)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Country code is empty'
            );
            throw new ParametersException($error);
        }
        if(!ContinentValidation::is_valid_continent_code($country_code)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Country code is not valid'
            );
            throw new ParametersException($error);
        }
        $where_list = array('code' => $country_code
        );
        return Db::isset_row('_country',0,$where_list);
    }

    public static function isset_country_code_full(string $country_code_full = null){
        if(empty($country_code_full)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Country code full is empty'
            );
            throw new ParametersException($error);
        }
        if(!ContinentValidation::is_valid_continent_code($country_code_full)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Country code full is not valid'
            );
            throw new ParametersException($error);
        }
        $where_list = array('code_full' => $country_code_full
        );
        return Db::isset_row('_country',0,$where_list);
    }

    public static function get_country_id_from_country_code(string $country_code = null){
        if(empty($country_code)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Country code is empty'
            );
            throw new ParametersException($error);
        }
        if(!ContinentValidation::is_valid_continent_code($country_code)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Country code is not valid'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('id'),
            'table' => '_country',
            'where' => array('code' => $country_code, 'type' => 0),
            'limit' => 1
        );
        $r = Db::select($q);
        if(count($r)) return null;
        return $r[0]['id'];
    }

    public static function get_country_id_from_country_code_full(string $country_code_full = null){
        if(empty($country_code_full)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Country code full is empty'
            );
            throw new ParametersException($error);
        }
        if(!ContinentValidation::is_valid_continent_code_full($country_code_full)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Country code full is not valid'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('id'),
            'table' => '_country',
            'where' => array('code_full' => $country_code_full, 'type' => 0),
            'limit' => 1
        );
        $r = Db::select($q);
        if(count($r)) return null;
        return $r[0]['id'];
    }

    public static function get_country_id_from_country_code_iso(string $country_code_iso = null){
        if(empty($country_code_iso)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Country code iso is empty'
            );
            throw new ParametersException($error);
        }
        if(!ContinentValidation::is_valid_continent_code_iso($country_code_iso)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Country code iso is not valid'
            );
            throw new ParametersException($error);
        }
        $q = array('select' => array('id'),
            'table' => '_country',
            'where' => array('code_iso' => $country_code_iso, 'type' => 0),
            'limit' => 1
        );
        $r = Db::select($q);
        if(count($r)) return null;
        return $r[0]['id'];
    }

    public static function get_country_code_from_country_id(int $country_id = null){

        if(empty($country_id)){
            $error = ['title' => 'Parameters problem', 'info' => 'Country ID is empty'];
            throw new ParametersException($error);
        }
        $q = ['select' => ['code'], 'table' => '_country', 'where' => ['id' => $country_id, 'type' => 0], 'limit' => 1]; #pre($q);
        $r = Db::select($q);
        if(!$r) return null;
        return $r[0]['code'];
    }

    public static function get_country_code_full_from_country_id(int $country_id = null){
        if(empty($country_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Country ID is empty'
            );
            throw new ParametersException($error);
        }

        $q = array('select' => array('code_full'),
            'table' => '_country',
            'where' => array('id' => $country_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);
        if(empty($r)) return null;
        return $r[0]['code_full'];
    }

    public static function add_country(string $country_code = null,string $country_code_full = null,string $country_code_iso = null){
        if(empty($country_code)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Country code is empty'
            );
            throw new ParametersException($error);
        }
        if(!ContinentValidation::is_valid_continent_code($country_code)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Country code is not valid'
            );
            throw new ParametersException($error);
        }
        if(!ContinentValidation::is_valid_continent_code_full($country_code_full)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Country code full is not valid'
            );
            throw new ParametersException($error);
        }
        if(!ContinentValidation::is_valid_continent_code_iso($country_code_iso)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Country code iso is not valid'
            );
            throw new ParametersException($error);
        }
        $values_list = array('code' => $country_code,
            'date' => 'NOW()'
        );
        if(!empty($country_code_full)) $values_list['code_full'] = $country_code_full;
        if(!empty($country_code_iso)) $values_list['code_iso'] = $country_code_iso;
        $q = array('table' => '_country',
            'values' => $values_list
        );
        $r = Db::insert($q);
        if(count($r) == 0){
            $error = array('title' => 'DB query problem',
                'info' => 'Country was not added',
                'data' => array('country_code' => $country_code,
                    'country_code_full' => $country_code_full,
                    'country_code_iso' => $country_code_iso
                )
            );
            throw new DbQueryException($error);
        }

        return $r[0]['id'];
    }

    public static function remove_country_id(int $country_id = null,bool $is_need_remove_country_localization = true){
        if(empty($country_id)){
            $error = array('title' => 'Parameters problem',
                'info' => 'Country ID is empty'
            );
            throw new ParametersException($error);
        }

        if($is_need_remove_country_localization)
            if(CountryLocalization::remove_country_localization($country_id)){

                $error = array('title' => 'DB query problem',
                    'info' => 'Country localization was not removed'
                );
                throw new DbQueryException($error);

            }

        if(!Db::pseudo_delete_from_id($country_id,'_country',0)){

            $error = array('title' => 'DB query problem',
                'info' => 'Country was not removed'
            );
            throw new DbQueryException($error);

        }

        return true;

    }

    public static function remove_country_code(string $country_code = null,bool $is_need_remove_country_localization = true){

        if(empty($country_code)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Country code is empty'
            );
            throw new ParametersException($error);

        }

        if($is_need_remove_country_localization){

            $country_id = self::get_country_id_from_country_code($country_code);

            if(!empty($country_id))
                if(CountryLocalization::remove_country_localization($country_id)){

                    $error = array('title' => 'DB query problem',
                        'info' => 'Country localization was not removed'
                    );

                    throw new DbQueryException($error);

                }

        }

        $where_list = array('code' => $country_code
        );

        if(!Db::pseudo_delete_from_where_list('_country',0,$where_list)){

            $error = array('title' => 'DB query problem',
                'info' => 'Country was not removed'
            );
            throw new DbQueryException($error);

        }

        return true;

    }

    public static function remove_country_code_full(string $country_code_full = null,bool $is_need_remove_country_localization = true){

        if(empty($country_code_full)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Country code full is empty'
            );
            throw new ParametersException($error);

        }

        if($is_need_remove_country_localization){

            $country_id = self::get_country_id_from_country_code_full($country_code_full);

            if(!empty($country_id))
                if(CountryLocalization::remove_country_localization($country_id)){

                    $error = array('title' => 'DB query problem',
                        'info' => 'Country localization was not removed'
                    );

                    throw new DbQueryException($error);

                }

        }

        $where_list = array('code_full' => $country_code_full
        );

        if(!Db::pseudo_delete_from_where_list('_country',0,$where_list)){

            $error = array('title' => 'DB query problem',
                'info' => 'Country was not removed'
            );
            throw new DbQueryException($error);

        }

        return true;

    }

    public static function remove_country_code_iso(string $country_code_iso = null,bool $is_need_remove_country_localization = true){

        if(empty($country_code_iso)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Country code full is empty'
            );
            throw new ParametersException($error);

        }

        if($is_need_remove_country_localization){

            $country_id = self::get_country_id_from_country_code_iso($country_code_iso);

            if(!empty($country_id))
                if(CountryLocalization::remove_country_localization($country_id)){

                    $error = array('title' => 'DB query problem',
                        'info' => 'Country localization was not removed'
                    );

                    throw new DbQueryException($error);

                }

        }

        $where_list = ['code_iso' => $country_code_iso];

        if(!Db::pseudo_delete_from_where_list('_country',0,$where_list)){

            $error = array('title' => 'DB query problem',
                'info' => 'Country was not removed'
            );
            throw new DbQueryException($error);

        }

        return true;

    }

    public static function set_country_id_default(int $country_id = null){
        self::$country_id = empty($country_id) ? null : $country_id;
        return true;
    }

    public static function set_country_code_default(string $country_code = null){
        self::$country_code = empty($country_code) ? null : $country_code;
        return true;
    }

    public static function set_countr_code_full_default(string $country_code_full = null){
        self::$country_code_full = empty($country_code_full) ? null : $country_code_full;
        return true;
    }

    public static function set_country_code_iso_default(string $country_code_iso = null){
        self::$country_code_iso = empty($country_code_iso) ? null : $country_code_iso;
        return true;
    }
}