<?php

namespace Core\Module\Geo;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;
use Core\Module\Lang\LangConfig;

class ContinentLocalization{

    /** @var int */
    public static $continent_localization_id;

    /** @var int */
    public static $lang_id;

    /** @var string */
    public static $continent_name;

    /**
     * Reset default data
     * @return bool
     */
    public static function reset_data(){

        self::$continent_localization_id = null;
        self::$lang_id = null;
        self::$continent_name = null;

        return true;

    }

    /**
     * @param int|null $continent_localization_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_continent_localization_id(int $continent_localization_id = null){

        if(empty($continent_localization_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Continent localization ID is empty'
            );

            throw new ParametersException($error);

        }

        return Db::isset_row_id($continent_localization_id,'_continent_localization',0);

    }

    /**
     * @param int|null $continent_id
     * @param int|null $lang_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_continent_localization(int $continent_id = null, int $lang_id = null){

        $error_info_list = [];

        if(empty($continent_id)) $error_info_list[] = 'Continent ID is empty';

        if(empty($lang_id)) $error_info_list[] = 'Lang ID is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $where_list = array('continent_id' => $continent_id,
            'lang_id' => $lang_id
        );

        return Db::isset_row('_continent_localization',0,$where_list);

    }

    /**
     * @param int|null $continent_id
     * @param int|null $lang_id
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_continent_name(int $continent_id = null, int $lang_id = null){

        $error_info_list = [];

        if(empty($continent_id)) $error_info_list[] = 'Continent ID is empty';

        if(empty($lang_id)) $error_info_list[] = 'Lang ID is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('name'),
            'table' => '_continent_localization',
            'where' => array('continent_id' => $continent_id,
                'lang_id' => $lang_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0]['name'];

    }

    /**
     * @param int|null $contient_localization_id
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_continent_name_from_continent_localization_id(int $contient_localization_id = null){

        if(empty($contient_localization_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Continent localization ID is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('name'),
            'table' => '_continent_localization',
            'where' => array('id' => $contient_localization_id, 'type' => 0),
            'type' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0]['name'];

    }

    /**
     * @return null|string
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_continent_name_default(){

        if(!empty(self::$continent_name)) return self::$continent_name;

        if(empty(Continent::$continent_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Default continent ID is empty'
            );

            throw new ParametersException($error);

        }

        if(!empty(self::$continent_localization_id)) return self::get_continent_name_from_continent_localization_id(self::$continent_localization_id);
        else{

            if(empty(self::$lang_id))
                self::set_lang_id_default(LangConfig::$lang_id_default);

            return self::get_continent_name(Continent::$continent_id, self::$lang_id);

        }

    }

    /**
     * @param int|null $continent_localization_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_continent_localization_id(int $continent_localization_id = null){

        if(empty($continent_localization_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Continent localization ID is empty'
            );

            throw new ParametersException($error);

        }

        if(!Db::pseudo_delete_from_id($continent_localization_id,'_continent_localization',0)){

            $error = array('title' => 'DB query problem',
                'info' => 'Continent localization was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $continent_id
     * @param int|null $lang_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_continent_localization(int $continent_id = null, int $lang_id = null){

        if(empty($continent_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Continent ID is empty'
            );

            throw new ParametersException($error);

        }

        $where_list = array('continent_id' => $continent_id
        );

        if(!empty($lang_id)) $where_list['lang_id'] = $lang_id;

        if(!Db::pseudo_delete_from_where_list('_continent_localization',0,$where_list)){

            $error = array('title' => 'DB query problem',
                'info' => 'Continent localization was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $continent_localization_id
     * @return bool
     */
    public static function set_continent_localization_id_default(int $continent_localization_id = null){

        self::$continent_localization_id = empty($continent_localization_id) ? null : $continent_localization_id;

        return true;

    }

    /**
     * @param int|null $lang_id
     * @return bool
     */
    public static function set_lang_id_default(int $lang_id = null){

        self::$lang_id = empty($lang_id) ? null : $lang_id;

        return true;

    }

    /**
     * @param string|null $continent_name
     * @return bool
     */
    public static function set_continent_name_default(string $continent_name = null){

        self::$continent_name = empty($continent_name) ? null : $continent_name;

        return true;

    }

}