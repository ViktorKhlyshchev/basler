<?php

namespace Core\Module\Geo;

use Core\Module\Db\Db;
use Core\Module\Exception\ParametersException;
use Common\Modules\Ip;

class GeoUpdate{

    /** @var string */
    private static $dir ='Core/Resources/Localization';

    /** @var string */
    private static $file_ip4_name ='GeoLite2-City-Blocks-IPv4.csv';

    /** @var string */
    private static $file_ip6_name ='GeoLite2-City-Blocks-IPv6.csv';

    /** @var array */
    private static $file_city_name_list = array('ru' => 'GeoLite2-City-Locations-ru.csv',
        'de' => 'GeoLite2-City-Locations-de.csv',
        'en' => 'GeoLite2-City-Locations-en.csv',
        'es' => 'GeoLite2-City-Locations-es.csv',
        'fr' => 'GeoLite2-City-Locations-fr.csv',
        'ja' => 'GeoLite2-City-Locations-ja.csv',
        'pt' => 'GeoLite2-City-Locations-pt.csv',
        'zh' => 'GeoLite2-City-Locations-zh.csv'
    );

    /**
     * @return bool
     */
    private static function isset_file_list(){

        if(!file_exists(self::$dir.'/'.self::$file_ip4_name)) return false;

        if(!file_exists(self::$dir.'/'.self::$file_ip6_name)) return false;

        foreach(self::$file_city_name_list as $file_name)
            if(!file_exists(self::$dir.'/'.$file_name))
                return false;

        return true;

    }

    /**
     * @param null $lang
     * @param null $code
     * @return array
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\ParametersException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function isset_continent($lang = null, $code = null){

        $q = array('select' => array(
                 array('column' => 'id'
                ),
                 array('column' => 'name_'.$lang
                )
            ),
            'table' => '_continent',
            'where' => array(
                 array('column' => 'code',
                    'value' => $code
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return array(null,null);

        return array(
            $r[0]['id'],
            $r[0]['name_'.$lang]
        );

    }

    /**
     * @param null $lang
     * @param null $code
     * @return array
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function isset_country($lang = null, $code = null){

        $error_info_list = [];

        if(empty($lang)) $error_info_list[] = 'Lang is empty';

        if(empty($code)) $error_info_list[] = 'Code is empty';

        if(count($error_info_list) > 0){

            $error = [
                'title' => ParametersException::$title,
                'info' => $error_info_list
            ];

            throw new ParametersException($error);

        }

        $q = array('select' => array(
                 array('column' => 'id'
                ),
                 array('column' => 'name_'.$lang
                )
            ),
            'table' => '_country',
            'where' => array(
                 array('column' => 'code',
                    'value' => $code
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return array(null,null);

        return array(
            $r[0]['id'],
            $r[0]['name_'.$lang]
        );

    }

    /**
     * @param null $lang
     * @param null $country_id
     * @param null $name
     * @return array
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function isset_city($lang = null, $country_id = null, $name = null){

        $error_info_list = [];

        if(empty($lang)) $error_info_list[] = 'Lang is empty';

        if(empty($country_id)) $error_info_list[] = 'Country ID is empty';

        if(empty($name)) $error_info_list[] = 'Name is empty';

        if(count($error_info_list) > 0){

            $error = [
                'title' => ParametersException::$title,
                'info' => $error_info_list
            ];

            throw new ParametersException($error);

        }

        $q = array('select' => array(
                 array('column' => 'id'
                ),
                 array('column' => 'name_'.$lang
                )
            ),
            'table' => '_city',
            'where' => array(
                 array('column' => 'country_id',
                    'value' => $country_id,
                ),
                 array('column' => 'name_'.$lang,
                    'value' => $name
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return array(null,null);

        return array(
            $r[0]['id'],
            $r[0]['name_'.$lang]
        );

    }

    /**
     * @param null $lang
     * @param null $country_id
     * @param null $name
     * @return array
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function isset_region($lang = null, $country_id = null, $name = null){

        $error_info_list = [];

        if(empty($lang)) $error_info_list[] = 'Lang is empty';

        if(empty($country_id)) $error_info_list[] = 'Country ID is empty';

        if(empty($name)) $error_info_list[] = 'Name is empty';

        if(count($error_info_list) > 0){

            $error = [
                'title' => ParametersException::$title,
                'info' => $error_info_list
            ];

            throw new ParametersException($error);

        }

        $q = array('select' => array(
                 array('column' => 'id'
                ),
                 array('column' => 'name_'.$lang
                )
            ),
            'table' => '_region',
            'where' => array(
                 array('column' => 'country_id',
                    'value' => $country_id,
                ),
                 array('column' => 'name_'.$lang,
                    'value' => $name
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return array(null,null);

        return array(
            $r[0]['id'],
            $r[0]['name_'.$lang]
        );

    }

    /**
     * @param null $name
     * @return null
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function isset_timezone($name = null){

        $q = array('select' => array(
                 array('column' => 'id'
                )
            ),
            'table' => '_timezone',
            'where' => array(
                 array('column' => 'name',
                    'value' => $name,
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'limit' => 1
        );

        $r = Db::select($q);

        return count($r)==0?null:$r[0]['id'];

    }

    /**
     * @param null $geo_id
     * @return bool
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function isset_geo($geo_id = null){

        $q = array('select' => array(
                 array('column' => 'id'
                )
            ),
            'table' => '_geo',
            'where' => array(
                 array('column' => 'id',
                    'value' => $geo_id,
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'limit' => 1
        );

        $r = Db::select($q);

        return count($r)!=0;

    }

    /**
     * @param null $network
     * @return null
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function isset_geo_ip($network = null){

        $q = array('select' => array(
                 array('column' => 'id'
                )
            ),
            'table' => '_geo_ip',
            'where' => array(
                 array('column' => 'network',
                    'value' => $network,
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'limit' => 1
        );

        $r = Db::select($q);

        return count($r)==0?null:$r[0]['id'];

    }

    /**
     * @param null $geo_id
     * @return array
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function get_geo_data($geo_id = null){

        $q = array('select' => array(
                 array('column' => 'id',
                ),
                 array('column' => 'continent_id',
                ),
                 array('column' => 'country_id',
                ),
                 array('column' => 'region_id',
                ),
                 array('column' => 'city_id',
                ),
                 array('column' => 'timezone_id',
                )
            ),
            'table' => '_geo',
            'where' => array(
                 array('column' => 'id',
                    'value' => $geo_id,
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return array(
                null,
                null,
                null,
                null,
                null,
                null
            );

        return array(
            $r[0]['id'],
            $r[0]['continent_id'],
            $r[0]['country_id'],
            $r[0]['region_id'],
            $r[0]['city_id'],
            $r[0]['timezone_id']
        );

    }

    /**
     * @param null $lang
     * @param null $code
     * @param null $name
     * @return null
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function add_continent($lang = null, $code = null, $name = null){

        $q = array('table' => '_continent',
            'values' => array(
                 array('code' => $code,
                    'name_'.$lang => $name,
                    'type' => 0
                )
            )
        );

        $r = Db::insert($q);

        return count($r)==0?null:$r[0]['id'];

    }

    /**
     * @param null $lang
     * @param null $continent_id
     * @param null $code
     * @param null $name
     * @return null
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function add_country($lang = null, $continent_id = null, $code = null, $name = null){

        $q = array('table' => '_country',
            'values' => array(
                 array('continent_id' => $continent_id,
                    'code' => $code,
                    'name_'.$lang => $name,
                    'type' => 0
                )
            )
        );

        $r = Db::insert($q);

        return count($r)==0?null:$r[0]['id'];

    }

    /**
     * @param null $lang
     * @param null $continent_id
     * @param null $country_id
     * @param null $code
     * @param null $name
     * @return null
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function add_region($lang = null, $continent_id = null, $country_id = null, $code = null, $name = null){

        $q = array('table' => '_region',
            'values' => array(
                 array('continent_id' => $continent_id,
                    'country_id' => $country_id,
                    'code' => $code,
                    'name_'.$lang => $name,
                    'type' => 0
                )
            )
        );

        $r = Db::insert($q);

        return count($r)==0?null:$r[0]['id'];

    }

    /**
     * @param null $lang
     * @param null $continent_id
     * @param null $country_id
     * @param null $region_id
     * @param null $timezone_id
     * @param null $name
     * @return null
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function add_city($lang = null, $continent_id = null, $country_id = null, $region_id = null, $timezone_id = null, $name = null){

        $q = array('table' => '_city',
            'values' => array(
                 array('continent_id' => $continent_id,
                    'country_id' => $country_id,
                    'region_id' => $region_id,
                    'timezone_id' => $timezone_id,
                    'name_'.$lang => $name,
                    'type' => 0
                )
            )
        );

        $r = Db::insert($q);

        return count($r)==0?null:$r[0]['id'];

    }

    /**
     * @param null $geo_id
     * @param null $continent_id
     * @param null $country_id
     * @param null $region_id
     * @param null $city_id
     * @param null $timezone_id
     * @return null
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function add_geo($geo_id = null, $continent_id = null, $country_id = null, $region_id = null, $city_id = null, $timezone_id = null){

        $q = array('table' => '_geo',
            'values' => array(
                 array('id' => $geo_id,
                    'continent_id' => $continent_id,
                    'country_id' => $country_id,
                    'region_id' => $region_id,
                    'city_id' => $city_id,
                    'timezone_id' => $timezone_id,
                    'type' => 0
                )
            )
        );

        $r = Db::insert($q);

        return count($r)==0?null:$r[0]['id'];

    }

    /**
     * @param null $geo_id
     * @param null $country_geo_id
     * @param null $network
     * @param null $ip_start_long
     * @param null $ip_finish_long
     * @param null $postal_code
     * @param null $latitude
     * @param null $longitude
     * @param null $radius
     * @return null
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function add_geo_ip($geo_id = null, $country_geo_id = null, $network = null, $ip_start_long = null, $ip_finish_long = null, $postal_code = null, $latitude = null, $longitude = null, $radius = null){

        $q = array('table' => '_geo_ip',
            'values' => array(
                 array('geo_id' => $geo_id,
                    'country_geo_id' => $country_geo_id,
                    'network' => $network,
                    'ip_start_long' => $ip_start_long,
                    'ip_finish_long' => $ip_finish_long,
                    'postal_code' => $postal_code,
                    'latitude' => $latitude,
                    'longitude' => $longitude,
                    'radius' => $radius,
                    'date_create' => 'NOW()',
                    'type' => 0
                )
            )
        );

        $r = Db::insert($q);

        return count($r)==0?null:$r[0]['id'];

    }

    /**
     * @param int|null $continent_id
     * @param string|null $lang
     * @param string|null $name
     * @return array|bool
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function update_continent(int $continent_id = null, string $lang = null, string $name = null){

        $q = array('table' => '_continent',
            'set' => array(
                 array('column' => 'name_'.$lang,
                    'value' => $name
                )
            ),
            'where' => array(
                 array('column' => 'id',
                    'value' => $continent_id
                )
            )
        );

        return Db::update($q);

    }

    /**
     * @param int|null $country_id
     * @param string|null $lang
     * @param string|null $name
     * @return array|bool
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function update_country(int $country_id = null, string $lang = null, string $name = null){

        $q = array('table' => '_country',
            'set' => array(
                 array('column' => 'name_'.$lang,
                    'value' => $name
                )
            ),
            'where' => array(
                 array('column' => 'id',
                    'value' => $country_id
                )
            )
        );

        return Db::update($q);

    }

    /**
     * @param int|null $region_id
     * @param string|null $lang
     * @param string|null $name
     * @return array|bool
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function update_region(int $region_id = null, string $lang = null, string $name = null){

        $q = array('table' => '_region',
            'set' => array(
                 array('column' => 'name_'.$lang,
                    'value' => $name
                )
            ),
            'where' => array(
                 array('column' => 'id',
                    'value' => $region_id
                )
            )
        );

        return Db::update($q);

    }

    /**
     * @param int|null $city_id
     * @param string|null $lang
     * @param string|null $name
     * @return array|bool
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function update_city(int $city_id = null, string $lang = null, string $name = null){

        $q = array('table' => '_city',
            'set' => array(
                 array('column' => 'name_'.$lang,
                    'value' => $name
                )
            ),
            'where' => array(
                 array('column' => 'id',
                    'value' => $city_id
                )
            )
        );

        return Db::update($q);

    }

    /**
     * @param int|null $city_id
     * @param null $postal_code
     * @param float|null $latitude
     * @param float|null $longitude
     * @return array|bool
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function update_city_place(int $city_id = null, $postal_code = null, float $latitude = null, float $longitude = null){

        $q = array('table' => '_city',
            'set' => array(
                 array('column' => 'postal_code',
                    'value' => $postal_code
                ),
                 array('column' => 'latitude',
                    'value' => $latitude
                ),
                 array('column' => 'longitude',
                    'value' => $longitude
                ),
                 array('column' => 'date_update',
                    'value' => 'NOW()'
                )
            ),
            'where' => array(
                 array('column' => 'id',
                    'value' => $city_id
                )
            )
        );

        return Db::update($q);

    }

    /**
     * @param int|null $geo_id
     * @param int|null $continent_id
     * @param int|null $country_id
     * @param int|null $region_id
     * @param int|null $city_id
     * @param int|null $timezone_id
     * @return array|bool
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function update_geo(int $geo_id = null, int $continent_id = null, int $country_id = null, int $region_id = null, int $city_id = null, int $timezone_id = null){

        $q = array('table' => '_geo',
            'set' => array(
                 array('column' => 'continent_id',
                    'value' => $continent_id
                ),
                 array('column' => 'country_id',
                    'value' => $country_id
                ),
                 array('column' => 'region_id',
                    'value' => $region_id
                ),
                 array('column' => 'city_id',
                    'value' => $city_id
                ),
                 array('column' => 'timezone_id',
                    'value' => $timezone_id
                ),
                 array('column' => 'date_update',
                    'value' => 'NOW()'
                ),
            ),
            'where' => array(
                 array('column' => 'id',
                    'value' => $geo_id
                )
            )
        );

        return Db::update($q);

    }

    /**
     * @param int|null $geo_ip_id
     * @param int|null $geo_id
     * @param int|null $country_geo_id
     * @param null $network
     * @param null $ip_start_long
     * @param null $ip_finish_long
     * @param null $postal_code
     * @param float|null $latitude
     * @param float|null $longitude
     * @param int|null $radius
     * @return array|bool
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function update_geo_ip(int $geo_ip_id = null, int $geo_id = null, int $country_geo_id = null, $network = null, $ip_start_long = null, $ip_finish_long = null, $postal_code = null, float $latitude = null, float $longitude = null, int $radius = null){

        $q = array('table' => '_geo_ip',
            'set' => array(
                 array('column' => 'geo_id',
                    'value' => $geo_id
                ),
                 array('column' => 'country_geo_id',
                    'value' => $country_geo_id
                ),
                 array('column' => 'network',
                    'value' => $network
                ),
                 array('column' => 'ip_start_long',
                    'value' => $ip_start_long
                ),
                 array('column' => 'ip_finish_long',
                    'value' => $ip_finish_long
                ),
                 array('column' => 'postal_code',
                    'value' => $postal_code
                ),
                 array('column' => 'latitude',
                    'value' => $latitude
                ),
                 array('column' => 'longitude',
                    'value' => $longitude
                ),
                 array('column' => 'radius',
                    'value' => $radius
                ),
                 array('column' => 'date_update',
                    'value' => 'NOW()'
                )
            ),
            'where' => array(
                 array('column' => 'id',
                    'value' => $geo_ip_id
                )
            )
        );

        return Db::update($q);

    }

    /**
     * @param string|null $lang
     * @param null $code
     * @param string|null $name
     * @return mixed|null
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function get_continent_id(string $lang = null, $code = null, string $name = null){

        list($continent_id,$isset_name)=self::isset_continent($lang,$code);

        if(empty($continent_id)) $continent_id=self::add_continent($lang,$code,$name);
        else if(empty($isset_name))
            self::update_continent($continent_id,$lang,$name);

        return $continent_id;

    }

    /**
     * @param string|null $lang
     * @param int|null $continent_id
     * @param null $code
     * @param string|null $name
     * @return mixed|null
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function get_country_id(string $lang = null, int $continent_id = null, $code = null, string $name = null){

        list($country_id,$isset_name)=self::isset_country($lang,$code);

        if(empty($country_id)) $country_id=self::add_country($lang,$continent_id,$code,$name);
        else if(empty($isset_name))
            self::update_country($country_id,$lang,$name);

        return $country_id;

    }

    /**
     * @param string|null $lang
     * @param int|null $continent_id
     * @param int|null $country_id
     * @param null $code
     * @param string|null $name
     * @return mixed|null
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function get_region_id(string $lang = null, int $continent_id = null, int $country_id = null, $code = null, string $name = null){

        list($region_id,$isset_name)=self::isset_region($lang,$country_id,$name);

        if(empty($region_id)) $region_id=self::add_region($lang,$continent_id,$country_id,$code,$name);
        else if(empty($isset_name))
            self::update_region($region_id,$lang,$name);

        return $region_id;

    }

    /**
     * @param string|null $lang
     * @param int|null $continent_id
     * @param int|null $country_id
     * @param int|null $region_id
     * @param int|null $timezone_id
     * @param string|null $name
     * @return mixed|null
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function get_city_id(string $lang = null, int $continent_id = null, int $country_id = null, int $region_id = null, int $timezone_id = null, string $name = null){

        list($city_id,$isset_name)=self::isset_city($lang,$country_id,$name);

        if(empty($city_id)) $city_id=self::add_city($lang,$continent_id,$country_id,$region_id,$timezone_id,$name);
        else if(empty($isset_name))
            self::update_city($city_id,$lang,$name);

        return $city_id;

    }

    /**
     * @param string|null $name
     * @return null
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function get_timezone_id(string $name = null){

        return self::isset_timezone($name);

    }

    /**
     * @param int|null $geo_id
     * @param int|null $continent_id
     * @param int|null $country_id
     * @param int|null $region_id
     * @param int|null $city_id
     * @param int|null $timezone_id
     * @return int
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function get_geo_id(int $geo_id = null, int $continent_id = null, int $country_id = null, int $region_id = null, int $city_id = null, int $timezone_id = null){

        if(self::isset_geo($geo_id))
            self::update_geo($geo_id,$continent_id,$country_id,$region_id,$city_id,$timezone_id);
        else
            self::add_geo($geo_id,$continent_id,$country_id,$region_id,$city_id,$timezone_id);

        return $geo_id;

    }

    /**
     * @return bool
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function set_file_ip4(){

        $file_object=fopen(self::$dir.'/'.self::$file_ip4_name,"r");

        $cols_name_list = mb_split(",",trim(fgets($file_object)));

        while(!feof($file_object)){

            $value_list = mb_split(",",trim(fgets($file_object)));
            $temp = [];

            foreach($value_list as $index => $value){

                $key =trim($cols_name_list[$index]);
                $value =trim($value);

                switch($key){

                    case 'network':{

                        list($ip_start,$ip_finish)=Ip::get_cidr_to_ip_range($value);

                        $temp['ip_start'] = $ip_start;
                        $temp['ip_finish'] = $ip_finish;
                        $temp['ip_start_long'] =ip2long($ip_start);
                        $temp['ip_finish_long'] =ip2long($ip_finish);

                        $temp[$key] = $value;

                        break;

                    }

                    default:{

                        $temp[$key] = $value;

                        break;

                    }

                }

            }

            $network = $temp['network'];
//            $geo_id = empty($temp['geoname_id']) ? null : (int)$temp['geoname_id'];
            $country_geo_id = empty($temp['registered_country_geoname_id']) ? null : (int)$temp['registered_country_geoname_id'];
            $postal_code = empty($temp['postal_code']) ? null : $temp['postal_code'];
            $latitude = empty($temp['latitude']) ? null : (double)$temp['latitude'];
            $longitude = empty($temp['longitude']) ? null : (double)$temp['longitude'];
            $radius = empty($temp['radius']) ? null : (int)$temp['radius'];

            list($geo_id,$continent_id,$country_id,$region_id,$city_id,$timezone_id)=self::get_geo_data((int)$temp['geoname_id']);

            if(!empty($geo_id)){

                if(!empty($city_id))
                    self::update_city_place($city_id,$postal_code,$latitude,$longitude);

                $geo_ip_id=self::isset_geo_ip($network);

                if(empty($geo_ip_id))
                    self::add_geo_ip($geo_id,$country_geo_id,$network,$temp['ip_start_long'],$temp['ip_finish_long'],$postal_code,$latitude,$longitude,$radius);
                else
                    self::update_geo_ip($geo_ip_id,$geo_id,$country_geo_id,$network,$temp['ip_start_long'],$temp['ip_finish_long'],$postal_code,$latitude,$longitude,$radius);

            }

        }

        fclose($file_object);

        return true;

    }

    /**
     * set file city list
     */
    private static function set_file_city_list(){

        foreach(self::$file_city_name_list as $lang => $file_name){

            $file_object =fopen(self::$dir.'/'.$file_name,"r");
            $cols_name_list = mb_split(';',preg_replace('/,(?=(?:[^"]*$)|(?:[^"]*"[^"]*"[^"]*)*$)/x',';',trim(fgets($file_object))));

            $n=0;

            while(!feof($file_object)){

                $row=trim(fgets($file_object));

                if(empty($row))
                    break;

                $value_list = mb_split(';',str_replace('"','',$row));
                $temp = [];

                if(count($value_list)!=count($cols_name_list)){

                    $value_list = mb_split(';',preg_replace('/,(?=(?:[^"]*$)|(?:[^"]*"[^"]*"[^"]*)*$)/x',';',$row));

                    if(count($value_list)!=count($cols_name_list))
                        break;

                }

                foreach($value_list as $index => $value){

                    $key =trim($cols_name_list[$index]);
                    $value =str_replace('"','',trim($value));

                    $temp[$key] = $value;

                }

                $geo_id = null;

                list($geo_id,$continent_id,$country_id,$region_id,$city_id,$timezone_id)=self::get_geo_data((int)$temp['geoname_id']);

                if(empty($geo_id)){

                    $continent_id = empty($temp['continent_name']) ? null : self::get_continent_id($lang,strtolower($temp['continent_code']),$temp['continent_name']);
                    $country_id = empty($temp['country_name']) ? null : self::get_country_id($lang,$continent_id,strtolower($temp['country_iso_code']),$temp['country_name']);
                    $region_id = empty($temp['subdivision_1_name']) ? null : self::get_region_id($lang,$continent_id,$country_id,strtolower($temp['subdivision_1_iso_code']),$temp['subdivision_1_name']);
                    $timezone_id = empty($temp['time_zone']) ? null : self::get_timezone_id($temp['time_zone']);
                    $city_id = empty($temp['city_name']) ? null : self::get_city_id($lang,$continent_id,$country_id,$region_id,$timezone_id,$temp['city_name']);

                    if(!empty($temp['geoname_id']))
                        self::get_geo_id((int)$temp['geoname_id'],$continent_id,$country_id,$region_id,$city_id,$timezone_id);

                }
                else{

                    if(!empty($continent_id))
                        self::update_continent($continent_id,$lang,$temp['continent_name']);

                    if(!empty($country_id))
                        self::update_country($country_id,$lang,$temp['country_name']);

                    if(!empty($region_id))
                        self::update_region($region_id,$lang,$temp['subdivision_1_name']);

                    if(!empty($city_id))
                        self::update_city($city_id,$lang,$temp['city_name']);

                }

                $n++;

            }

            fclose($file_object);

        }

    }

    /**
     * @return bool
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    private static function set(){

        if(self::isset_file_list()){

            self::set_file_city_list();
            self::set_file_ip4();

            return true;

        }

        return false;

    }

    /**
     * @return bool
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function init(){

        return self::set();

    }

}