<?php

namespace Core\Module\Geo;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;
use Core\Module\Lang\LangConfig;

class CityLocalization{

    /** @var int */
    public static $city_localization_id;

    /** @var int */
    public static $lang_id;

    /** @var string */
    public static $city_name;

    /**
     * Reset default data
     * @return bool
     */
    public static function reset_data(){

        self::$city_localization_id = null;
        self::$lang_id = null;
        self::$city_name = null;

        return true;

    }

    /**
     * @param int|null $city_localization_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_city_localization_id(int $city_localization_id = null){

        if(empty($city_localization_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'City localization ID is empty'
            );

            throw new ParametersException($error);

        }

        return Db::isset_row_id($city_localization_id,'_city_localization',0);

    }

    /**
     * @param int|null $city_id
     * @param int|null $lang_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_city_localization(int $city_id = null, int $lang_id = null){

        $error_info_list = [];

        if(empty($city_id)) $error_info_list[] = 'City ID is empty';

        if(empty($lang_id)) $error_info_list[] = 'Lang ID is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $where_list = array('city_id' => $city_id,
            'lang_id' => $lang_id
        );

        return Db::isset_row('_city_localization',0,$where_list);

    }

    /**
     * @param int|null $city_localization_id
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_city_name_from_city_localization_id(int $city_localization_id = null){

        if(empty($city_localization_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'City localization ID is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('name'),
            'table' => '_city_localization',
            'where' => array('id' => $city_localization_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0]['name'];

    }

    /**
     * @param int|null $city_id
     * @param int|null $lang_id
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_city_name(int $city_id = null, int $lang_id = null){

        $error_info_list = [];

        if(empty($city_id)) $error_info_list[] = 'City ID is empty';

        if(empty($lang_id)) $error_info_list[] = 'Lang ID is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('name'),
            'table' => '_city_localization',
            'where' => array('city_id' => $city_id,
                'lang_id' => $lang_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0]['name'];

    }

    /**
     * @param string|null $city_name
     * @param int|null $lang_id
     * @return int|null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_city_id(string $city_name = null, int $lang_id = null){

        $error_info_list = [];

        if(empty($city_name)) $error_info_list[] = 'City name is empty';

//        if(empty($lang_id))
//            $error_info_list[] = 'Lang ID is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('id'),
            'table' => '_city_localization',
            'where' => array('name' => $city_name, 'type' => 0),
            'limit' => 1
        );

        if(!is_null($lang_id)) $q['where']['lang_id'] = $lang_id;

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0]['id'];

    }

    /**
     * @param array $city_name_list
     * @param int|null $lang_id
     * @return array
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_city_id_list_from_name_list(array $city_name_list = [],int $lang_id = null){

        $error_info_list = [];

        if(count($city_name_list) === 0)
            $error_info_list[] = 'City name is empty';

//        if(empty($lang_id))
//            $error_info_list[] = 'Lang ID is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('city_id',
                'name'),
            'table' => '_city_localization',
            'where' => array('name' => $city_name_list, 'type' => 0),
            'limit' => 1
        );

        if(!is_null($lang_id)) $q['where']['lang_id'] = $lang_id;

        $r = Db::select($q);

        if(count($r) === 0) return [];

        $list = [];

        foreach($r as $row)
            $list[$row['city_id']] = $row['name'];

        return $list;

    }

    /**
     * @param array $city_id_list
     * @param int|null $lang_id
     * @return array
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_city_id_list_from_city_id_list(array $city_id_list = [],int $lang_id = null){

        $error_info_list = [];

        if(count($city_id_list) === 0)
            $error_info_list[] = 'City ID list is empty';

//        if(empty($lang_id))
//            $error_info_list[] = 'Lang ID is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('city_id',
                'name'),
            'table' => '_city_localization',
            'where' => array('city_id' => $city_id_list,
                'type' => 0
            )
        );

        if(!is_null($lang_id)) $q['where']['lang_id'] = $lang_id;

        $r = Db::select($q);

        if(count($r) === 0) return [];

        $list = [];

        foreach($r as $row)
            $list[$row['city_id']] = $row['name'];

        return $list;

    }

    /**
     * @param string|null $city_name
     * @param int|null $lang_id
     * @return int|null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_city_id_from_name(string $city_name = null, int $lang_id = null){

        $error_info_list = [];

        if(empty($city_name)) $error_info_list[] = 'City name is empty';

//        if(empty($lang_id))
//            $error_info_list[] = 'Lang ID is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('city_id'),
            'table' => '_city_localization',
            'where' => array('name' => [
                    'transform' => 'lower',
                    'value' => $city_name
                ], 'type' => 0),
            'limit' => 1
        );

        if(!is_null($lang_id)) $q['where']['lang_id'] = $lang_id;

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0]['city_id'];

    }

    /**
     * @param int|null $city_id
     * @param int|null $lang_id
     * @param string|null $city_name
     * @return mixed
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function add_city_name(int $city_id = null, int $lang_id = null, string $city_name = null){

        $error_info_list = [];

        if(empty($city_id)) $error_info_list[] = 'City ID is empty';

        if(empty($lang_id)) $error_info_list[] = 'Lang ID is empty';

        if(empty($city_name)) $error_info_list[] = 'City name is empty';
        else if(!CityValidation::is_valid_city_name($city_name)) $error_info_list[] = 'City name is not valid';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $q = array('table' => '_city_localization',
            'values' => array('city_id' => $city_id,
                'lang_id' => $lang_id,
                'name' => $city_name,
                'date' => 'NOW()'
            )
        );

        $r = Db::insert($q);

        if(count($r) === 0){

            $error = array('title' => 'DB query problem',
                'info' => 'City was not added'
            );

            throw new DbQueryException($error);

        }

        return $r[0]['id'];

    }

    /**
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_city_name_default(){

        if(empty(City::$city_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Default city ID is empty'
            );

            throw new ParametersException($error);

        }

        if(!empty(self::$city_localization_id)) return self::get_city_name_from_city_localization_id(self::$city_localization_id);
        else{

            if(empty(self::$lang_id))
                self::set_lang_id_default(LangConfig::$lang_id_default);

            return self::get_city_name(City::$city_id, self::$lang_id);

        }

    }

    /**
     * @param int|null $city_localization_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_city_localization_id(int $city_localization_id = null){

        if(empty($city_localization_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'City localization ID is empty'
            );

            throw new ParametersException($error);

        }

        if(!Db::pseudo_delete_from_id($city_localization_id,'_city_localization',0)){

            $error = array('title' => 'DB query problem',
                'info' => 'City was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $city_id
     * @param int|null $lang_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_city_localization(int $city_id = null, int $lang_id = null){

        if(empty($city_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'City ID is empty'
            );

            throw new ParametersException($error);

        }

        $where_list = array('city_id' => $city_id
        );

        if(!empty($lang_id)) $where_list['lang_id'] = $lang_id;

        if(!Db::pseudo_delete_from_where_list('_city_localization',0,$where_list)){

            $error = array('title' => 'DB query problem',
                'info' => 'City was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $city_localization_id
     * @return bool
     */
    public static function set_city_localization_id_default(int $city_localization_id = null){

        self::$city_localization_id = empty($city_localization_id) ? null : $city_localization_id;

        return true;

    }

    /**
     * @param int|null $lang_id
     * @return bool
     */
    public static function set_lang_id_default(int $lang_id = null){

        self::$lang_id = empty($lang_id) ? null : $lang_id;

        return true;

    }

    /**
     * @param string|null $city_name
     * @return bool
     */
    public static function set_city_name_default(string $city_name = null){

        self::$city_name = empty($city_name) ? null : $city_name;

        return true;

    }

}
