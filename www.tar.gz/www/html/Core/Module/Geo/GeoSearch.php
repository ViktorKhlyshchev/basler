<?php

namespace Core\Module\Geo;

use Core\Module\Db\Db;
use Core\Module\Exception\ParametersException;
use Common\Modules\IpConvert; # use Core\Module\Ip\IpConvert;

class GeoSearch {

    private static $dir ='Core/Resources/Localization';
    private static $file_ip4_name ='GeoLite2-City-Blocks-IPv4.csv';
    private static $file_ip6_name ='GeoLite2-City-Blocks-IPv6.csv';

    private static $file_city_name_list = array('ru' => 'GeoLite2-City-Locations-ru.csv',
        'de' => 'GeoLite2-City-Locations-de.csv',
        'en' => 'GeoLite2-City-Locations-en.csv',
        'es' => 'GeoLite2-City-Locations-es.csv',
        'fr' => 'GeoLite2-City-Locations-fr.csv',
        'ja' => 'GeoLite2-City-Locations-ja.csv',
        'pt' => 'GeoLite2-City-Locations-pt.csv',
        'zh' => 'GeoLite2-City-Locations-zh.csv'
    );

    private static function get_geo_data(int $geo_id = null){
        if(empty($geo_id)){
            $error = [
                'title' => ParametersException::$title,
                'info' => 'Geo ID is empty'
            ];
            throw new ParametersException($error);
        }
        $q = array('select' => array(
                 array('column' => 'id'),
                 array('column' => 'continent_id'),
                 array('column' => 'country_id'),
                 array('column' => 'region_id'),
                 array('column' => 'city_id'),
                 array('column' => 'timezone_id')
            ),
            'table' => '_geo',
            'where' => array(
                 array('column' => 'id',
                    'value' => $geo_id,
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'limit' => 1
        );
        $r = Db::select($q);
        if(count($r) === 0) return array(
                null,
                null,
                null,
                null,
                null,
                null
            );
        else
            return array(
                $r[0]['id'],
                $r[0]['continent_id'],
                $r[0]['country_id'],
                $r[0]['region_id'],
                $r[0]['city_id'],
                $r[0]['timezone_id']
            );
    }

    public static function search_geo_id_from_ipv4(int $serach_geo_id = null){
        $file_object=fopen(self::$dir.'/'.self::$file_ip4_name,"r");
        $cols_name_list = mb_split(",",trim(fgets($file_object)));
        $row_index=0;
        while(!feof($file_object)){
            $value_list = mb_split(",",trim(fgets($file_object)));
            $temp = [];
            $row_index++;
            foreach($value_list as $index => $value){
                $key =trim($cols_name_list[$index]);
                $value =trim($value);
                switch($key){
                    case 'network':{
                        if(!empty($value)){
                            list($ip_start,$ip_finish)=IpConvert::get_cidr_to_ip_range($value);
                            $temp['ip_start'] = $ip_start;
                            $temp['ip_finish'] = $ip_finish;
                            $temp['ip_start_long'] =ip2long($ip_start);
                            $temp['ip_finish_long'] =ip2long($ip_finish);
                            $temp[$key] = $value;
                        }
                        break;
                    }
                    default:{
                        $temp[$key] = $value;
                        break;
                    }
                }
            }
            $geo_id = empty($temp['geoname_id']) ? null : (int)$temp['geoname_id'];
            if((int)$geo_id == (int)$serach_geo_id){
                $network = $temp['network'];
                $country_geo_id = empty($temp['registered_country_geoname_id']) ? null : (int)$temp['registered_country_geoname_id'];
                $postal_code = empty($temp['postal_code']) ? null : $temp['postal_code'];
                $latitude = empty($temp['latitude']) ? null : (double)$temp['latitude'];
                $longitude = empty($temp['longitude']) ? null : (double)$temp['longitude'];
                $radius = empty($temp['radius']) ? null : (int)$temp['radius'];
                list($geo_id,$continent_id,$country_id,$region_id,$city_id,$timezone_id)=self::get_geo_data((int)$temp['geoname_id']);
                echo $geo_id.' '.(int)$temp['geoname_id'].' '.(int)$temp['registered_country_geoname_id']."\n";
                if((int)$temp['geoname_id'] != (int)$geo_id){
                    echo 'CSV geo_name_id: '.$temp['geoname_id']."\n";
                    echo 'DB geo_name_id: '.$geo_id."\n";
                    print_r($temp);
                    die;
                }
            }
        }
        fclose($file_object);
        echo 'complete: '.$row_index."\n";
        echo 'search do not give result';
        return true;
    }
}