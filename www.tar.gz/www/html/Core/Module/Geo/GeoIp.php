<?php

namespace Core\Module\Geo;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class GeoIp{

    /** @var int */
    public static $geo_ip_id;

    /** @var string */
    public static $geo_ip_network;

    /** @var string */
    public static $postal_code;

    /** @var int */
    public static $ip_start_long;

    /** @var int */
    public static $ip_finish_long;

    /** @var double */
    public static $latitude;

    /** @var double */
    public static $longitude;

    /** @var int */
    public static $radius;

    /**
     * Reset default data
     * @return bool
     */
    public static function reset_data(){

        self::$geo_ip_id = null;
        self::$postal_code = null;
        self::$latitude = null;
        self::$longitude = null;
        self::$radius = null;

        return true;

    }

    /**
     * @param int|null $geo_ip_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_geo_ip_id(int $geo_ip_id = null){

        if(empty($geo_ip_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Geo IP ID is empty'
            );

            throw new ParametersException($error);

        }

        return Db::isset_row_id($geo_ip_id,'_geo_ip',0);

    }

    /**
     * @param int|null $geo_ip_id
     * @return array|null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_geo_ip_data(int $geo_ip_id = null){

        if(empty($geo_ip_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Geo IP ID is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('geo_id',
                'country_geo_id',
                'network',
                'ip_start_long',
                'ip_finish_long',
                'postal_code',
                'latitude',
                'longitude',
                'radius'),
            'table' => '_geo_ip',
            'where' => array('id' => $geo_ip_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return array('geo_id' => $r[0]['geo_id'],
            'country_geo_id' => $r[0]['country_geo_id'],
            'network' => $r[0]['network'],
            'ip_start_long' => $r[0]['ip_satrt_long'],
            'ip_finish_long' => $r[0]['ip_finish_long'],
            'postal_code' => $r[0]['postal_code'],
            'latitude' => $r[0]['latitude'],
            'longitude' => $r[0]['longitude'],
            'radius' => $r[0]['radius']
        );

    }

    /**
     * @param string|null $ip_address
     * @return array|null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_geo_ip_data_from_ip_address(string $ip_address = null){

        if(empty($ip_address)){

            $error = array('title' => 'Parameters problem',
                'info' => 'IP address is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('id',
                'geo_id',
                'country_geo_id',
                'network',
                'ip_start_long',
                'ip_finish_long',
                'postal_code',
                'latitude',
                'longitude',
                'radius'),
            'table' => '_geo_ip',
            'where' => array(
                 array('column' => 'network',
                    'method' => '>>=',
                    'value' => $ip_address
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return array('geo_id' => $r[0]['geo_id'],
            'geo_ip_id' => $r[0]['id'],
            'country_geo_id' => $r[0]['country_geo_id'],
            'network' => $r[0]['network'],
            'ip_start_long' => $r[0]['ip_start_long'],
            'ip_finish_long' => $r[0]['ip_finish_long'],
            'postal_code' => $r[0]['postal_code'],
            'latitude' => $r[0]['latitude'],
            'longitude' => $r[0]['longitude'],
            'radius' => $r[0]['radius']
        );

    }

    /**
     * @param int|null $ip_address_long
     * @return array|null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_geo_ip_data_from_ip_address_long(int $ip_address_long = null){

        if(empty($ip_address_long)){

            $error = array('title' => 'Parameters problem',
                'info' => 'IP address long is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('id',
                'geo_id',
                'country_geo_id',
                'network',
                'ip_start_long',
                'ip_finish_long',
                'postal_code',
                'latitude',
                'longitude',
                'radius'),
            'table' => '_geo_ip',
            'where' => array(
                 array('column' => 'ip_start_long',
                    'method' => '<=',
                    'value' => $ip_address_long
                ),
                 array('column' => 'ip_finish_long',
                    'method' => '>=',
                    'value' => $ip_address_long
                ),
                 array('column' => 'type',
                    'value' => 0
                )
            ),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return array('geo_id' => $r[0]['geo_id'],
            'geo_ip_id' => $r[0]['id'],
            'country_geo_id' => $r[0]['country_geo_id'],
            'network' => $r[0]['network'],
            'ip_start_long' => $r[0]['ip_start_long'],
            'ip_finish_long' => $r[0]['ip_finish_long'],
            'postal_code' => $r[0]['postal_code'],
            'latitude' => $r[0]['latitude'],
            'longitude' => $r[0]['longitude'],
            'radius' => $r[0]['radius']
        );

    }

    /**
     * @param int|null $geo_ip_id
     * @return array|null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_geo_coordinates(int $geo_ip_id = null){

        if(empty($geo_ip_id)){

            $error = array('title' => 'Paraemters problem',
                'info' => 'Geo IP ID is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('latitude',
                'longitude'),
            'table' => '_geo_ip',
            'where' => array('id' => $geo_ip_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return array('latitiude' => $r[0]['latitude'],
            'longitude' => $r[0]['longitude']
        );

    }

    /**
     * @param int|null $geo_ip_id
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_geo_network(int $geo_ip_id = null){

        if(empty($geo_ip_id)){

            $error = array('title' => 'Paraemters problem',
                'info' => 'Geo IP ID is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('network'),
            'table' => '_geo_ip',
            'where' => array('id' => $geo_ip_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0]['network'];

    }

    /**
     * @param int|null $geo_id
     * @param int|null $country_geo_id
     * @param string|null $network
     * @param int|null $ip_start_long
     * @param int|null $ip_finish_long
     * @param string|null $postal_code
     * @param float|null $latitude
     * @param float|null $longitude
     * @param int|null $radius
     * @return mixed
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function add_geo_ip(int $geo_id = null, int $country_geo_id = null, string $network = null, int $ip_start_long = null, int $ip_finish_long = null, string $postal_code = null, float $latitude = null, float $longitude = null, int $radius = null){

        $error_info_list = [];

        if(empty($geo_id)) $error_info_list[] = 'Geo ID is empty';

        if(empty($network)) $error_info_list[] = 'Network is empty';

        if(empty($ip_start_long)) $error_info_list[] = 'IP long start is empty';

        if(empty($ip_finish_long)) $error_info_list[] = 'IP long finish is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $q = array('table' => '_geo_ip',
            'values' => array('geo_id' => $geo_id,
                'country_geo_id' => $country_geo_id,
                'network' => $network,
                'ip_start_long' => $ip_start_long,
                'ip_finish_long' => $ip_finish_long,
                'postal_code' => $postal_code,
                'latitude' => $latitude,
                'longitude' => $longitude,
                'radius' => $radius
            )
        );

        $r = Db::insert($q);

        if(count($r) === 0){

            $error = array('title' => 'DB query problem',
                'info' => 'Geo IP was not added'
            );

            throw new DbQueryException($error);

        }

        return $r[0]['id'];

    }

    /**
     * @param int|null $geo_ip_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_geo_ip_id(int $geo_ip_id = null){

        if(empty($geo_ip_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Geo IP ID is empty'
            );

            throw new ParametersException($error);

        }

        if(!Db::pseudo_delete_from_id($geo_ip_id,'_geo_ip',0)){

            $error = array('title' => 'DB query problem',
                'info' => 'Geo IP was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param array $geo_ip_data
     * @return bool
     */
    public static function set_geo_ip_data_default(array $geo_ip_data = []){

        if(!empty($geo_ip_data['geo_id']))
            Geo::set_geo_id_default($geo_ip_data['geo_id']);

        if(!empty($geo_ip_data['country_geo_id']))
            Geo::set_country_geo_id_default($geo_ip_data['country_geo_id']);

        if(!empty($geo_ip_data['geo_ip_id']))
            self::set_geo_ip_id_default($geo_ip_data['geo_ip_id']);

        if(!empty($geo_ip_data['network']))
            self::set_geo_ip_network_default($geo_ip_data['network']);

        if(!empty($geo_ip_data['ip_start_long']))
            self::set_ip_start_long_default($geo_ip_data['ip_start_long']);

        if(!empty($geo_ip_data['ip_finish_long']))
            self::set_ip_finish_long_default($geo_ip_data['ip_finish_long']);

        if(!empty($geo_ip_data['postal_code']))
            self::set_postal_code_default($geo_ip_data['postal_code']);

        if(!empty($geo_ip_data['latitude']))
            self::set_latitude_default($geo_ip_data['latitude']);

        if(!empty($geo_ip_data['longitude']))
            self::set_longitude_default($geo_ip_data['longitude']);

        if(!empty($geo_ip_data['latitude']))
            self::set_latitude_default($geo_ip_data['latitude']);

        if(!empty($geo_ip_data['radius']))
            self::set_radius_default($geo_ip_data['radius']);

        return true;

    }

    /**
     * @param int|null $geo_ip_id
     * @return bool
     */
    public static function set_geo_ip_id_default(int $geo_ip_id = null){

        self::$geo_ip_id = empty($geo_ip_id) ? null : $geo_ip_id;

        return true;

    }

    /**
     * @param string|null $geo_ip_network
     * @return bool
     */
    public static function set_geo_ip_network_default(string $geo_ip_network = null){

        self::$geo_ip_network = empty($geo_ip_network) ? null : $geo_ip_network;

        return true;

    }

    /**
     * @param string|null $postal_code
     * @return bool
     */
    public static function set_postal_code_default(string $postal_code = null){

        self::$postal_code = empty($postal_code) ? null : $postal_code;

        return true;

    }

    /**
     * @param int|null $ip_start_long
     * @return bool
     */
    public static function set_ip_start_long_default(int $ip_start_long = null){

        self::$ip_start_long = empty($ip_start_long) ? null : $ip_start_long;

        return true;

    }

    /**
     * @param int|null $ip_finish_long
     * @return bool
     */
    public static function set_ip_finish_long_default(int $ip_finish_long = null){

        self::$ip_finish_long = empty($ip_finish_long) ? null : $ip_finish_long;

        return true;

    }

    /**
     * @param float|null $latitude
     * @return bool
     */
    public static function set_latitude_default(float $latitude = null){

        self::$latitude = empty($latitude) ? null : $latitude;

        return true;

    }

    /**
     * @param float|null $longitude
     * @return bool
     */
    public static function set_longitude_default(float $longitude = null){

        self::$longitude = empty($longitude) ? null : $longitude;

        return true;

    }

    /**
     * @param int|null $radius
     * @return bool
     */
    public static function set_radius_default(int $radius = null){

        self::$radius = empty($radius) ? null : $radius;

        return true;

    }

}