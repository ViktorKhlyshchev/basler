<?php

namespace Core\Module\Geo;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class Region{

    /** @var int */
    public static $region_id;

    /** @var string */
    public static $region_code;

    /**
     * Reset default data
     * @return bool
     */
    public static function reset_data(){

        self::$region_id = null;
        self::$region_code = null;

        return true;

    }

    /**
     * @param int|null $region_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_region_id(int $region_id = null){

        if(empty($region_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Region ID is empty'
            );

            throw new ParametersException($error);

        }

        return Db::isset_row_id($region_id,'_region',0);

    }

    /**
     * @param string|null $region_code
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_region_code(string $region_code = null){

        if(empty($region_code)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Region code is empty'
            );

            throw new ParametersException($error);

        }

        $where_list = array('code' => $region_code
        );

        return Db::isset_row('_region',0,$where_list);

    }

    /**
     * @param int|null $continent_id
     * @param int|null $country_id
     * @param string|null $region_code
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_region_id(int $continent_id = null, int $country_id = null, string $region_code = null){

        $error_info_list = [];

        if(empty($continent_id)) $error_info_list[] = 'Continent ID is empty';

        if(empty($country_id)) $error_info_list[] = 'Country ID is empty';

        if(empty($region_code)) $error_info_list[] = 'Region code is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $where_list = array('continent_id' => $continent_id,
            'country_id' => $country_id,
            'code' => $region_code
        );

        return Db::get_row_id('_region',0,$where_list);

    }

    /**
     * @return int|null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_region_id_default(){

        if(!empty(self::$region_id)) return self::$region_id;

        $error_info_list = [];

        if(empty(Continent::$continent_id)) $error_info_list[] = 'Default continent ID is empty';

        if(empty(Country::$country_id)) $error_info_list[] = 'Default country ID is empty';

        if(empty(self::$region_code)) $error_info_list[] = 'Defulat region code is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $region_id=self::get_region_id(Continent::$continent_id,Country::$country_id, self::$region_code);

        if(empty($region_id)) return null;

        self::set_region_id_default($region_id);

        return $region_id;

    }

    /**
     * @param int|null $continent_id
     * @param int|null $country_id
     * @param string|null $region_code
     * @return mixed
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function add_region(int $continent_id = null, int $country_id = null, string $region_code = null){

        $error_info_list = [];

        if(empty($continent_id)) $error_info_list[] = 'Continent ID is empty';

        if(empty($country_id)) $error_info_list[] = 'Country ID is empty';

        if(empty($region_code)) $error_info_list[] = 'Region code is empty';
        else if(!RegionValidation::is_valid_region_code($region_code)) $error_info_list[] = 'Region code is not valid';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $q = array('table' => '_region',
            'values' => array('continent_id' => $continent_id,
                'country_id' => $country_id,
                'code' => $region_code,
                'date' => 'NOW()'
            )
        );

        $r = Db::insert($q);

        if(count($r) === 0){

            $error = array('title' => 'DB query problem',
                'info' => 'Region was not added'
            );

            throw new DbQueryException($error);

        }

        return $r[0]['id'];

    }

    /**
     * @param int|null $region_id
     * @param bool $is_need_remove_region_localization
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_region_id(int $region_id = null, bool $is_need_remove_region_localization=true){

        if(empty($region_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Region ID is empty'
            );

            throw new ParametersException($error);

        }

        if($is_need_remove_region_localization)
            if(!RegionLocalization::remove_region_localization($region_id)){

                $error = array('title' => 'DB query problem',
                    'info' => 'Region localization was not removed'
                );

                throw new DbQueryException($error);

            }

        if(!Db::pseudo_delete_from_id($region_id,'_region',0)){

            $error = array('title' => 'DB query problem',
                'info' => 'Region was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $continent_id
     * @param int|null $country_id
     * @param string|null $region_code
     * @param bool $is_need_remove_region_localization
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_region(int $continent_id = null, int $country_id = null, string $region_code = null, bool $is_need_remove_region_localization=true){

        $error_info_list = [];

        if(empty($continent_id)) $error_info_list[] = 'Continent ID is empty';

        if(empty($country_id)) $error_info_list[] = 'Country ID is empty';

        if(empty($region_code)) $error_info_list[] = 'Region code is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

//        if($is_need_remove_region_localization){
//
//            $region_id=self::get_region_id($continent_id,$country_id,$region_code);
//
//            if(!empty($region_id))
//
//        }

        $where_list = array('continent_id' => $continent_id,
            'country_id' => $country_id,
            'code' => $region_code
        );

        if($is_need_remove_region_localization){

            $region_id=self::get_region_id($continent_id,$country_id,$region_code);

            if(!empty($region_id))
                if(!RegionLocalization::remove_region_localization($region_id)){

                    $error = array('title' => 'DB query problem',
                        'info' => 'Region localization was not removed'
                    );

                    throw new DbQueryException($error);

                }


        }

        if(!Db::pseudo_delete_from_where_list('_region',0,$where_list)){

            $error = array('title' => 'DB query problem',
                'info' => 'Region was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $region_id
     * @return bool
     */
    public static function set_region_id_default(int $region_id = null){

        self::$region_id = empty($region_id) ? null : $region_id;

        return true;

    }

    /**
     * @param string|null $region_code
     * @return bool
     */
    public static function set_region_code_default(string $region_code = null){

        self::$region_code = empty($region_code) ? null : $region_code;

        return true;

    }

}