<?php

namespace Core\Module\Geo;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;
use Core\Module\Timezone\Timezone;

class Geo{

    /** @var int */
    public static $geo_id;

    /** @var int */
    public static $country_geo_id;

    /**
     * Reset default data
     * @return bool
     */
    public static function reset_data(){

        self::$geo_id = null;
        self::$country_geo_id = null;

        return true;

    }

    /**
     * @param int|null $geo_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_geo_id(int $geo_id = null){

        if(empty($geo_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Geo ID is empty'
            );

            throw new ParametersException($error);

        }

        return Db::isset_row_id($geo_id,'_geo',0);

    }

    /**
     * @param int|null $continent_id
     * @param int|null $country_id
     * @param int|null $region_id
     * @param int|null $city_id
     * @param int|null $timezone_id
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_geo_id(int $continent_id = null, int $country_id = null, int $region_id = null, int $city_id = null, int $timezone_id = null){

        if(empty($continent_id)&&empty($country_id)&&empty($region_id)&&empty($city_id)&&empty($timezone_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'All parameters are empty'
            );

            throw new ParametersException($error);

        }

        $where_list = [];

        if(!empty($continent_id)) $where_list['continent_id'] = $continent_id;

        if(!empty($country_id)) $where_list['country_id'] = $country_id;

        if(!empty($region_id)) $where_list['region_id'] = $region_id;

        if(!empty($city_id)) $where_list['city_id'] = $city_id;

        if(!empty($timezone_id)) $where_list['timezone_id'] = $timezone_id;

        if(count($where_list) === 0) return null;

        return Db::get_row_id('_geo',0,$where_list);

    }

    /**
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_geo_id_default(){

        if(empty(Continent::$continent_id)&&empty(Country::$country_id)&&empty(Region::$region_id)&&empty(City::$city_id)&&empty(Timezone::$timezone_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'All default parameters are empty'
            );

            throw new ParametersException($error);

        }

        return self::get_geo_id(Continent::$continent_id,Country::$country_id,Region::$region_id,City::$city_id,Timezone::$timezone_id);

    }

    /**
     * @param int|null $geo_id
     * @return array|null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_geo_data(int $geo_id = null){

        if(empty($geo_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Geo ID is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('continent_id',
                'country_id',
                'region_id',
                'city_id',
                'timezone_id'),
            'table' => '_geo',
            'where' => array('id' => $geo_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return array('continent_id' => $r[0]['continent_id'],
            'country_id' => $r[0]['country_id'],
            'region_id' => $r[0]['region_id'],
            'city_id' => $r[0]['city_id'],
            'timezone_id' => $r[0]['timezone_id']
        );

    }

    /**
     * @param int|null $continent_id
     * @param int|null $country_id
     * @param int|null $region_id
     * @param int|null $city_id
     * @param int|null $timezone_id
     * @return mixed
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function add_geo(int $continent_id = null, int $country_id = null, int $region_id = null, int $city_id = null, int $timezone_id = null){

        if(empty($continent_id)&&empty($country_id)&&empty($region_id)&&empty($city_id)&&empty($timezone_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'All parameters are empty'
            );

            throw new ParametersException($error);

        }

        $value_list = [];

        if(!empty($continent_id)) $value_list['continent_id'] = $continent_id;

        if(!empty($country_id)) $value_list['country_id'] = $country_id;

        if(!empty($region_id)) $value_list['region_id'] = $region_id;

        if(!empty($city_id)) $value_list['city_id'] = $city_id;

        if(!empty($timezone_id)) $value_list['timezone_id'] = $timezone_id;

        $q = array('table' => '_geo',
            'values' => $value_list
        );

        $r = Db::insert($q);

        if(count($r) === 0){

            $error = array('title' => 'DB query problem',
                'info' => 'Geo was not added'
            );

            throw new DbQueryException($error);

        }

        return $r[0]['id'];

    }

    /**
     * @param int|null $geo_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_geo_id(int $geo_id = null){

        if(empty($geo_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Geo ID is empty'
            );

            throw new ParametersException($error);

        }

        if(!Db::pseudo_delete_from_id($geo_id,'_geo',0)){

            $error = array('title' => 'DB query problem',
                'info' => 'Geo ID was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $geo_id
     * @return bool
     */
    public static function set_geo_id_default(int $geo_id = null){

        self::$geo_id = empty($geo_id) ? null : $geo_id;

        return true;

    }

    /**
     * @param int|null $country_geo_id
     * @return bool
     */
    public static function set_country_geo_id_default(int $country_geo_id = null){

        self::$country_geo_id = empty($country_geo_id) ? null : $country_geo_id;

        return true;

    }

    /**
     * @param array $geo_data
     * @return bool
     */
    public static function set_geo_data_default(array $geo_data = []){

        Continent::reset_data();
        Country::reset_data();
        Region::reset_data();
        City::reset_data();
        Timezone::reset_data();

        if(!empty($geo_data['continent_id']))
            Continent::set_continent_id_default($geo_data['continent_id']);

        if(!empty($geo_data['country_id']))
            Country::set_country_id_default($geo_data['country_id']);

        if(!empty($geo_data['region_id'])) region::set_region_id_default($geo_data['region_id']);

        if(!empty($geo_data['city_id']))
            City::set_city_id_default($geo_data['city_id']);

        if(!empty($geo_data['timezone_id']))
            Timezone::set_timezone_id_default($geo_data['timezone_id']);

        return true;

    }

}