<?php

namespace Core\Module\Geo;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;

class Continent{

    /** @var int */
    public static $continent_id;

    /** @var string */
    public static $continent_code;

    /**
     * Reset default data
     * @return bool
     */
    public static function reset_data(){

        self::$continent_id = null;
        self::$continent_code = null;

        return true;

    }

    /**
     * @param int|null $continent_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_continent_id(int $continent_id = null){

        if(empty($continent_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Continent ID is empty'
            );

            throw new ParametersException($error);

        }

        return Db::isset_row_id($continent_id,'_continent',0);

    }

    /**
     * @param int|null $continent_id
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_continent_code(int $continent_id = null){

        if(empty($continent_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Continent ID is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('code'),
            'table' => '_continent',
            'where' => array('id' => $continent_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0]['code'];

    }

    /**
     * @param string|null $continent_code
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_continent_id_from_continent_code(string $continent_code = null){

        if(empty($continent_code)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Continent code is empty'
            );

            throw new ParametersException($error);

        }

        if(!ContinentValidation::is_valid_continent_code($continent_code)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Continent code is not valid'
            );

            throw new ParametersException($error);

        }

        $where_list = array('code' => strtolower($continent_code)
        );

        $continent_id=Db::get_row_id('_continent',0,$where_list);

        if(empty($continent_id)) return null;

        return $continent_id;

    }

    /**
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_continent_id_from_continent_code_default(){

        if(!empty(self::$continent_id))
            self::$continent_id;

        if(empty(self::$continent_code)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Default continent code is empty'
            );

            throw new ParametersException($error);

        }

        $continent_id=self::get_continent_id_from_continent_code(self::$continent_code);

        self::set_continent_id_default($continent_id);

        return $continent_id;

    }

    /**
     * @param int|null $continent_id
     * @param bool $is_need_remove_continent_localization
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_continent_id(int $continent_id = null, bool $is_need_remove_continent_localization=true){

        if(empty($continent_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Continent ID is empty'
            );

            throw new ParametersException($error);

        }

        if($is_need_remove_continent_localization)
            if(!ContinentLocalization::remove_continent_localization($continent_id)){

                $error = array('title' => 'DB query problem',
                    'info' => 'Continent localization was not removed'
                );

                throw new DbQueryException($error);

            }

        if(!Db::pseudo_delete_from_id($continent_id,'_continent',0)){

            $error = array('title' => 'DB query problem',
                'info' => 'Continent ID was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $continent_id
     * @return bool
     */
    public static function set_continent_id_default(int $continent_id = null){

        self::$continent_id = empty($continent_id) ? null : $continent_id;

        return true;

    }

    /**
     * @param string|null $continent_code
     * @return bool
     */
    public static function set_continent_code_default(string $continent_code = null){

        self::$continent_code = empty($continent_code) ? null : $continent_code;

        return true;

    }

}