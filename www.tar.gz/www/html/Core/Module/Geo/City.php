<?php

namespace Core\Module\Geo;

use Core\Module\Db\Db;
use Core\Module\Exception\DbQueryException;
use Core\Module\Exception\ParametersException;
use Core\Module\Lang\LangConfig;

class City{

    /** @var string */
    public static $tn='_city';

    /** @var int */
    public static $city_id;

    /** @var string */
    public static $city_name;

    /** @var string */
    public static $city_postal_code;

    /** @var double */
    public static $city_latitude;

    /** @var double */
    public static $city_longitude;

    /**
     * Reset default data
     * @return bool
     */
    public static function reset_data(){

        self::$city_id = null;
        self::$city_name = null;
        self::$city_postal_code = null;
        self::$city_latitude = null;
        self::$city_longitude = null;

        return true;

    }

    /**
     * @param int|null $city_id
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function isset_city_id(int $city_id = null){

        if(empty($city_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'City ID is empty'
            );

            throw new ParametersException($error);

        }

        return Db::isset_row_id($city_id,'_city',0);

    }

    /**
     * @param int|null $city_id
     * @return null|string
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_city_postal_code_from_city_id(int $city_id = null){

        if(empty(self::$city_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'City ID is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('postal_code'),
            'table' => '_city',
            'where' => array('id' => $city_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        self::$city_postal_code = empty($r[0]['postal_code']) ? null : stripslashes($r[0]['postal_code']);

        return self::$city_postal_code;

    }

    /**
     * @param int|null $city_id
     * @return int|null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_country_id(int $city_id = null){

        if(empty($city_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'City ID is empty'
            );

            throw new ParametersException($error);

        }

        $q = [
            'select' => [
                'country_id'
            ],
            'table' => self::$tn,
            'where' => [
                'id' => $city_id,
                'type' => 0
            ],
            'limit' => 1
        ];

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0]['country_id'];

    }

    /**
     * @return null|string
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_city_postal_code_default(){

        if(!empty(self::$city_postal_code)) return self::$city_postal_code;

        if(empty(self::$city_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Default city ID is empty'
            );

            throw new ParametersException($error);

        }

        $city_postal_code=self::get_city_postal_code_from_city_id(self::$city_id);

        self::set_city_postal_code_default($city_postal_code);

        return $city_postal_code;

    }

    /**
     * @param int|null $city_id
     * @return null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_city_coordinate_from_city_id(int $city_id = null){

        if(empty($city_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'City ID is empty'
            );

            throw new ParametersException($error);

        }

        $q = array('select' => array('latitude',
                'longitude'),
            'table' => '_city',
            'where' => array('id' => $city_id, 'type' => 0),
            'limit' => 1
        );

        $r = Db::select($q);

        if(count($r) === 0) return null;

        return $r[0];

    }

    /**
     * @return array|null
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_city_coordinate_default(){

        if(!empty(self::$city_latitude)&&!empty(self::$city_longitude)) return array('latitude' => self::$city_latitude,
                'longitude' => self::$city_longitude
            );

        if(empty(self::$city_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Default city ID is empty'
            );

            throw new ParametersException($error);

        }

        $city_coordinate=self::get_city_coordinate_from_city_id(self::$city_id);

        self::set_city_latitude_default($city_coordinate['latitude']);
        self::set_city_longitude_default($city_coordinate['longitude']);

        return $city_coordinate;

    }

    /**
     * @param string|null $source
     * @return array
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_city_ids_from_city(string $source = null){

        $country_id = null;
        $city_id = null;
        $country = null;
        $city = null;
        $result = null;

        $list = mb_split(',',$source);

        if(count($list)==1){

            $city =trim($list[0]);
            $city_id =CityLocalization::get_city_id_from_name(mb_strtolower($city,'utf-8'));

            if(!empty($city_id)){

                $city =CityLocalization::get_city_name($city_id,LangConfig::$lang_id_default);
                $country_id =City::get_country_id($city_id);

                if(!empty($country_id))
                    $country=CountryLocalization::get_country_name($country_id,LangConfig::$lang_id_default);

                if(!empty($country_id)&&!empty($city_id))
                    $result = $country.', '.$city;
                else if(!empty($city_id))
                    $result = $city;
                else
                    return null;

            }
            else
                return null;

        }
        else{

            $country =trim($list[0]);
            $country_id =CountryLocalization::get_country_id_from_name(mb_strtolower($country,'utf-8'));

            $city =trim($list[1]);
            $city_id =CityLocalization::get_city_id_from_name(mb_strtolower($city,'utf-8'));

            if(!empty($country_id)) $country=CountryLocalization::get_country_name($country_id,LangConfig::$lang_id_default);

            if(!empty($city_id)) $city=CityLocalization::get_city_name($city_id,LangConfig::$lang_id_default);

            if(!empty($country_id)&&!empty($city_id)) $result = $country.', '.$city;
            else if(!empty($city_id)) $result = $city;
            else
                return null;

        }

        return [
            'country_id' => $country_id,
            'city_id' => $city_id,
            'country' => $country,
            'city' => $city,
            'result' => $result
        ];

    }

    /**
     * @param int|null $city_id
     * @param bool $is_need_remove_city_localization
     * @return bool
     * @throws DbQueryException
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PhpException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function remove_city_id(int $city_id = null, bool $is_need_remove_city_localization=true){

        if(empty($city_id)){

            $error = array('title' => 'Parameters problem',
                'info' => 'City ID is empty'
            );

            throw new ParametersException($error);

        }

        if($is_need_remove_city_localization)
            if(!CityLocalization::remove_city_localization($city_id)){

                $error = array('title' => 'DB query problem',
                    'info' => 'City localization was not removew'
                );

                throw new DbQueryException($error);

            }

        if(!Db::pseudo_delete_from_id($city_id,'_city',0)){

            $error = array('title' => 'DB query problem',
                'info' => 'City was not removed'
            );

            throw new DbQueryException($error);

        }

        return true;

    }

    /**
     * @param int|null $city_id
     * @return bool
     */
    public static function set_city_id_default(int $city_id = null){

        self::$city_id = empty($city_id) ? null : $city_id;

        return true;

    }

    /**
     * @param string|null $city_name
     * @return bool
     */
    public static function set_city_name_default(string $city_name = null){

        self::$city_name = empty($city_name) ? null : $city_name;

        return true;

    }

    /**
     * @param string|null $city_postal_code
     * @return bool
     */
    public static function set_city_postal_code_default(string $city_postal_code = null){

        self::$city_postal_code = empty($city_postal_code) ? null : $city_postal_code;

        return true;

    }

    /**
     * @param float|null $latitude
     * @return bool
     */
    public static function set_city_latitude_default(float $latitude = null){

        self::$city_latitude = empty($latitude) ? null : $latitude;

        return true;

    }

    /**
     * @param float|null $longitude
     * @return bool
     */
    public static function set_city_longitude_default(float $longitude = null){

        self::$city_longitude = empty($longitude) ? null : $longitude;

        return true;

    }

}