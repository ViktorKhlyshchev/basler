<?php

namespace Core\Module\Sqlite;

use Core\Module\Exception\ParametersException;

class Sqlite{

    /**
     * @param string|null $sqlite_path
     * @return \SQLite3
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function open_sqlite(string $sqlite_path = null){

        if(empty($sqlite_path)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Sqlite path is empty'
            );

            throw new ParametersException($error);

        }

        return new \SQLite3($sqlite_path);

    }

    /**
     * @param null $sqlite_object
     * @return mixed
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function close_sqlite($sqlite_object = null){

        if(empty($sqlite_object)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Sqlite object is empty'
            );

            throw new ParametersException($error);

        }

        return $sqlite_object->close();

    }

    /**
     * @param string|null $sqlite_path
     * @param null $data
     * @return string|null
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function get_escape_string(string $sqlite_path = null, $data = null){

        if(empty($sqlite_path)){

            $error = array('title' => 'Parameters problem',
                'info' => 'Sqlite object is empty'
            );

            throw new ParametersException($error);

        }

        $sqlite_object=self::open_sqlite($sqlite_path);

        $data = $sqlite_object->escapeString($data);

        self::close_sqlite($sqlite_object);

        return $data;

    }

    /**
     * @param string|null $sqlite_path
     * @param string|null $query
     * @return mixed
     * @throws ParametersException
     * @throws \Core\Module\Exception\DbParametersException
     * @throws \Core\Module\Exception\DbQueryException
     * @throws \Core\Module\Exception\DbQueryParametersException
     * @throws \Core\Module\Exception\DbValidationValueException
     * @throws \Core\Module\Exception\PathException
     * @throws \Core\Module\Exception\SystemException
     */
    public static function exec(string $sqlite_path = null, string $query = null){

        $error_info_list = [];

        if(empty($sqlite_path)) $error_info_list['sqlite_path'] = 'Sqlite path is empty';

        if(empty($query)) $error_info_list['query'] = 'Query is empty';

        if(count($error_info_list) > 0){

            $error = array('title' => 'Parameters problem',
                'info' => $error_info_list
            );

            throw new ParametersException($error);

        }

        $sqlite_object=self::open_sqlite($sqlite_path);

        $sqlite_object->exec(SqliteConfig::$begin_transaction);
        $sqlite_object->exec($query);
        $sqlite_object->exec(SqliteConfig::$commit);

        return self::close_sqlite($sqlite_object);

    }

}