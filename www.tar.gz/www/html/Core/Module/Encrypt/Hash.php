<?php

namespace Core\Module\Encrypt;

use Core\Modules\Json;

class Hash {

    public static function get_encode($data, string $type='sha1'){
        return hash($type, $data);
    }

    public static function get_sha1_encode($data){
        return self::get_encode($data);
    }

    public static function get_sha256_encode($data){
        return self::get_encode($data, 'sha256');
    }

    public static function get_sha384_encode($data){
        return self::get_encode($data, 'sha384');
    }

    public static function get_sha512_encode($data){
        return self::get_encode($data, 'sha512');
    }

    public static function get_md2_encode($data){
        return self::get_encode($data, 'md2');
    }

    public static function get_md4_encode($data){
        return self::get_encode($data, 'md4');
    }

    public static function get_md5_encode($data){
        return self::get_encode($data, 'md5');
    }

    public static function get_random_hash(string $type = 'sha1'){
        return self::get_encode(uniqid(rand(), true), $type);
    }

    public static function get_rcrc32(){
        return self::get_encode(mt_rand(), 'crc32');
    }

    public static function get_random_hash_from_data(array $data = [], string $type = 'sha1'){
        return self::get_encode(uniqid(Json::encode($data), true), $type);
    }
}