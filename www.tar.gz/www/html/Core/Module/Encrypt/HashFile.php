<?php

namespace Core\Module\Encrypt;

class HashFile {
    
    public static function get_encode(string $file_path,string $type='sha1'){
        return hash_file($type,$file_path);
    }
    
    public static function get_sha1_encode($file_path){
        return self::get_encode($file_path);
    }
    
    public static function get_sha256_encode($file_path){
        return self::get_encode($file_path,'sha256');
    }
    
    public static function get_sha384_encode($file_path){
        return self::get_encode($file_path,'sha384');
    }
    
    public static function get_sha512_encode($file_path){
        return self::get_encode($file_path,'sha512');
    }
    
    public static function get_md2_encode($file_path){
        return self::get_encode($file_path,'md2');
    }
    
    public static function md4_encode($file_path){
        return self::get_encode($file_path,'md4');
    }
    
    public static function get_md5_encode($file_path){
        return self::get_encode($file_path,'md5');
    }
}