<?php

namespace Core\Content\Error;

use Core\Module\Exception\PathException;
use Core\Module\Lang\Lang;
use Core\Module\Lang\LangConfig;

class ErrorContent {

    private static $lang_key_default = 'en';
    private static $lang_list = ['ru', 'en'];

    private static $code_list = [
        'bad_request' => 400,
        'unauthorized' => 401,
        'access_denied' => 403,
        'user_blocked' => 403,
        'user_removed' => 403,
        'forbidden' => 403,
        'not_found' => 404,
        'method_not_allowed' => 405,
        'unprocessable_entity' => 422,
        'server_error' => 500,
        'bad_nettopway' => 502,
        'service_unavailable' => 503,
        'unkonown_error' => 520,
    ];

    public static function bad_request(array $data = null){
        return self::get_error('bad_request', $data);
    }

    public static function unauthorized(array $data = null){
        return self::get_error('unauthorized', $data);
    }

    public static function access_denied(array $data = null){
        return self::get_error('access_denied', $data);
    }

    public static function user_blocked(array $data = null){
        return self::get_error('user_blocked', $data);
    }

    public static function user_removed(array $data = null){
        return self::get_error('user_removed', $data);
    }

    public static function forbidden(array $data = null){
        return self::get_error('forbidden', $data);
    }

    public static function not_found(array $data = null){
        return self::get_error('not_found', $data);
    }

    public static function method_not_allowed(array $data = null){
        return self::get_error('method_not_allowed', $data);
    }

    public static function unprocessable_entity(array $data = null){ # Unprocessable entity #1 # Unprocessable entity #
        return self::get_error('unprocessable_entity', $data);
    }

    public static function server_error(array $data = null){
        return self::get_error('server_error', $data);
    }

    public static function bad_nettopway(array $data = null){
        return self::get_error('bad_nettopway', $data);
    }

    public static function service_unavailable(array $data = null){
        return self::get_error('service_unavailable', $data);
    }

    public static function unkonown_error(array $data = null){
        return self::get_error('unkonown_error', $data);
    }

    public static function get_error(string $key = null, array $info = null){
        $data = array('code' => self::get_code($key),
            'title' => self::get_content($key)
        );
        if(!empty($info)){
            if(isset($info['title'])) unset($info['title']);
            $data['data'] = $info;
        }
        return $data;
    }

    public static function get_code(string $key = null){
        if(isset(self::$code_list[$key])) return self::$code_list[$key];
        return 0;
    }

    public static function get_content(string $key = null){ # pre(debug_backtrace());
        if(empty(Lang::$lang_key)){
            Lang::set_lang_id_default(LangConfig::$lang_id_default);
            Lang::set_lang_key_default(LangConfig::$lang_key_default);
        }
        if(array_search(Lang::$lang_key, self::$lang_list) !== false){
            $file_path = DR .'/Core/Content/Error/ErrorContent'.ucfirst(Lang::$lang_key).'.php';
            if(file_exists($file_path)) $class_name = '\Core\Content\Error\ErrorContent'.ucfirst(Lang::$lang_key);
        }
        if(empty($class_name)){ //  $file_path = DirConfig::$DR.'/Core/Content/Error/ErrorContent'.ucfirst(self::$lang_key_default).'.php';
            $file_path = DR .'/Core/Content/Error/ErrorContent'. ucfirst(self::$lang_key_default) .'.php';
            $class_name = '\Core\Content\Error\ErrorContent'. ucfirst(self::$lang_key_default);
            if(!file_exists($file_path)){
                $error = [
                    'title' => 'System problem',
                    'info' => 'Error file is not exists'
                ];
                throw new PathException($error);
            }
        }
        return $class_name::init($key);
    }
}