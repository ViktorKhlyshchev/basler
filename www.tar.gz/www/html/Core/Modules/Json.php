<?php

namespace Core\Modules;

use Core\Module\Exception\ParametersValidationException;
use Core\Module\Exception\SystemException;

class Json { # Core/Module/Json/Json.php

    public static function encode_cyrillic(array $array){
        $str = preg_replace_callback('/\\\\u([a-f0-9]{4})/i', create_function('$m', 'return chr(hexdec($m[1])-1072+224);'), $array);
        return iconv('cp1251', 'utf-8', $str);
    }

    public static function encode(array $array){
        try {
            return json_encode($array, JSON_UNESCAPED_UNICODE);
        } catch(\Exception $error){ pred($error);
            throw new SystemException($error);
        }
    }

    public static function is_json(string $string = null){
        return !preg_match('/[^, :{}\\[\\]0-9.\\-+Eaeflnr-u \\n\\r\\t]/', preg_replace('/"(\\.|[^"\\\\])*"/', '', $string));
    }

    public static function get_json_from_exec(string $exec = null, bool $need_array = false){
        if(empty($exec)) return null;
        exec($exec, $out); #pre($exec); pred($out);
        $r = '';
        foreach($out as $row) $r .= trim($row);
        if($need_array){ #if(!$r) return false;            #if(!$r) return null;
            if(!$r) return [];
            return self::decode($r);
        }
        return $r;
    }

    public static function get_exec(string $exec = null){
        if(empty($exec)) return ['error' => '$exec empty'];
        exec($exec, $out);
        $json = '';
        foreach($out as $row) $json .= trim($row); # pred($json);
        if(!$json) return ['error' => 'empty JSON returned'];
        $r = Json::decoder($json); #pred($r);
        if(!$r || isset($r['json_error'])){ $r['out'] = $out; return $r; } # pred($r); return (bool)$r['success'];
        return $r;
    }

    public static function decode(string $string = null, bool $is_assoc = true){ #pred(debug_backtrace());
        $array = json_decode($string, $is_assoc);
        $decode_status = json_last_error();
        switch($decode_status){
            case JSON_ERROR_NONE:{
                return $array;
                break;
            }
            case JSON_ERROR_DEPTH:{
                $log_content = ['json' => $string, 'decode_status' => 'JSON_ERROR_DEPTH', 'error' => 'Достигнута максимальная глубина стека'];
                break;
            }
            case JSON_ERROR_STATE_MISMATCH:{
                $log_content = ['json' => $string, 'decode_status' => 'JSON_ERROR_STATE_MISMATCH', 'error' => 'Некорректные разряды или не совпадение режимов'];
                break;
            }
            case JSON_ERROR_CTRL_CHAR:{
                $log_content = ['json' => $string, 'decode_status' => 'JSON_ERROR_CTRL_CHAR', 'error' => 'Некорректный управляющий символ'];
                break;
            }
            case JSON_ERROR_SYNTAX:{
                $log_content = ['json' => $string, 'decode_status' => 'JSON_ERROR_SYNTAX', 'error' => 'Синтаксическая ошибка, не корректный JSON'];
                break;
            }
            case JSON_ERROR_UTF8:{
                $log_content = ['json' => $string, 'decode_status' => 'JSON_ERROR_UTF8', 'error' => 'Некорректные символы UTF-8, возможно неверная кодировка'];
                break;
            }
            default:{
                $log_content = ['json' => $string, 'decode_status' => 'JSON_ERROR_UTF8', 'error' => 'Неизвестная ошибка'];
                break;
            }
        }
        $error = ['title' => 'Json Validation Problem', 'info' => 'String is not json format', 'data' => ['log' => $log_content]];
        pre($error); pred(debug_backtrace());
        throw new ParametersValidationException($error);
    }

    public static function decoder(string $string = null, bool $is_assoc = true){ #pred(debug_backtrace());
        $array = json_decode($string, $is_assoc);
        $decode_status = json_last_error();
        switch($decode_status){
            case JSON_ERROR_NONE:{
                return $array;
                break;
            }
            case JSON_ERROR_DEPTH:{
                $log_content = ['json' => $string, 'decode_status' => 'JSON_ERROR_DEPTH', 'error' => 'Достигнута максимальная глубина стека'];
                break;
            }
            case JSON_ERROR_STATE_MISMATCH:{
                $log_content = ['json' => $string, 'decode_status' => 'JSON_ERROR_STATE_MISMATCH', 'error' => 'Некорректные разряды или не совпадение режимов'];
                break;
            }
            case JSON_ERROR_CTRL_CHAR:{
                $log_content = ['json' => $string, 'decode_status' => 'JSON_ERROR_CTRL_CHAR', 'error' => 'Некорректный управляющий символ'];
                break;
            }
            case JSON_ERROR_SYNTAX:{
                $log_content = ['json' => $string, 'decode_status' => 'JSON_ERROR_SYNTAX', 'error' => 'Синтаксическая ошибка, не корректный JSON'];
                break;
            }
            case JSON_ERROR_UTF8:{
                $log_content = ['json' => $string, 'decode_status' => 'JSON_ERROR_UTF8', 'error' => 'Некорректные символы UTF-8, возможно неверная кодировка'];
                break;
            }
            default:{
                $log_content = ['json' => $string, 'decode_status' => 'JSON_ERROR_UTF8', 'error' => 'Неизвестная ошибка'];
                break;
            }
        }
        $error = ['error' => 'String is not json format', 'json_error' => 'Json Validation Problem', 'info' => 'String is not json format', 'data' => ['log' => $log_content]];
        return $error;
    }
}