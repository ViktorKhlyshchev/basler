<?php

namespace Core\Modules;

use Common\Modules\Date; #use Core\Modules\Dir;
use Configs\DirConfig;
use Core\Module\Email\EmailSend; #use Common\Models\History;
use Common\Models\XavierInfo;

class Log {

    private static $date;
    private static $timezone;
    private static $title_default = 'Unknown title';
    public static $is_error;
    public static $file_path;
    public static $file_name; # private static $need_send_to_mail;
    public static $content;

    private static function reset_data(){
        self::$is_error = true;
        self::$file_path = null;
        self::$file_name = null; #        self::$need_send_to_mail = true;
        return true;
    }

    private static function send_content(array $content, array $error){
        $title = \Config::$project_name.' | Unknown title';
        if(isset($error['title'])){
            if(is_array($error['title'])) $title = array_shift($error['title']);
            else if(is_string($error['title'])) $title = $error['title'];
            else $title = self::$title_default;
        }
        return EmailSend::init(\Config::$email_log, $title, '<pre>'.implode("<br />".PHP_EOL, $content).'</pre>', \Config::$email_no_replay);
    }

    private static function write_content(array $error){
        $content[] = 'ERROR:';
        $content[] = '<pre>'.print_r($error, true).'</pre>';
        $content[] = '';
        $content[] = 'SERVER:';
        $content[] = '<pre>'.print_r($_SERVER, true).'</pre>';
        $content[] = '';
        $content[] = 'GET:';
        $content[] = '<pre>'.print_r($_GET, true).'</pre>';
        $content[] = '';
        $content[] = 'POST:';
        $content[] = '<pre>'.print_r($_POST, true).'</pre>';
        $content[] = '';
        $content[] = 'FILES:';
        $content[] = '<pre>'.print_r($_FILES, true).'</pre>'; #  if(self::$need_send_to_mail)    self::send_content($content, $error);
        # if(\Config::$is_debug) echo '<a href = "'.self::$file_path.'" target = "_blank">Link</a>'."\n";
        #self::$file_path = Dir::get_global_dir(self::$file_path);
        self::$file_path = self::create_file();
        #return (bool)file_put_contents(self::$file_path, implode('<br/>', $content), FILE_APPEND);
        return self::log('main', implode('<br/>', $content));
    }

    private static function create_file($suf = 'main'){ #        $year = Date::get_year();        $month = Date::get_month();        $day = Date::get_day();
        $dp = DR .'/'. DirConfig::$dir_log .'/'. $suf .'/'. date('Y.m.d'); # pre($dp); pre(is_dir($dp));
        if(!is_dir($dp)) $r = mkdir($dp, 0775, true);
        self::$file_path = $dp .'/'. self::$file_name;#        pred(self::$file_path);
        return self::$file_path;
    }

    private static function create_sdird($suf = 'main'){ # create "standart dir" day
        $year = Date::get_year();         #if(is_dir($dp)) return true;
        $month = Date::get_month();
        $day = Date::get_day();
        $dp = DR .'/'. DirConfig::$dir_log .'/'. $suf .'/'. $year .'.'. $month .'.'. $day; #pre($fp);
        if(!is_dir($dp)) $r = mkdir($dp, 0775, true);
        return true;
    }

    private static function create_sdirm($suf = 'main'){ # create "standart dir" month
        $year = Date::get_year();
        $month = Date::get_month();
        $dp = DR .'/'. DirConfig::$dir_log .'/'. $suf .'/'. $year .'.'. $month; #pre($fp);
        if(is_dir($dp)) return $dp;
        if($r = mkdir($dp, 0775, true)) return $dp;
    }

    private static function create_logdir($suf){ # create "standart dir" month
        $dp = DR .'/'. DirConfig::$dir_log .'/'. $suf; #pre($fp);
        if(is_dir($dp)) return $dp;
        if($r = mkdir($dp, 0775)) return $dp;
    }

    private static function create_dir($suf = 'main'){
        #if(is_dir($dp)) return true;
        $year = Date::get_year();
        $month = Date::get_month();
        $day = Date::get_day();
        $dp = DR .'/'. DirConfig::$dir_log;
        if(!is_dir($dp)) $r = mkdir($dp, 0775, true);
        return true;
    }

    private static function set_file_name(){
        if(empty(self::$file_name)) self::$file_name = Date::get_date_from_mask("Y.m.d_h.i.s.ms").'_'. mt_rand(0, 10).'.html';
        return true;
    }

    public static function init(array $content = [], bool $is_error = true, bool $need_send_to_mail = true){
        if(isset($_SERVER['HTTP_HOST'])) $content['host'] = $_SERVER['HTTP_HOST']; #if(\Config::$is_debug) pre($content);
        self::reset_data();
        self::$is_error = $is_error; # self::$need_send_to_mail = $need_send_to_mail;
        self::$content = $content;
        self::set_file_name();
        if(!self::create_file()) return false; #History::update_error();
        return (bool)self::write_content($content);
    }

    public static function sbl($content = null){ # sendbox last
        $log = '';
        $log .= " ==================\n";
        $log .= 'Date: '.date("Y-m-d H:i:s")."\n";
        if(!$content){
            $cmd = 'free -ht'; exec($cmd, $o);
            $log .= implode("\n", $o)."\n";
            $log .= 'PHP used:'. convert_digital_size(memory_get_usage())."\n";
        }
        if(!$dp = self::create_sdirm('sbl')) return false;
        $day = Date::get_day();
        $fp = $dp .'/'. $day .'_sbl.log'; #pre($fp);
        return (bool)file_put_contents($fp, $content, FILE_APPEND);
    }

    public static function set_dt(){ # set datetime
        if(!self::$timezone){
            $r = XavierInfo::get_list_from_group('about');
            self::$timezone = $r['about']['timezone'];
        }
        self::$date = new \DateTime();
        self::$date->modify('+'. self::$timezone .' hour');
    }

    public static function auR($content){ # aist_upload
        self::set_dt();
        if(!$dp = self::create_sdirm('au')) return false;
        $fp = $dp .'/'. self::$date->format('d') .'.log'; #pre($fp);
        $content = '['. self::$date->format('H:i:s') .'] '. $content ."\n";
        return (bool)file_put_contents($fp, $content, FILE_APPEND);
    }
    public static function au($content){ # aist_upload
        self::log('aist_upload', $content);
    }

    public static function log($dir, $content){ # aist_upload
        self::set_dt();
        if(is_array($content) || is_object($content)) $content = json_encode($content);
        if(!$log_dp = self::create_logdir($dir)) return false;
        $log_fp = $log_dp .'/'. date('Y.m.d') .'.log';
        $content = '<div class="ib logtime">['. self::$date->format('H:i:s') .']</div> '. $content ."\n";
        return (bool)file_put_contents($log_fp, $content, FILE_APPEND);
    }

    public static function clean_logR($content){ # clean log
        self::set_dt();
        if(!$dp = self::create_sdirm('cl')) return false;
        $fp = $dp .'/'. self::$date->format('d') .'.log'; #pre($fp);
        $content = '['. self::$date->format('H:i:s') .'] '. $content ."\n";
        return (bool)file_put_contents($fp, $content, FILE_APPEND);
    }

    public static function clean_log($content){ # clean log
        self::log('clean', $content);
    }

    public static function erlog($content){ # errors log
        self::log('errors', $content);
        return;
        if(is_array($content) || is_object($content)) $content = json_encode($content);
        self::set_dt();
        $dp = DR .'/'. DirConfig::$dir_log_er;
        $log_fp = $dp .'/'.  self::$date->format('Y.m.d') .'.log';
        $content = '['. self::$date->format('H:i:s') .'] '. $content ."\n";
        $r = @file_put_contents($log_fp, $content, FILE_APPEND);
        if(!$r){ $er = __CLASS__ .'::'. __FUNCTION__ .' | Cant log erlog! fp:__'. $log_fp; if(ajax) er($er); else pred($er); } # if(!$r) pred(__CLASS__ .'::'. __FUNCTION__ .' | Cant log erlog!');
    }
}