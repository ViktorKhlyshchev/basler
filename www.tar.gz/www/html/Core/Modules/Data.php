<?php

namespace Core\Modules;

class Data { # Core/Module/Data/Data.php

    public static function is_string($data = null){
        if(empty($data)) return false;
        return is_string($data);
    }

    public static function is_integer($data = null){
        if(is_null($data)) return false;
        return is_integer($data);
    }

    public static function is_float($data = null){
        if(is_null($data)) return false;
        return is_float($data);
    }

    public static function isset_word_in_string(string $word = null, string $string = null){
        if(empty($word) || empty($string)) return false;
        return strpos($string, $word) !== false;
    }

    public static function is_array($data = null){
        if(is_null($data)) return false;
        return is_array($data);
    }

    public static function is_associative_array($data = null){
        if(is_null($data)) return false;
        if(!is_array($data)) return false; #$data = ['h' => 'k', 'p'];pred(key($data)); pre(array_keys($data));        pred(range(0, count($data)-1));
        return array_keys($data) !== range(0, count($data)-1);
    }

    public static function is_associative_arrays($data = null){ # simplified version, checks only first key
        if(is_null($data)) return false;
        if(!is_array($data)) return false;
        reset($data); // reset pointer to first element of array
        pre(key($data));
        pred(gettype(key($data)) === 'string');
        if(gettype(key($data)) === 'string') return true;
    }
}