<?php

namespace Core\Modules\User; #namespace Core\Action\User\User;

use Core\Module\Email\EmailSend;
use Core\Module\Email\EmailValidation;
use Core\Module\Encrypt\Hash;
use Core\Module\Exception\ParametersException;
use Core\Module\Exception\ParametersValidationException;
use Core\Module\Exception\PhpException;
use Core\Module\OsServer\OsServer;
use Core\Module\PromoCode\PromoCode;
use Core\Module\Url\Url;
use Core\Module\User\User;
use Core\Module\User\UserAccess;
use Core\Module\User\UserAccessTypeValidation;
use Core\Module\User\UserBalance;
use Core\Module\User\UserEmail;
use Core\Module\User\UserHash;
use Configs\UserHashLinkConfig;
use Configs\UserHashTypeConfig; #use Core\Module\User\UserHashTypeConfig;
use Core\Module\User\UserLogin;
use Core\Module\User\UserLoginValidation;

class AddUser { # AddUserSystemAction

    private static $user_id;
    private static $user_email_id;
    private static $user_login_id;
    private static $user_hash_id;
    private static $user_hash_type_id;
    private static $user_balance_id;
    private static $login;
    private static $password;
    private static $user_invite_hash;
    private static $user_hash_type_name;
    private static $user_email;
    private static $link;
    private static $user_access_type_list = [];
    private static $promo_code; #    private static $promo_login;

    private static function is_valid_user_email(){
        if(!EmailValidation::is_valid_email(self::$user_email)){
            $error = ['title' => ParametersValidationException::$title, 'info' => 'User email is not valid'];
            throw new ParametersValidationException($error);
        }
        return true;
    }

    private static function is_valid_user_login(){
        if(!UserLoginValidation::is_valid_user_login(self::$login)){
            $error = ['title' => ParametersValidationException::$title, 'info' => 'User login is not valid'];
            throw new ParametersValidationException($error);
        }
        return true;
    }

    private static function is_valid_user_password(){
        if(!UserLoginValidation::is_valid_user_password(self::$password)){
            $error = [ 'title' => ParametersValidationException::$title, 'info' => 'User password is not valid'];
            throw new ParametersValidationException($error);
        }
        return true;
    }

    private static function isset_user_email(){
        if(UserEmail::isset_user_email_in_all_list(self::$user_email)){
            $error = ['title' => ParametersValidationException::$title, 'info' => 'User email already exists'];
            throw new ParametersValidationException($error);
        }
        return false;
    }

    private static function isset_user_login(){ //        if(UserLogin::isset_user_login_in_all(self::$login)){
        if(UserLogin::isset_user_login_in_active(self::$login)){
            $error = ['title' => ParametersValidationException::$title, 'info' => 'User login already exists'];
            throw new ParametersValidationException($error);
        }
        return false;
    }

    private static function set_user_hash_type_id(){
        self::$user_hash_type_id = UserHashTypeConfig::get_user_hash_type_id(self::$user_hash_type_name);
        if(empty(self::$user_hash_type_id)){
            $error = [
                'title' => PhpException::$title,
                'info' => 'User hash type ID is empty'
            ];
            throw new PhpException($error);
        }
        return true;
    }

    private static function add_user(){
        self::$user_id = User::add_user();
        if(empty(self::$user_id)){
            $error = [
                'title' => PhpException::$title,
                'info' => 'User was not add'
            ];
            throw new PhpException($error);
        }
        return true;
    }

    private static function add_email(){
        self::$user_email_id = UserEmail::add_user_email(self::$user_id, self::$user_email);
        if(empty(self::$user_email)){
            $error = [
                'title' => PhpException::$title,
                'info' => 'User email was not add'
            ];
            throw new PhpException($error);
        }
        return true;
    }

    private static function add_user_access_list(){
        if(count(self::$user_access_type_list) === 0){
            $error = [
                'title' => ParametersException::$title,
                'info' => 'User access type list is empty'
            ];
            throw new ParametersException($error);
        }
        $user_access_type_name_list = [];
        foreach(self::$user_access_type_list as $user_access_type_name){
            if(!UserAccessTypeValidation::isset_user_access_name($user_access_type_name)){
                $error = [
                    'title' => ParametersValidationException::$title,
                    'info' => 'User access type is not valid'
                ];
                throw new ParametersValidationException($error);
            }
            $user_access_type_name_list[] = $user_access_type_name;
        }
        if(count($user_access_type_name_list) === 0){
            $error = [
                'title' => PhpException::$title,
                'info' => 'Value list is empty'
            ];
            throw new PhpException($error);
        }
        if(!UserAccess::add_user_access(self::$user_id,$user_access_type_name_list)){
            $error = [
                'title' => PhpException::$title,
                'info' => 'User access list was not add'
            ];
            throw new PhpException($error);
        }
        return true;
    }

    private static function add_user_login(){
        self::$user_login_id = UserLogin::add_user_login(self::$user_id, self::$login,Hash::get_sha1_encode(self::$password));
        if(empty(self::$user_login_id)){
            $error = [
                'title' => PhpException::$title,
                'info' => 'User login was not add'
            ];
            throw new PhpException($error);
        }
        return true;
    }

    private static function add_user_balance(){
        if(UserBalance::isset_user_balance(self::$user_id)) return true;
        self::$user_balance_id = UserBalance::add_user_balance(self::$user_id);
        if(empty(self::$user_balance_id)){
            $error = [
                'title' => PhpException::$title,
                'info' => 'User balance was not add'
            ];
            throw new PhpException($error);
        }
        return true;
    }

    private static function set_user_invite_hash(){
        $list = [
            User::$user_id,
            self::$user_id,
            self::$user_email,
            self::$user_email_id,
            time(),
            rand(0,time())
        ];
        self::$user_invite_hash=Hash::get_sha1_encode('confirm_registration_'.implode(':',$list));
        return true;
    }

    private static function add_user_hash_for_invite(){
        $code = null;
        $login = null;
        if(!empty(self::$promo_code)){
            if(PromoCode::isset_promo_code(self::$promo_code)) $code=self::$promo_code;
            else if(UserLogin::isset_user_login_in_active(self::$promo_code)) $login=self::$promo_code;
        }
        self::$user_hash_id = UserHash::add_user_hash(self::$user_id, self::$user_hash_type_id,$code, self::$user_invite_hash,$login);
        if(empty(self::$user_hash_type_id)){
            $error = [
                'title' => PhpException::$title,
                'info' => 'User hash type was not add'
            ];
            throw new PhpException($error);
        }
        return true;
    }

    private static function send_invite(){
        $inner = [];
        $link =UserHashLinkConfig::get_link_full('confirm_email').'/'.self::$user_invite_hash;
        if(OsServer::$is_windows)
            self::$link = $link;
        $inner[] = 'Здравствуйте!';
        $inner[] = '';
        $inner[] = 'Для подтверждения регистрации, пожалуйста, перейдите по ссылке: <a href="'.$link.'">'.$link.'</a>';
        $inner[] = '';
        $inner[] = 'С уважением,';
        $inner[] = 'Команда <a href="'.\Config::$http_type.'://'.Url::$host.'/">АИСТ-КОНТРОЛЬ</a>';
        return EmailSend::init(array(self::$user_email),'Регистрация '.\Config::$project_name,implode("<br />\n\r",$inner),\Config::$email_no_replay);
    }

    private static function set_return(){
        $data = [
            'user_id' => self::$user_id,
            'user_email' => self::$user_email,
            'user_login' => self::$login
        ];
        if(!empty(self::$link)) $data['link'] = self::$link;
        return $data;
    }

    private static function set(){
        if(self::is_valid_user_email())
            if(!self::isset_user_email())
                if(self::is_valid_user_login())
                    if(!self::isset_user_login())
                        if(self::is_valid_user_password()){
                            self::add_user();
                            self::add_email();
                            self::add_user_login();
                            self::add_user_access_list();
                            self::add_user_balance();
                            self::set_user_hash_type_id();
                            self::set_user_invite_hash();
                            self::add_user_hash_for_invite();
                            self::send_invite();
                            return self::set_return();
                        }
        return null;
    }

    public static function init(string $user_email = null, string $login = null, string $password = null, array $user_access_type_name_list = [],string $user_hash_type_name = null, string $promo_code = null){
//        \Config::$is_debug=true;
        $error_info_list = [];
        if(empty($user_email)) $error_info_list[] = 'User email is empty';
        if(empty($login)) $error_info_list[] = 'Login is empty';
        if(empty($password)) $error_info_list[] = 'Password is empty';
        if(empty($user_hash_type_name)) $error_info_list[] = 'User hash type name is empty';
        if(count($user_access_type_name_list) === 0)
            $error_info_list[] = 'User access type name list is empty';
        if(count($error_info_list) > 0){
            $error = [
                'title' => ParametersException::$title,
                'info' => $error_info_list
            ];
            throw new ParametersException($error);
        }
        self::$login = $login;
        self::$password = $password;
        self::$user_email = $user_email;
        self::$user_access_type_list = $user_access_type_name_list;
        self::$user_hash_type_name = $user_hash_type_name;
        self::$promo_code = empty($promo_code) ? null : mb_strtolower($promo_code,'utf-8');
        return self::set();
    }
}