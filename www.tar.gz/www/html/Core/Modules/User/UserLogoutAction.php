<?php

namespace Core\Modules\User;# Core\Action\Logout\UserLogout;

use Core\Module\Session\Session;
use Core\Module\Token\Token;
use Core\Module\User\User;
use Core\Module\User\UserLogout;

class UserLogoutAction { # Core/Action/Logout/UserLogout/UserLogoutSystemAction.php

    private static $user_id;
    private static $token_id;
    private static $session_id;

    public static function init(){

        self::$token_id = Token::$token_id;
        self::$user_id = User::$user_id;
        self::$session_id = Session::$session_id; #pred(Session::$session_id);
        if(!empty(Session::$session_id)){
            if(empty(User::$user_id) && empty(Token::$token_id)) Session::remove_session_id_default();
            else
                Session::remove_session(User::$user_id, Token::$token_id);
        } #pre(Token::$token_hash);
        if(!empty(Token::$token_hash)) Token::remove_token_from_token_hash(Token::$token_hash); #pre(Token::$token_hash);
        $r = UserLogout::add_user_logout(self::$user_id, self::$token_id, self::$session_id);# pred($r);
        return true;
    }
}