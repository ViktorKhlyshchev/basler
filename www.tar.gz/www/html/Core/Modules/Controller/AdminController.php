<?php

namespace Core\Modules\Controller;

use Core\Module\Url\Url;
use Core\Module\User\UserAccess;
use Admin\Controllers\ErrorPageController;

class AdminController {

    public $views_dir;
    public $view_dir;
    public $layouts_dir = DR .'/Admin/Layouts'; #public $layout;
    public $req;
    public $res;
    public $action;
    public $title = '';

    public function __construct($c = null){ #public function init(){  #if($c === 'api'){ if(!UserAccess::$is_root && !UserAccess::$is_admin){ new ErrorPageController(); die; } }

        if($c !== 'duplo_test'){
            if($c !== 'err' && !defined('p404')){
                define('p404', true); if(!UserAccess::$is_root && !UserAccess::$is_admin){ new ErrorPageController(); die; }
            }
        }

        global $req;
        if(ajax) $this->action = $req->post('action'); #if(!$this->beforeAction()) die; #$cr = new \ReflectionClass('Core\Module\Controller\Controller');
        $cr = new \ReflectionClass(get_called_class()); #pred($cr);
        $this->views_dir = str_replace('Controller', '', basename($cr->getFileName(), '.php'));
        $this->view_dir = DR .'/Admin/Views/'. $this->views_dir; #        pred($this->view_dir);
        $this->req = $req; #pred($this->req);
    }

    public function action($name = null){
        global $req;  #pre($name);        #if($name === 'action_rend_create_serv_form'){ #pre($req->ajax);            pre($req);            pred($_SERVER);        }
        if(!$name) return;
        if(ajax){
            if($this->csrf_off !== true){
                if(!csupcsrf($req->post('csrf'))) pred(444555);
            }
        }

        if(!$this->beforeAction($name)) return;
        return $this->$name();
    }

    public function rend($view = null, &$res = [], $layout = null){
        $res['view'] = $view; #$res['layout'] = $layout;
        $res['vurl'] = Url::get_url($this->view_dir); #pred($res['vurl']);
        if((func_num_args() === 1 && is_array($view)) || !func_num_args()) $view = str_replace('action_', '', debug_backtrace()[1]['function']); #$res = $view; }
        #pre($this->views_dir); pre($view); #pred(__FILE__); # $a = new \ReflectionClass('ZN\Database\InternalDB'); #pred(basename($a->getFileName(), '.php'));        pred(ReflectionClass::getFileName($this));        pred($this);
        ob_start(null, 0);
        require $this->view_dir .'/'. $view .'.php';
        $rend = ob_get_clean();
        return $rend;
    }

    public function rendd($view = null, &$res = [], $layout = null){
        $res['view'] = $view; #$res['layout'] = $layout;
        $res['vurl'] = Url::get_url($this->view_dir); #pred($res['vurl']);
        if((func_num_args() === 1 && is_array($view)) || !func_num_args()) $view = str_replace('action_', '', debug_backtrace()[1]['function']); #$res = $view; }  #pre($this->view_dir .'/'. $view .'.php');
        require $this->view_dir .'/'. $view .'.php';
    }

    public function rends($view = null, $res = null){ # render and show
        if((func_num_args() === 1 && is_array($view)) || !func_num_args()){
            $res = $view;
            $view = str_replace('action_', '', debug_backtrace()[1]['function']);
        } # pre($this->views_dir);        pre($view); # pred(__FILE__); # $a = new \ReflectionClass('ZN\Database\InternalDB'); # pred(basename($a->getFileName(), '.php'));        pred(ReflectionClass::getFileName($this));        pred($this);
        ob_start(null, 0);
        require $this->view_dir .'/'. $view .'.php';
        $rend = ob_get_clean();
        echo $rend; die;
    }

    public function rendl($view = null, $layout = null){
        $res['view'] = $view;
        if(!$layout) $layout = 'index';
        $res['layout'] = $layout;
        $res['vurl'] = Url::get_url($this->view_dir); #pred($res['vurl']);
        if((func_num_args() === 1 && is_array($view)) || !func_num_args()){
            $view = str_replace('action_', '', debug_backtrace()[1]['function']);
        } #pre($this->views_dir); pre($view); # pred(__FILE__); # $a = new \ReflectionClass('ZN\Database\InternalDB'); #pred(basename($a->getFileName(), '.php'));        pred(ReflectionClass::getFileName($this));        pred($this);
        ob_start(null, 0);
        require $this->view_dir .'/'. $view .'.php';
        $content = ob_get_clean();
        ob_start(null, 0);
        $rpath = $this->layouts_dir .'/'. $layout .'/index.php'; #pred($rpath);
        require $rpath;
        $rend = ob_get_clean();
        echo $rend; die;
    }

    public function nf404(){
        return;
    }
}