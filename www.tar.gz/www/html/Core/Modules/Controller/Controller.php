<?php

namespace Core\Modules\Controller;

class Controller {

    static $views_dir;
    static $view_dir;
    #public function __construct(){
    public static function init(){
        #if(!$this->beforeAction()) die;
        #$cr = new \ReflectionClass('Core\Module\Controller\Controller');
        $cr = new \ReflectionClass(get_called_class());
        self::$views_dir = basename($cr->getFileName(), '.php');
        self::$view_dir = __DIR__ .'/../views/'. self::$views_dir;
    }

    public function action($name = null){
        global $req;  #pre($name);        #if($name === 'action_rend_create_serv_form'){ #pre($req->ajax);            pre($req);            pred($_SERVER);        }
        if(!$name) return;
        if(ajax){
            if($this->csrf_off !== true){
                if(!csupcsrf($req->post('csrf'))) pred(444555);
            }
        }

        if(!$this->beforeAction($name)) return;
        return $this->$name();
    }

    public static function rend($view = null, $res = null){
        if((func_num_args() === 1 && is_array($view)) || !func_num_args()){
            $res = $view;
            $view = str_replace('action_', '', debug_backtrace()[1]['function']);
        }
        #pre($this->views_dir);        pre($view);
        #pred(__FILE__);
        # $a = new \ReflectionClass('ZN\Database\InternalDB');

        #
        #pred(basename($a->getFileName(), '.php'));        pred(ReflectionClass::getFileName($this));        pred($this);
        ob_start(null, 0);
        require __DIR__ .'/../views/'. self::$views_dir .'/'. $view .'.php';
        $rend = ob_get_clean();
        return $rend;
    }

    public function nf404(){
        return;
    }
}