<?php

namespace Core\Modules;

use Common\Modules\Date;
use Core\Module\Exception\ParametersException;
use Core\Module\Exception\PathException;
use Core\Module\Exception\SystemException;

class Dir {

    public static $log;
    public static $er = [];

    public static function get_global_dir(string $path = null, bool $is_always = false){
        if(!cli && !$is_always) return $path;
        $pos = mb_strripos($path, DR, 0, 'utf-8');
        if($pos === false) return DR .'/'. $path;
        return $path;
    }

    public static function get_global_dirn(string $path = null, bool $is_always = false){
        $pos = mb_strripos($path, DR, 0, 'utf-8');
        if($pos === false) return DR .'/'. $path;
        return $path;
    }

    public static function create_dirn(string $path = null, int $access = 0775){

        if(empty($path)){ pre('path is empty!!'. __FUNCTION__); return false; } #pred(debug_backtrace());
        if(substr($path, 0, 1) !== '/') $path = self::get_global_dirn($path);
        if(is_dir($path)) return true;
        $r = @mkdir($path, $access, true);  #pred($path);
        if(!$r) return; #   return false;
        @chmod($path, 0775);
        return true; #pre($r);# $error = error_get_last(); #$error['message'] = [$error['message'], 'path:__'. $path]; #pred($error);        throw new SystemException(new \Exception(implode('|', $error['message'])));
    }

    public static function get_file_list_from_dir(string $path = null){
        if(empty($path)){
            $error = ['title' => 'Dir path problem', 'info' => 'Dir path is empty'];
            throw new ParametersException($error);
        }
        $path = self::get_global_dir($path);
        if(!is_dir($path)){
            $error = ['title' => 'Path problem', 'info' => 'Path is not dir', 'data' => ['path' => $path]];
            throw new PathException($error);
        }
        return scandir($path);
    }

    public static function get_root_dir(){ return $_SERVER['DOCUMENT_ROOT']; }

    public static function get_current_dir(){ return getcwd(); }

    public static function set_current_dir(string $path = null){
        if(empty($path)){       $error = array('title' => 'Parameters problem',                'info' => 'Dir path is empty'         );    throw new ParametersException($error);        }
        $path = self::get_global_dir($path);
        if(!is_dir($path)){ $error = array('title' => 'Path problem', 'info' => 'Path is not dir', 'data' => array('path' => $path)); throw new PathException($error);    }
        return chdir($path);
    }

    public static function create_dir(string $path = null, int $access = 0775){

        if(is_dir($path)) return true; #file_exists
        if(empty($path)){ pre('path is empty!!'. __FUNCTION__); return false; } #pred(debug_backtrace());
        $path = self::get_global_dir($path); #pred($path);
        if(is_dir($path)) return true;
        $r = @mkdir($path, $access, true); # pred($r);
        if($r) return true; # pre($path);
        $error = error_get_last(); #pred($error);
        $error['message'] = [$error['message'], 'path:__'. $path]; #pred($error);
        throw new SystemException(new \Exception(json_encode($error)));
    }

    public static function remove_dir(string $dir = null){
        if(empty($dir)){ $error = ['title' => 'Parameters problem', 'info' => 'Dir path is empty']; throw new ParametersException($error); }
        $dir = self::get_global_dir($dir);
        if(!is_dir($dir)){ $error = ['title' => 'Dir path problem', 'info' => 'Path is not dir', 'path' => $dir]; throw new PathException($error); }
        self::clean_dir($dir);
        if(count(scandir($dir)) === 2) return rmdir($dir);
        return true;
    }

    public static function remove_dirn(string $dp = null){ #pred(debug_backtrace());
        self::$er = [];
        if(empty($dp)){ $error = ['title' => 'Parameters problem', 'info' => 'Dir path is empty']; throw new ParametersException($error); }
        $dp = self::get_global_dirn($dp); #pred($dp);
        if(file_exists($dp) && is_file($dp)){ $error = ['title' => 'Dir path problem', 'info' => 'Path is not dir', 'path' => $dp]; throw new PathException($error); }
        if(!is_dir($dp)) return true;
        $r = self::clean_dir($dp);# pre($dp); pre($r);
        if(!$r){ self::$er[] = 'Cant clean dir!'. $dp; return; }
        return rmdir($dp);
    }

    public static function remove_dirnn(string $dp = null){
        self::$er = [];
        if(empty($dp)){ $error = ['title' => 'Parameters problem', 'info' => 'Dir path is empty']; throw new ParametersException($error); }
        $dp = self::get_global_dirn($dp); #pred($dp);
        if(file_exists($dp) && is_file($dp)){ $error = ['title' => 'Dir path problem', 'info' => 'Path is not dir', 'path' => $dp]; throw new PathException($error); }
        if(!is_dir($dp)) return true;
        $r = self::cleann_dir($dp); #pre($dp); pred($r);
        if(!$r){ self::$er[] = 'Cant clean dir!'. $dp; pre(self::$er); return; }
        return rmdir($dp); #if(count(scandir($dp)) === 2)
    }

    public static function cleann_dir(string $dp = null){
        if(empty($dp)){ $error = ['title' => 'Parameters problem', 'info' => 'Dir path is empty']; throw new ParametersException($error); }
        $dp = self::get_global_dirn($dp);
        if(file_exists($dp) && is_file($dp)){ $error = ['title' => 'Dir path problem', 'info' => 'Path is not dir', 'path' => $dp]; throw new PathException($error); }
        if(!is_dir($dp)) return true;

        $objs = scandir($dp);
        if(count($objs) === 2) return true;
        foreach($objs as $on){ #pre($file_name); object_name
            if($on === '.' || $on === '..') continue;
            $op = $dp .'/'. $on; #pred($op);
            if(is_file($op)){
                $r = @unlink($op); #pre($r);
                $error = error_get_last(); if(!$r){ self::$er[] = 'cant unlink file:__'. $op; pre(self::$er); return;}
            } else if(is_dir($op)){
                $r = self::remove_dirn($op);
            } # pred($r);
        }
        return $r;
    }

    public static function clean_dir(string $dp = null){
        if(empty($dp)){ $error = ['title' => 'Parameters problem', 'info' => 'Dir path is empty']; throw new ParametersException($error); }
        $dp = self::get_global_dirn($dp);
        if(file_exists($dp) && is_file($dp)){ $error = ['title' => 'Dir path problem', 'info' => 'Path is not dir', 'path' => $dp]; throw new PathException($error); }
        if(!file_exists($dp)) return true;

        foreach(scandir($dp) as $file_name){ #pre($file_name);
            if($file_name !== '.' && $file_name !== '..'){
                $file_path = $dp.'/'.$file_name;
                if(is_file($file_path)){ $r = @unlink($file_path); $error = error_get_last(); if(!$r){self::$er[] = 'cant unlink file:__'. $file_path; return;} }
                else
                    if(is_dir($file_path)){ $r = self::remove_dir($file_path);  } # pred($r);
            }
        }
        #pre($r);
        #pred(321);
        return true;
    }

    public static function copy_dir(string $from_dir, string $to_dir){
        if(empty($from_dir)){
            $error = ['title' => 'Parameters problem', 'info' => 'Path for copy is not dir', 'data' => ['path' => $from_dir]];
            throw new ParametersException($error);
        }
        if(empty($to_dir)){
            $error = ['title' => 'Parameters problem', 'info' => 'Path for copy is not dir', 'data' => ['path' => $to_dir]];
            throw new ParametersException($error);
        }
        $from_dir = self::get_global_dir($from_dir);
        $to_dir = self::get_global_dir($to_dir);
        if(!is_dir($from_dir)){
            $error = ['title' => 'Parameters problem', 'info' => 'Path for copy is not dir', 'data' => ['path' => $from_dir]];
            throw new ParametersException($error);
        }
        if(!file_exists($to_dir))
            self::create_dir($to_dir);
        elseif(!is_dir($to_dir)){
            $error = ['title' => 'Path problem', 'info' => 'Copy path is not dir', 'data' => ['path' => $to_dir]];
            throw new PathException($error);
        }
        foreach(scandir($from_dir) as $file_name)
            if($file_name != '.' && $file_name != '..'){
                $file_path = $from_dir.'/'.$file_name;
                if(is_file($file_path))
                    copy($file_path, $to_dir.'/'.$file_name);
                elseif(is_dir($file_path)){
                    self::create_dir($to_dir.'/'.$file_name);
                    self::copy_dir($file_path, $to_dir.'/'.$file_name);
                }
            }
        return true;
    }

    public static function get_dir_from_timestamp(string $path_default = null, int $timestamp = null){
        $error_info_list = [];
        if(empty($path_default)) $error_info_list[] = 'Path default is empty';
        if(empty($timestamp)) $error_info_list[] = 'Timestamp is empty';
        if(count($error_info_list) > 0){
            $error = ['title' => 'Parameters problem', 'info' => $error_info_list, 'data' => ['path_default' => $path_default, 'timestamp' => $timestamp]];
            throw new ParametersException($error);
        }
        $path_default = self::get_global_dir($path_default);
        return self::get_dir_from_date($path_default, Date::get_date_time_full($timestamp));
    }

    public static function get_dir_from_date(string $path_default = null, string $date = null){
        $error_info_list = [];
        if(empty($path_default)) $error_info_list[] = 'Path default is empty';
        if(empty($date)) $error_info_list[] = 'Date is empty';
        if(count($error_info_list) > 0){
            $error = ['title' => 'Parameters problem', 'info' => $error_info_list, 'data' => ['path_default' => $path_default, 'date' => $date]];
            throw new ParametersException($error);
        }
        $path_default = self::get_global_dir($path_default);
        list($year, $month, $day) = Date::get_date_split_from_string($date);
        self::create_dir($path_default);
        $path_default.= '/'.$year;
        self::create_dir($path_default);
        $path_default.= '/'.$month;
        self::create_dir($path_default);
        $path_default.= '/'.$day;
        self::create_dir($path_default);
        return $path_default;
    }

    public static function get_dir_from_date_path(string $path_default = null, string $path_date = null){
        $error_info_list = [];
        if(empty($path_default)) $error_info_list[] = 'Path default is empty';
        if(empty($path_date)) $error_info_list[] = 'Path date is empty';
        if(count($error_info_list) > 0){
            $error = ['title' => 'Parameters problem', 'info' => $error_info_list, 'data' => ['path_default' => $path_default, 'path_date' => $path_date]];
            throw new ParametersException($error);
        }
        $path_default = self::get_global_dir($path_default);
        $list = mb_split('/', $path_date);
        if(count($list) !== 3){
            $error = ['title' => 'Parameters problem', 'info' => $error_info_list, 'data' => ['path_default' => $path_default, 'path_date' => $path_date]];
            throw new ParametersException($error);
        }
        self::create_dir($path_default);
        $path_default.= '/'.$list[0];
        self::create_dir($path_default);
        $path_default.= '/'.$list[1];
        self::create_dir($path_default);
        $path_default.= '/'.$list[2];
        self::create_dir($path_default);
        return $path_default;
    }
}