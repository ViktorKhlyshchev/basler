<?php

namespace Core\Action\User\Admin;

use Core\Module\Email\EmailSend;
use Core\Module\Encrypt\Hash;
use Core\Module\Exception\AccessDeniedException;
use Core\Module\Exception\ParametersException;
use Core\Module\Exception\ParametersValidationException;
use Core\Module\Exception\PhpException;
use Core\Module\OsServer\OsServer;
use Core\Module\Url\Url;
use Core\Module\User\User;
use Core\Module\User\UserAccess;
use Configs\UserAccessTypeConfig;
use Core\Module\User\UserData;
use Core\Module\User\UserEmail;
use Core\Module\User\UserHash;
use Configs\UserHashLinkConfig;
use Configs\UserHashTypeConfig;
use Core\Module\User\UserLogin;

class AddAdminSystemAction {

    private static $user_id;
    private static $user_login_id;
    private static $user_access_id;
    private static $user_email_id;
    private static $user_data_id;
    private static $user_hash_id;
    private static $user_hash_type_id;
    private static $user_access_type_id;
    private static $user_login;
    private static $user_name;
    private static $user_surname;
    private static $user_email;
    private static $user_hash_invite;
    private static $user_access_type_name;
    private static $user_hash_type_name;
    private static $need_send_invite;
    private static $link;

    private static function is_valid_access(){
        if(!UserAccess::$is_root && !UserAccess::$is_admin){
            $error = ['title' => AccessDeniedException::$title, 'info' => 'Access denied#11'];
            throw new AccessDeniedException($error);
        }
        return true;
    }

    private static function is_valid_user_hash_type(){
        self::$user_hash_type_id = UserHashTypeConfig::get_user_hash_type_id(self::$user_hash_type_name);
        if(empty(self::$user_hash_type_id)){
            $error = ['title' => ParametersValidationException::$title, 'info' => 'User hash type name is not valid'];
            throw new ParametersValidationException($error);
        }
        return true;
    }

    private static function is_valid_user_access_type(){
        self::$user_access_type_id = UserAccessTypeConfig::get_user_access_type_id(self::$user_access_type_name);
        if(empty(self::$user_access_type_id)){
            $error = ['title' => ParametersValidationException::$title, 'info' => 'User access type name is not valid'];
            throw new ParametersValidationException($error);
        }
        return true;
    }

    private static function isset_login(){
        if(UserLogin::isset_user_login_in_active(self::$user_login,User::$user_id)){
            $error = ['title' => ParametersException::$title, 'info' => 'User login already exists'];
            throw new ParametersValidationException($error);
        }
        return false;
    }

    private static function isset_email(){
        if(UserEmail::isset_user_email_in_active_list(self::$user_email,User::$user_id)){
            $error = ['title' => ParametersException::$title, 'info' => 'User email already exists'];
            throw new ParametersValidationException($error);
        }
        return false;
    }

    private static function set_user_hash_invite(){
        $user_hash_invite_list = [
            User::$user_id,
            self::$user_login,
            self::$user_email,
            self::$user_name,
            self::$user_surname,
            time()
        ];
        self::$user_hash_invite = Hash::get_sha1_encode(implode(':', $user_hash_invite_list));
        return true;
    }

    private static function add_user(){
        self::$user_id = User::add_user();
        if(empty(self::$user_id)){
            $error = ['title' => PhpException::$title, 'info' => 'User was not add'];
            throw new PhpException($error);
        }
    }

    private static function add_user_email(){
        self::$user_email_id = UserEmail::add_user_email(self::$user_id, self::$user_email);
        if(empty(self::$user_email_id)){
            $error = ['title' => PhpException::$title, 'info' => 'User email was not add'];
            throw new PhpException($error);
        }
        return true;
    }

    private static function add_user_data(){
        self::$user_data_id = UserData::add_user_data(self::$user_id, self::$user_name, self::$user_surname,null);
        if(empty(self::$user_data_id)){
            $error = [
                'title' => PhpException::$title,
                'info' => 'User data was not add'
            ];
            throw new PhpException($error);
        }
        return true;
    }

    private static function add_user_login(){
        self::$user_login_id = UserLogin::add_user_login(self::$user_id, self::$user_login,null);
        if(empty(self::$user_login_id)){
            $error = [
                'title' => PhpException::$title,
                'info' => 'User login was not add'
            ];
            throw new PhpException($error);
        }
        return true;
    }

    private static function add_user_access(){
        self::$user_access_id = UserAccess::add_user_access(self::$user_id, [self::$user_access_type_name]);
        if(empty(self::$user_access_id)){
            $error = [
                'title' => PhpException::$title,
                'info' => 'User access was not add'
            ];
            throw new PhpException($error);
        }
        return true;
    }

    private static function add_user_hash_invite(){
        $user_hash_type_id = UserHashTypeConfig::get_user_hash_type_id('registration_invite');
        self::$user_hash_id = UserHash::add_user_hash(self::$user_id,$user_hash_type_id,null, self::$user_hash_invite);
        if(empty(self::$user_access_id)){
            $error = [
                'title' => PhpException::$title,
                'info' => 'User hash invite was not add'
            ];
            throw new PhpException($error);
        }
        return true;
    }

    private static function send_invite(){
        if(!self::$need_send_invite) return false;
        $inner = [];
        $link = UserHashLinkConfig::get_link_full('registration_invite').'/'.self::$user_hash_invite;
        if(OsServer::$is_windows) self::$link = $link;
        $inner[] = 'Здравствуйте!';
        $inner[] = '';
        $inner[] = 'Для подтверждения регистрации, пожалуйста, перейдите по ссылке: <a href = "'.$link.'">'.$link.'</a>';
        $inner[] = '';
        $inner[] = 'С уважением,';
        $inner[] = 'Команда <a href = "'.\Config::$http_type.'://'.Url::$host.'/">АИСТ-КОНТРОЛЬ</a>';
        return EmailSend::init(array(self::$user_email),'Регистрация '.\Config::$project_name,implode("<br />\n\r",$inner),\Config::$email_no_replay);
    }

    public static function init(
        string $user_login = null,
        string $user_email = null,
        string $user_name = null,
        string $user_surname = null,
        string $user_hash_type_name = null,
        string $user_access_type_name = null,
        bool $need_send_invite = true
    ){ #pred(func_get_args());
        $error_info_list = [];
        if(empty($user_login)) $error_info_list[] = 'User login is empty';
        if(empty($user_email)) $error_info_list[] = 'User email is empty';
        if(empty($user_name)) $error_info_list[] = 'User name is empty';
        if(empty($user_surname)) $error_info_list[] = 'User surname is empty';
        if(empty($user_access_type_name)) $error_info_list[] = 'User access type name is empty';
        if(empty($user_hash_type_name)) $error_info_list[] = 'User hash type name is empty';
        if(count($error_info_list) > 0){
            $error = ['title' => ParametersException::$title, 'info' => $error_info_list];
            throw new ParametersException($error);
        }

        self::$user_login = mb_strtolower(trim($user_login));
        self::$user_email = mb_strtolower(trim($user_email));
        self::$user_name = trim($user_name);
        self::$user_surname = trim($user_surname);
        self::$user_access_type_name = $user_access_type_name;
        self::$user_hash_type_name = $user_hash_type_name;
        self::$need_send_invite = $need_send_invite;

        if(self::is_valid_access() && self::is_valid_user_access_type() && self::is_valid_user_hash_type())
            if(!self::isset_login() && !self::isset_email()){
                self::add_user();
                self::add_user_access();
                self::add_user_login();
                self::add_user_email();
                self::add_user_data();
                self::set_user_hash_invite();
                self::add_user_hash_invite();
                self::send_invite();
                $data = [
                    'user_id' => self::$user_id,
                    'user_login_id' => self::$user_login_id,
                    'user_email_id' => self::$user_email_id,
                    'user_access_id' => self::$user_access_id,
                    'user_data_id' => self::$user_data_id,
                    'user_hash_id' => self::$user_hash_id,
                    'user_hash_invite' => self::$user_hash_invite
                ];
                if(!empty(self::$link)) $data['link'] = self::$link;
                return $data;
            }
    }
}