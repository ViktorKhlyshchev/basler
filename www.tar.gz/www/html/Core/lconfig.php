<?php

$lconfig = [
    #'upload_speed_quality_min_for_offences' => 21,
    #'upload_speed_quality_min_for_non_offences' => 1,
    #'upload_forbid_not_detected_number' => true,
    #'upload_forbid_lane_opposite' => true
    'upload_forbid_lane' => true
];

foreach($lconfig as $k => $v) self::${$k} = $v; #pred(self::$car_number_no_detect_ftp_send);

#if(\Config::$is_debug) error_reporting(E_ALL);
#if(\Config::$is_debug) error_reporting(E_ALL & ~E_WARNING);
#if(\Config::$is_debug) error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE);