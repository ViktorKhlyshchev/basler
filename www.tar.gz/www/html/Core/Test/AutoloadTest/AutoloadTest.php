<?php

namespace Core\Test\AutoloadTest;

class AutoloadTest{

    public static function init(){

        echo 'AutoloadTest';

    }

}