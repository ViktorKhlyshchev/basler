<?php

namespace Core\Test\Db;

use Core\Module\Db\DbValueType\TableLang;

class DbValueValidateTest{

    public static function init(){

//        TableLang::init();

        $object='Core\Module\Db\DbValueType\TableLang';

        $object::init();


    }

}