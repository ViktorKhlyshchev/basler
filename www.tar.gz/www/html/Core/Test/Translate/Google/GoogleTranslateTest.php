<?php

namespace Core\Test\Translate\Google;

use Core\Module\Translate\Google\GoogleTranslate;

class GoogleTranslateTest{

    public static function init(){

        echo GoogleTranslate::get('Привет друг!','en')."\n<br />";

    }

}
