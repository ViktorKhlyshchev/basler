<?php

namespace Core\Test\Browser;

use Core\Module\Browser\Browser;
use Core\Module\Device\Device;
use Core\Module\Os\Os;
use Core\Module\Useragent\Useragent;
use Core\Module\Worktime\Worktime;

class BrowserTest{
    
    private static $useragent_list = array('Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.1.4322; FDM)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; Avant Browser [avantbrowser.com]; Hotbar 4.4.5.0)',
        'Mozilla/4.61 [en] (X11; U; ) - BrowseX (2.0.0 Windows)',
        'Mozilla/3.0 (x86 [en] Windows NT 5.1; Sun)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; KKman2.0)',
        'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; SV1; .NET CLR 2.0.50727)',
        'Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 6.0)',
        'Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 6.0 ; .NET CLR 2.0.50215; SL Commerce Client v1.0; Tablet PC 2.0',
        'Mozilla/6.0 (compatible; MSIE 7.0a1; Windows NT 5.2; SV1)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; TheFreeDictionary.com; .NET CLR 1.1.4322; .NET CLR 1.0.3705; .NET CLR 2.0.50727)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; WOW64; SV1; .NET CLR 2.0.50727)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; Win64; x64; SV1; .NET CLR 2.0.50727)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; XMPP Tiscali Communicator v.10.0.2; .NET CLR 2.0.50727)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; T312461)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1) Netscape/8.0.4',
        'Mozilla/4.0 (compatible; MSIE 6.0; America Online Browser 1.1; rev1.2; Windows NT 5.1; SV1; .NET CLR 1.1.4322)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows 98; Win 9x 4.90; Creative)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; FunWebProducts; .NET CLR 1.1.4322; PeoplePal 6.2)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows XP)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; APC; .NET CLR 1.0.3705; .NET CLR 1.1.4322; .NET CLR 2.0.50215; InfoPath.1)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; Deepnet Explorer 1.5.0; .NET CLR 1.0.3705)',
        'Mozilla/4.0 (compatible- MSIE 6.0- Windows NT 5.1- SV1- .NET CLR 1.1.4322',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Media Center PC',
        'Mozilla/4.0 (compatible; MSIE 5.01; Windows 95; MSIECrawler)',
        'Mozilla/4.0 (compatible; MSIE 6.0; AOL 9.0; Windows NT 5.1)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.1.4322; Alexa Toolbar; (R1 1.5))',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; Maxthon; .NET CLR 1.1.4322)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; Win64; AMD64)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; Win64; AMD64)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Crazy Browser 2.0.0 Beta 1; .NET CLR 1.0.3705; .NET CLR 1.1.4322)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Update a; AOL 6.0; Windows 98)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; YPC 3.0.2; .NET CLR 1.1.4322; yplus 4.4.02b)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.0.3705; .NET CLR 1.1.4322; .NET CLR 2.0.40607)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322) Babya Discoverer 8.0:',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; Crazy Browser 1.0.5)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT) ::ELNSB50::000061100320025802a00111000000000507000 900000000',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; MyIE2; Deepnet Explorer)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; .NET CLR 1.0.3705; .NET CLR 1.1.4322)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; FREE; .NET CLR 1.1.4322)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.1.4322)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; Q312461)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows 98; Win 9x 4.90)',
        'Mozilla/4.0 (compatible; MSIE 5.5; Windows 98)',
        'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT 5.0; .NET CLR 1.1.4322)',
        'Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)',
        'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT 5.0; T312461)',
        'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT 4.0)',
        'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT 4.0; .NET CLR 1.0.2914)',
        'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT 5.0)',
        'Mozilla/4.0 (compatible; MSIE 5.5; Windows 95)',
        'Mozilla/4.0 (compatible; MSIE 5.5; Windows 95; BCD2000)',
        'Mozilla/4.0 (compatible; MSIE 4.01; Digital AlphaServer 1000A 4/233; Windows NT; Powered By 64-Bit Alpha Processor)',
        'Mozilla/2.0 (compatible; MSIE 3.02; Windows CE; 240x320)',
        'Mozilla/1.22 (compatible; MSIE 2.0; Windows 95)',
        'Mozilla/1.22 (compatible; MSIE 2.0d; Windows NT)',
        'Mozilla/4.0 (compatible; MSIE 5.0; Windows 3.1)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322) NS8/0.9.6',
        'Mozilla/4.79 [en] (Windows NT 5.0; U)',
        'Mozilla/4.76 [en] (Windows NT 5.0; U)',
        'Mozilla/0.91 Beta (Windows)',
        'Mozilla/0.6 Beta (Windows)',
        'Mozilla/4.7 (compatible; OffByOne; Windows 2000) Webster Pro V3.4',
        'Opera/9.00 (Windows NT 4.0; U; en)',
        'Opera/9.00 (Windows NT 5.1; U; en)',
        'Opera/9.0 (Windows NT 5.1; U; en)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; en) Opera 9.0',
        'Opera/8.01 (Windows NT 5.1)',
        'Mozilla/5.0 (Windows NT 5.1; U; en) Opera 8.01',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)',
        'Mozilla/5.0 (Windows NT 5.1; U; en) Opera 8.00',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; en) Opera 8.00',
        'Opera/8.00 (Windows NT 5.1; U; en)',
        'Opera/7.60 (Windows NT 5.2; U) [en] (IBM EVV/3.0/EAK01AG9/LE)',
        'Opera/7.54 (Windows NT 5.1; U) [pl]',
        'Opera/7.11 (Windows NT 5.1; U) [en]',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows ME) Opera 7.11 [en]',
        'Mozilla/4.0 (compatible; MSIE 6.0; MSIE 5.5; Windows NT 5.0) Opera 7.02 Bork-edition [en]',
        'Mozilla/4.0 (compatible; MSIE 6.0; MSIE 5.5; Windows NT 4.0) Opera 7.0 [en]',
        'Mozilla/4.0 (compatible; MSIE 5.0; Windows 2000) Opera 6.0 [en]',
        'Mozilla/4.0 (compatible; MSIE 5.0; Windows 95) Opera 6.01 [en]',
        'Mozilla/3.0 (compatible; WebCapture 2.0; Auto; Windows)',
        'Mozilla/4.0 (compatible; Powermarks/3.5; Windows 95/98/2000/NT)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; FREE; .NET CLR 1.1.4322)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; KTXN)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; .NET CLR 1.0.3705; .NET CLR 1.1.4322)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; ru) Opera 8.50',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; FunWebProducts)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; MRA 4.3 (build 01218); .NET CLR 1.1.4322)',
        'Opera/9.01 (Windows NT 5.1; U; en)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1) Opera 7.54 [en]',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; InfoPath.1)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; MRA 4.6 (build 01425))',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; ru) Opera 8.01',
        'Opera/9.00 (Windows NT 5.1; U; ru)',
        'Opera/9.0 (Windows NT 5.1; U; en)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; FunWebProducts; MRA 4.6 (build 01425); .NET CLR 1.1.4322; .NET CLR 2.0.50727)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; ru) Opera 8.01',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; InfoPath.1',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; MRA 4.6 (build 01425); MRSPUTNIK 1, 5, 0, 19 SW)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)',
        'Mozilla/4.0 (compatible; MSIE 6.0; AOL 9.0; Windows NT 5.1)'
    );
    
    public static function init(){

        Worktime::set_timestamp_point('Browser Test Start');

        foreach(self::$useragent_list as $useragent){

            $_SERVER['HTTP_USER_AGENT'] = $useragent;

            Useragent::reset();
            Browser::reset();
            Os::reset();
            Device::reset();

            Useragent::init();
            Browser::init();
            Os::init();
            Device::init();

//            echo 'browser name: '.Browser::$browser_name."\n";
//            echo 'browser version: '.Browser::$browser_version."\n";
//            echo 'os name: '.Os::$os_name."\n";
//            echo 'device firm: '.Device::$firm_name."\n";
//            echo 'device model: '.Device::$model_name."\n";
//            echo"\n";

        }

        Worktime::set_timestamp_point('Browser Test Finish');

    }
    
}